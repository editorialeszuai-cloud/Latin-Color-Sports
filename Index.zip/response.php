<?php
session_start(); // Asegúrate de que la sesión esté iniciada
require_once 'dbfotografos.php';
$pdo = conectar();

$ref_local = $_GET['reference'] ?? '';

// 1. Verificar firma para evitar inyecciones (Seguridad)
// ... [Tu lógica de validación de firma aquí] ...

// 2. Si el pago es válido, actualiza el estado en BD
if ($ref_local) {
    $stmt = $pdo->prepare("UPDATE compras SET estado = 'Pagado' WHERE referencia = ?");
    $stmt->execute([$ref_local]);
}

// 3. Recuperamos la compra para saber el estado real y si es invitado o tiene cuenta
$compra = null;
if ($ref_local) {
    $stmt = $pdo->prepare("SELECT * FROM compras WHERE referencia = ? LIMIT 1");
    $stmt->execute([$ref_local]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);
}

$aprobado = $compra && $compra['estado'] === 'Pagado';

// Ajusta este criterio según tu esquema real (por ejemplo usuario_id NULL = invitado)
$esInvitado = $compra && empty($compra['usuario_id']);
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <title>Estado de tu compra - Latin Color Sports</title>
    <style>
        .btn-premium:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 20px rgba(37, 211, 102, 0.4) !important;
        }
    </style>
</head>
<body style="background: #050505; color: #fff; text-align: center; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; padding: 0; margin: 0; -webkit-font-smoothing: antialiased;">

    <!-- Navbar Naranja Limpio (Solo Logos) basado en image_fa2743.png -->
    <div style="background: linear-gradient(90deg, #ffffff 0%, #ffbd00 15%, #ff6200 40%, #fd3a13 100%); padding: 10px 20px; display: flex; align-items: center; justify-content: flex-start; min-height: 80px; box-shadow: 0 4px 25px rgba(0,0,0,0.5); margin-bottom: 50px;">
        <div style="display: flex; align-items: center; gap: 20px; background: white; padding: 8px 24px; border-radius: 0 50px 50px 0; margin-left: -20px; box-shadow: 5px 0 20px rgba(0,0,0,0.15);">
            <!-- Logo Latincolor Group -->
            <img src="https://www.latincolorsports.com/imagenes/LATINCOLOR.png" alt="Latincolor Group" style="height: 55px; width: auto; object-fit: contain;">
            <!-- Logo Latin Color Sports -->
            <img src="https://www.latincolorsports.com/uploads/LATIN-SPORTS.png" alt="Latin Color Sports" style="height: 55px; width: auto; object-fit: contain;">
        </div>
    </div>

    <!-- Estados del Pago -->
    <div style="padding: 0 20px; margin-bottom: 35px;">
        <?php if ($aprobado): ?>
            <div style="display: inline-flex; align-items: center; justify-content: center; background: rgba(74, 222, 128, 0.1); border: 1px solid rgba(74, 222, 128, 0.2); padding: 6px 16px; border-radius: 30px; margin-bottom: 16px;">
                <span style="color: #4ADE80; font-size: 14px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;">Transacción Exitosa</span>
            </div>
            <h2 style="color: #ffffff; font-size: 28px; font-weight: 700; margin: 0 0 12px 0; letter-spacing: -0.5px;">¡Tu pago fue aprobado!</h2>
            <p style="color: #a3a3a3; max-width: 440px; margin: 0 auto; font-size: 15px; line-height: 1.6;">
                Hemos confirmado tu compra correctamente. Tu material fotográfico de alta calidad está listo.
            </p>
        <?php else: ?>
            <div style="display: inline-flex; align-items: center; justify-content: center; background: rgba(248, 113, 113, 0.1); border: 1px solid rgba(248, 113, 113, 0.2); padding: 6px 16px; border-radius: 30px; margin-bottom: 16px;">
                <span style="color: #F87171; font-size: 14px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase;">Procesando</span>
            </div>
            <h2 style="color: #ffffff; font-size: 28px; font-weight: 700; margin: 0 0 12px 0; letter-spacing: -0.5px;">Estamos confirmando tu pago</h2>
            <p style="color: #a3a3a3; max-width: 440px; margin: 0 auto; font-size: 15px; line-height: 1.6;">
                Esto puede tardar unos minutos en actualizarse de forma segura. Si el problema persiste, nuestro equipo de soporte está listo para ayudarte.
            </p>
        <?php endif; ?>
    </div>

    <!-- Contenedor de Bloques de Acción -->
    <div style="display: flex; flex-direction: column; gap: 20px; max-width: 440px; margin: 0 auto; padding: 0 20px 40px 20px;">

        <!-- Flujo para Invitados -->
        <?php if ($aprobado && $esInvitado): ?>
            <div style="border: 1px solid rgba(255, 255, 255, 0.05); border-radius: 16px; padding: 24px; background: linear-gradient(135deg, #111111 0%, #161616 100%); box-shadow: 0 10px 30px rgba(0,0,0,0.4); text-align: left;">
                <p style="margin: 0; color: #e5e5e5; font-size: 15px; line-height: 1.6;">
                    🚀 <strong style="color: #fff;">¡Tu pedido está en camino!</strong> Muchas gracias por tu confianza. En unos minutos recibirás un enlace de acceso directo para descargar tus fotos en tu correo electrónico.
                </p>
            </div>
        <?php endif; ?>

        <!-- Sección de Cuenta / Descargas (Estilo Premium Glassmorphic) -->
        <div style="background: linear-gradient(135deg, rgba(255, 255, 255, 0.04) 0%, rgba(255, 255, 255, 0.01) 100%); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(255, 255, 255, 0.08); padding: 32px 24px; border-radius: 20px; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.6);">
            
            <p style="margin: 0 0 10px 0; font-size: 18px; font-weight: 600; color: #ffffff; letter-spacing: -0.3px;">
                ¿Ya tienes una cuenta con nosotros?
            </p>
            
            <p style="margin: 0 0 24px 0; font-size: 14px; color: #a3a3a3; line-height: 1.6; max-width: 340px; margin-left: auto; margin-right: auto;">
                Accede instantáneamente para organizar, ver y descargar todo tu historial fotográfico en máxima resolución.
            </p>
            
            <!-- Botón Premium Reactivo -->
            <a href="https://latincolorsports.com/miscomprasfotos.php" class="btn-premium"
               style="display: inline-flex; align-items: center; justify-content: center; gap: 10px; text-decoration: none; padding: 14px 32px; border-radius: 14px; background: linear-gradient(135deg, #25D366 0%, #1ea951 100%); color: #000; font-weight: 700; font-size: 15px; letter-spacing: -0.1px; box-shadow: 0 4px 15px rgba(37, 211, 102, 0.25); transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);">
               
               <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
               
               Ir a mis descargas
            </a>
            
        </div>

    </div>

</body>
</html>