<?php
require 'dbfotografos.php';
$pdo = conectar();

$compra_id = $_GET['compra_id'] ?? '';
if (!$compra_id) {
    die('<p style="color:red; text-align:center; padding:20px;">Error: ID de compra no especificado.</p>');
}

try {
    $stmt = $pdo->prepare("SELECT *, firebase_uid as uid_propietario FROM compras WHERE id = ?");
    $stmt->execute([$compra_id]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$compra) die('Error: Orden no encontrada.');

    $stmt = $pdo->prepare("
        SELECT d.precio, d.id_foto, d.evento_id AS detalle_evento_id, 
               f.url AS foto_url, e.titulo AS evento_titulo, l.pais
        FROM detalle_compras d
        LEFT JOIN fotos f ON d.id_foto = f.id
        LEFT JOIN postulaciones p ON f.postulacion_id = p.id
        LEFT JOIN eventos e ON (d.evento_id = e.id OR p.evento_id = e.id)
        LEFT JOIN lugares l ON e.lugar_id = l.id
        WHERE d.id_compra = ?
    ");
    $stmt->execute([$compra_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // L�gica de pa�s
    $pais_evento = 'Desconocido';
    foreach ($items as $item) {
        if (!empty($item['detalle_evento_id'])) {
            $stmtLugar = $pdo->prepare("SELECT l.pais FROM eventos e JOIN lugares l ON e.lugar_id = l.id WHERE e.id = ?");
            $stmtLugar->execute([$item['detalle_evento_id']]);
            if ($res = $stmtLugar->fetch()) { $pais_evento = $res['pais']; break; }
        }
    }
    
    $es_colombia = (strcasecmp(trim((string)$pais_evento), 'Colombia') === 0);
    $total_precio = (float)$compra['total'];
    $transaccion_id = $compra['referencia'];
    
    $public_key = "pub_prod_qDvUDoTJtgy1bVkcuQJ7rcgkOM4oxbLw";
    $secret_integrity = "prod_integrity_BWG58peE6yhM382mYETKtAjra3xNEARl"; 
	  // C�lculo correcto para USD (centavos)
	  
    $amount_in_cents = intval(round($total_precio * 100 * 3500));
	$amount_in_cents2 = intval(round($total_precio * 100 * 17,60));
    $currency = "COP";

    // Firma
    $cadena_firma = $transaccion_id . $amount_in_cents . $currency . $secret_integrity;
    $firma = hash("sha256", $cadena_firma);

} catch (PDOException $e) {
    die("Error de base de datos: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout | Latin Color Sports</title>
		<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background: #050505; color: #eee; font-family: sans-serif; }
        .glass { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(10px); }
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
    </style>
</head>
<body class="bg-[#050505] text-white min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-[#0f0f0f] border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
        <div class="p-6 border-b border-white/5 bg-black/40 text-center">
            <h1 class="text-xl font-black italic uppercase tracking-tighter">Latin Color <span class="text-orange-500">Sports</span></h1>
        </div>
        
        <div id="user_status" class="text-[10px] text-gray-500 font-bold uppercase tracking-widest text-center mt-2">Cargando sesi�n...</div>

        <div class="p-6">
            <div class="space-y-3 max-h-48 overflow-y-auto custom-scroll pr-2 mb-6">
                <?php foreach($items as $item): ?>
                    <div class="flex items-center gap-3 bg-white/5 p-2 rounded-xl border border-white/5">
                        <img src="<?= htmlspecialchars($item['foto_url'] ?? 'idevento.jpg') ?>" class="w-10 h-10 object-cover rounded-lg" onerror="this.src='/uploads/idevento.jpg'">
                        <div class="flex-1 min-w-0">
                            <p class="text-[9px] text-gray-500 truncate uppercase font-bold"><?= htmlspecialchars($item['evento_titulo'] ?? 'Evento') ?></p>
                            <p class="text-[11px]"><?= $item['id_foto'] ? "Foto #".$item['id_foto'] : "Pack Completo" ?></p>
                        </div>
                        <p class="text-xs font-bold">$<?= number_format((float)$item['precio'], $es_colombia ? 0 : 2, ',', '.') ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

           <div class="text-center mb-6 max-w-xs mx-auto p-5 bg-gray-900/40 border border-gray-800/80 rounded-2xl backdrop-blur-sm shadow-xl">
    <p class="text-[10px] tracking-widest text-gray-500 uppercase font-black mb-3 dynamic-fade">Total a pagar</p>
    
    <div class="flex flex-col gap-2.5">
        
        <div class="flex items-center justify-between bg-gradient-to-r from-gray-950/60 to-gray-950/20 px-3 py-2 rounded-xl border border-gray-800/60 transition-all duration-300 hover:border-indigo-500/30 animate-fade-in">
            <span class="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Monto Base</span>
            <div class="flex items-baseline gap-1">
                <span class="text-xs text-gray-500 font-medium">$</span>
                <span class="text-xl font-black text-white tracking-tight"><?= number_format($total_precio, $es_colombia ? 0 : 2, ',', '.') ?></span>
                <span class="text-[10px] text-indigo-400 font-bold uppercase ml-1"><?= $es_colombia ? 'COP' : 'USD' ?></span>
            </div>
        </div>

        <?php if (isset($amount_in_cents) && $amount_in_cents > 0): ?>
            <div class="flex items-center justify-between bg-gradient-to-r from-gray-950/60 to-gray-950/20 px-3 py-2 rounded-xl border border-gray-800/60 transition-all duration-300 hover:border-emerald-500/30 dynamic-delay-1 animate-fade-in">
                <span class="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Pasarela</span>
                <div class="flex items-baseline gap-1">
                    <span class="text-xs text-gray-500 font-medium">$</span>
                    <span class="text-xl font-black text-white tracking-tight"><?= number_format($amount_in_cents / 100, 2, ',', '.') ?></span>
                    <span class="text-[10px] text-emerald-400 font-bold uppercase ml-1"><?= $currency ?></span>
                </div>
            </div>
        <?php endif; ?>

        <?php if (isset($amount_in_cents2) && $amount_in_cents2 > 0): ?>
            <div class="flex items-center justify-between bg-gradient-to-r from-gray-950/60 to-gray-950/20 px-3 py-2 rounded-xl border border-gray-800/60 transition-all duration-300 hover:border-amber-500/30 dynamic-delay-2 animate-fade-in">
                <span class="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Monto MXN</span>
                <div class="flex items-baseline gap-1">
                    <span class="text-xs text-gray-500 font-medium">$</span>
                    <span class="text-xl font-black text-white tracking-tight"><?= number_format($amount_in_cents2 / 100, 2, ',', '.') ?></span>
                    <span class="text-[10px] text-amber-400 font-bold uppercase ml-1">MXN</span>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>

<style>
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(6px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
.animate-fade-in {
    animation: fadeInUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
.dynamic-fade { animation: fadeInUp 0.3s ease forwards; }
.dynamic-delay-1 { animation-delay: 0.1s; opacity: 0; }
.dynamic-delay-2 { animation-delay: 0.2s; opacity: 0; }
</style>

            <?php require 'medios.php'; ?>
			
       <div class="wompi-container flex justify-center py-2 scale-110">
                <form>
                    <script
                        src="https://checkout.wompi.co/widget.js"
                        data-render="button"
                        data-public-key="<?= $public_key ?>"
                        data-currency="COP"
                        data-amount-in-cents="<?= $amount_in_cents ?>"
                        data-reference="<?= $transaccion_id ?>"
                        data-redirect-url="https://latincolorsports.com/response.php"
                        data-signature:integrity="<?= $firma ?>">
                    </script>
                </form>
            </div>
        </div>
		

        <div class="p-4 bg-black/40 border-t border-white/5 text-center">
            <button onclick="window.history.back()" class="text-[10px] font-bold text-gray-500 hover:text-white transition uppercase tracking-widest flex items-center justify-center gap-2 w-full">
                Cancelar y volver
            </button>
        </div>
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
        import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";
        const auth = getAuth(initializeApp({
            apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
            projectId: "latin-group-406b1",
            authDomain: "latin-group-406b1.firebaseapp.com",
            storageBucket: "latin-group-406b1.firebasestorage.app",
            messagingSenderId: "21494348297",
            appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
        }));

        onAuthStateChanged(auth, (user) => {
            if (user && user.uid === "<?= $compra['uid_propietario'] ?>") {
                document.getElementById('user_status').innerText = "CUENTA: " + user.email;
            } else {
                window.location.href = "login_app.html";
            }
        });
    </script>
</body>
</html>