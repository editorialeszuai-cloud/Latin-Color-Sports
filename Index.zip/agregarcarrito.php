<?php
require 'dbfotografos.php';
header('Content-Type: application/json; charset=utf-8');

$firebase_uid = $_GET['firebase_uid'] ?? '';
$foto_id = isset($_GET['foto_id']) ? (int)$_GET['foto_id'] : 0;

if(empty($firebase_uid) || $foto_id <= 0){
    echo json_encode(['status'=>'error','msg'=>'Datos insuficientes']);
    exit;
}

try {
    // 1. Obtener datos del evento usando la jerarquía: Fotos -> Galerias -> Postulaciones -> Eventos
    $sqlEvento = "SELECT e.paquetes_eventos, e.id AS evento_id 
                  FROM fotos f
                  INNER JOIN galerias g ON f.galeria_id = g.id
                  INNER JOIN postulaciones p ON g.postulacion_id = p.id
                  INNER JOIN eventos e ON p.evento_id = e.id
                  WHERE f.id = ? LIMIT 1";
    
    $stmtEv = $pdo->prepare($sqlEvento);
    $stmtEv->execute([$foto_id]);
    $eventoData = $stmtEv->fetch(PDO::FETCH_ASSOC);

    $evento_id = $eventoData['evento_id'] ?? 0;
    $paquetes_ids = !empty($eventoData['paquetes_eventos']) ? json_decode($eventoData['paquetes_eventos'], true) : [];

    // 2. INSERTAR LA FOTO
    $stmtCheck = $pdo->prepare("SELECT id FROM carrito WHERE firebase_uid = ? AND foto_id = ?");
    $stmtCheck->execute([$firebase_uid, $foto_id]);
    
    if (!$stmtCheck->fetch()) {
        $pdo->prepare("INSERT INTO carrito (firebase_uid, foto_id, precio, fecha_agregado) VALUES (?, ?, 0, NOW())")
            ->execute([$firebase_uid, $foto_id]);
    }

    // 3. CONTAR FOTOS DEL MISMO EVENTO (Usando la misma jerarquía)
    $sqlCount = "SELECT COUNT(c.id) as total 
                 FROM carrito c
                 INNER JOIN fotos f ON c.foto_id = f.id
                 INNER JOIN galerias g ON f.galeria_id = g.id
                 INNER JOIN postulaciones p ON g.postulacion_id = p.id
                 WHERE c.firebase_uid = ? AND p.evento_id = ?";
    $stmtCount = $pdo->prepare($sqlCount);
    $stmtCount->execute([$firebase_uid, $evento_id]);
    $fotos_en_carrito = (int)$stmtCount->fetch(PDO::FETCH_ASSOC)['total'];

    // 4. CALCULAR PRECIO SEGÚN TABLA paquetes_fotos
    $precio_unidad = 0; 
    
    if (!empty($paquetes_ids)) {
        $in = str_repeat('?,', count($paquetes_ids) - 1) . '?';
        $stmtPk = $pdo->prepare("SELECT id, precio_por_unidad, unidades_incluidas FROM paquetes_fotos WHERE id IN ($in) ORDER BY unidades_incluidas DESC");
        $stmtPk->execute($paquetes_ids);
        $paquetes_info = $stmtPk->fetchAll(PDO::FETCH_ASSOC);

        // Buscar el mejor precio aplicado por volumen
        foreach ($paquetes_info as $pkg) {
            if ($fotos_en_carrito >= (int)$pkg['unidades_incluidas']) {
                $precio_unidad = (float)$pkg['precio_por_unidad'];
                break; // Encontramos el mejor paquete aplicable
            }
        }
    }

    // 5. ACTUALIZACIÓN RETROACTIVA: Aplicar precio a todas las fotos del mismo evento en el carrito
    $sqlUpdate = "UPDATE carrito c
                  INNER JOIN fotos f ON c.foto_id = f.id
                  INNER JOIN galerias g ON f.galeria_id = g.id
                  INNER JOIN postulaciones p ON g.postulacion_id = p.id
                  SET c.precio = ?
                  WHERE c.firebase_uid = ? AND p.evento_id = ?";
    $pdo->prepare($sqlUpdate)->execute([$precio_unidad, $firebase_uid, $evento_id]);

    echo json_encode([
        'status' => 'ok',
        'precio_unidad' => $precio_unidad,
        'cantidad' => $fotos_en_carrito
    ]);

} catch (PDOException $e) {
    echo json_encode(['status'=>'error', 'msg' => 'Error de sistema: ' . $e->getMessage()]);
}