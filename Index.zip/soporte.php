<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<title>Administrador Latin Colors Sports</title>
<style>
/* 1. VARIABLES Y CONFIGURACIÓN BASE */
:root {
  --bg: #0f1724;
  --panel: #0b1220;
  --accent: #4f46e5;
  --orange-primary: #f97316;
  --text: #e6eef8;
  --muted: #99a3b2;
  --width: 260px; 
  --topbar-height: 60px;
}

* { box-sizing: border-box; }

body {
  margin: 0;
  font-family: 'Inter', sans-serif;
  color: #1e293b;
  background: #f6f8fb;
  min-height: 100vh;
}

.app { display: flex; min-height: 100vh; }

/* SIDEBAR ESTILO ORIGINAL */
.sidebar {
  width: var(--width);
  background: linear-gradient(180deg, var(--bg), var(--panel));
  padding: 1rem 0;
  display: flex;
  flex-direction: column;
  position: fixed;
  left: 0; top: 0; bottom: 0;
  z-index: 40;
  transition: transform .25s ease;
  overflow-y: auto;
}

.main-area {
  flex: 1;
  margin-left: var(--width);
  display: flex;
  flex-direction: column;
  min-width: 0;
}

.topbar {
  height: var(--topbar-height);
  background: #fff;
  border-bottom: 1px solid #e6eef8;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 1.5rem;
  position: sticky;
  top: 0;
  z-index: 20;
}

.brand { display: flex; align-items: center; gap: .75rem; padding: 1rem; text-decoration: none; border-bottom: 1px solid rgba(255,255,255,0.05); }
.brand .logo { width: 45px; height: 45px; border-radius: 8px; background: white; display: flex; align-items: center; justify-content: center; overflow: hidden; }

nav { flex: 1; padding: 1rem 0.5rem; }
.nav-item { display: flex; align-items: center; gap: 0.75rem; padding: 0.7rem 1rem; border-radius: 10px; color: var(--text); text-decoration: none; margin-bottom: 0.25rem; transition: 0.2s; font-size: 14px; }
.nav-item:hover { background: rgba(255,255,255,0.05); color: white; }

.has-submenu .submenu-items { max-height: 0; overflow: hidden; transition: 0.3s; padding-left: 1.5rem; background: rgba(0,0,0,0.1); }
.has-submenu.open .submenu-items { max-height: 500px; padding: 0.5rem 0 0.5rem 1.5rem; }

.sub-nav-item { display: block; padding: 0.5rem 1rem; font-size: 13px; color: var(--muted); text-decoration: none; border-radius: 8px; }
.sub-nav-item:hover { color: white; }

/* BOTONES DE CAMBIO DE ROL */
.btn-tool {
    padding: 15px; background: #f8fafc; border-radius: 12px; text-decoration: none; color: #1e293b;
    font-weight: bold; border: 1px solid #e2e8f0; text-align: center; transition: 0.2s; display: block;
}
.btn-tool:hover { background: #f1f5f9; border-color: var(--orange-primary); color: var(--orange-primary); }

.role-switcher {
    display: flex; gap: 10px; margin-bottom: 20px;
}
.btn-sw { flex: 1; padding: 12px; border: none; border-radius: 10px; color: white; font-weight: bold; cursor: pointer; }

@media(max-width: 767px) {
  .sidebar { transform: translateX(-110%); }
  .sidebar.open { transform: translateX(0); }
  .main-area { margin-left: 0; }
}
</style>
</head>
<body>

<div class="app">
    <!-- SIDEBAR ORIGINAL UNIFICADO -->
    <aside class="sidebar closed" id="sidebar">
        <a href="soporte.php" class="brand">
            <div class="logo"><img src="uploads/LATIN-SPORTS.png" width="40"></div>
            <div><h1 style="color:white; font-size:14px; margin:0;">Mi Dashboard</h1><div style="font-size:10px; color:gray">Panel de administración</div></div>
        </a>

        <nav role="navigation">
            <!-- Usuarios -->
            <div class="nav-item has-submenu">
                <div style="display:flex; align-items:center; gap:10px; width:100%;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="7" r="4"/><path d="M5.5 21a6.5 6.5 0 0 1 13 0"/></svg>
                    Usuarios
                </div>
                <div class="submenu-items">
                    <a href="usuarios.php" class="sub-nav-item">Todos</a>
					 <a href="clientes.php" class="sub-nav-item">Clientes</a>
                    <div class="nav-item has-submenu">
                        <div style="font-size:13px; color:var(--muted)">Fotógrafos ▾</div>
                        <div class="submenu-items">
                            <a href="fotografos.php" class="sub-nav-item">Editar Fotografos</a>
                            <a href="postulaciones.php" class="sub-nav-item">Postulaciones</a>
                        </div>
                    </div>
                    <a href="comerciales.php" class="sub-nav-item">Comerciales</a>
                    <a href="organizadores.php" class="sub-nav-item">Organizadores</a>
                </div>
            </div>

            <!-- Lugares, Sedes, Escenarios -->
            <a href="lugar.php" class="nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2C8 2 5 5 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-4-3-7-7-7z"/><circle cx="12" cy="9" r="2"/></svg>
                Lugares
            </a>
            <a href="sedes.php" class="nav-item">Sedes</a>
            <a href="escenarios.php" class="nav-item">Escenarios</a>
            <a href="disciplina.php" class="nav-item">Disciplinas</a>
            <a href="eventos.php" class="nav-item">Eventos</a>
			<a href="cambiodeestado.php" class="nav-item">Cambiar Estado</a>
			<a href="ventassoporte.php" class="nav-item">ventas</a>
            <!-- Postulaciones y Gestión -->
            <div class="nav-item has-submenu">
                <div style="display:flex; align-items:center; gap:10px; width:100%;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                    Gestión
                </div>
                <div class="submenu-items">
                    <a href="calendariomega.php" class="sub-nav-item">Crear Calendario</a>
                    <a href="postulaciones.php" class="sub-nav-item">Aceptar Postulaciones</a>
                    <a href="ver_calendario.php" class="sub-nav-item">Asignar Calendario</a>
					<a href="asignaciones.php" class="sub-nav-item">Fotografos Asignados</a>
                    <a href="ventas.php" class="sub-nav-item">Ventas</a>
                </div>
            </div>

            <a href="paquete.php" class="nav-item">Paquetes</a>
            <a href="comision.php" class="nav-item">Comisiones</a>
            <a href="retirocomisiones.php" class="nav-item">Retiros</a>
            <a href="analitica.php" class="nav-item">Analíticas <span style="background:var(--orange-primary); font-size:9px; padding:2px 5px; border-radius:4px; margin-left:5px;">PRO</span></a>
        </nav>

        <div style="padding:1rem; border-top:1px solid rgba(255,255,255,0.05)">
            <button id="logoutButton" style="width:100%; padding:10px; background:#ef4444; color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer;">Cerrar Sesión</button>
        </div>
    </aside>

    <div id="overlay" class="app-overlay"></div>

    <!-- ÁREA PRINCIPAL -->
    <div class="main-area">
        <header class="topbar">
            <div style="display:flex; align-items:center; gap:15px;">
                <button class="hamburger" id="openBtn" style="background:#0f172a; color:white; border:none; padding:8px; border-radius:5px; cursor:pointer;">☰</button>
                <div style="font-weight:bold; color:#0f172a;">Dashboard Maestro</div>
            </div>
            
            <div style="background:#f97316; padding:5px 15px; border-radius:12px; display:flex; align-items:center; gap:12px; color:white;">
                <img id="userFotoPerfil" src="uploads/perfil.jpg" style="width:32px; height:32px; border-radius:50%; object-fit:cover; border:2px solid white;">
                <div style="font-size:11px;">
                    <div><strong>Nombre:</strong> <span id="userName">Cargando...</span></div>
                    <div><strong>Rol:</strong> <span id="userRole">...</span></div>
                </div>
            </div>
        </header>

        <div class="content">
            <div style="background:#fff; padding:2rem; border-radius:15px; box-shadow:0 2px 10px rgba(0,0,0,0.05); text-align:center;">
                <h1 style="color:black; margin-bottom:1.5rem;">Latin Color Sports</h1>
                
                <a href="eventos.php" style="display:inline-block; padding:0.8rem 2rem; background:var(--orange-primary); color:white; font-weight:600; border-radius:8px; text-decoration:none; margin-bottom:2rem; box-shadow:0 4px 10px rgba(249,115,22,0.3)">
                    🔥 Ver Próximos Eventos
                </a>

                <!-- PANEL DINÁMICO DE SOPORTE/ADMIN -->
                <div id="roleContent"></div>
            </div>
        </div>
    </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// Función para ejecutar el cambio de rol
async function ejecutarCambioRol(nuevoRol, uid) {
    try {
        const res = await fetch('cambiar_rol.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ nuevo_rol: nuevoRol, uid: uid })
        });
        const data = await res.json();
        
        if(data.status === 'success') {
            alert(`Rol actualizado a: ${nuevoRol.toUpperCase()}`);
            window.location.reload();
        } else {
            alert("Error del servidor: " + (data.message || "No se pudo cambiar el rol"));
        }
    } catch (e) {
        console.error("Error en petición:", e);
        alert("Error de conexión con el servidor.");
    }
}







onAuthStateChanged(auth, async (user) => {
    if (user) {
        try {
            const token = await user.getIdToken();
            const res = await fetch('get_user_info.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ firebase_token: token })
            });
            
            // Verificamos si hubo error en el servidor
            if (!res.ok) {
                const text = await res.text();
                console.error("Error del servidor (PHP):", text);
                throw new Error("Error en servidor: " + text);
            }

            const data = await res.json();
            
            if (data.status === 'success') {
                const u = data.user;


                const r = (u.rol || "").toLowerCase();
                
                // Actualizar UI básica
                if(document.getElementById('userName')) document.getElementById('userName').textContent = u.nombre || "Usuario";
                if(document.getElementById('userRole')) document.getElementById('userRole').textContent = u.rol || "Sin rol";
                if(u.foto_perfil && document.getElementById('userFotoPerfil')) document.getElementById('userFotoPerfil').src = u.foto_perfil;

                // Lógica de inyección de panel
                const container = document.getElementById('roleContent');
                if (container) {
                    // SI ES ADMIN
                    if (r === 'admin') {
                        container.innerHTML = `
                            <div style="border-top: 1px solid #eee; padding-top: 20px; max-width: 600px; margin: 0 auto;">
                                <h3 style="margin-bottom:15px;">Control de Sesión Maestra</h3>
                                <div class="role-switcher" style="display: flex; gap: 10px; margin-bottom: 20px;">
                                    <button id="btnAdmin" class="btn-sw" style="background:#4f46e5; color:white; border:none; padding:10px; cursor:pointer;">MODO ADMIN</button>
                                    <button id="btnSoporte" class="btn-sw" style="background:#10b981; color:white; border:none; padding:10px; cursor:pointer;">MODO SOPORTE</button>
                                </div>
                            </div>
                        `;
                        document.getElementById('btnAdmin').addEventListener('click', () => ejecutarCambioRol('admin', u.firebase_uid));
                        document.getElementById('btnSoporte').addEventListener('click', () => ejecutarCambioRol('soporte', u.firebase_uid));
                    } 
                    // SI ES SOPORTE
                    else if (r === 'soporte') {
                        container.innerHTML = `
                            <div style="border-top: 1px solid #eee; padding-top: 20px; max-width: 600px; margin: 0 auto;">
                                <a href="revisar_postulaciones.php" style="display:block; padding:15px; background:#ecfdf5; border-radius:8px; text-decoration:none; color:#065f46; font-weight:bold; border:1px solid #10b981; text-align:center; margin-bottom:10px;">
                                    Ir a Análisis
                                </a>
                                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                                    <button id="btnAdminSoporte" class="btn-sw" style="background:#4f46e5; color:white; border:none; padding:10px; cursor:pointer;">MODO ADMIN</button>
                                    <a href="logs_sistema.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Logs</a>
                                    <a href="nav_comercial.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Comercial</a>
                                    <a href="nav_fotografo.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Fotógrafo</a>
									<a href="nav_organizador.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Organizador</a>
                                    <a href="eventosadmin.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Gestionar Fotos</a>
									<a href="fotos_ocultas.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Fotos Ocultas</a>
                                    <a href="procesar_todo.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Procesar Todo</a>
									  <a href="auditoria.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Auditoria</a>
  <a href="analisis.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">AI Gestion</a>
                                                                    
                                                              
							   </div>
                            </div>
                        `;
                        document.getElementById('btnAdminSoporte').addEventListener('click', () => ejecutarCambioRol('admin', u.firebase_uid));
                    }
                }
            } else {
                console.warn("Datos de usuario no encontrados:", data);
            }
        } catch (error) {
            console.error("Error al obtener info del usuario:", error);
        }
    } else {
        window.location.href = 'login_app.html';
    }
});


// Logout
const logoutBtn = document.getElementById('logoutButton');
if(logoutBtn) {
    logoutBtn.onclick = () => signOut(auth);
}
</script>


<script>
// Manejo de Menús desplegables
document.addEventListener('click', (e) => {
    const item = e.target.closest('.has-submenu');
    if (item) {
        // Evita que el clic en un sub-item cierre el menú padre
        if(e.target.classList.contains('sub-nav-item')) return;
        item.classList.toggle('open');
    }
});

const openBtn = document.getElementById('openBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

openBtn.onclick = () => {
    sidebar.classList.toggle('open');
    sidebar.classList.toggle('closed');
    overlay.classList.toggle('visible');
};

overlay.onclick = () => {
    sidebar.classList.add('closed');
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
};
</script>
</body>
</html>