<?php
// editar_perfil.php
ini_set('display_errors', 0); // Desactivar en producción para evitar corromper respuestas JSON
error_reporting(E_ALL);
require 'dbfotografos.php'; // Conexión PDO

// --- Procesamiento POST (API Fetch) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $firebase_uid = $_POST['firebase_uid'] ?? null;
    if (!$firebase_uid) {
        echo json_encode(['success' => false, 'message' => 'Firebase UID faltante o sesión expirada.']);
        exit;
    }

    try {
        // Buscar usuario por firebase_uid
        $stmt = $pdo->prepare("SELECT id, nombre, foto_perfil FROM usuarios WHERE firebase_uid = ? LIMIT 1");
        $stmt->execute([$firebase_uid]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$usuario) {
            echo json_encode(['success' => false, 'message' => 'Usuario no encontrado en el sistema.']);
            exit;
        }

        $nuevo_nombre = trim($_POST['nombre'] ?? '');
        if (empty($nuevo_nombre)) {
            echo json_encode(['success' => false, 'message' => 'El nombre no puede estar vacío.']);
            exit;
        }

        // Actualizar nombre
        $stmt = $pdo->prepare("UPDATE usuarios SET nombre = ? WHERE id = ?");
        $stmt->execute([$nuevo_nombre, $usuario['id']]);

        // Subir nueva foto de perfil si se envía
        $foto_perfil = $_FILES['foto_perfil'] ?? null;
        if ($foto_perfil && $foto_perfil['tmp_name'] && $foto_perfil['error'] === UPLOAD_ERR_OK) {
            
            // Validar extensiones permitidas
            $ext = strtolower(pathinfo($foto_perfil['name'], PATHINFO_EXTENSION));
            $extensiones_validas = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($ext, $extensiones_validas)) {
                $nombreArchivo = 'perfil_' . $usuario['id'] . '_' . time() . '.' . $ext;
                $ruta = 'uploads/';
                if (!is_dir($ruta)) mkdir($ruta, 0755, true);

                // Eliminar foto de perfil anterior si existe para no acumular basura
                if (!empty($usuario['foto_perfil']) && file_exists($ruta . $usuario['foto_perfil'])) {
                    @unlink($ruta . $usuario['foto_perfil']);
                }

                if (move_uploaded_file($foto_perfil['tmp_name'], $ruta . $nombreArchivo)) {
                    $stmt = $pdo->prepare("UPDATE usuarios SET foto_perfil = ? WHERE id = ?");
                    $stmt->execute([$nombreArchivo, $usuario['id']]);
                }
            } else {
                echo json_encode(['success' => false, 'message' => 'Formato de imagen inválido (solo JPG, PNG, WEBP).']);
                exit;
            }
        }

        echo json_encode(['success' => true, 'message' => '¡Perfil actualizado con éxito!']);
        exit;

    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error interno en la base de datos.']);
        exit;
    }
}

// --- Procesamiento GET: Obtener datos actuales para pintar el formulario inicialmente ---
$datosUser = ['nombre' => '', 'foto_perfil' => ''];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['get_profile'])) {
    header('Content-Type: application/json; charset=utf-8');
    $uid = $_GET['get_profile'] ?? '';
    $stmt = $pdo->prepare("SELECT nombre, foto_perfil FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmt->execute([$uid]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($res ? $res : ['nombre' => '', 'foto_perfil' => '']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Editar Perfil | Latin Color Sports</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<style>
    /* Estilización del input file */
    input[type="file"]::file-selector-button {
        background-color: rgba(255, 255, 255, 0.1);
        color: #ffffff;
        border: 0;
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 11px;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.2s;
    }
    input[type="file"]::file-selector-button:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }
</style>
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.appspot.com",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
    measurementId: "G-NXZW7KNWW1"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

onAuthStateChanged(auth, async user => {
    if(user){
        document.getElementById('firebase_uid').value = user.uid;
        
        // Cargar los datos actuales en tiempo real desde la DB
        try {
            const res = await fetch(`editar_perfil.php?get_profile=${user.uid}`);
            const data = await res.json();
            if(data) {
                document.getElementById('nombre').value = data.nombre || '';
                if(data.foto_perfil) {
                    document.getElementById('preview_foto').src = 'uploads/' + data.foto_perfil;
                }
            }
        } catch (e) {
            console.error("Error cargando perfil inicial", e);
        }

        // Setup Logout
        document.getElementById('logoutButton').addEventListener('click', async () => {
            await signOut(auth);
            window.location.href = 'login_app.html';
        });

    } else {
        window.location.href = 'login_app.html';
    }
});
</script>
</head>

<body class="bg-[#050505] text-white font-sans min-h-screen antialiased selection:bg-orange-500 selection:text-white">

<nav class="bg-[#0f0f0f] border-b border-white/5 sticky top-0 z-50 backdrop-blur-md bg-opacity-90">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">

      <div class="flex-shrink-0 flex items-center gap-2">
        <div class="w-9 h-9 rounded-xl bg-orange-600/10 border border-orange-500/30 flex items-center justify-center">
            <img class="h-6 w-auto" src="uploads/LATIN-SPORTS.png" alt="Logo">
        </div>
        <span class="font-black text-sm tracking-wider uppercase text-white">Latin Color <span class="text-orange-500">Sports</span></span>
      </div>

      <div class="flex items-center gap-4">
	     <a href="login_app.html" class="px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition">Home</a>
        <a href="datos_bancarios.php" class="px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition">Datos Bancarios</a>
        <button id="logoutButton" class="px-3 py-2 text-xs font-bold uppercase tracking-wider bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl hover:bg-red-600 hover:text-white transition-colors">Salir</button>
      </div>

    </div>
  </div>
</nav>

<div class="max-w-md mx-auto px-4 py-12">
    
    <button onclick="window.location.href='menu_fotografo.php'" class="group mb-6 flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-gray-400 hover:text-orange-500 transition-colors">
        <span class="text-base group-hover:-translate-x-1 transition-transform">←</span> Volver al Menú
    </button>


    <div class="bg-[#0f0f0f] border border-white/10 p-8 rounded-3xl shadow-2xl space-y-6 relative overflow-hidden">
        <div class="absolute -right-20 -top-20 w-40 h-40 bg-orange-600/10 blur-3xl rounded-full"></div>
        
        <div class="text-center">
            <p class="text-[10px] uppercase font-black tracking-widest text-orange-500 mb-1">Mi Cuenta</p>
            <h1 class="text-xl font-bold text-white">Editar Perfil</h1>
            <p class="text-xs text-gray-400 mt-1">Mantén actualizada tu identidad pública dentro de la plataforma.</p>
        </div>

        <div class="flex flex-col items-center justify-center gap-3">
            <div class="relative group w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-orange-600 to-amber-500 shadow-xl">
                <div class="w-full h-full rounded-full bg-[#050505] overflow-hidden flex items-center justify-center">
                    <img id="preview_foto" src="uploads/default-avatar.png" alt="Avatar" class="w-full h-full object-cover">
                </div>
            </div>
            <p class="text-[10px] uppercase text-gray-500 font-bold tracking-wider">Vista previa</p>
        </div>

        <form id="formPerfil" method="POST" enctype="multipart/form-data" class="space-y-4">
            <input type="hidden" name="firebase_uid" id="firebase_uid" value="">

            <div>
                <label for="nombre" class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Nombre Completo</label>
                <input type="text" name="nombre" id="nombre" required placeholder="Tu nombre artístico o real" 
                       class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 text-sm transition-colors">
            </div>

            <div>
                <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Actualizar Foto de Perfil</label>
                <input type="file" name="foto_perfil" id="input_foto" accept="image/png, image/jpeg, image/jpg, image/webp"
                       class="w-full bg-black/40 border border-white/10 text-white p-2.5 rounded-xl focus:outline-none text-xs text-gray-400">
            </div>

            <button type="submit" id="btnSubmit" class="w-full bg-orange-600 hover:bg-orange-500 text-white text-xs uppercase font-black tracking-widest py-3.5 px-4 rounded-xl shadow-lg shadow-orange-600/10 transition-all active:scale-[0.98] mt-4">
                Guardar Cambios
            </button>
        </form>

        <div id="mensaje" class="text-center text-xs font-bold p-3 rounded-xl hidden transition-all"></div>
    </div>
</div>

<script>
// Manejador para previsualizar la imagen en tiempo real antes de subirla
document.getElementById('input_foto').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('preview_foto').src = e.target.result;
        }
        reader.readAsDataURL(file);
    }
});

// Manejador del submit mediante AJAX
document.getElementById('formPerfil').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.target;
    const btnSubmit = document.getElementById('btnSubmit');
    const mensajeElemento = document.getElementById('mensaje');
    const formData = new FormData(form);

    // Estado visual de carga
    btnSubmit.innerText = "Guardando...";
    btnSubmit.disabled = true;

    try {
        const res = await fetch('editar_perfil.php', {
            method: 'POST',
            body: formData
        });
        
        const json = await res.json();
        mensajeElemento.classList.remove('hidden', 'bg-red-500/10', 'text-red-400', 'border-red-500/20', 'bg-emerald-500/10', 'text-emerald-400', 'border-emerald-500/20');

        if (json.success) {
            mensajeElemento.classList.add('block', 'bg-emerald-500/10', 'text-emerald-400', 'border', 'border-emerald-500/20');
            mensajeElemento.textContent = "✓ " + json.message + " Redirigiendo...";
            
            setTimeout(() => {
                window.location.href = 'menu_fotografo.php';
            }, 1500);
        } else {
            btnSubmit.innerText = "Guardar Cambios";
            btnSubmit.disabled = false;
            mensajeElemento.classList.add('block', 'bg-red-500/10', 'text-red-400', 'border', 'border-red-500/20');
            mensajeElemento.textContent = "✕ " + json.message;
        }
    } catch (error) {
        btnSubmit.innerText = "Guardar Cambios";
        btnSubmit.disabled = false;
        mensajeElemento.classList.add('block', 'bg-red-500/10', 'text-red-400', 'border', 'border-red-500/20');
        mensajeElemento.textContent = "✕ Error crítico al conectar con el servidor.";
    }
});
</script>

</body>
</html>