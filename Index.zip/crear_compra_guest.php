<?php
header('Content-Type: application/json');
require_once 'dbfotografos.php';
$pdo = conectar();

$input = json_decode(file_get_contents('php://input'), true);

$guest_uid = trim($input['guest_uid'] ?? '');
$nombre    = trim($input['nombre'] ?? '');
$email     = trim($input['email'] ?? '');
$whatsapp  = trim($input['whatsapp'] ?? '');

if (!$guest_uid || !$nombre || !$email) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos.']);
    exit;
}

// 1. Obtener items del carrito
$stmt = $pdo->prepare("SELECT foto_id, evento_id, precio FROM carrito WHERE firebase_uid = ?");
$stmt->execute([$guest_uid]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$items) {
    echo json_encode(['status' => 'error', 'message' => 'El carrito está vacío.']);
    exit;
}

$public_key       = "pub_prod_qDvUDoTJtgy1bVkcuQJ7rcgkOM4oxbLw";
$secret_integrity = "prod_integrity_BWG58peE6yhM382mYETKtAjra3xNEARl";
$currency         = "COP";

try {
    $total = array_sum(array_column($items, 'precio'));
    
    // Cálculo: Precio * 3500 (Tasa) * 100 (Centavos)
    $amount_in_cents = intval(round($total * 3500 * 100));
    $referencia = "LCS-" . time() . "-" . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));

    $pdo->beginTransaction();

    // 2. Insertar Compra
    $sql_compra = "INSERT INTO compras (firebase_uid, referencia, total, estado, fecha_compra) VALUES (?, ?, ?, 'Pendiente', NOW())";
    $pdo->prepare($sql_compra)->execute([$guest_uid, $referencia, $total]);
    $id_compra = $pdo->lastInsertId();

    // 3. Insertar Invitado (Asegúrate de que la tabla tenga estas columnas)
    $sql_invitado = "INSERT INTO clientes_invitados (compra_id, nombre, email, whatsapp, guest_uid, fecha) VALUES (?, ?, ?, ?, ?, NOW())";
    $pdo->prepare($sql_invitado)->execute([$id_compra, $nombre, $email, $whatsapp, $guest_uid]);

    // 4. Detalle y Comisiones
    $s_det = $pdo->prepare("INSERT INTO detalle_compras (id_compra, id_foto, evento_id, precio) VALUES (:cid, :fid, :eid, :pre)");
    $s_com = $pdo->prepare("INSERT INTO comisiones_usuario (admin, fotografo, organizador, soporte, comercial, compra_id, foto_id, evento_id) VALUES (:adm, :fot, :org, :sop, :com, :cid, :fid, :eid)");

    foreach ($items as $item) {
        $v = (float)$item['precio'];
        $f = $item['foto_id'] ?? null;
        $e = $item['evento_id'] ?? null;
        
        $s_det->execute([':cid'=>$id_compra, ':fid'=>$f, ':eid'=>$e, ':pre'=>$v]);
        $s_com->execute([
            ':adm'=>round($v*0.35,2), ':fot'=>round($v*0.50,2),
            ':org'=>round($v*0.10,2), ':sop'=>round($v*0.03,2),
            ':com'=>round($v*0.02,2), ':cid'=>$id_compra, ':fid'=>$f, ':eid'=>$e
        ]);
    }

    // 5. Finalizar
    $pdo->prepare("DELETE FROM carrito WHERE firebase_uid = ?")->execute([$guest_uid]);
    $pdo->commit();

    // 6. Firma
    $firma = hash("sha256", $referencia . $amount_in_cents . $currency . $secret_integrity);

$totalesPaypal = [5, 10, 15, 20, 25];

$metodo_pago = in_array((float)$total, $totalesPaypal)
    ? 'paypal'
    : 'wompi';

echo json_encode([
    'status'          => 'success',
    'metodo_pago'     => $metodo_pago,
    'total'           => $total,
    'compra_id'       => $id_compra,
    'referencia'      => $referencia,
    'amount_in_cents' => $amount_in_cents,
    'currency'        => $currency,
    'firma'           => $firma,
    'public_key'      => $public_key
]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log("Error en crear_compra_guest: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Error en el servidor.']);
}