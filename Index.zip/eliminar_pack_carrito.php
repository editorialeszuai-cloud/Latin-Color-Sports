<?php
require_once 'dbfotografos.php';
$pdo = conectar();
header('Content-Type: application/json');

$evento_id = isset($_POST['evento_id']) ? intval($_POST['evento_id']) : 0;
$firebase_uid = isset($_POST['firebase_uid']) ? $_POST['firebase_uid'] : '';

if (!$evento_id || !$firebase_uid) {
    echo json_encode(['status' => 'error', 'message' => 'Faltan datos para eliminar']);
    exit;
}

try {
    // IMPORTANTE: Borramos donde foto_id es NULL para no borrar fotos sueltas por error
    $sql = "DELETE FROM carrito 
            WHERE firebase_uid = ? 
            AND evento_id = ? 
            AND foto_id IS NULL";
            
    $stmt = $pdo->prepare($sql);
    $result = $stmt->execute([$firebase_uid, $evento_id]);

    if ($result) {
        echo json_encode(['status' => 'ok', 'message' => 'Pack eliminado correctamente']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se encontró el pack en el carrito']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}