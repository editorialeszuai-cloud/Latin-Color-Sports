<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'dbfotografos.php';
header('Content-Type: application/json');

function resp($status, $message, $extra = []) {
    echo json_encode(array_merge([
        'status' => $status,
        'message' => $message
    ], $extra));
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    resp('error', 'No se recibieron datos JSON');
}

$comisiones   = $input['comisiones'] ?? [];
$firebase_uid = $input['firebase_uid'] ?? null;
$tipo = 'organizador';

if (empty($comisiones)) {
    resp('error', 'No se proporcionaron comisiones a retirar');
}

if (!$firebase_uid) {
    resp('error', 'Usuario no proporcionado');
}

try {
    $placeholders = implode(',', array_fill(0, count($comisiones), '?'));

    // 🔎 Obtener comisiones (SIN estado_retiro)
    $stmtVal = $pdo->prepare("
        SELECT id, organizador AS monto
        FROM comisiones_usuario
        WHERE id IN ($placeholders)
    ");
    $stmtVal->execute($comisiones);
    $validados = $stmtVal->fetchAll(PDO::FETCH_ASSOC);

    if (!$validados) {
        resp('error', 'Ninguna comisión válida encontrada');
    }

    $pdo->beginTransaction();
    $fecha = date('Y-m-d H:i:s');

    // 📥 Insertar / actualizar retiro
    $stmtInsert = $pdo->prepare("
        INSERT INTO retiros_comisiones
        (comision_id, tipo, retirada, firebase_uid, total, fecha)
        VALUES (:comision_id, :tipo, 1, :firebase_uid, :total, :fecha)
        ON DUPLICATE KEY UPDATE
            retirada = 1,
            firebase_uid = VALUES(firebase_uid),
            total = VALUES(total),
            fecha = VALUES(fecha)
    ");

    $insertados = [];

    foreach ($validados as $c) {
        $data = [
            'comision_id'  => $c['id'],
            'tipo'         => $tipo,
            'firebase_uid' => $firebase_uid,
            'total'        => (float)$c['monto'],
            'fecha'        => $fecha
        ];

        $stmtInsert->execute($data);
        $insertados[] = $data;
    }

    $pdo->commit();

    resp('success', 'Comisiones retiradas correctamente', [
        'cantidad'   => count($insertados),
        'comisiones' => array_column($insertados, 'comision_id'),
        'fecha'      => $fecha
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    resp('error', 'Error en la transacción', [
        'message' => $e->getMessage()
    ]);
}
