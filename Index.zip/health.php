<?php
// Archivo health.php
http_response_code(200);
echo "OK";
exit();
?>