<?php
session_start();
require_once __DIR__ . '/dbfotografos.php';
$pdo = conectar();

// Recibimos los datos desde la URL (?id=...&ref=...&reason=...)
$compra_id = $_GET['id'] ?? '';
$paypal_ref = $_GET['ref'] ?? 'N/A'; // Puede no venir si el error fue antes de generar la orden
$reason = $_GET['reason'] ?? 'TRANSACTION_REFUSED'; // Razón del rechazo

if (!$compra_id) {
    die("Error: Falta el ID de la transacción para procesar el fallo.");
}

try {
    // 1. Verificamos que la compra existe
    $stmt = $pdo->prepare("SELECT * FROM compras WHERE id = ?");
    $stmt->execute([$compra_id]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$compra) {
        die('Error: Orden no encontrada.');
    }

    // 2. Actualizamos el estado a 'DECLINED' en la base de datos
    // Nota: Guardamos la razón del rechazo en el campo de pasarela si lo deseas, o solo el ID
    $stmtUpdate = $pdo->prepare("UPDATE compras 
                                 SET estado = 'DECLINED', 
                                     x_transaction_id = ?, 
                                     metodo_pago = 'PayPal' 
                                 WHERE id = ?");
    
    $stmtUpdate->execute([$paypal_ref, $compra_id]);

    // 3. En lugar de redirigir inmediatamente, mostramos una pantalla de error amigable
    // para que el usuario sepa qué pasó y tenga un botón para regresar a intentar el pago.
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Rechazado - LatinColorSports</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .error-container {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 450px;
            width: 100%;
        }
        .icon {
            font-size: 60px;
            color: #dc3545;
            margin-bottom: 20px;
        }
        h1 {
            margin-bottom: 10px;
            font-size: 24px;
            color: #333;
        }
        p {
            color: #6c757d;
            font-size: 16px;
            line-height: 1.5;
            margin-bottom: 25px;
        }
        .details {
            background-color: #f1f3f5;
            padding: 12px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 13px;
            text-align: left;
            margin-bottom: 30px;
            word-break: break-all;
        }
        .btn {
            display: inline-block;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            padding: 12px 25px;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.2s;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<div class="error-container">
    <div class="icon">✕</div>
    <h1>Transacción Rechazada</h1>
    <p>Lo sentimos, PayPal ha rechazado la transacción o ha ocurrido un problema al procesar tu solicitud de crédito.</p>
    
    <div class="details">
        <strong>ID Compra:</strong> <?php echo htmlspecialchars($compra_id); ?><br>
        <strong>Ref. PayPal:</strong> <?php echo htmlspecialchars($paypal_ref); ?><br>
        <strong>Motivo:</strong> <?php echo htmlspecialchars($reason); ?>
    </div>

    <a href="https://latincolorsports.com/miscomprasfotos.php" class="btn">Volver a intentar</a>
</div>

</body>
</html>
<?php
} catch (Exception $e) {
    die("Error crítico al procesar el rechazo: " . $e->getMessage());
}
?>