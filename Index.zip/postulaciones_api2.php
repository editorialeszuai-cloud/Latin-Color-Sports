<?php
header("Content-Type: application/json; charset=utf-8");
require_once "db.php"; // Aseg��rate de que defina $pdo o la funci��n conectar()

// --- FUNCI��N RESPUESTA ---
function resp($status, $msg='', $data=null){
    echo json_encode(['status'=>$status, 'message'=>$msg, 'data'=>$data], JSON_UNESCAPED_UNICODE);
    exit;
}

// --- OBTENER ENTRADA ---
$rawInput = file_get_contents("php://input");
$data = json_decode($rawInput, true) ?: $_POST;

$accion = $data['accion'] ?? '';
$firebaseToken = $data['firebase_token'] ?? null;
$evento_id = intval($data['evento_id'] ?? 0);

if(!$firebaseToken) resp('error', 'Token no recibido.');

try {
    // 1. VERIFICACI��N MANUAL (Sin librer��as externas)
    $partes = explode('.', $firebaseToken);
    if (count($partes) !== 3) resp('error', 'Token inv��lido.');
    
    $payload = json_decode(base64_decode($partes[1]), true);
    $firebase_uid = $payload['sub'] ?? null;

    if (!$firebase_uid) resp('error', 'Token inv��lido o UID no extra��do.');

    // 2. CONEXI��N PDO
    if (!isset($pdo)) {
        if (function_exists('conectar')) {
            $pdo = conectar();
        } else {
            throw new Exception("No se pudo conectar a la base de datos.");
        }
    }

    // --- Obtener ID de usuario ---
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmt->execute([$firebase_uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if(!$user) resp('error', 'Usuario no encontrado en la base de datos.');
    $usuario_id = $user['id'];

    // --- ACCI��N: LISTAR ---
    if($accion === 'listar'){
        $sql = "SELECT e.id, e.titulo, e.descripcion, e.fecha, e.fechafin, e.tipo_evento, 
                       l.nombre_lugar AS lugar_nombre, f.nombre AS organizador
                FROM eventos e
                LEFT JOIN lugares l ON l.id = e.lugar_id
                LEFT JOIN usuarios f ON f.id = e.comercial_id
                WHERE e.id NOT IN (SELECT evento_id FROM postulaciones WHERE usuario_id = ?)
                ORDER BY e.fecha ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$usuario_id]);
        $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        resp('success', 'Eventos obtenidos', $eventos);
    }

    // --- ACCI��N: POSTULAR ---
    elseif($accion === 'postular'){
        if(!$evento_id) resp('error', 'Evento no v��lido.');

        $stmt = $pdo->prepare("SELECT id FROM postulaciones WHERE usuario_id = ? AND evento_id = ? LIMIT 1");
        $stmt->execute([$usuario_id, $evento_id]);
        if($stmt->fetch()) resp('error', 'Ya te has postulado a este evento.');

        $sqlInsert = "INSERT INTO postulaciones (usuario_id, evento_id, estado, calendario_id, capacidad_mb, unidad_fotos, creado_en)
                      VALUES (?, ?, 'pendiente', 0, 0, 'N/A', NOW())";
        
        $stmt = $pdo->prepare($sqlInsert);
        $success = $stmt->execute([$usuario_id, $evento_id]);

        if($success){
            resp('success', 'Te has postulado correctamente.');
        } else {
            resp('error', 'No se pudo completar la postulaci��n.');
        }
    } 
    else {
        resp('error', 'Acci��n no v��lida.');
    }

} catch (Throwable $e) {
    resp('error', 'Error cr��tico: ' . $e->getMessage());
}
?>