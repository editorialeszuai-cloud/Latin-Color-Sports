<?php
// get_carrito.php
// Devuelve los ítems del carrito de un firebase_uid (puede ser guest_)
header('Content-Type: application/json');
require_once 'dbfotografos.php';
$pdo = conectar();

$firebase_uid = trim($_GET['firebase_uid'] ?? '');
if (!$firebase_uid) { echo json_encode(['items'=>[]]); exit; }

$stmt = $pdo->prepare("
    SELECT c.foto_id, c.evento_id, c.precio,
           f.url AS foto_url,
           e.titulo AS evento_titulo
    FROM carrito c
    LEFT JOIN fotos f ON c.foto_id = f.id
    LEFT JOIN eventos e ON c.evento_id = e.id
    WHERE c.firebase_uid = ?
");
$stmt->execute([$firebase_uid]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['items' => $items]);