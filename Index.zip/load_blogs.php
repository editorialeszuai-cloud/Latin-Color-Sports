<?php
header("Content-Type: text/html; charset=utf-8");
require_once "db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['uid'])) {
    $firebase_uid = $_POST['uid'];
    $conn = conectar();

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE firebase_uid=? LIMIT 1");
    $stmt->bind_param("s",$firebase_uid);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$user = $result->fetch_assoc()) {
        echo '<p style="color:red;">Usuario no encontrado.</p>';
        exit;
    }
    $usuario_id = $user['id'];

    $stmt = $conn->prepare("SELECT titulo,resumen,categoria,estado,fecha_creacion FROM blogs WHERE usuario_id=? ORDER BY fecha_creacion DESC");
    $stmt->bind_param("i",$usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) { echo '<p>No tienes blogs creados.</p>'; exit; }

    while($blog = $result->fetch_assoc()){
        echo '<div class="blog">';
        echo '<h3>'.htmlspecialchars($blog['titulo']).'</h3>';
        echo '<p><strong>Categoría:</strong> '.htmlspecialchars($blog['categoria']).' | <strong>Estado:</strong> '.htmlspecialchars($blog['estado']).'</p>';
        echo '<p>'.nl2br(htmlspecialchars($blog['resumen'])).'</p>';
        echo '<p><small>Creado el: '.$blog['fecha_creacion'].'</small></p>';
        echo '</div>';
    }

    $stmt->close();
    $conn->close();
} else {
    echo '<p style="color:red;">UID no enviado.</p>';
}
?>
