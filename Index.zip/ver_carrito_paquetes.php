<?php
require 'dbfotografos.php';
$firebase_uid = $_GET['firebase_uid'] ?? '';
if(!$firebase_uid) exit('<p class="text-red-600">No hay usuario</p>');

// Obtener items del carrito de paquetes
$stmt = $pdo->prepare("
    SELECT cp.id, cp.evento_id, cp.precio, e.titulo
    FROM carrito_paquetes cp
    INNER JOIN eventos e ON cp.evento_id = e.id
    WHERE cp.firebase_uid=?
    ORDER BY cp.fecha DESC
");
$stmt->execute([$firebase_uid]);
$carrito = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = 0;

foreach($carrito as $item){
    $total += $item['precio'];
    echo '<div class="carrito-item flex justify-between items-center p-2 border-b border-gray-300">';
    echo '<div class="flex-1">'.htmlspecialchars($item['titulo']).'</div>';
    echo '<span class="precio font-bold" data-precio="'.$item['precio'].'">$'.number_format($item['precio'],0).'</span>';
    echo ' <span class="delete-btn" onclick="eliminarItem('.$item['id'].',\'paquete\')">✖</span>';
    echo '</div>';
}

// Botón flotante de pago
if(!empty($carrito)){
    echo '<a href="checkout_paquetes.php?firebase_uid='.urlencode($firebase_uid).'" 
            style="
                position:fixed;
                right:20px;
                bottom:200px;
                background:green;
                color:#fff;
                padding:14px 20px;
                border-radius:50px;
                font-weight:bold;
                box-shadow:0 4px 12px rgba(0,0,0,0.5);
                text-decoration:none;
                transition:0.3s;
            ">
            Pagar paquetes ($'.number_format($total,0).')
          </a>';
}
?>
