<?php
require_once 'dbfotografos.php';
header('Content-Type: application/json; charset=utf-8');

$firebase_uid = $_POST['firebase_uid'] ?? '';
$galeria_id = $_POST['galeria_id'] ?? '';

if(!$firebase_uid || !$galeria_id){
    echo json_encode(['status'=>'error','msg'=>'Faltan datos']);
    exit;
}

// Obtener datos de la galería original
$stmt = $pdo->prepare("SELECT titulo, evento_id, precio, fotografo_id FROM galerias WHERE id = ?");
$stmt->execute([$galeria_id]);
$galeria = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$galeria){
    echo json_encode(['status'=>'error','msg'=>'Galería no encontrada']);
    exit;
}

// Insertar en galerias_usuario
$stmt2 = $pdo->prepare("
    INSERT INTO galerias_usuario (firebase_uid, galeria_origen_id, evento_id, titulo)
    VALUES (?, ?, ?, ?)
");
$stmt2->execute([$firebase_uid, $galeria_id, $galeria['evento_id'], $galeria['titulo']]);

$galeria_usuario_id = $pdo->lastInsertId(); // ID recién creado

// ===== Calcular comisiones =====
$porcentajes = [
    'admin' => 0.60,
    'fotografo' => 0.05,
    'organizador' => 0.05,
    'soporte' => 0.03,
    'comercial' => 0.03
];

$comisiones = [];
foreach($porcentajes as $rol => $pct){
    $comisiones[$rol] = round($galeria['precio'] * $pct,2);
}

// ===== Insertar comisiones en tabla (opcional: crear tabla `comisiones_usuario`) =====
$stmt3 = $pdo->prepare("
    INSERT INTO comisiones_usuario (galeria_usuario_id, admin, fotografo, organizador, soporte, comercial)
    VALUES (?, ?, ?, ?, ?, ?)
");
$stmt3->execute([
    $galeria_usuario_id,
    $comisiones['admin'],
    $comisiones['fotografo'],
    $comisiones['organizador'],
    $comisiones['soporte'],
    $comisiones['comercial']
]);

echo json_encode(['status'=>'ok', 'galeria_usuario_id'=>$galeria_usuario_id, 'comisiones'=>$comisiones]);
