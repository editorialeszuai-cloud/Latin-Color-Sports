<?php
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

if(empty($data['firebase_token']) || empty($data['postulacion_id']) || empty($data['titulo'])){
    echo json_encode(['success'=>false,'message'=>'Datos incompletos']);
    exit;
}

$firebase_token = $data['firebase_token'];
$postulacion_id = intval($data['postulacion_id']);
$titulo = trim($data['titulo']);

// Conecta a tu base de datos
include 'db.php';

// Validar el usuario mediante firebase_token
$user_uid = getUidFromFirebaseToken($firebase_token);
if(!$user_uid){
    echo json_encode(['success'=>false,'message'=>'UID Firebase no encontrado']);
    exit;
}

// Verificar que la postulación exista y pertenezca a este usuario
$stmt = $db->prepare("SELECT id FROM postulaciones WHERE id=? AND firebase_uid=?");
$stmt->execute([$postulacion_id, $user_uid]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if(!$post){
    echo json_encode(['success'=>false,'message'=>'Postulación no encontrada']);
    exit;
}

// Crear galería
$stmt = $db->prepare("INSERT INTO galerias (postulacion_id, titulo) VALUES (?, ?)");
$stmt->execute([$postulacion_id, $titulo]);
$galeria_id = $db->lastInsertId();

echo json_encode(['success'=>true,'galeria_id'=>$galeria_id]);
exit;

function getUidFromFirebaseToken($token){
    // Aquí deberías usar Firebase Admin SDK para verificar token
    // Por ahora simulamos
    return 'uid_ejemplo'; // Reemplaza con tu lógica real
}
