<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'dbfotografos.php';

try {
    $pdo->query("SELECT 1");
    echo "✅ Conexión correcta";
} catch (Exception $e){
    echo "❌ Error de conexión: ".$e->getMessage();
}
