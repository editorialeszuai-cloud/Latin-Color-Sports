
    <!-- Iconos de experiencia -->

<div class="experiencia">
<div class="experiencia-olimpicos">
             <div class="contenedor">
     <button class="svg-btn">
      <svg width="50" height="50" viewBox="0 0 100 100">
        <!-- Degradado -->
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#f6c35c"/>
            <stop offset="100%" stop-color="#f04b2f"/>
          </linearGradient>
        </defs>

        <!-- Círculo -->
        <circle cx="50" cy="50" r="48" fill="url(#grad)" />

        <!-- Flechas -->
        <polyline points="38,30 52,50 38,70"
                  fill="none"
                  stroke="white"
                  stroke-width="8"
                  stroke-linecap="round"
                  stroke-linejoin="round"/>
                  
        <polyline points="52,30 66,50 52,70"
                  fill="none"
                  stroke="white"
                  stroke-width="8"
                  stroke-linecap="round"
                  stroke-linejoin="round"/>
      </svg>
          <h3>EXPERIENCIA EN DEPORTES OLÍMPICOS</h3>
   
    </button>
    

  </div>


<style>
/* ==== NUEVO BLOQUE DE ANIMACIÓN ==== */
.contenedor-iconos {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  padding: 18px 28px;
  border: 5px solid #ff6600;
  border-radius: 50px;
  width: fit-content;
  margin: 30px auto;
  overflow: hidden; /* necesario para el efecto */
  height: 100px; /* visible solo 1 grupo de 5 iconos aprox */
  transition: transform 0.5s ease-in-out;
}

.contenedor-iconos img {
  width: 38px;
  height: auto;
  display: block;
  background-color: orange;
  border-radius: 50%;
  padding: 5px;
  border: 2px solid #ff6600;
}

@media (max-width: 768px) {
  .contenedor-iconos {
    padding: 14px 20px;
    gap: 14px;
  }

  .contenedor-iconos img {
    width: 28px;
  }
}
</style>

<div class="contenedor-iconos">
   <img src="iconosolim/experiencias iconos-01.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-02.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-03.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-04.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-05.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-06.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-07.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-08.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-09.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-10.png" alt="" width="20px"> 
  <img src="iconosolim/experiencias iconos-11.png" alt="" width="20px" >
  <img src="iconosolim/experiencias iconos-12.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-13.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-14.png" alt="" width="20px" >
  <img src="iconosolim/experiencias iconos-15.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-16.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-17.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-18.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-19.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-20.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-21.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-22.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-23.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-24.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-25.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-26.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-27.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-28.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-29.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-30.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-31.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-32.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-33.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-34.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-35.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-36.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-37.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-38.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-39.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-40.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-41.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-42.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-43.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-44.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-45.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-46.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-47.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-48.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-49.png" alt="" width="20px">
  <img src="iconosolim/experiencias iconos-50.png" alt="" width="20px">
</div>
</div>
<div class="experiencia-paralimpicos">
             <div class="contenedor">
                 
     <button class="svg-btn" aria-label="Avanzar">
  <svg viewBox="0 0 100 100" width="50" height="50" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <!-- Degradado verde -->
      <linearGradient id="greenGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#8fd3b0"/>
        <stop offset="100%" stop-color="#3fa57a"/>
      </linearGradient>
    </defs>

    <!-- Círculo -->
    <circle cx="50" cy="50" r="48" fill="url(#greenGrad)" />

    <!-- Anillo interior suave (opcional, como la imagen) -->
    <circle cx="50" cy="50" r="40"
            fill="none"
            stroke="rgba(255,255,255,0.25)"
            stroke-width="2"
            stroke-dasharray="4 6"/>

    <!-- Flechas -->
    <polyline points="36,28 52,50 36,72"
              fill="none"
              stroke="white"
              stroke-width="9"
              stroke-linecap="round"
              stroke-linejoin="round"/>

    <polyline points="52,28 68,50 52,72"
              fill="none"
              stroke="white"
              stroke-width="9"
              stroke-linecap="round"
              stroke-linejoin="round"/>
  </svg>
  
  
</button>
   <h3>EXPERIENCIA EN DEPORTES PARALÍMPICOS</h3>
   
  </div>

<style> 
  /* ==== VARIANTE VERDE MENTA ==== */
.iconos2 {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  padding: 18px 28px;
  border: 5px solid #2ecc71; /* verde brillante */
  border-radius: 50px;
  width: fit-content;
  margin: 30px auto;
  overflow: hidden;
  height: 100px;
  transition: transform 0.5s ease-in-out;
}

.iconos2 img {
  width: 38px;
  height: auto;
  display: block;
  background-color: #a8f5c2; /* mismo tono que el fondo */
  border-radius: 50%;
  padding: 5px;
  border: 2px solid #2ecc71; /* borde verde */
}

@media (max-width: 768px) {
  .iconos2 {
    padding: 14px 20px;
    gap: 14px;
  }

  .iconos2 img {
    width: 28px;
  }
}
  </style> 
            
            <div class="iconos2">
   <img src="iconos/experiencias iconos individual paralimpicos-01.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-02.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-03.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-04.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-05.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-06.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-07.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-08.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-09.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-10.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-11.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-12.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-13.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-14.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-15.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-16.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-17.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-18.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-19.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-20.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-21.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-22.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-23.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-24.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-25.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-26.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-27.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-28.png" width="20px">
  <img src="iconos/experiencias iconos individual paralimpicos-29.png" width="20px">                  
            </div>
        </div>
</div>
</section>


<script>
/* ==== ROTADOR SEGURO PARA AMBOS CONTENEDORES (naranja y verde) ==== */
(function setupRotator(selector, visibleCount = 5, intervalMs = 3000) {
  const cont = document.querySelector(selector);
  if (!cont) return; // si no existe, salimos

  // Capturamos las imágenes originales (clonadas) ANTES de vaciar el contenedor
  const originals = Array.from(cont.querySelectorAll('img')).map(img => img.cloneNode(true));
  let index = 0;

  function showGroup() {
    // si no hay iconos, nada que hacer
    if (originals.length === 0) return;

    // calcular slice (si llega al final, tomamos lo que queda y luego reiniciamos)
    const group = originals.slice(index, index + visibleCount);

    // si el grupo queda vacío porque index+visibleCount > length, concatenamos desde inicio
    if (group.length < visibleCount) {
      const remain = visibleCount - group.length;
      group.push(...originals.slice(0, remain));
    }

    // limpiar y añadir el grupo
    cont.innerHTML = '';
    group.forEach(node => cont.appendChild(node.cloneNode(true)));

    // actualizar índice circularmente
    index += visibleCount;
    if (index >= originals.length) index = index % originals.length;
  }

  // mostrar inicialmente y arrancar interval
  showGroup();
  const timer = setInterval(showGroup, intervalMs);

  // opcional: pausa on hover y reanuda on leave
  cont.addEventListener('mouseenter', () => clearInterval(timer));
  cont.addEventListener('mouseleave', () => setInterval(showGroup, intervalMs));
})('.contenedor-iconos', 5, 3000); // para el contenedor naranja

(function setupRotatorGreen(selector, visibleCount = 5, intervalMs = 3000) {
  const cont = document.querySelector(selector);
  if (!cont) return;

  const originals = Array.from(cont.querySelectorAll('img')).map(img => img.cloneNode(true));
  let index = 0;

  function showGroup() {
    if (originals.length === 0) return;
    const group = originals.slice(index, index + visibleCount);
    if (group.length < visibleCount) {
      const remain = visibleCount - group.length;
      group.push(...originals.slice(0, remain));
    }
    cont.innerHTML = '';
    group.forEach(node => cont.appendChild(node.cloneNode(true)));
    index += visibleCount;
    if (index >= originals.length) index = index % originals.length;
  }

  showGroup();
  const timer = setInterval(showGroup, intervalMs);

  cont.addEventListener('mouseenter', () => clearInterval(timer));
  cont.addEventListener('mouseleave', () => setInterval(showGroup, intervalMs));
})('.iconos2', 5, 3000); // para el contenedor verde
</script>
