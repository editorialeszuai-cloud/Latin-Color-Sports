<?php
session_start();
require_once __DIR__ . '/dbfotografos.php';
$pdo = conectar();

// Recibimos el ID de la compra desde la URL (?id=...)
$compra_id = $_GET['id'] ?? '';
$paypal_ref = $_GET['ref'] ?? ''; // El ID de la transacción de PayPal

if (!$compra_id || !$paypal_ref) {
    die("Error: Faltan datos de la transacción.");
}

try {
    // 1. Verificamos que la compra existe y traemos los datos
    // En responsepaypal.php, antes del UPDATE:
$stmt = $pdo->prepare("SELECT estado FROM compras WHERE id = ?");
$stmt->execute([$compra_id]);
$estadoActual = $stmt->fetchColumn();

if ($estadoActual !== 'APPROVED') {
    // Solo actualiza si aún no estaba aprobado
    $stmtUpdate = $pdo->prepare("UPDATE compras 
                                 SET estado = 'APPROVED', 
                                     x_transaction_id = ?, 
                                     metodo_pago = 'PayPal' 
                                 WHERE id = ?");
    $stmtUpdate->execute([$paypal_ref, $compra_id]);
}

header("Location: https://latincolorsports.com/miscomprasfotos.php");
exit();
	
	
} catch (Exception $e) {
    die("Error crítico: " . $e->getMessage());
}
?>