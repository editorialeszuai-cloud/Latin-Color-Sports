<?php
$url_imagen = urldecode($_GET['img'] ?? ''); 
$format = $_GET['format'] ?? 'webp'; 
$size = 600; 

// 1. Determinar si es local o S3
$isS3 = (strpos($url_imagen, 's3.amazonaws.com') !== false);
$nombre_archivo_seguro = md5($url_imagen);
$destinoDir = __DIR__ . "/uploads/thumbs_{$size}/";
$destino = $destinoDir . $nombre_archivo_seguro . "." . $format;
$watermarkPath = __DIR__ . "/uploads/watermark.png";

if (!is_dir($destinoDir)) mkdir($destinoDir, 0755, true);

// 2. Caché
if (file_exists($destino)) {
    header("Content-Type: image/" . ($format === 'jpg' ? 'jpeg' : $format));
    readfile($destino);
    exit;
}

// 3. Cargar imagen (S3 o Local)
$data = $isS3 ? @file_get_contents($url_imagen) : @file_get_contents(__DIR__ . "/" . $url_imagen);
if (!$data) { header("HTTP/1.1 404 Not Found"); exit("Imagen no encontrada"); }
$src = imagecreatefromstring($data);

// 4. Recorte
$w = imagesx($src); $h = imagesy($src);
$min = min($w, $h);
$cropped = imagecreatetruecolor($size, $size);
imagecopyresampled($cropped, $src, 0, 0, ($w-$min)/2, ($h-$min)/2, $size, $size, $min, $min);

// 5. MARCA DE AGUA (Forzamos la ruta absoluta aquí)
if (file_exists($watermarkPath)) {
    $wm = imagecreatefrompng($watermarkPath);
    // Convertir el logo a un lienzo con canal alfa real
    $wm_w = imagesx($wm); $wm_h = imagesy($wm);
    $wm_w_new = (int)($size * 0.3);
    $wm_h_new = (int)(($wm_h / $wm_w) * $wm_w_new);
    
    // Fusionar correctamente
    imagecopyresampled($cropped, $wm, $size - $wm_w_new - 20, $size - $wm_h_new - 20, 0, 0, $wm_w_new, $wm_h_new, $wm_w, $wm_h);
    imagedestroy($wm);
}

// 6. Salida
header("Content-Type: image/" . ($format === 'jpg' ? 'jpeg' : $format));
if ($format === 'webp') imagewebp($cropped, $destino, 80);
else imagejpeg($cropped, $destino, 80);

// Servir la imagen
readfile($destino);
imagedestroy($src); imagedestroy($cropped);
?>