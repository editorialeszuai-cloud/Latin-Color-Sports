<?php

require_once 'dbfotografos.php';

header('Content-Type: application/json');

$pdo = conectar();

$data = json_decode(file_get_contents('php://input'), true);

$guest_uid = trim($data['guest_uid'] ?? '');
$real_uid  = trim($data['real_uid'] ?? '');

if (
    empty($guest_uid) ||
    empty($real_uid) ||
    !str_starts_with($guest_uid, 'guest_')
) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Datos inválidos'
    ]);
    exit;
}

try {

    $pdo->beginTransaction();

    // Obtener fotos del carrito guest
    $stmt = $pdo->prepare("
        SELECT foto_id, evento_id, precio
        FROM carrito
        WHERE firebase_uid = ?
    ");

    $stmt->execute([$guest_uid]);

    $fotosGuest = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($fotosGuest as $foto) {

        // Verificar si ya existe en el carrito real
        $check = $pdo->prepare("
            SELECT id
            FROM carrito
            WHERE firebase_uid = ?
            AND foto_id = ?
        ");

        $check->execute([
            $real_uid,
            $foto['foto_id']
        ]);

        if (!$check->fetch()) {

            $insert = $pdo->prepare("
                INSERT INTO carrito
                (
                    firebase_uid,
                    foto_id,
                    evento_id,
                    precio
                )
                VALUES (?, ?, ?, ?)
            ");

            $insert->execute([
                $real_uid,
                $foto['foto_id'],
                $foto['evento_id'],
                $foto['precio']
            ]);
        }
    }

    // Eliminar carrito temporal
    $pdo->prepare("
        DELETE FROM carrito
        WHERE firebase_uid = ?
    ")->execute([$guest_uid]);

    // Actualizar compras pendientes
    $pdo->prepare("
        UPDATE compras
        SET firebase_uid = ?
        WHERE firebase_uid = ?
        AND estado = 'Pendiente'
    ")->execute([
        $real_uid,
        $guest_uid
    ]);

    $pdo->commit();

    echo json_encode([
        'status' => 'success',
        'message' => 'Carrito sincronizado correctamente'
    ]);

} catch (Exception $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        '[migrar_carrito] ' .
        $e->getMessage()
    );

    echo json_encode([
        'status' => 'error',
        'message' => 'Error al sincronizar carrito'
    ]);
}