<?php
header("Content-Type: application/json; charset=utf-8");
require 'dbfotografos.php';
require_once __DIR__ . '/vendor/autoload.php';
use Firebase\Auth\Token\Verifier;
use Firebase\Auth\Token\Exception\InvalidToken;

// Leer POST
$evento_id = (int)($_POST['evento_id'] ?? 0);
$fotografo_id = (int)($_POST['fotografo_id'] ?? 0);
$firebase_token = $_POST['firebase_token'] ?? '';

if (!$evento_id || !$fotografo_id || !$firebase_token) {
    echo json_encode(['status'=>'error','message'=>'Datos inválidos.']);
    exit;
}

// Verificar token
try {
    $verifier = new Verifier('latin-group-406b1');
    $verifiedIdToken = $verifier->verifyIdToken($firebase_token);
    $uid = $verifiedIdToken->claims()->get('sub');

    // Obtener usuario de la DB
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id = ? AND firebase_uid = ?");
    $stmt->execute([$fotografo_id, $uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['status'=>'error','message'=>'Usuario no coincide con el token.']);
        exit;
    }

} catch (InvalidToken $e) {
    echo json_encode(['status'=>'error','message'=>'Token inválido.', 'debug'=>$e->getMessage()]);
    exit;
} catch (Throwable $e) {
    echo json_encode(['status'=>'error','message'=>'Error interno.', 'debug'=>$e->getMessage()]);
    exit;
}

// Verificar si ya se postuló
$stmt = $pdo->prepare("SELECT * FROM asignar_eventos WHERE evento_id = ? AND fotografo_id = ?");
$stmt->execute([$evento_id, $fotografo_id]);
if ($stmt->fetch()) {
    echo json_encode(['status'=>'error','message'=>'Ya estás postulado a este evento.']);
    exit;
}

// Insertar postulación con capacidad y fotos inicializadas en 0
$stmt = $pdo->prepare("INSERT INTO asignar_eventos (evento_id, fotografo_id, capacidad_mb, capacidad_de_fotos) VALUES (?, ?, 0, 0)");
$stmt->execute([$evento_id, $fotografo_id]);

echo json_encode(['status'=>'success','message'=>'Postulación registrada correctamente.']);
