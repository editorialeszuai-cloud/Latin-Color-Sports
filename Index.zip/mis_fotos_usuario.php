<?php
require 'vendor/autoload.php'; // Asegúrate de tener Firebase Admin SDK instalado vía Composer
require 'dbfotografos.php';

use Firebase\Auth\Token\Exception\InvalidToken;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Auth;

header('Content-Type: application/json');

// =====================
// Conectar a BD
// =====================
$pdo = conectar();

// =====================
// Obtener token de cabecera
// =====================
$idToken = $_SERVER['HTTP_AUTHORIZATION'] ?? null;
if (!$idToken) {
    http_response_code(401);
    echo json_encode(['error' => 'Token no proporcionado']);
    exit;
}

try {
    // =====================
    // Inicializar Firebase Admin
    // =====================
    $factory = (new Factory)->withServiceAccount('ruta/a/tu/firebase-service-account.json');
    $auth = $factory->createAuth();

    // =====================
    // Verificar token
    // =====================
    $verifiedToken = $auth->verifyIdToken($idToken);
    $firebase_uid = $verifiedToken->claims()->get('sub');

    // =====================
    // Consultar fotos del usuario
    // =====================
    $stmt = $pdo->prepare("
        SELECT 
            f.id AS foto_id,
            f.url AS nombre_archivo,
            e.titulo AS evento_titulo,
            u.nombre AS fotografo_nombre,
            c.id AS compra_id,
            c.fecha_compra
        FROM compras c
        INNER JOIN detalle_compras dc ON dc.id_compra = c.id
        INNER JOIN fotos f ON f.id = dc.id_foto
        INNER JOIN postulaciones p ON p.id = f.postulacion_id
        INNER JOIN eventos e ON e.id = p.evento_id
        INNER JOIN usuarios u ON u.id = p.usuario_id
        WHERE c.estado = 'Aceptada'
          AND f.tipo = 'image/jpeg'
          AND u.firebase_uid = :uid
        ORDER BY c.fecha_compra DESC
    ");
    $stmt->execute(['uid' => $firebase_uid]);
    $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($fotos);

} catch (InvalidToken $e) {
    http_response_code(401);
    echo json_encode(['error' => 'Token inválido: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error del servidor: ' . $e->getMessage()]);
}
