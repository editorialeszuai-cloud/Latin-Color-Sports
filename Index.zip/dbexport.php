<?php
// conexion.php
$host = "database-1.c8302k404lkf.us-east-1.rds.amazonaws.com";      // o el host de tu servidor MySQL
$usuario = "root";  // cámbialo por tu usuario real
$contrasena = "DannyCruxTecnoLoad!#"; // cámbialo por tu contraseña real
$base_datos = "latincolors";  // cámbialo por el nombre real de tu base de datos

$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

// Verificar si hay error en la conexión
if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

// Configurar codificación UTF-8
$conexion->set_charset("utf8");
?>
