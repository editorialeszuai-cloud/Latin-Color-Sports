<?php
// Habilita los errores de PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "¡El servidor PHP funciona!";
// Simula un error para ver si se muestra
trigger_error("Si ves esto, el manejo de errores funciona.", E_USER_NOTICE);
?>