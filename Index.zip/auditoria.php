<?php
// auditoria.php
require_once 'dbfotografos.php';
date_default_timezone_set('America/Bogota');

// 1. Lógica para Bloquear / Desbloquear IPs via POST/AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'], $_POST['ip'])) {
    $ip_target = $_POST['ip'];
    if ($_POST['accion'] === 'bloquear') {
        $stmt_block = $pdo->prepare("INSERT IGNORE INTO ips_bloqueadas (ip) VALUES (?)");
        $stmt_block->execute([$ip_target]);
    } elseif ($_POST['accion'] === 'desbloquear') {
        $stmt_unblock = $pdo->prepare("DELETE FROM ips_bloqueadas WHERE ip = ?");
        $stmt_unblock->execute([$ip_target]);
    }
    
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(['status' => 'success']);
        exit;
    }
    header("Location: auditoria.php");
    exit;
}

// 2. Manejo de Filtros (Fechas y Omitir Bloqueadas)
$fecha_inicio = $_GET['fecha_inicio'] ?? date('Y-m-01');
$fecha_fin    = $_GET['fecha_fin'] ?? date('Y-m-d');
$omitir_bloqueadas = isset($_GET['omitir_bloqueadas']) && $_GET['omitir_bloqueadas'] === '1';

// Construcción del filtro WHERE dinámico para las estadísticas del resumen
$where_stats = "WHERE DATE(a.fecha_hora) BETWEEN ? AND ?";
if ($omitir_bloqueadas) {
    $where_stats .= " AND b.ip IS NULL";
}

// 3. Consulta de Ranking por IP (Con corrección de Collation incrustada)
$sql = "SELECT 
            a.ip_acceso, 
            COUNT(*) as total_visitas, 
            MAX(a.fecha_hora) as ultima_conexion, 
            MAX(a.nombre_usuario) as usuario_referencia,
            MAX(a.rol) as ultimo_rol,
            IF(b.ip IS NOT NULL, 1, 0) as esta_bloqueada
        FROM auditoria_navegacion a
        LEFT JOIN ips_bloqueadas b ON a.ip_acceso = b.ip COLLATE utf8mb4_general_ci
        WHERE DATE(a.fecha_hora) BETWEEN ? AND ?
        GROUP BY a.ip_acceso 
        ORDER BY total_visitas DESC 
        LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute([$fecha_inicio, $fecha_fin]);
$logs = $stmt->fetchAll();

// 4. Obtener Lista de IPs Bloqueadas
$ips_bloqueadas_lista = $pdo->query("SELECT * FROM ips_bloqueadas ORDER BY fecha_bloqueo DESC")->fetchAll();

// 5. Estadísticas Generales dinámicas por fecha (Opcionalmente excluyendo bloqueadas)
$total_periodo = $pdo->prepare("
    SELECT COUNT(*) 
    FROM auditoria_navegacion a
    LEFT JOIN ips_bloqueadas b ON a.ip_acceso = b.ip COLLATE utf8mb4_general_ci
    $where_stats
");
$total_periodo->execute([$fecha_inicio, $fecha_fin]);
$total_mes = $total_periodo->fetchColumn();

$ips_unicas_periodo = $pdo->prepare("
    SELECT COUNT(DISTINCT a.ip_acceso) 
    FROM auditoria_navegacion a
    LEFT JOIN ips_bloqueadas b ON a.ip_acceso = b.ip COLLATE utf8mb4_general_ci
    $where_stats
");
$ips_unicas_periodo->execute([$fecha_inicio, $fecha_fin]);
$ips_unicas_mes = $ips_unicas_periodo->fetchColumn();


// Totales Históricos Absolutos (Ignoran el rango de fecha, pero respetan el botón de omitir si está activo)
$where_historico = $omitir_bloqueadas ? "WHERE b.ip IS NULL" : "";

$total_historico = $pdo->query("
    SELECT COUNT(*) 
    FROM auditoria_navegacion a
    LEFT JOIN ips_bloqueadas b ON a.ip_acceso = b.ip COLLATE utf8mb4_general_ci
    $where_historico
")->fetchColumn();

$ips_unicas_total = $pdo->query("
    SELECT COUNT(DISTINCT a.ip_acceso) 
    FROM auditoria_navegacion a
    LEFT JOIN ips_bloqueadas b ON a.ip_acceso = b.ip COLLATE utf8mb4_general_ci
    $where_historico
")->fetchColumn();


// 6. Conteo Diario (Últimos 7 días)
$sql_diario = "SELECT DATE(a.fecha_hora) as dia, COUNT(*) as cuenta 
               FROM auditoria_navegacion a
               LEFT JOIN ips_bloqueadas b ON a.ip_acceso = b.ip COLLATE utf8mb4_general_ci
               WHERE DATE(a.fecha_hora) BETWEEN ? AND ?" . ($omitir_bloqueadas ? " AND b.ip IS NULL" : "") . "
               GROUP BY dia ORDER BY dia DESC LIMIT 7";
$stmt_diario = $pdo->prepare($sql_diario);
$stmt_diario->execute([$fecha_inicio, $fecha_fin]);
$diarios = $stmt_diario->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auditoría de Tráfico | Latin Color Sports</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-slate-950 p-4 md:p-10 text-slate-200">

    <div class="max-w-6xl mx-auto space-y-8">
        
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black uppercase tracking-tighter text-white italic">
                    Auditoría de <span class="text-orange-500">Accesos</span>
                </h1>
                <p class="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Análisis de tráfico por IP y control de seguridad</p>
            </div>
            <a href="soporte.php" class="bg-slate-800 hover:bg-slate-700 px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-slate-700">Volver</a>
        </div>

        <!-- Tarjetas de Estadísticas Ajustadas a las Fechas Seleccionadas -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div class="bg-slate-900 p-5 rounded-3xl border border-slate-800">
                <p class="text-[10px] uppercase text-slate-500 font-black tracking-[0.2em]">Visitas en el Periodo</p>
                <p class="text-2xl font-black text-white mt-1"><?= number_format($total_mes) ?></p>
            </div>
            <div class="bg-slate-900 p-5 rounded-3xl border border-slate-800">
                <p class="text-[10px] uppercase text-slate-500 font-black tracking-[0.2em]">IPs Únicas (Periodo)</p>
                <p class="text-2xl font-black text-orange-500 mt-1"><?= number_format($ips_unicas_mes) ?></p>
            </div>
            <div class="bg-slate-900 p-5 rounded-3xl border border-slate-800">
                <p class="text-[10px] uppercase text-slate-500 font-black tracking-[0.2em]">Total Histórico</p>
                <p class="text-2xl font-black text-white mt-1"><?= number_format($total_historico) ?></p>
            </div>
            <div class="bg-slate-900 p-5 rounded-3xl border border-slate-800">
                <p class="text-[10px] uppercase text-slate-500 font-black tracking-[0.2em]">Total IPs Únicas</p>
                <p class="text-2xl font-black text-orange-500 mt-1"><?= number_format($ips_unicas_total) ?></p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Formulario de Filtros con Botón de Omisión de IPs Bloqueadas -->
            <form method="GET" class="lg:col-span-2 bg-slate-900 p-6 rounded-3xl border border-slate-800 flex flex-wrap gap-4 items-end">
                <div class="flex-1 min-w-[140px]">
                    <label class="block text-[9px] uppercase font-black text-slate-500 mb-2">Desde</label>
                    <input type="date" name="fecha_inicio" value="<?= $fecha_inicio ?>" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm text-white focus:ring-2 focus:ring-orange-500 outline-none">
                </div>
                <div class="flex-1 min-w-[140px]">
                    <label class="block text-[9px] uppercase font-black text-slate-500 mb-2">Hasta</label>
                    <input type="date" name="fecha_fin" value="<?= $fecha_fin ?>" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm text-white focus:ring-2 focus:ring-orange-500 outline-none">
                </div>
                
                <!-- Toggle Switch para Omitir IPs Bloqueadas -->
                <div class="flex items-center space-x-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800 h-[46px] px-4 select-none">
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="omitir_bloqueadas" value="1" <?= $omitir_bloqueadas ? 'checked' : '' ?> class="sr-only peer" onchange="this.form.submit()">
                        <div class="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 peer-checked:after:bg-orange-500 after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-950 border peer-checked:border-orange-800/60 border-slate-700"></div>
                    </label>
                    <span class="text-[9px] uppercase font-black text-slate-400 tracking-wider">Omitir Bloqueadas</span>
                </div>

                <button type="submit" class="bg-orange-600 hover:bg-orange-500 px-8 h-[46px] rounded-xl text-[10px] font-black uppercase tracking-widest text-white transition-all shadow-lg shadow-orange-900/20">
                    Filtrar
                </button>
            </form>

            <div class="bg-slate-900 p-6 rounded-3xl border border-slate-800">
                <p class="text-[9px] font-black text-slate-500 uppercase mb-4 tracking-widest">Actividad en el Periodo (Días)</p>
                <div class="flex gap-2 overflow-x-auto pb-1 chunk-scroll">
                    <?php if(empty($diarios)): ?>
                        <div class="w-full text-center text-slate-600 text-[10px] uppercase font-bold py-2">Sin registros</div>
                    <?php else: ?>
                        <?php foreach($diarios as $d): ?>
                            <div class="flex-1 min-w-[45px] bg-slate-950 p-2 rounded-lg text-center border border-slate-800">
                                <span class="block text-[8px] text-slate-600"><?= date('d/m', strtotime($d['dia'])) ?></span>
                                <span class="font-bold text-xs text-orange-500"><?= $d['cuenta'] ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-2xl">
            <h2 class="text-lg font-black uppercase tracking-tight text-white mb-4 italic"><i class="fas fa-chart-line text-orange-500 mr-2"></i> Tráfico por IP Detectado</h2>
            <table id="tablaLogsIP" class="w-full text-sm text-left">
                <thead>
                    <tr class="text-slate-500 border-b border-slate-800">
                        <th class="p-4 uppercase tracking-wider text-[10px]">Dirección IP</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Visitas</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Último Usuario</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Última Conexión</th>
                        <th class="p-4 uppercase tracking-wider text-[10px] text-center">Acción</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800">
                    <?php foreach($logs as $log): ?>
                    <tr class="hover:bg-slate-800/50 transition-all">
                        <td class="p-4 font-mono font-bold text-slate-100">
                            <i class="fas fa-network-wired <?= $log['esta_bloqueada'] ? 'text-red-500' : 'text-orange-500/50' ?> mr-2"></i><?= $log['ip_acceso'] ?>
                        </td>
                        <td class="p-4"><span class="bg-orange-500/10 text-orange-500 px-3 py-1 rounded-lg font-black text-xs"><?= $log['total_visitas'] ?></span></td>
                        <td class="p-4">
                            <div class="flex flex-col">
                                <span class="text-slate-200 font-bold text-sm"><?= htmlspecialchars($log['usuario_referencia'] ?? 'Invitado') ?></span>
                                <span class="text-[9px] text-slate-500 uppercase font-black tracking-widest"><?= $log['ultimo_rol'] ?? 'N/A' ?></span>
                            </div>
                        </td>
                        <td class="p-4 text-xs font-mono text-slate-400"><?= $log['ultima_conexion'] ?></td>
                        <td class="p-4 text-center">
                            <?php if ($log['esta_bloqueada']): ?>
                                <button onclick="gestionarIP('<?= $log['ip_acceso'] ?>', 'desbloquear')" class="bg-red-950/40 hover:bg-red-900 border border-red-800 text-red-400 text-[9px] font-black uppercase tracking-wider px-3 py-1.5 rounded-lg transition-all">
                                    Bloqueada
                                </button>
                            <?php else: ?>
                                <button onclick="gestionarIP('<?= $log['ip_acceso'] ?>', 'bloquear')" class="bg-slate-950 hover:bg-orange-600 border border-slate-800 hover:border-orange-500 text-slate-400 hover:text-white text-[9px] font-black uppercase tracking-wider px-3 py-1.5 rounded-lg transition-all">
                                    Bloquear
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-2xl border-t-4 border-t-red-900/50">
            <div class="mb-4">
                <h2 class="text-lg font-black uppercase tracking-tight text-white italic"><i class="fas fa-ban text-red-500 mr-2"></i> Lista Negra / IPs Bloqueadas</h2>
                <p class="text-slate-500 text-xs mt-0.5">Estas direcciones IP tienen el acceso restringido a la plataforma.</p>
            </div>
            <table id="tablaIPsBloqueadas" class="w-full text-sm text-left">
                <thead>
                    <tr class="text-slate-500 border-b border-slate-800">
                        <th class="p-4 uppercase tracking-wider text-[10px]">Dirección IP</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Fecha de Restricción</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Motivo</th>
                        <th class="p-4 uppercase tracking-wider text-[10px] text-center">Gestión</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800">
                    <?php if (empty($ips_bloqueadas_lista)): ?>
                        <tr>
                            <td colspan="4" class="p-8 text-center text-slate-500 text-xs uppercase font-bold tracking-widest">No hay IPs restringidas actualmente.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach($ips_bloqueadas_lista as $blocked): ?>
                        <tr class="hover:bg-red-950/10 transition-all">
                            <td class="p-4 font-mono font-bold text-red-400"><i class="fas fa-shield-alt mr-2"></i><?= $blocked['ip'] ?></td>
                            <td class="p-4 text-xs text-slate-400 font-mono"><?= $blocked['fecha_bloqueo'] ?></td>
                            <td class="p-4 text-xs text-slate-300 italic"><?= htmlspecialchars($blocked['motivo'] ?? 'Restricción manual') ?></td>
                            <td class="p-4 text-center">
                                <button onclick="gestionarIP('<?= $blocked['ip'] ?>', 'desbloquear')" class="bg-slate-950 hover:bg-green-600 border border-slate-800 hover:border-green-500 text-slate-400 hover:text-white text-[9px] font-black uppercase tracking-wider px-3 py-1.5 rounded-lg transition-all">
                                    Permitir Acceso
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // Inicializar Tabla Principal
            $('#tablaLogsIP').DataTable({
                order: [[1, 'desc']],
                pageLength: 20,
                language: { url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' },
                drawCallback: function() {
                    $('.dataTables_wrapper').addClass('text-slate-400');
                    $('input[type="search"]').addClass('bg-slate-950 border-slate-700 rounded-lg p-2 text-slate-200 px-3 mb-4 outline-none focus:ring-1 focus:ring-orange-500');
                }
            });

            // Inicializar Tabla de Lista Negra
            if ($('#tablaIPsBloqueadas tbody tr').length > 1 || !$('#tablaIPsBloqueadas .tracking-widest').length) {
                $('#tablaIPsBloqueadas').DataTable({
                    order: [[1, 'desc']],
                    pageLength: 10,
                    language: { url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' },
                    drawCallback: function() {
                        $('.dataTables_wrapper').addClass('text-slate-400');
                        $('input[type="search"]').addClass('bg-slate-950 border-slate-700 rounded-lg p-2 text-slate-200 px-3 mb-4 outline-none focus:ring-1 focus:ring-red-500');
                    }
                });
            }
        });

        // Interacción Asíncrona para Bloquear / Desbloquear sin romper el estado del filtro
        function gestionarIP(ip, accion) {
            if (confirm(`¿Estás seguro de que deseas ${accion} la IP: ${ip}?`)) {
                $.post('auditoria.php', { ip: ip, accion: accion }, function() {
                    location.reload();
                });
            }
        }
    </script>
</body>
</html>