<?php
$host = 'database-1.c8302k404lkf.us-east-1.rds.amazonaws.com'; // ej: database-1.xyz.us-east-1.rds.amazonaws.com
$user = 'admin';
$pass = 'DannyCrux2026!#';
$db   = 'latincolors';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
echo "¡Conexión exitosa a RDS MySQL!";
?>
