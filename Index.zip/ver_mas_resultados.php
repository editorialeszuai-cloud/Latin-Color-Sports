<?php
require_once 'dbfotografos.php';

$evento_id = isset($_GET['evento_id']) ? (int)$_GET['evento_id'] : 0;
$token     = $_GET['token'] ?? null;

$tmpFile = __DIR__ . "/tmp/faces_busqueda_$token.json";

if (!$evento_id || !$token || !file_exists($tmpFile)) {
    die("Acceso no v��lido o resultados expirados.");
}

// Leer resultados desde archivo
$resultados = json_decode(file_get_contents($tmpFile), true);
?>

<?php
require_once 'navusuriopremium.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Resultados Completos</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
<style>
.foto-img {
    cursor: pointer;
}
.nivel-tag {
    cursor: default; /* no clicable */
}

.grid-container { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 12px; }
.foto-container { position: relative; overflow: hidden; border-radius: 8px; }
.foto-img { width: 100%; display: block; border-radius: 8px; transition: transform 0.2s; }
.foto-container:hover .foto-img { transform: scale(1.05); }
.nivel-tag { position: absolute; top: 5px; left: 5px; background: rgba(0,0,0,0.6); color: #fff; padding: 2px 6px; font-size: 0.8rem; border-radius: 4px; }
</style>
</head>
<body class="bg-gray-100 p-4">

<h1 class="text-2xl font-bold mb-4">Resultados completos del evento</h1>

<div class="grid-container">
<?php foreach ($resultados as $f): ?>
  <div class="foto-container">
    <a href="ver_foto.php?id=<?= $f['id'] ?>">
        <img class="foto-img" src="foto_watermark.php?img=<?= urlencode($f['url']) ?>&w=300" alt="Foto <?= $f['id'] ?>">
    </a>
    <div class="nivel-tag"><?= htmlspecialchars($f['nivel']) ?></div>
</div>

<?php endforeach; ?>
</div>

<script>
// Evitar clic derecho sobre todas las im��genes con clase .foto-img
document.querySelectorAll('.foto-img').forEach(img => {
    img.addEventListener('contextmenu', e => {
        e.preventDefault();
        alert('Clic derecho deshabilitado en esta imagen.');
    });
});
</script>
</body>
</html>
