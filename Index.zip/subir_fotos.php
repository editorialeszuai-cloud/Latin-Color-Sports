<?php
require 'db.php';

$galeria_id = $_GET['galeria_id'] ?? null;

// Obtener info de la galería
$galeria = null;
if ($galeria_id) {
    $stmt = $pdo->prepare("SELECT g.*, e.titulo AS evento, u.nombre AS fotografo
                           FROM galerias g
                           JOIN eventos e ON g.evento_id = e.id
                           JOIN usuarios u ON g.fotografo_id = u.id
                           WHERE g.id = ?");
    $stmt->execute([$galeria_id]);
    $galeria = $stmt->fetch();
}

// Procesar subida de fotos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto']) && $galeria_id) {
    $file = $_FILES['foto'];
    $descripcion = $_POST['descripcion'] ?? '';

    if ($file['error'] === 0) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $nombre_archivo = uniqid() . "." . $ext;
        $ruta_destino = 'uploads/' . $nombre_archivo;

        if (!is_dir('uploads')) mkdir('uploads', 0777, true);

        if (move_uploaded_file($file['tmp_name'], $ruta_destino)) {
            $stmt = $pdo->prepare("INSERT INTO fotos (galeria_id, nombre_archivo, descripcion) VALUES (?, ?, ?)");
            $stmt->execute([$galeria_id, $nombre_archivo, $descripcion]);
            $mensaje = "Foto subida con éxito.";
        } else {
            $mensaje = "Error al mover el archivo.";
        }
    } else {
        $mensaje = "Error en la subida del archivo.";
    }
}

// Obtener fotos de la galería
$fotos = [];
if ($galeria_id) {
    $stmt = $pdo->prepare("SELECT * FROM fotos WHERE galeria_id = ?");
    $stmt->execute([$galeria_id]);
    $fotos = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Subir Fotos a Galería</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="p-6 bg-gray-100">

<h1 class="text-2xl font-bold mb-4">Galería: <?= htmlspecialchars($galeria['titulo'] ?? '') ?></h1>
<p class="mb-4 text-gray-600">Evento: <?= htmlspecialchars($galeria['evento'] ?? '') ?> | Fotógrafo: <?= htmlspecialchars($galeria['fotografo'] ?? '') ?></p>

<?php if(isset($mensaje)): ?>
    <p class="mb-4 p-2 bg-green-200 text-green-800 rounded"><?= htmlspecialchars($mensaje) ?></p>
<?php endif; ?>

<!-- Formulario subir foto -->
<form method="POST" enctype="multipart/form-data" class="mb-6 flex gap-2 items-center">
    <input type="file" name="foto" required class="border rounded p-1">
    <input type="text" name="descripcion" placeholder="Descripción (opcional)" class="border rounded p-1 flex-1">
    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">Subir Foto</button>
</form>

<!-- Mostrar fotos subidas -->
<div class="grid grid-cols-3 gap-4">
    <?php foreach($fotos as $f): ?>
        <div class="bg-white rounded shadow overflow-hidden">
            <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>" class="w-full h-48 object-cover">
            <div class="p-2">
                <p class="text-sm text-gray-700"><?= htmlspecialchars($f['descripcion']) ?></p>
                <p class="text-xs text-gray-500"><?= $f['fecha_subida'] ?></p>
            </div>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>
