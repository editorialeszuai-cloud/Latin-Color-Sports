<?php
session_start();
require_once 'dbfotografos.php'; // Conexión PDO

header('Content-Type: text/html; charset=utf-8');

// ======== Obtener eventos con metodo_monetizacion = 'No Pago' (ordenados por título) ========
$eventos = $pdo->query("
    SELECT * 
    FROM eventos 
    WHERE metodo_monetizacion = 'No Pago' 
    ORDER BY titulo ASC
")->fetchAll(PDO::FETCH_ASSOC);

$evento_map = [];
foreach($eventos as $e) $evento_map[$e['id']] = $e;

// ======== Obtener galerías asociadas solo a esos eventos ========
$galerias = $pdo->query("
    SELECT g.* 
    FROM galerias g
    INNER JOIN eventos e ON e.id = g.evento_id
    WHERE e.metodo_monetizacion = 'No Pago'
    ORDER BY e.titulo ASC, g.fecha_creacion DESC
")->fetchAll(PDO::FETCH_ASSOC);

// ======== Obtener fotos de esas galerías ========
if(!empty($galerias)){
    $galeria_ids = implode(',', array_column($galerias, 'id'));
    $fotos = $pdo->query("SELECT * FROM fotos WHERE galeria_id IN ($galeria_ids)")->fetchAll(PDO::FETCH_ASSOC);
} else {
    $fotos = [];
}

// ======== Mapear fotos por galería ========
$fotos_map = [];
foreach ($fotos as $f) $fotos_map[$f['galeria_id']][] = $f;

// ======== Preparar colección del usuario (si firebase_uid viene por POST) ========
$colecciones = [];
$fotos_usuario_map = [];
$firebase_uid_post = $_POST['firebase_uid'] ?? '';
if($firebase_uid_post){
    $stmt = $pdo->prepare("SELECT * FROM galerias_usuario WHERE firebase_uid = ? ORDER BY fecha_agregada DESC");
    $stmt->execute([$firebase_uid_post]);
    $colecciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach($colecciones as $c){
        $stmt2 = $pdo->prepare("SELECT * FROM fotos_usuario WHERE galeria_usuario_id = ?");
        $stmt2->execute([$c['id']]);
        $fotos_usuario_map[$c['id']] = $stmt2->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Galerías y Colecciones</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
img { cursor: pointer; }
#photoModal { display: none; }
</style>
</head>
<body class="p-6 bg-gray-100">

<h1 class="text-3xl font-bold mb-6">Galerías de Eventos Patrocinados</h1>

<div id="galerias" class="space-y-8">
<?php 
$galerias_por_evento = [];
foreach($galerias as $g) $galerias_por_evento[$g['evento_id']][] = $g;

// Ordenar por título del evento (por si el SQL no lo asegura completamente)
uksort($galerias_por_evento, function($a, $b) use ($evento_map) {
    return strcasecmp($evento_map[$a]['titulo'] ?? '', $evento_map[$b]['titulo'] ?? '');
});

foreach($galerias_por_evento as $evento_id => $gal_list): 
    $evento = $evento_map[$evento_id] ?? null;
?>
    <div class="bg-gray-50 p-4 rounded shadow-sm">
        <h2 class="text-2xl font-semibold text-blue-700 mb-3">
            <?= htmlspecialchars($evento['titulo'] ?? 'Evento sin nombre') ?>
        </h2>

        <div class="grid grid-cols-3 gap-4">
        <?php foreach($gal_list as $g): ?>
            <div class="bg-white p-3 rounded shadow">
                <h3 class="font-semibold text-lg">
                    <?= htmlspecialchars($g['titulo']) ?> 
                    - <span class="text-green-600 font-bold">$<?= number_format($g['precio'],2) ?></span>
                </h3>
                <div class="grid grid-cols-3 gap-1 mt-2">
                <?php foreach($fotos_map[$g['id']] ?? [] as $f): ?>
                    <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>" 
                         alt="<?= htmlspecialchars($f['descripcion']) ?>" 
                         class="w-full h-24 object-cover rounded"
                         onclick="openModal('uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>','<?= htmlspecialchars(addslashes($f['descripcion'])) ?>')">
                <?php endforeach; ?>
                </div>
                <div class="mt-2">
                    <button class="bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700 w-full add-btn" data-gid="<?= $g['id'] ?>">
                        Agregar a mi colección
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
<?php endforeach; ?>
</div>



<hr class="my-6">

<h1 class="text-3xl font-bold mb-6">Mi Colección Privada</h1>
<div id="coleccionUsuario">
<?php foreach($colecciones as $c): ?>
<div class="bg-white p-3 mb-4 rounded shadow">
    <h2 class="font-semibold"><?= htmlspecialchars($c['titulo']) ?></h2>
    <div class="grid grid-cols-3 gap-1 mt-2">
    <?php foreach($fotos_usuario_map[$c['id']] ?? [] as $f): ?>
        <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>" 
             alt="<?= htmlspecialchars($f['descripcion']) ?>" 
             class="w-full h-24 object-cover rounded"
             onclick="openModal('uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>','<?= htmlspecialchars(addslashes($f['descripcion'])) ?>')">
    <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>
</div>

<!-- Modal -->
<div id="photoModal" class="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 hidden">
    <div class="relative bg-white rounded shadow-lg max-w-3xl w-full p-4">
        <button class="absolute top-2 right-2 text-gray-700 text-xl font-bold" onclick="closeModal()">×</button>
        <img id="modalImage" src="" class="w-full h-auto rounded">
        <p id="modalDesc" class="mt-2 text-gray-700"></p>
        <a id="downloadBtn" href="#" download class="mt-2 inline-block bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">Descargar</a>
    </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

let firebase_uid = '';
const coleccionDiv = document.getElementById('coleccionUsuario');

onAuthStateChanged(auth, async (user) => {
    if(user){
        const token = await user.getIdToken();
        const res = await fetch('get_user_info.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({ firebase_token: token })
        });
        const data = await res.json();
        if(data.status==='success' && data.user){
            firebase_uid = data.user.firebase_uid;
            cargarColeccion();
            activarBotones();
        }
    } else alert('No autenticado');
});

// ======== Agregar a colección ========
function activarBotones(){
    document.querySelectorAll('.add-btn').forEach(b=>{
        b.addEventListener('click', async ()=>{
            if(!firebase_uid) return;
            const fd = new FormData();
            fd.append('firebase_uid', firebase_uid);
            fd.append('galeria_id', b.dataset.gid);

            const res = await fetch('agregar_galeria_usuario.php', {
                method:'POST',
                body: fd
            });
            const data = await res.json();
            if(data.status==='ok'){
                alert('Galería agregada a tu colección');
                cargarColeccion();
            } else {
                alert('Error: '+(data.msg||'No se pudo agregar'));
            }
        });
    });
}

// ======== Cargar colección del usuario ========
async function cargarColeccion(){
    const fd = new FormData();
    fd.append('firebase_uid', firebase_uid);
    const res = await fetch(window.location.href, {method:'POST', body: fd});
    const html = await res.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const coleccion = doc.getElementById('coleccionUsuario');
    coleccionDiv.innerHTML = coleccion ? coleccion.innerHTML : '';
}

// ======== Modal ========
const modal = document.getElementById('photoModal');
function openModal(src, desc){
    document.getElementById('modalImage').src = src;
    document.getElementById('modalDesc').innerText = desc;
    document.getElementById('downloadBtn').href = src;
    modal.classList.remove('hidden');
}
function closeModal(){ modal.classList.add('hidden'); }

</script>

</body>
</html>
