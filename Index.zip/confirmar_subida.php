<?php
// confirmar_subida.php
header('Content-Type: application/json');
require 'dbfotografos.php'; // conexión PDO a la base de datos

$usuario_id = $_POST['usuario_id'] ?? null;
$postulacion_id = $_POST['postulacion_id'] ?? null;
$subido = $_POST['subido'] ?? 'no';

if (!$usuario_id || !$postulacion_id) {
    echo json_encode(['success' => false, 'message' => 'Faltan parámetros.']);
    exit;
}

try {
    // Forzar modo de error de PDO
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Revisar si ya existe registro
    $stmt = $db->prepare("SELECT id FROM confirmaciones WHERE usuario_id=? AND postulacion_id=?");
    $stmt->execute([$usuario_id, $postulacion_id]);
    $existe = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existe) {
        // Actualizar registro existente
        $stmt = $db->prepare("UPDATE confirmaciones SET subido=?, fecha=NOW() WHERE id=?");
        $stmt->execute([$subido, $existe['id']]);
    } else {
        // Insertar nuevo registro
        $stmt = $db->prepare("INSERT INTO confirmaciones (usuario_id, postulacion_id, subido) VALUES (?, ?, ?)");
        $stmt->execute([$usuario_id, $postulacion_id, $subido]);
    }

    echo json_encode(['success' => true, 'message' => 'Confirmación registrada correctamente.']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error en la base de datos: ' . $e->getMessage()]);
}
