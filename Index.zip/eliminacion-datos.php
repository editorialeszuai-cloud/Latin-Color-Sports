<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminación de Datos de Usuario | Latin Group SAS</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">

    <!-- Fuente moderna -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f3f4f6, #e5e7eb);
            color: #111827;
            margin: 0;
            padding: 0;
        }

        header {
            background: #1e40af;
            color: white;
            text-align: center;
            padding: 3rem 1rem 2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        header p {
            font-size: 1rem;
            opacity: 0.9;
        }

        main {
            max-width: 900px;
            margin: 2rem auto;
            background: white;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.1);
        }

        h2 {
            color: #1e3a8a;
            margin-top: 2rem;
            margin-bottom: 1rem;
            font-weight: 700;
            border-left: 5px solid #3b82f6;
            padding-left: 10px;
        }

        p, li {
            line-height: 1.7;
            font-size: 1rem;
            color: #374151;
        }

        ul {
            margin-left: 1.5rem;
            margin-bottom: 1rem;
        }

        a {
            color: #2563eb;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        footer {
            text-align: center;
            background: #1e40af;
            color: white;
            padding: 1.5rem 1rem;
            margin-top: 3rem;
            font-size: 0.9rem;
        }

        @media (max-width: 600px) {
            main {
                margin: 1rem;
                padding: 1.5rem;
            }
            header h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Eliminación de Datos de Usuario</h1>
        <p>Latin Group SAS – Última actualización: 21 de octubre de 2025</p>
    </header>

    <main>
        <p>En <strong>Latin Group SAS</strong>, respetamos tu derecho a la privacidad y al control de tus datos personales. Si deseas eliminar tu cuenta o los datos asociados a ella, este documento explica el proceso y las condiciones para hacerlo.</p>

        <h2>1. ¿Qué datos se eliminan?</h2>
        <p>Al solicitar la eliminación de tus datos personales, se eliminarán de forma permanente:</p>
        <ul>
            <li>Tu perfil de usuario (nombre, correo electrónico, rol y preferencias).</li>
            <li>Historial de compras, interacciones y fotografías adquiridas.</li>
            <li>Cualquier información asociada a tu cuenta en nuestros sistemas (Firebase y bases de datos internas).</li>
        </ul>
        <p>Algunos datos financieros procesados por pasarelas de pago externas no podrán eliminarse directamente, ya que son gestionados por dichas plataformas conforme a sus políticas legales y fiscales.</p>

        <h2>2. ¿Cómo solicitar la eliminación de tus datos?</h2>
        <p>Puedes solicitar la eliminación de tu cuenta y datos personales de las siguientes formas:</p>
        <ul>
            <li>Enviando un correo electrónico a <a href="mailto:privacidad@latingroupsas.com">privacidad@latingroupsas.com</a> con el asunto <strong>“Eliminación de mis datos personales”</strong>.</li>
            <li>Incluyendo en el correo tu nombre completo, dirección de correo electrónico registrada y, si lo deseas, una breve razón de la solicitud (opcional).</li>
        </ul>
        <p>También podrás hacerlo desde la aplicación móvil, en la sección <strong>Configuración → Eliminar cuenta</strong>, donde podrás confirmar la eliminación permanente.</p>

        <h2>3. Tiempo de respuesta</h2>
        <p>Una vez recibida tu solicitud, nuestro equipo verificará la identidad del titular y procesará la eliminación dentro de un plazo máximo de <strong>10 días hábiles</strong>.</p>

        <h2>4. Efectos de la eliminación</h2>
        <ul>
            <li>No podrás volver a acceder con las mismas credenciales.</li>
            <li>Las fotografías compradas y asociadas a tu cuenta se eliminarán definitivamente.</li>
            <li>Si deseas volver a usar nuestros servicios, deberás crear una nueva cuenta.</li>
        </ul>

        <h2>5. Conservación limitada</h2>
        <p>En cumplimiento con la legislación colombiana (Ley 1581 de 2012 y Decreto 1377 de 2013), algunos datos mínimos podrán conservarse temporalmente con fines legales o contables, pero no se usarán para ningún otro propósito.</p>

        <h2>6. Contacto</h2>
        <p>Para cualquier consulta sobre la eliminación de tus datos, comunícate con nuestro equipo de protección de datos:</p>
        <p><strong>Latin Group SAS</strong><br>
        📍 Medellín, Colombia<br>
        📧 <a href="mailto:privacidad@latingroupsas.com">privacidad@latingroupsas.com</a><br>
        📞 +57 300 000 0000</p>

        <p>Estamos comprometidos con la transparencia y la protección de tu información.</p>
    </main>

    <footer>
        © 2025 Latin Group SAS. Todos los derechos reservados.
    </footer>
</body>
</html>
