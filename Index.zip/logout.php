<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Iniciar Sesión | Latin Color Sports</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;900&display=swap');
body { font-family: 'Inter', sans-serif; background: #0a0a0a; }
.fade-in { animation: fadeIn 0.4s ease-out; }
@keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
input { outline: none; }
input:focus { border-color: #f97316 !important; box-shadow: 0 0 0 3px rgba(249,115,22,0.15); }
</style>
</head>

<body class="min-h-screen flex items-center justify-center p-4">

  <div class="w-full max-w-sm fade-in">

    <!-- LOGO -->
    <div class="text-center mb-8">
 <a href="index.php"> <img src="../uploads/LATIN-SPORTS.png" class="w-12 h-12 rounded-xl mx-auto mb-3" onerror="this.style.display='none'"></a>
      <h1 class="text-white font-black text-xl uppercase tracking-widest">Latin Color Sports</h1>
      <p class="text-white/30 text-xs mt-1">Inicia sesión para continuar</p>
    </div>

    <!-- CARD -->
    <div class="bg-white/5 border border-white/10 rounded-2xl p-6">

      <!-- MENSAJE -->
      <div id="messageBox" class="hidden mb-4 p-3 rounded-xl text-xs font-bold"></div>

      <!-- SOCIALES -->
      <div class="space-y-2 mb-5">
        <button id="googleLoginButton"
          class="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-white text-gray-800 font-bold text-sm hover:bg-gray-100 active:scale-95 transition-all">
          <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.08 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-3.59-13.46-8.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
          Continuar con Google
        </button>
        <button id="facebookLoginButton"
          class="hidden w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-[#1877f2] text-white font-bold text-sm hover:bg-[#1565d8] active:scale-95 transition-all">
          <svg width="18" height="18" fill="white" viewBox="0 0 24 24"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.235 2.686.235v2.97h-1.513c-1.491 0-1.956.93-1.956 1.886v2.269h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>
          Continuar con Facebook
        </button>
      </div>

      <div class="flex items-center gap-3 mb-5">
        <div class="h-px bg-white/10 flex-1"></div>
        <span class="text-white/20 text-[10px] uppercase font-black tracking-widest">o con email</span>
        <div class="h-px bg-white/10 flex-1"></div>
      </div>

      <!-- FORM EMAIL -->
      <form id="loginForm" class="space-y-3">
        <input type="email" id="email" required placeholder="Email"
          class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder-white/20 transition-all">
        <input type="password" id="password" required placeholder="Contraseña"
          class="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder-white/20 transition-all">
        <button type="submit" id="submitButton"
          class="w-full py-3 rounded-xl bg-orange-500 hover:bg-orange-400 active:scale-95 text-white font-black text-sm uppercase tracking-widest transition-all shadow-lg shadow-orange-500/20 disabled:opacity-50">
          Iniciar Sesión
        </button>
      </form>

      <a href="forgot-password.html"
        class="block text-center text-xs text-white/30 hover:text-orange-400 mt-3 transition-colors">
        ¿Olvidaste tu contraseña?
      </a>
    </div>

    <!-- REGISTRO -->
    <button onclick="window.location.href='registro.html'"
      class="w-full mt-3 py-3 rounded-xl bg-transparent border border-white/10 text-white/40 hover:border-orange-500/40 hover:text-orange-400 font-bold text-sm uppercase tracking-widest transition-all">
      Crear una cuenta
    </button>

  </div>

<!-- 🔸 SCRIPT -->
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { 
  getAuth, signInWithEmailAndPassword, GoogleAuthProvider, FacebookAuthProvider,
  signInWithPopup, onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// 🔧 Configuración Firebase
const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Elementos
const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const submitButton = document.getElementById('submitButton');
const googleLoginButton = document.getElementById('googleLoginButton');
const facebookLoginButton = document.getElementById('facebookLoginButton');
const messageBox = document.getElementById('messageBox');

function displayMessage(message, type = 'success') {
  messageBox.textContent = message;
  messageBox.classList.remove('hidden', 'bg-red-100', 'bg-green-100', 'text-red-800', 'text-green-800');
  if (type === 'error') messageBox.classList.add('bg-red-100', 'text-red-800');
  else messageBox.classList.add('bg-green-100', 'text-green-800');
}

function setLoading(isLoading) {
  submitButton.disabled = isLoading;
  googleLoginButton.disabled = isLoading;
  facebookLoginButton.disabled = isLoading;
  submitButton.textContent = isLoading ? 'Cargando...' : 'Iniciar Sesión';
}

// 🔍 Obtener rol desde backend
async function fetchRoleFromBackend(uid) {
  try {
    const response = await fetch(`getRole.php?uid=${encodeURIComponent(uid)}`);
    if (!response.ok) throw new Error('Error al conectar con la API de roles.');
    const data = await response.json();
    if (!data.rol) throw new Error('Rol no definido en el backend.');
    return data.rol.trim().toLowerCase();
  } catch (error) {
    console.error(error);
    return 'cliente';
  }
}

// 🔄 Redirección según rol
async function loadRoleAndRedirect(user) {
  try {
    displayMessage('Login exitoso. Verificando tu rol...', 'success');
    setLoading(true);
    const role = await fetchRoleFromBackend(user.uid);
    console.log(`Rol verificado: "${role}"`);

    const rutas = {
      admin: 'menu.php',
      fotografo: 'menu_fotografo.php',
      organizador: 'nav_organizador.php',
      cliente: 'nav_usuarios.php',
      comercial: 'nav_comercial.php'
    };

    window.location.href = rutas[role] || 'dashboard.html';
  } catch (error) {
    console.error(error);
    window.location.href = 'dashboard.html';
  } finally {
    setLoading(false);
  }
}

// 🔐 Login con Email
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  setLoading(true);
  try {
    const userCredential = await signInWithEmailAndPassword(auth, emailInput.value, passwordInput.value);
    await loadRoleAndRedirect(userCredential.user);
  } catch (error) {
    setLoading(false);
    let msg = 'Error de login.';
    if (error.code === 'auth/user-not-found') msg = 'El usuario no existe.';
    if (error.code === 'auth/wrong-password') msg = 'Contraseña incorrecta.';
    if (error.code === 'auth/invalid-email') msg = 'Formato de email inválido.';
    displayMessage(msg, 'error');
  }
});

// 🌐 Login con Google o Facebook
async function handleSocialLogin(provider) {
  setLoading(true);
  messageBox.classList.add('hidden');
  try {
    const userCredential = await signInWithPopup(auth, provider);
    await loadRoleAndRedirect(userCredential.user);
  } catch (error) {
    setLoading(false);
    displayMessage(`Error en login social: ${error.message}`, 'error');
  }
}

googleLoginButton.addEventListener('click', () => handleSocialLogin(new GoogleAuthProvider()));
facebookLoginButton.addEventListener('click', () => handleSocialLogin(new FacebookAuthProvider()));

// 🔁 Mantener sesión activa
onAuthStateChanged(auth, async (user) => {
  if (user) {
    await loadRoleAndRedirect(user);
  } else {
    setLoading(false);
  }
});
</script>
</body>
</html>
