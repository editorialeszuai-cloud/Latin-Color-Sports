import { auth } from "./firebase-config.js";

onAuthStateChanged(auth, async (user) => {
  if (user) {
    const token = await user.getIdToken();
    const userId = 5; // ID de la tabla usuarios que quieres consultar

    const res = await fetch("get_user_info.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ firebase_token: token, id: userId })
    });

    const data = await res.json();
    console.log(data);

    if (data.loggedIn && data.status === 'success') {
      // Mostrar info del usuario
      document.getElementById("mensaje").innerText = `Bienvenido ${data.user.nombre}, rol: ${data.user.rol}`;
      document.getElementById("contenido").style.display = "block";
    } else {
      document.getElementById("mensaje").innerText = data.message;
      document.getElementById("contenido").style.display = "none";
    }
  } else {
    document.getElementById("mensaje").innerText = "Debes iniciar sesión";
    document.getElementById("contenido").style.display = "none";
  }
});
