<script type="module">
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

onAuthStateChanged(window.auth, (user) => {
  const btn = document.getElementById('btnConfirmar');
  if (!btn) return;

  if (user) {
    // Reemplaza el guest_uid por el uid real, pero pasa el guest también para el merge
    const currentHref = btn.href;
    const url = new URL(currentHref);
    url.searchParams.set('guest_uid',    url.searchParams.get('firebase_uid')); // guarda el guest
    url.searchParams.set('firebase_uid', user.uid); // reemplaza con uid real
    btn.href = url.toString();
  }
});
</script>