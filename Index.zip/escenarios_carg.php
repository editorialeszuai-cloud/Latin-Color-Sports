<?php
header('Content-Type: application/json');
require_once "conexion.php";
$conn = conectar();

$accion = $_POST['accion'] ?? '';

if($accion === 'listar'){
    $res = $conn->query("SELECT id, nombre FROM escenarios ORDER BY nombre");
    $data = [];
    while($row = $res->fetch_assoc()){
        $data[] = $row;
    }
    echo json_encode(['success'=>true,'data'=>$data]);
} else {
    echo json_encode(['success'=>false,'message'=>'Acción no válida']);
}
?>
