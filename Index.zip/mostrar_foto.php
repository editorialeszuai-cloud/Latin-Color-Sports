<?php
session_start();
require 'db.php';

if (!isset($_SESSION['firebase_uid'])) die("Acceso denegado");
$uid = $_SESSION['firebase_uid'];

$foto = $_GET['file'] ?? '';
$foto = basename($foto); // Evitar directorios
$filepath = __DIR__ . "/uploads/$foto";

if (!file_exists($filepath)) die("Archivo no encontrado");

// Permitir ver foto si es pública o del usuario
$stmt = $pdo->prepare("
    SELECT f.id FROM fotos f 
    LEFT JOIN galerias g ON f.galeria_id=g.id
    LEFT JOIN usuarios u ON g.fotografo_id=u.firebase_uid
    WHERE f.nombre_archivo=? 
");
$stmt->execute([$foto]);

if ($stmt->rowCount() === 0) die("No tienes permiso para ver esta foto");

// Enviar imagen
$info = getimagesize($filepath);
header("Content-Type: " . $info['mime']);
readfile($filepath);
exit;
