<?php
// db.php — conexión a MySQL usando PDO

function getDbConnection() {
    // ⚙️ CONFIGURA TUS DATOS DE CONEXIÓN AQUÍ
    $host = 'database-1.c8302k404lkf.us-east-1.rds.amazonaws.com';            // o 127.0.0.1
    $dbname = 'latincolors';   // 👈 nombre de tu base de datos
    $username = 'admin'; // 👈 usuario de la BD (por ejemplo: 'root' o el del cPanel)
    $password = 'DannyCruxTecnoLoad!#'; // 👈 contraseña de la BD

    try {
        $pdo = new PDO(
            "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
            $username,
            $password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Muestra errores de SQL
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        // Si falla la conexión, muestra el error y detiene el script
        http_response_code(500);
        echo json_encode([
            'status' => 'error',
            'message' => 'Error al conectar con la base de datos',
            'detalle' => $e->getMessage()
        ]);
        exit;
    }
}
?>
