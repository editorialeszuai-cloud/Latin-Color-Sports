import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

let postulacionesData = [];
let postulacionActual = null;
let galeriaActual = null;
let firebaseToken = null;

onAuthStateChanged(auth, async (user) => {
  if(!user) return window.location.href='login_app.html';

  document.getElementById('uidText').textContent = user.uid;
  document.getElementById('emailText').textContent = user.email;
  firebaseToken = await user.getIdToken();

  const res = await fetch('get_user_info.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({firebase_token: firebaseToken})
  });
  const data = await res.json();

  if(data.status==='success') {
    document.getElementById('nombreText').textContent = data.user.nombre;
    cargarCalendarioUsuario();
  } else {
    document.getElementById('nombreText').textContent = 'No encontrado';
  }
});

document.getElementById('logoutButton').addEventListener('click', async () => {
  await signOut(auth);
  window.location.href = 'login_app.html';
});

async function cargarCalendarioUsuario() {
  const cont = document.getElementById('calendarioUsuario');
  cont.innerHTML = '<p class="text-gray-500">Cargando tus postulaciones...</p>';

  try {
    const res = await fetch('postulaciones_usuario_calendario.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({firebase_token: firebaseToken})
    });
    const data = await res.json();

    if(!data.success) { cont.innerHTML = `<p class="text-red-600">${data.message}</p>`; return; }
    postulacionesData = data.data;

    if(data.data.length===0) { cont.innerHTML = '<p class="text-gray-500">No tienes postulaciones aún.</p>'; return; }

    let html = `<table class="min-w-full bg-white border rounded shadow text-sm">
      <thead class="bg-gray-100 text-gray-700 uppercase text-xs">
        <tr>
          <th>Evento</th><th>Sede</th><th>Escenario</th><th>Disciplina</th>
          <th>Fecha</th><th>Hora</th><th>Estado</th><th>Galería</th>
        </tr>
      </thead><tbody>`;

    data.data.forEach(p => {
      const colorEstado = p.estado==='aceptado'?'text-green-600 font-semibold':
                          p.estado==='rechazado'?'text-red-600 font-semibold':'text-gray-600';
      html += `<tr class="border-b hover:bg-gray-50">
        <td>${p.evento_nombre||'-'}</td>
        <td>${p.nombre_sede||'-'}</td>
        <td>${p.nombre_escenario||'-'}</td>
        <td>${p.nombre_disciplina||'-'}</td>
        <td>${p.fecha||'-'}</td>
        <td>${p.hora||'-'}</td>
        <td class="${colorEstado}">${p.estado}</td>
        <td><button data-postulacion-id="${p.id}" class="btnGaleria bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded text-xs">Galería</button>
</td>
      </tr>`;
    });

    html += '</tbody></table>';
    cont.innerHTML = html;

  } catch(err) {
    console.error(err);
    cont.innerHTML='<p class="text-red-600">Error cargando postulaciones</p>';
  }
}

window.abrirGaleria = (postulacion_id) => {
  if(!postulacion_id) return alert("Postulación no encontrada");
  postulacionActual = postulacion_id;
  galeriaActual = null;

  document.getElementById('modalGaleria').classList.remove('hidden');
  document.getElementById('crearGaleriaDiv').classList.add('hidden');
  document.getElementById('formSubirFoto').classList.add('hidden');
  document.getElementById('contenidoGaleria').innerHTML = '';

  cargarGalerias();
};

document.getElementById('cerrarModal').addEventListener('click', () => {
  document.getElementById('modalGaleria').classList.add('hidden');
});

document.getElementById('btnNuevaGaleria').addEventListener('click', () => {
  document.getElementById('crearGaleriaDiv').classList.toggle('hidden');
});

document.getElementById('guardarNuevaGaleria').addEventListener('click', async () => {
  let nombre = document.getElementById('nombreNuevaGaleria').value.trim();
  const preset = document.getElementById('presetGaleria').value;
  if(preset) nombre = preset;
  if(!nombre) return alert("Escribe un nombre o selecciona un preset");

  try {
    const res = await fetch('crear_galeria.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({postulacion_id: postulacionActual, nombre, firebase_token: firebaseToken})
    });
    const data = await res.json();
    if(data.success){
      document.getElementById('nombreNuevaGaleria').value='';
      document.getElementById('presetGaleria').value='';
      document.getElementById('crearGaleriaDiv').classList.add('hidden');
      cargarGalerias();
    } else alert(data.message||"Error creando galería");
  } catch(err) {
    console.error(err);
    alert("Error creando galería");
  }
});

// Cargar galerías existentes
async function cargarGalerias(){
  const select = document.getElementById('galeriaSelect');
  select.innerHTML = '<option value="">Cargando galerías...</option>';

  try {
    const res = await fetch('get_galeria.php', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({postulacion_id: postulacionActual, firebase_token: firebaseToken})
    });
    const data = await res.json();

    if(!data.success) { select.innerHTML='<option value="">Error</option>'; return; }

    if(data.galerias.length === 0){
      select.innerHTML = '<option value="">No hay galerías</option>';
    } else {
      select.innerHTML = data.galerias.map(g => `<option value="${g.id}">${g.nombre}</option>`).join('');
    }

    select.addEventListener('change', ()=>{
      galeriaActual = select.value;
      if(galeriaActual) document.getElementById('formSubirFoto').classList.remove('hidden');
      else document.getElementById('formSubirFoto').classList.add('hidden');
      cargarFotos();
    });

  } catch(err){
    console.error(err);
    select.innerHTML='<option value="">Error</option>';
  }
}

// Subir fotos
document.getElementById('formSubirFoto').addEventListener('submit', async (e)=>{
  e.preventDefault();
  if(!galeriaActual) return alert("Selecciona una galería");

  const archivos = document.getElementById('fotoArchivo').files;
  if(archivos.length===0) return alert("Selecciona al menos una foto");

  const descripcion = document.getElementById('fotoDescripcion').value;
  const formData = new FormData();
  formData.append('galeria_id', galeriaActual);
  formData.append('postulacion_id', postulacionActual);
  formData.append('firebase_token', firebaseToken);
  formData.append('descripcion', descripcion);

  for(let i=0;i<archivos.length;i++) formData.append('fotos[]', archivos[i]);

  try{
    const res = await fetch('subir_fotos.php',{method:'POST', body: formData});
    const data = await res.json();

    if(data.success){
      document.getElementById('fotoArchivo').value='';
      document.getElementById('fotoDescripcion').value='';
      cargarFotos();
    } else alert(data.message||"Error subiendo fotos");

  } catch(err){
    console.error(err);
    alert("Error subiendo fotos");
  }
});

// Mostrar fotos
async function cargarFotos(){
  if(!galeriaActual) { document.getElementById('contenidoGaleria').innerHTML=''; return; }
  const cont = document.getElementById('contenidoGaleria');
  cont.innerHTML='<p class="text-gray-500 col-span-full">Cargando fotos...</p>';

  try{
    const res = await fetch('get_fotos_galeria.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({galeria_id: galeriaActual, firebase_token: firebaseToken})
    });
    const data = await res.json();

    if(!data.success){ cont.innerHTML='<p class="text-red-600">Error cargando fotos</p>'; return; }
    if(data.fotos.length === 0){ cont.innerHTML='<p class="text-gray-500">No hay fotos</p>'; return; }

    cont.innerHTML = data.fotos.map(f => `<img src="${f.url}" class="w-full h-32 object-cover rounded" title="${f.descripcion||''}">`).join('');

  } catch(err){
    console.error(err);
    cont.innerHTML='<p class="text-red-600">Error cargando fotos</p>';
  }
}
