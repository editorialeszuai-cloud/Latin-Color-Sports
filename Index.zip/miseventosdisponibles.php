<?php
require 'dbfotografos.php';
$conn = conectar();
$pdo = $conn;

$eventos = [];
$asign_map = [];
$galerias_map = [];
$fotos_map = [];
$mensaje = '';

// Solo cargamos eventos si recibimos uid vía POST (AJAX)
$input = json_decode(file_get_contents('php://input'), true);
$uid = $input['firebase_uid'] ?? null;

if ($uid) {
    // Obtener id de usuario
    $stmt = $pdo->prepare("SELECT id, nombre FROM usuarios WHERE firebase_uid = :uid");
    $stmt->execute(['uid' => $uid]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$usuario) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    $fotografo_id = $usuario['id'];

    // Eventos donde está asignado el fotógrafo
    $stmt = $pdo->prepare("
        SELECT e.*
        FROM eventos e
        INNER JOIN asignar_eventos a ON e.id = a.evento_id
        WHERE a.fotografo_id = :fotografo_id
          AND e.fecha >= CURDATE()
        ORDER BY e.fecha ASC
    ");
    $stmt->execute(['fotografo_id' => $fotografo_id]);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Asignaciones
    $stmt = $pdo->prepare("SELECT * FROM asignar_eventos WHERE fotografo_id = :fotografo_id");
    $stmt->execute(['fotografo_id' => $fotografo_id]);
    $asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($asignaciones as $a) {
        $asign_map[$a['evento_id']][] = $a['fotografo_id'];
    }

    // Galerías
    $stmt = $pdo->prepare("SELECT * FROM galerias WHERE fotografo_id = :fotografo_id ORDER BY fecha_creacion DESC");
    $stmt->execute(['fotografo_id' => $fotografo_id]);
    $galerias = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($galerias as $g) {
        $galerias_map[$g['evento_id']][$g['fotografo_id']][] = $g;
    }

    // Fotos
    $stmt = $pdo->prepare("SELECT * FROM fotos WHERE galeria_id IN (SELECT id FROM galerias WHERE fotografo_id=:fotografo_id)");
    $stmt->execute(['fotografo_id' => $fotografo_id]);
    $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($fotos as $f) {
        $fotos_map[$f['galeria_id']][] = $f;
    }

    echo json_encode([
        'status' => 'success',
        'eventos' => $eventos,
        'asign_map' => $asign_map,
        'galerias_map' => $galerias_map,
        'fotos_map' => $fotos_map
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Fotografías</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<meta name="viewport" content="width=device-width,initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen p-4">
<h1 class="text-3xl font-bold mb-6 text-center">Mis Eventos y Galerías</h1>

<div id="loadingMessage" class="text-gray-500 text-center mb-4">Cargando eventos, espera a que se autentique...</div>
<div id="errorMessage" class="text-red-600 text-center mb-4 hidden"></div>

<div id="eventosContainer" class="grid gap-6"></div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

// 🔥 Config Firebase
const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.appspot.com",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const eventosContainer = document.getElementById('eventosContainer');
const loadingMessage = document.getElementById('loadingMessage');
const errorMessage = document.getElementById('errorMessage');

function renderEventos(eventos, asign_map, galerias_map, fotos_map) {
    eventosContainer.innerHTML = '';
    if (!eventos.length) {
        eventosContainer.innerHTML = '<p class="text-gray-500">No tienes eventos para esta fecha.</p>';
        return;
    }

    eventos.forEach(evento => {
        const divEvento = document.createElement('div');
        divEvento.className = "bg-white p-6 rounded shadow";
        divEvento.innerHTML = `<h2 class="text-xl font-semibold">${evento.titulo}</h2>
                               <p class="text-gray-500 text-sm mb-3">Fecha: ${evento.fecha}</p>`;

        const asignados = asign_map[evento.id] || [];
        asignados.forEach(fid => {
            const galerias = galerias_map[evento.id]?.[fid] || [];
            galerias.forEach(g => {
                const fotos = fotos_map[g.id] || [];
                const divGaleria = document.createElement('div');
                divGaleria.className = 'border p-3 rounded mb-3 bg-gray-50';
                divGaleria.innerHTML = `<h3 class="font-semibold">${g.titulo}</h3>
                                        <div class="grid grid-cols-3 gap-2 mt-2">
                                        ${fotos.map(f => {
                                            if(f.tipo_archivo==='imagen') {
                                                return `<img src="uploads/${f.nombre_archivo}" class="w-full h-24 object-cover rounded">`;
                                            } else {
                                                return `<video src="uploads/${f.nombre_archivo}" class="w-full h-24 object-cover rounded" controls></video>`;
                                            }
                                        }).join('')}
                                        </div>`;
                divEvento.appendChild(divGaleria);
            });
        });

        eventosContainer.appendChild(divEvento);
    });
}

// Detectar usuario logueado
onAuthStateChanged(auth, async (user) => {
    if (!user) {
        errorMessage.textContent = "No estás logueado.";
        errorMessage.classList.remove('hidden');
        return;
    }

    try {
        const token = await user.getIdToken(true);
        const res = await fetch(window.location.href, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ firebase_uid: user.uid })
        });
        const data = await res.json();

        loadingMessage.style.display = 'none';

        if (data.status === 'success') {
            renderEventos(data.eventos, data.asign_map, data.galerias_map, data.fotos_map);
        } else {
            errorMessage.textContent = data.message || 'Error al cargar eventos.';
            errorMessage.classList.remove('hidden');
        }
    } catch (err) {
        console.error(err);
        loadingMessage.style.display = 'none';
        errorMessage.textContent = "Error al conectar con el servidor.";
        errorMessage.classList.remove('hidden');
    }
});
</script>
</body>
</html>
