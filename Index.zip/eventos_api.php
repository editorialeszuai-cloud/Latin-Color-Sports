<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once "conexion.php";
$conn = conectar();

$accion = $_POST['accion'] ?? '';
$id = $_POST['id'] ?? null;

// Campos del formulario
$titulo              = $_POST['titulo'] ?? '';
$descripcion         = $_POST['descripcion'] ?? '';
$organizador_id      = $_POST['organizador_id'] ?? '';
$fecha               = $_POST['fecha'] ?? '';
$fechafin            = $_POST['fechafin'] ?? '';
$lugar_id            = $_POST['lugar_id'] ?? '';
$tipo_evento         = $_POST['tipo_evento'] ?? '';
$metodo_monetizacion = $_POST['metodo_monetizacion'] ?? 'Pago';
$capacidad_gb        = $_POST['capacidad_gb'] ?? '';
$max_fotografos      = $_POST['max_fotografos'] ?? '';
$photo_licensing     = $_POST['photo_licensing'] ?? '';
$comercial_id        = $_POST['comercial_id'] ?? null;

$paquetes_eventos_json   = json_encode($_POST['paquetes_eventos'] ?? []);
$disciplinas_evento_json = json_encode($_POST['disciplinas_evento'] ?? []);

// Archivos
$uploadDir = "uploads/";

function subirArchivo($file, $dir) {
    if (!empty($file['name'])) {
        $targetFile = $dir . uniqid() . "_" . basename($file['name']);
        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            return $targetFile;
        }
    }
    return null;
}

$logoPath  = subirArchivo($_FILES['logo'] ?? [], $uploadDir);
$bannerPath = subirArchivo($_FILES['banner'] ?? [], $uploadDir);
$iconoPath = subirArchivo($_FILES['icono_foto'] ?? [], $uploadDir);

try {
    if ($accion === 'crear') {
        $stmt = $conn->prepare("INSERT INTO eventos 
            (titulo, descripcion, organizador_id, fecha, fechafin, lugar_id, tipo_evento, metodo_monetizacion, capacidad_gb, max_fotografos, photo_licensing, logo, banner, icono_foto, comercial_id, paquetes_eventos, disciplinas_evento)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        // 🔹 Tipos correctos: s=string, i=integer
        $stmt->bind_param(
            "ssisssssssssssiss",
            $titulo,
            $descripcion,
            $organizador_id,
            $fecha,
            $fechafin,
            $lugar_id,
            $tipo_evento,
            $metodo_monetizacion,
            $capacidad_gb,
            $max_fotografos,
            $photo_licensing,
            $logoPath,
            $bannerPath,
            $iconoPath,
            $comercial_id,
            $paquetes_eventos_json,
            $disciplinas_evento_json
        );

        $stmt->execute();
        echo json_encode(['success' => true]);

    } elseif ($accion === 'editar' && $id) {
        // Recuperar imágenes actuales si no se suben nuevas
        $stmt = $conn->prepare("SELECT logo, banner, icono_foto FROM eventos WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $actual = $stmt->get_result()->fetch_assoc();

        $logoPath   = $logoPath   ?: $actual['logo'];
        $bannerPath = $bannerPath ?: $actual['banner'];
        $iconoPath  = $iconoPath  ?: $actual['icono_foto'];

        $stmt = $conn->prepare("UPDATE eventos SET 
            titulo=?, descripcion=?, organizador_id=?, fecha=?, fechafin=?, lugar_id=?, tipo_evento=?, metodo_monetizacion=?, capacidad_gb=?, max_fotografos=?, photo_licensing=?, logo=?, banner=?, icono_foto=?, comercial_id=?, paquetes_eventos=?, disciplinas_evento=?
            WHERE id=?");

        $stmt->bind_param(
            "ssisssssssssssissi",
            $titulo,
            $descripcion,
            $organizador_id,
            $fecha,
            $fechafin,
            $lugar_id,
            $tipo_evento,
            $metodo_monetizacion,
            $capacidad_gb,
            $max_fotografos,
            $photo_licensing,
            $logoPath,
            $bannerPath,
            $iconoPath,
            $comercial_id,
            $paquetes_eventos_json,
            $disciplinas_evento_json,
            $id
        );

        $stmt->execute();
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
