<?php
require_once "conexion.php";
$conn = conectar();

// Obtener todos los eventos
$result = $conn->query("SELECT * FROM eventos ORDER BY id DESC");
?>

<div class="bg-gray-50 p-6 rounded-lg border border-gray-200 shadow-inner mt-6">
  <h2 class="text-2xl font-semibold text-gray-800 mb-4">Gestión de Eventos</h2>

  <!-- FORMULARIO PARA CREAR EVENTO -->
  <form action="" method="POST" enctype="multipart/form-data" class="space-y-4 mb-6">
    <input type="hidden" name="accion" value="crear">

    <div>
      <label class="block text-sm font-medium text-gray-700">Título del Evento</label>
      <input type="text" name="titulo" required
             class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Descripción</label>
      <textarea name="descripcion" rows="3"
                class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500"></textarea>
    </div>

    <div class="grid grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-medium text-gray-700">Fecha</label>
        <input type="date" name="fecha" required
               class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700">Lugar</label>
        <input type="text" name="lugar" required
               class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
      </div>
    </div>

    <div class="grid grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-medium text-gray-700">Tipo de Evento</label>
        <select name="tipo_evento" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
          <option value="Conferencia">Conferencia</option>
          <option value="Concierto">Concierto</option>
          <option value="Webinar">Webinar</option>
          <option value="Otro">Otro</option>
        </select>
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700">Método de Monetización</label>
        <select name="metodo_monetizacion" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
          <option value="Pago">Pago</option>
          <option value="Gratis">Gratis</option>
          <option value="Suscripción">Suscripción</option>
        </select>
      </div>
    </div>

    <div class="grid grid-cols-2 gap-4">
      <div>
        <label class="block text-sm font-medium text-gray-700">Logo</label>
        <input type="file" name="logo" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
      </div>

      <div>
        <label class="block text-sm font-medium text-gray-700">Banner de la Marca</label>
        <input type="file" name="banner" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
      </div>
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Photo Licensing Terms</label>
      <textarea name="photo_licensing" rows="2"
                class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500"></textarea>
    </div>

    <button type="submit"
            class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">
      Crear Evento
    </button>
  </form>

  <!-- LISTA DE EVENTOS -->
  <h3 class="text-lg font-semibold mb-2">Eventos Registrados</h3>
  <table class="w-full border text-sm">
    <thead class="bg-gray-200 text-gray-800">
      <tr>
        <th class="p-2 border">ID</th>
        <th class="p-2 border">Título</th>
        <th class="p-2 border">Fecha</th>
        <th class="p-2 border">Lugar</th>
        <th class="p-2 border">Tipo</th>
        <th class="p-2 border">Método</th>
        <th class="p-2 border">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr class="border-b hover:bg-gray-50">
          <td class="p-2 border text-center"><?= $row['id'] ?></td>
          <td class="p-2 border"><?= htmlspecialchars($row['titulo']) ?></td>
          <td class="p-2 border text-center"><?= htmlspecialchars($row['fecha']) ?></td>
          <td class="p-2 border"><?= htmlspecialchars($row['lugar']) ?></td>
          <td class="p-2 border"><?= htmlspecialchars($row['tipo_evento']) ?></td>
          <td class="p-2 border"><?= htmlspecialchars($row['metodo_monetizacion']) ?></td>
          <td class="p-2 border text-center">
            <form action="" method="POST" class="inline">
              <input type="hidden" name="accion" value="eliminar">
              <input type="hidden" name="id" value="<?= $row['id'] ?>">
              <button type="submit"
                class="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700 text-xs"
                onclick="return confirm('¿Eliminar este evento?');">
                Eliminar
              </button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>