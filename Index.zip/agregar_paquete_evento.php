<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'dbfotografos.php';

$firebase_uid = $_GET['firebase_uid'] ?? '';
$evento_id = isset($_GET['evento_id']) ? (int)$_GET['evento_id'] : 0;
$precio = isset($_GET['precio']) ? (int)$_GET['precio'] : 0;

if (!$firebase_uid || $evento_id <= 0 || $precio <= 0) {
    echo json_encode(['status'=>'error','msg'=>'Datos inválidos']);
    exit;
}

// Verificar si ya existe el paquete en carrito_paquetes
$stmt = $pdo->prepare("SELECT COUNT(*) FROM carrito_paquetes WHERE firebase_uid=? AND evento_id=?");
$stmt->execute([$firebase_uid,$evento_id]);
if($stmt->fetchColumn() > 0){
    echo json_encode(['status'=>'error','msg'=>'Paquete ya agregado']);
    exit;
}

// Insertar en carrito_paquetes
$stmt = $pdo->prepare("INSERT INTO carrito_paquetes (firebase_uid, evento_id, precio, fecha) VALUES (?, ?, ?, NOW())");
$stmt->execute([$firebase_uid, $evento_id, $precio]);

// Contar todas las fotos del evento para mostrar en la respuesta
$stmt = $pdo->prepare("SELECT COUNT(*) FROM fotos f INNER JOIN postulaciones p ON f.postulacion_id = p.id WHERE p.evento_id=?");
$stmt->execute([$evento_id]);
$total_fotos = (int)$stmt->fetchColumn();

echo json_encode([
    'status'=>'ok',
    'total_fotos'=>$total_fotos,
    'precio'=>$precio
]);
