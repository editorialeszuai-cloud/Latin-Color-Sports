<?php
require_once 'dbfotografos.php';

// Recibir variables del POST
$evento_id  = isset($_POST['evento_id']) ? intval($_POST['evento_id']) : 1;
$galeria    = isset($_POST['galeria']) && $_POST['galeria'] !== "" ? intval($_POST['galeria']) : null;
$fotografo  = isset($_POST['fotografo']) && $_POST['fotografo'] !== "" ? intval($_POST['fotografo']) : null;
$disciplina = isset($_POST['disciplina']) && $_POST['disciplina'] !== "" ? intval($_POST['disciplina']) : null;
$sede       = isset($_POST['sede']) && $_POST['sede'] !== "" ? intval($_POST['sede']) : null;
$fecha      = isset($_POST['fecha']) && $_POST['fecha'] !== "" ? $_POST['fecha'] : null;

// VARIABLES CLAVE PARA LA CARGA INFINITA
$limit  = isset($_POST['limit']) ? intval($_POST['limit']) : 40;
$offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;

// Construcción dinámica del SQL
$sql = "SELECT DISTINCT f.id, f.url 
        FROM fotos f 
        INNER JOIN postulaciones p ON f.postulacion_id = p.id 
        LEFT JOIN calendario_fotografos cf ON cf.postulacion_id = f.postulacion_id 
        WHERE p.evento_id = :evento_id";

if ($galeria)    $sql .= " AND f.galeria_id = :galeria";
if ($fotografo)  $sql .= " AND p.usuario_id = :fotografo";
if ($disciplina) $sql .= " AND cf.disciplina_id = :disciplina";
if ($sede)       $sql .= " AND cf.sede_id = :sede";
if ($fecha)      $sql .= " AND cf.fecha = :fecha";

$sql .= " ORDER BY f.id DESC LIMIT :limit OFFSET :offset";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':evento_id', $evento_id, PDO::PARAM_INT);
if ($galeria)    $stmt->bindValue(':galeria', $galeria, PDO::PARAM_INT);
if ($fotografo)  $stmt->bindValue(':fotografo', $fotografo, PDO::PARAM_INT);
if ($disciplina) $stmt->bindValue(':disciplina', $disciplina, PDO::PARAM_INT);
if ($sede)       $stmt->bindValue(':sede', $sede, PDO::PARAM_INT);
if ($fecha)      $stmt->bindValue(':fecha', $fecha, PDO::PARAM_STR);

$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$stmt->execute();
$fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($fotos);