<?php
header("Content-Type: application/json; charset=utf-8");

// --------------------------------------
// 1. Conexi��n BD
// --------------------------------------
$mysqli = new mysqli(
    "localhost",
    "adminsports1_tecnoload",
    "TNB#QbHRw2192r17",
    "adminsports1_latin_group"
);

if ($mysqli->connect_errno) {
    echo json_encode(["error" => "Error conectando a la base de datos"]);
    exit();
}

// --------------------------------------
// 2. Leer JSON del POST
// --------------------------------------
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["error" => "JSON inv��lido"]);
    exit();
}

// Validar campos
if (
    !isset($data["label"]) ||
    !isset($data["descriptor"]) ||
    !isset($data["foto_id"])
) {
    echo json_encode([
        "error" => "Faltan datos requeridos: label, descriptor, foto_id"
    ]);
    exit();
}

$label = $mysqli->real_escape_string($data["label"]);
$foto_id = intval($data["foto_id"]);
$descriptor = $data["descriptor"];

// Validar descriptor
if (!is_array($descriptor) || count($descriptor) !== 128) {
    echo json_encode(["error" => "descriptor debe ser un array de 128 valores"]);
    exit();
}

$descriptorJSON = json_encode($descriptor);

// --------------------------------------
// 3. Verificar que la foto exista
// --------------------------------------
$stmtCheck = $mysqli->prepare("SELECT id FROM fotos WHERE id = ? LIMIT 1");
$stmtCheck->bind_param("i", $foto_id);
$stmtCheck->execute();
$stmtCheck->store_result();

if ($stmtCheck->num_rows === 0) {
    echo json_encode(["error" => "foto_id no existe"]);
    exit();
}

$stmtCheck->close();

// --------------------------------------
// 4. Insertar rostro
// --------------------------------------
$stmt = $mysqli->prepare("
    INSERT INTO faces (label, descriptor, foto_id)
    VALUES (?, ?, ?)
");
$stmt->bind_param("ssi", $label, $descriptorJSON, $foto_id);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "face_id" => $stmt->insert_id,
        "foto_id" => $foto_id
    ]);
} else {
    echo json_encode([
        "error" => "Error guardando rostro",
        "mysql_error" => $stmt->error
    ]);
}

$stmt->close();
$mysqli->close();
