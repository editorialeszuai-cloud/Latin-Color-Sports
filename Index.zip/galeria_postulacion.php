<?php
// galeria_postulaciones.php
include 'conexion.php'; // Ajustar conexión a tu base de datos

// Detectar si es FormData o JSON
$firebase_uid = null;
$accion = null;

// Para JSON
$input = json_decode(file_get_contents('php://input'), true);
if($input){
    $firebase_uid = $input['firebase_uid'] ?? null;
    $accion = $input['accion'] ?? null;
}
// Para FormData (multipart/form-data)
if(isset($_POST['firebase_uid'])) $firebase_uid = $_POST['firebase_uid'];
if(isset($_POST['accion'])) $accion = $_POST['accion'];

if(!$firebase_uid){ echo json_encode(['success'=>false,'message'=>'No hay UID de Firebase']); exit; }

// Obtener usuario
$stmt = $conn->prepare("SELECT id,nombre,email FROM usuarios WHERE firebase_uid=? LIMIT 1");
$stmt->bind_param("s",$firebase_uid);
$stmt->execute();
$res = $stmt->get_result();
if($res->num_rows==0){ echo json_encode(['success'=>false,'message'=>'Usuario no encontrado']); exit; }
$user = $res->fetch_assoc();
$user_id = $user['id'];

// --------------------
// ACCIONES API
if($accion=='get_postulaciones'){
    $stmt = $conn->prepare("SELECT * FROM postulaciones WHERE user_id=? ORDER BY fecha ASC");
    $stmt->bind_param("i",$user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $data = [];
    while($row=$res->fetch_assoc()) $data[]=$row;
    echo json_encode(['success'=>true,'data'=>$data]);
    exit;
}

if($accion=='get_galerias'){
    $postulacion_id = $input['postulacion_id'] ?? $_POST['postulacion_id'] ?? 0;
    if(!$postulacion_id){ echo json_encode(['success'=>false]); exit; }
    $stmt = $conn->prepare("SELECT id,nombre FROM galerias WHERE postulacion_id=? ORDER BY created_at DESC");
    $stmt->bind_param("i",$postulacion_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $galerias = [];
    while($row=$res->fetch_assoc()) $galerias[]=$row;
    echo json_encode(['success'=>true,'galerias'=>$galerias]);
    exit;
}

if($accion=='crear_galeria'){
    $postulacion_id = $input['postulacion_id'] ?? $_POST['postulacion_id'] ?? 0;
    $nombre = trim($input['nombre'] ?? $_POST['nombre'] ?? '');
    if(!$postulacion_id || !$nombre){ echo json_encode(['success'=>false,'message'=>'Datos inválidos']); exit; }
    $stmt = $conn->prepare("INSERT INTO galerias(postulacion_id,nombre,created_at) VALUES(?,?,NOW())");
    $stmt->bind_param("is",$postulacion_id,$nombre);
    if($stmt->execute()) echo json_encode(['success'=>true,'galeria_id'=>$stmt->insert_id,'nombre'=>$nombre]);
    else echo json_encode(['success'=>false,'message'=>'Error creando galería']);
    exit;
}

if($accion=='get_fotos'){
    $galeria_id = $input['galeria_id'] ?? $_POST['galeria_id'] ?? 0;
    if(!$galeria_id){ echo json_encode(['success'=>false]); exit; }
    $stmt = $conn->prepare("SELECT id,url,descripcion FROM fotos WHERE galeria_id=? ORDER BY created_at DESC");
    $stmt->bind_param("i",$galeria_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $fotos = [];
    while($row=$res->fetch_assoc()) $fotos[]=$row;
    echo json_encode(['success'=>true,'fotos'=>$fotos]);
    exit;
}

// Subir fotos
if($accion=='subir_fotos'){
    $galeria_id = $_POST['galeria_id'] ?? 0;
    $descripcion = $_POST['descripcion'] ?? '';
    $postulacion_id = $_POST['postulacion_id'] ?? 0;
    if(!$galeria_id || !$postulacion_id){ echo json_encode(['success'=>false,'message'=>'Datos inválidos']); exit; }
    if(!isset($_FILES['fotos'])){ echo json_encode(['success'=>false,'message'=>'No hay archivos']); exit; }

    $archivos = $_FILES['fotos'];
    $errores = [];
    for($i=0;$i<count($archivos['name']);$i++){
        $tmp_name = $archivos['tmp_name'][$i];
        $ext = pathinfo($archivos['name'][$i],PATHINFO_EXTENSION);
        $nombreArchivo = 'uploads/'.uniqid().'.'.$ext;
        if(!move_uploaded_file($tmp_name,$nombreArchivo)){ $errores[]=$archivos['name'][$i]; continue; }
        $stmt = $conn->prepare("INSERT INTO fotos(galeria_id,url,descripcion,created_at) VALUES(?,?,?,NOW())");
        $stmt->bind_param("iss",$galeria_id,$nombreArchivo,$descripcion);
        $stmt->execute();
    }
    if(count($errores)>0){ echo json_encode(['success'=>false,'message'=>'No se subieron: '.implode(',',$errores)]); }
    else echo json_encode(['success'=>true,'message'=>'Fotos subidas correctamente']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Postulaciones - Galerías</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<header class="bg-indigo-700 text-white p-4 shadow-md">
  <div class="container mx-auto flex justify-between items-center">
    <h1 class="text-2xl font-bold">Mis Postulaciones</h1>
  </div>
</header>

<main class="container mx-auto p-6">
  <div id="calendarioUsuario" class="bg-white p-4 rounded-lg shadow">
    <p class="text-gray-500">Cargando información de tus postulaciones...</p>
  </div>
</main>

<!-- MODAL GALERÍA -->
<div id="modalGaleria" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden">
  <div class="bg-white rounded-lg w-11/12 md:w-2/3 p-4 relative max-h-[90vh] overflow-auto">
    <button id="cerrarModal" class="absolute top-2 right-2 text-gray-700 text-xl">&times;</button>
    <h3 class="text-lg font-semibold mb-2">Galerías de Fotos</h3>

    <div class="mb-2 flex gap-2">
      <select id="galeriaSelect" class="border rounded px-2 py-1 flex-1">
        <option value="">Selecciona galería existente</option>
      </select>
      <button id="btnNuevaGaleria" class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded">Nueva Galería</button>
    </div>

    <div id="crearGaleriaDiv" class="mb-2 hidden">
      <input type="text" id="nombreNuevaGaleria" placeholder="Nombre de la galería" class="border rounded px-2 py-1 w-full mb-1">
      <select id="presetGaleria" class="border rounded px-2 py-1 w-full mb-1">
        <option value="">O elegir preset</option>
        <option value="Premiación">Premiación</option>
        <option value="Deporte">Deporte</option>
      </select>
      <button id="guardarNuevaGaleria" class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded w-full">Crear Galería</button>
    </div>

    <form id="formSubirFoto" class="flex flex-col gap-2 mt-2">
      <input type="file" id="fotoArchivo" accept="image/*" multiple required class="border rounded px-2 py-1">
      <input type="text" id="fotoDescripcion" placeholder="Descripción opcional" class="border rounded px-2 py-1">
      <button type="submit" class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded">Subir Foto(s)</button>
    </form>

    <div id="contenidoGaleria" class="grid grid-cols-2 md:grid-cols-3 gap-2 mt-4"></div>
  </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

let postulacionesData = [];
let postulacionActual = null;
let galeriaActual = null;

onAuthStateChanged(auth, async user=>{
  if(!user){ window.location.href='login_app.html'; return; }
  const firebase_uid = user.uid;

  async function cargarPostulaciones(){
    const cont = document.getElementById('calendarioUsuario');
    cont.innerHTML='<p class="text-gray-500">Cargando postulaciones...</p>';
    try{
      const res = await fetch('galeria_postulaciones.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({firebase_uid,accion:'get_postulaciones'})
      });
      const data = await res.json();
      if(!data.success){ cont.innerHTML='<p class="text-red-600">'+data.message+'</p>'; return; }
      postulacionesData = data.data;
      if(data.data.length===0){ cont.innerHTML='<p class="text-gray-500">No tienes postulaciones aún.</p>'; return; }

      let html = `<table class="min-w-full bg-white border rounded shadow text-sm">
        <thead class="bg-gray-100 text-gray-700 uppercase text-xs"><tr>
        <th>Evento</th><th>Sede</th><th>Escenario</th><th>Disciplina</th>
        <th>Fecha</th><th>Hora</th><th>Estado</th><th>Galería</th></tr></thead><tbody>`;
      data.data.forEach(p=>{
        const colorEstado = p.estado==='aceptado'?'text-green-600 font-semibold':p.estado==='rechazado'?'text-red-600 font-semibold':'text-gray-600';
        html+=`<tr class="border-b hover:bg-gray-50">
          <td>${p.evento_nombre||'-'}</td>
          <td>${p.nombre_sede||'-'}</td>
          <td>${p.nombre_escenario||'-'}</td>
          <td>${p.nombre_disciplina||'-'}</td>
          <td>${p.fecha||'-'}</td>
          <td>${p.hora||'-'}</td>
          <td class="${colorEstado}">${p.estado}</td>
          <td><button onclick="abrirGaleria(${p.id})" class="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded text-xs">Ver / Subir Fotos</button></td>
        </tr>`;
      });
      html+='</tbody></table>';
      cont.innerHTML=html;
    }catch(err){ console.error(err); cont.innerHTML='<p class="text-red-600">Error cargando postulaciones</p>'; }
  }

  window.abrirGaleria = async function(postulacion_id){
    postulacionActual = postulacion_id;
    galeriaActual = null;
    document.getElementById('modalGaleria').classList.remove('hidden');
    document.getElementById('crearGaleriaDiv').classList.add('hidden');
    await cargarGalerias();
    await cargarFotos();
  }

  async function cargarGalerias(){
    const select = document.getElementById('galeriaSelect');
    select.innerHTML='<option value="">Cargando galerías...</option>';
    try{
      const res = await fetch('galeria_postulaciones.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({firebase_uid,accion:'get_galerias',postulacion_id:postulacionActual})
      });
      const data = await res.json();
      if(!data.success){ select.innerHTML='<option value="">Error</option>'; return; }
      select.innerHTML = data.galerias.map(g=>`<option value="${g.id}">${g.nombre}</option>`).join('');
      select.value = galeriaActual || '';
      select.onchange = ()=>{ galeriaActual = select.value; cargarFotos(); }
    }catch(err){ console.error(err); select.innerHTML='<option value="">Error</option>'; }
  }

  async function cargarFotos(){
    const cont = document.getElementById('contenidoGaleria');
    if(!galeriaActual){ cont.innerHTML=''; return; }
    cont.innerHTML='<p class="text-gray-500 col-span-full">Cargando fotos...</p>';
    try{
      const res = await fetch('galeria_postulaciones.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({firebase_uid,accion:'get_fotos',galeria_id:galeriaActual})
      });
      const data = await res.json();
      if(!data.success){ cont.innerHTML='<p class="text-red-600">Error cargando fotos</p>'; return; }
      if(data.fotos.length===0){ cont.innerHTML='<p class="text-gray-500">No hay fotos</p>'; return; }
      cont.innerHTML = data.fotos.map(f=>`<img src="${f.url}" class="w-full h-32 object-cover rounded" title="${f.descripcion||''}">`).join('');
    }catch(err){ console.error(err); cont.innerHTML='<p class="text-red-600">Error cargando fotos</p>'; }
  }

  document.getElementById('btnNuevaGaleria').addEventListener('click',()=>{document.getElementById('crearGaleriaDiv').classList.toggle('hidden');});
  document.getElementById('cerrarModal').addEventListener('click',()=>{document.getElementById('modalGaleria').classList.add('hidden'); galeriaActual=null;});

  document.getElementById('guardarNuevaGaleria').addEventListener('click', async ()=>{
    let nombre = document.getElementById('nombreNuevaGaleria').value.trim();
    const preset = document.getElementById('presetGaleria').value;
    if(preset) nombre=preset;
    if(!nombre) return alert("Escribe nombre o selecciona preset");
    const res = await fetch('galeria_postulaciones.php',{method:'POST',body:JSON.stringify({firebase_uid,accion:'crear_galeria',postulacion_id:postulacionActual,nombre})});
    const data = await res.json();
    if(data.success){ galeriaActual=data.galeria_id; document.getElementById('nombreNuevaGaleria').value=''; document.getElementById('presetGaleria').value=''; document.getElementById('crearGaleriaDiv').classList.add('hidden'); cargarGalerias(); cargarFotos(); }
    else alert(data.message||"Error creando galería");
  });

  document.getElementById('formSubirFoto').addEventListener('submit',async e=>{
    e.preventDefault();
    if(!galeriaActual) return alert("Selecciona o crea una galería");
    const archivos = document.getElementById('fotoArchivo').files;
    if(archivos.length===0) return alert("Selecciona al menos una foto");
    const descripcion = document.getElementById('fotoDescripcion').value;
    const formData = new FormData();
    formData.append('accion','subir_fotos');
    formData.append('firebase_uid',firebase_uid);
    formData.append('galeria_id',galeriaActual);
    formData.append('postulacion_id',postulacionActual);
    formData.append('descripcion',descripcion);
    for(let i=0;i<archivos.length;i++) formData.append('fotos[]',archivos[i]);
    const res = await fetch('galeria_postulaciones.php',{method:'POST',body:formData});
    const data = await res.json();
    if(data.success){ document.getElementById('fotoArchivo').value=''; document.getElementById('fotoDescripcion').value=''; cargarFotos(); }
    else alert(data.message||"Error subiendo fotos");
  });

  cargarPostulaciones();
});
</script>
</body>
</html>
