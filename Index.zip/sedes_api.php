<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once "conexion.php";
$conn = conectar();

// Acción solicitada
$accion = $_POST['accion'] ?? '';
$id = $_POST['id'] ?? null;

// Campos
$titulo = $_POST['titulo'] ?? '';
$direccion = $_POST['direccion'] ?? '';

try {
    if ($accion === 'crear') {
        if (!$titulo || !$direccion) {
            throw new Exception("Faltan campos obligatorios.");
        }

        $stmt = $conn->prepare("INSERT INTO sedes (titulo, direccion) VALUES (?, ?)");
        $stmt->bind_param("ss", $titulo, $direccion);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Sede creada correctamente']);

    } elseif ($accion === 'editar' && $id) {
        if (!$titulo || !$direccion) {
            throw new Exception("Faltan campos obligatorios.");
        }

        $stmt = $conn->prepare("UPDATE sedes SET titulo = ?, direccion = ? WHERE id = ?");
        $stmt->bind_param("ssi", $titulo, $direccion, $id);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Sede actualizada correctamente']);

    } elseif ($accion === 'eliminar' && $id) {
        $stmt = $conn->prepare("DELETE FROM sedes WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Sede eliminada correctamente']);

    } elseif ($accion === 'listar') {
        $result = $conn->query("SELECT * FROM sedes ORDER BY id DESC");
        $data = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $data]);

    } else {
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
