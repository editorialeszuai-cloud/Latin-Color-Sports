<?php
header('Content-Type: application/json');
require_once 'dbfotografos.php';

$evento_id  = isset($_GET['evento_id'])  ? intval($_GET['evento_id'])  : 0;
$partido_id = isset($_GET['partido_id']) ? intval($_GET['partido_id']) : 0;
$sede_id    = isset($_GET['sede_id'])    ? intval($_GET['sede_id'])    : 0;

$sql = "SELECT DISTINCT f.id, f.url, m.url_miniatura, p.equipo_a, p.equipo_b 
        FROM fotos f
        INNER JOIN calendario_fotografos cf ON f.postulacion_id = cf.id
        LEFT JOIN partidos p ON cf.partido_id = p.id
        LEFT JOIN miniaturas m ON f.id = m.foto_id
        WHERE cf.evento_id = :evento_id";

$params = [':evento_id' => $evento_id];

if ($partido_id > 0) {
    $sql .= " AND cf.partido_id = :partido_id";
    $params[':partido_id'] = $partido_id;
} elseif ($sede_id > 0) {
    $sql .= " AND cf.sede_id = :sede_id";
    $params[':sede_id'] = $sede_id;
}

$sql .= " ORDER BY f.id DESC LIMIT 200";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($resultados);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Error en la consulta', 'detalle' => $e->getMessage()]);
}