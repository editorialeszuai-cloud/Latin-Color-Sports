<?php
require_once 'db.php';
require_once 'firebase_verify.php'; // archivo que valide el token

$input = json_decode(file_get_contents("php://input"), true);
if (!isset($input['firebase_token'])) {
    echo json_encode(["status" => "error", "message" => "No se proporcionó un ID Token de Firebase."]);
    exit;
}

$uid = verifyFirebaseToken($input['firebase_token']); // Función que retorna UID si es válido
if (!$uid) {
    echo json_encode(["status" => "error", "message" => "Token inválido o expirado."]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM usuarios WHERE firebase_uid = ?");
$stmt->execute([$uid]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    echo json_encode(["status" => "success", "user" => $user]);
} else {
    echo json_encode(["status" => "error", "message" => "Usuario no encontrado en la base de datos."]);
}
?>
