<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once "conexion.php";
$conn = conectar();

$accion = $_POST['accion'] ?? '';
$id = $_POST['id'] ?? null;

$evento_id    = $_POST['evento_id'] ?? null;
$sede_id      = $_POST['sede_id'] ?? null;
$escenario_id = $_POST['escenario_id'] ?? null;
$disciplina_id= $_POST['disciplina_id'] ?? null;
$fecha        = $_POST['fecha'] ?? null;
$hora         = $_POST['hora'] ?? null;

try {
    if($accion === 'listar'){
        $sql = "SELECT c.id, e.titulo as evento, s.titulo as sede, es.nombre as escenario, d.nombre_disciplina as disciplina, c.fecha, c.hora
                FROM calendarios c
                LEFT JOIN eventos e ON c.evento_id = e.id
                LEFT JOIN sedes s ON c.sede_id = s.id
                LEFT JOIN escenarios es ON c.escenario_id = es.id
                LEFT JOIN disciplinas d ON c.disciplina_id = d.id
                ORDER BY c.fecha, c.hora";

        $res = $conn->query($sql);
        $data = [];
        while($row = $res->fetch_assoc()){
            $data[] = $row;
        }
        echo json_encode(['success'=>true, 'data'=>$data]);

    } elseif($accion === 'crear'){
        $stmt = $conn->prepare("INSERT INTO calendarios (evento_id, sede_id, escenario_id, disciplina_id, fecha, hora) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("iiiiss", $evento_id, $sede_id, $escenario_id, $disciplina_id, $fecha, $hora);
        $stmt->execute();
        echo json_encode(['success'=>true]);

    } elseif($accion === 'editar' && $id){
        $stmt = $conn->prepare("UPDATE calendarios SET evento_id=?, sede_id=?, escenario_id=?, disciplina_id=?, fecha=?, hora=? WHERE id=?");
        $stmt->bind_param("iiiissi", $evento_id, $sede_id, $escenario_id, $disciplina_id, $fecha, $hora, $id);
        $stmt->execute();
        echo json_encode(['success'=>true]);

    } elseif($accion === 'eliminar' && $id){
        $stmt = $conn->prepare("DELETE FROM calendarios WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        echo json_encode(['success'=>true]);

    } else {
        echo json_encode(['success'=>false, 'message'=>'Acción no válida']);
    }

} catch(Exception $e){
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
?>
