<?php
error_reporting(0);
ob_start();

require 'dbfotografos.php';
require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');

    $evento_id = $_POST['evento_id'] ?? null;
    $page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;

    try {
        if (!$evento_id) {
            exit(json_encode(['success' => false, 'error' => 'Evento no especificado']));
        }

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // 1. Total de fotos del evento
        $stmtTotal = $pdo->prepare("
            SELECT COUNT(f.id) as total 
            FROM fotos f
            INNER JOIN galerias g ON f.galeria_id = g.id
            INNER JOIN postulaciones p ON g.postulacion_id = p.id
            WHERE p.evento_id = ?
        ");
        $stmtTotal->execute([$evento_id]);
        $totalFotos = (int)$stmtTotal->fetch()['total'];
        $totalPaginas = ceil($totalFotos / $limit);

        // 2. Traer fotos del evento
        $stmtF = $pdo->prepare("
            SELECT f.*, g.titulo as galeria_titulo, e.titulo as evento_titulo 
            FROM fotos f
            INNER JOIN galerias g ON f.galeria_id = g.id
            INNER JOIN postulaciones p ON g.postulacion_id = p.id
            LEFT JOIN eventos e ON p.evento_id = e.id
            WHERE p.evento_id = ?
            ORDER BY f.id DESC
            LIMIT $limit OFFSET $offset
        ");
        $stmtF->execute([$evento_id]);
        $fotos = $stmtF->fetchAll(PDO::FETCH_ASSOC);

        exit(json_encode([
            'success' => true, 
            'fotos' => $fotos, 
            'pagina_actual' => $page,
            'total_paginas' => $totalPaginas,
            'total_fotos' => $totalFotos
        ]));

    } catch (Exception $e) {
        exit(json_encode(['success' => false, 'error' => $e->getMessage()]));
    }
}
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>📸 Galería del Evento</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
</head>
<body class="bg-[#050505] text-white min-h-screen">
    <?php require 'navpublicidad.php'; ?>
    
    <div class="max-w-6xl mx-auto px-4 py-10">
        <div class="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
            <div>
                <h1 class="text-2xl font-black italic uppercase tracking-tighter text-orange-500">📸 Carrete del Evento</h1>
                <p class="text-xs text-gray-400" id="contador-total">Cargando...</p>
            </div>
            
            <div class="flex items-center gap-2">
                <button id="btn-prev" onclick="cambiarPagina(-1)" class="bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-bold disabled:opacity-30">« Ant</button>
                <span id="info-pagina" class="text-xs font-mono bg-black/40 px-3 py-1.5 rounded-xl border border-white/5">Pág: 1 / 1</span>
                <button id="btn-next" onclick="cambiarPagina(1)" class="bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-bold disabled:opacity-30">Sig »</button>
            </div>
        </div>

        <div id="loader" class="text-center my-20 text-orange-500 font-black animate-pulse text-sm uppercase tracking-widest">
            Accediendo al servidor...
        </div>

        <div id="contenedor-fotos" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"></div>
        
        <div id="alerta-vacio" class="hidden text-center my-20 text-gray-500 text-sm">
            No hay fotos cargadas para este evento.
        </div>
    </div>

<script>
    let paginaActual = 1;
    let totalPaginas = 1;
    const urlParams = new URLSearchParams(window.location.search);
    const eventoId = urlParams.get('evento_id');

    window.cambiarPagina = async function(direccion) {
        const nuevaPagina = paginaActual + direccion;
        if (nuevaPagina >= 1 && nuevaPagina <= totalPaginas) {
            paginaActual = nuevaPagina;
            await cargarFotos();
        }
    }

    async function cargarFotos() {
        if (!eventoId) return;
        
        document.getElementById('loader').classList.remove('hidden');
        
        const fd = new FormData();
        fd.append('evento_id', eventoId);
        fd.append('page', paginaActual);

        const res = await fetch(window.location.href, { method: 'POST', body: fd });
        const data = await res.json();
        
        document.getElementById('loader').classList.add('hidden');
        
        if (!data.success) return;

        totalPaginas = data.total_paginas;
        document.getElementById('contador-total').innerText = `Mostrando ${data.fotos.length} de ${data.total_fotos} fotos`;
        document.getElementById('info-pagina').innerText = `Pág: ${paginaActual} / ${totalPaginas || 1}`;
        
        document.getElementById('btn-prev').disabled = (paginaActual <= 1);
        document.getElementById('btn-next').disabled = (paginaActual >= totalPaginas);

        const cont = document.getElementById('contenedor-fotos');
        cont.innerHTML = '';

        if (data.fotos.length === 0) {
            document.getElementById('alerta-vacio').classList.remove('hidden');
        } else {
            document.getElementById('alerta-vacio').classList.add('hidden');
            data.fotos.forEach(f => {
                const card = document.createElement('div');
                card.className = 'bg-white/5 border border-white/5 rounded-2xl overflow-hidden flex flex-col group';
                card.innerHTML = `
                    <div class="relative aspect-square w-full bg-black flex items-center justify-center overflow-hidden">
                        <img src="${f.url}" loading="lazy" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                    </div>
                    <div class="p-3 text-[10px] bg-black/20">
                        <p class="text-orange-500 font-bold uppercase truncate">${f.evento_titulo || 'Evento'}</p>
                        <p class="text-gray-300 truncate">${f.galeria_titulo}</p>
                        <a href="foto_detallep.php?id=${f.id}" class="block mt-2 text-center bg-white/10 hover:bg-orange-500 hover:text-black py-1 rounded-lg uppercase font-black">Detalles</a>
                    </div>
                `;
                cont.appendChild(card);
            });
        }
    }

    // Carga inicial
    if (eventoId) {
        cargarFotos();
    } else {
        document.getElementById('loader').innerText = "Error: Falta ID de evento en la URL.";
    }
</script>
</body>
</html>