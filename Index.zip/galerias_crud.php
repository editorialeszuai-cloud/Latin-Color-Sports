<?php
require 'dbfotografos.php'; // Conexión PDO

// Procesar AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    $action = $_POST['action'] ?? '';

    // Crear galería
    if ($action === 'crear_galeria') {
        $postulacion_id = $_POST['postulacion_id'] ?? '';
        $titulo = $_POST['titulo'] ?? '';
        if (!$postulacion_id || !$titulo) {
            echo json_encode(['success'=>false,'message'=>'Datos incompletos']);
            exit;
        }
        $stmt = $pdo->prepare("INSERT INTO galerias (postulacion_id, titulo) VALUES (?, ?)");
        if($stmt->execute([$postulacion_id, $titulo])){
            echo json_encode(['success'=>true,'galeria_id'=>$pdo->lastInsertId(),'message'=>'Galería creada correctamente']);
        } else {
            echo json_encode(['success'=>false,'message'=>'Error creando galería']);
        }
        exit;
    }

    // Subir fotos
    if ($action === 'subir_fotos') {
        $galeria_id = $_POST['galeria_id'] ?? '';
        $postulacion_id = $_POST['postulacion_id'] ?? '';
        $descripcion = $_POST['descripcion'] ?? null;

        if (!$galeria_id || !$postulacion_id || !isset($_FILES['fotos'])) {
            echo json_encode(['success'=>false,'message'=>'Datos incompletos']);
            exit;
        }

        $carpeta = 'uploads/';
        if (!is_dir($carpeta)) mkdir($carpeta, 0777, true);

        $fotos = $_FILES['fotos'];
        $subidas = 0;

        for($i=0;$i<count($fotos['name']);$i++){
            $tmp = $fotos['tmp_name'][$i];
            $nombre = time().'_'.$fotos['name'][$i];
            $tipo = $fotos['type'][$i];
            $tamano_kb = round($fotos['size'][$i]/1024);

            if(move_uploaded_file($tmp, $carpeta.$nombre)){
                $stmt = $pdo->prepare("INSERT INTO fotos (galeria_id, postulacion_id, url, descripcion, tamano_kb, tipo) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$galeria_id, $postulacion_id, $nombre, $descripcion, $tamano_kb, $tipo]);
                $subidas++;
            }
        }

        echo json_encode(['success'=>true,'message'=>"$subidas fotos subidas correctamente"]);
        exit;
    }

    echo json_encode(['success'=>false,'message'=>'Acción no válida']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Galerías - Crear y Subir Fotos</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">

<h1 class="text-2xl font-bold mb-4">Crear Galería y Subir Fotos</h1>

<!-- Crear Galería -->
<div class="mb-4">
    <label>ID de Postulación:</label>
    <input type="number" id="postulacion_id" class="border rounded px-2 py-1 mb-2"><br>

    <label>Nombre de la Galería:</label>
    <input type="text" id="nombreGaleria" class="border rounded px-2 py-1 mb-2"><br>

    <label>Preset:</label>
    <select id="presetGaleria" class="border rounded px-2 py-1 mb-2">
      <option value="">-- Ninguno --</option>
      <option value="Premiación">Premiación</option>
      <option value="Deporte">Deporte</option>
    </select><br>

    <button id="btnCrearGaleria" class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded">Crear Galería</button>
</div>

<hr class="my-4">

<!-- Subir Fotos -->
<div id="subirFotosDiv" class="hidden">
    <h2 class="text-xl font-semibold mb-2">Subir Fotos</h2>
    <input type="file" id="fotosSubir" multiple class="border rounded px-2 py-1 mb-2"><br>
    <input type="text" id="descripcionFotos" placeholder="Descripción opcional" class="border rounded px-2 py-1 mb-2"><br>
    <button id="btnSubirFotos" class="bg-purple-500 hover:bg-purple-600 text-white px-3 py-1 rounded">Subir Fotos</button>
</div>

<script>
let galeriaActual = null;

// Crear galería
document.getElementById('btnCrearGaleria').addEventListener('click', async ()=> {
    let postulacion_id = document.getElementById('postulacion_id').value;
    let nombre = document.getElementById('nombreGaleria').value.trim();
    const preset = document.getElementById('presetGaleria').value;
    if(preset) nombre = preset;
    if(!postulacion_id || !nombre) return alert("Debes poner un ID y un nombre o preset");

    const fd = new FormData();
    fd.append('action','crear_galeria');
    fd.append('postulacion_id',postulacion_id);
    fd.append('titulo',nombre);

    try {
        const res = await fetch('',{method:'POST',body:fd});
        const data = await res.json();
        alert(data.message);
        if(data.success){
            galeriaActual = data.galeria_id;
            document.getElementById('subirFotosDiv').classList.remove('hidden');
        }
    } catch(err){
        console.error(err);
        alert("Error creando galería");
    }
});

// Subir fotos
document.getElementById('btnSubirFotos').addEventListener('click', async ()=> {
    if(!galeriaActual) return alert("Primero crea la galería");

    const archivos = document.getElementById('fotosSubir').files;
    if(archivos.length===0) return alert("Selecciona al menos una foto");

    const descripcion = document.getElementById('descripcionFotos').value;
    const postulacion_id = document.getElementById('postulacion_id').value;

    const fd = new FormData();
    fd.append('action','subir_fotos');
    fd.append('galeria_id',galeriaActual);
    fd.append('postulacion_id',postulacion_id);
    fd.append('descripcion',descripcion);

    for(let i=0;i<archivos.length;i++) fd.append('fotos[]',archivos[i]);

    try {
        const res = await fetch('',{method:'POST',body:fd});
        const data = await res.json();
        alert(data.message);
        if(data.success){
            document.getElementById('fotosSubir').value='';
            document.getElementById('descripcionFotos').value='';
        }
    } catch(err){
        console.error(err);
        alert("Error subiendo fotos");
    }
});
</script>
</body>
</html>
