<?php
header('Content-Type: application/json');
require_once "conexion.php";
$conn = conectar();
$input=json_decode(file_get_contents('php://input'),true);
function resp($status,$msg='',$data=null){ echo json_encode(['status'=>$status,'message'=>$msg,'data'=>$data]); exit;}
$accion=$input['accion']??'';

try{
    if($accion==='crear'){
        $nombre=$input['nombre_disciplina']??''; 
        $descripcion=$input['descripcion']??'';
        if(!$nombre) resp('error','El nombre de la disciplina es obligatorio.');
        $stmt=$conn->prepare("INSERT INTO disciplinas(nombre_disciplina,descripcion) VALUES(?,?)");
        $stmt->bind_param("ss",$nombre,$descripcion); 
        $stmt->execute() or resp('error','Error BD: '.$stmt->error);
        resp('success','Disciplina creada.');
    }
    elseif($accion==='editar'){
        $id=intval($input['id']??0); 
        $nombre=$input['nombre_disciplina']??''; 
        $descripcion=$input['descripcion']??'';
        if(!$id) resp('error','ID inválido.'); 
        if(!$nombre) resp('error','El nombre de la disciplina es obligatorio.');
        $stmt=$conn->prepare("UPDATE disciplinas SET nombre_disciplina=?, descripcion=? WHERE id=?");
        $stmt->bind_param("ssi",$nombre,$descripcion,$id); 
        $stmt->execute() or resp('error','Error BD: '.$stmt->error);
        resp('success','Disciplina actualizada.');
    }
    elseif($accion==='eliminar'){
        $id=intval($input['id']??0); 
        if(!$id) resp('error','ID inválido.');
        $stmt=$conn->prepare("DELETE FROM disciplinas WHERE id=?"); 
        $stmt->bind_param("i",$id); 
        $stmt->execute() or resp('error','Error BD: '.$stmt->error);
        resp('success','Disciplina eliminada.');
    }
    elseif($accion==='listar'){
        $result=$conn->query("SELECT * FROM disciplinas ORDER BY nombre_disciplina ASC"); 
        $data=[];
        while($row=$result->fetch_assoc()) $data[]=$row; 
        resp('success','Disciplinas obtenidas',$data);
    }else{ 
        resp('error','Acción desconocida.'); 
    }
}catch(Exception $e){ 
    resp('error',$e->getMessage()); 
}
?>
