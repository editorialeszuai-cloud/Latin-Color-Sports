<?php
ini_set('display_errors', 0);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

try {
    require 'dbfotografos.php'; 

    // 1. VALIDAR ENTRADA
    $firebase_uid = $_POST['firebase_uid'] ?? null;
    $evento_id    = (int)($_POST['evento_id'] ?? 0);

    if (!$firebase_uid || !$evento_id) {
        throw new Exception("Faltan parámetros de búsqueda.");
    }

    // 2. OBTENER EL DESCRIPTOR DEL PERFIL
    $stmtUser = $pdo->prepare("SELECT descriptor FROM perfiles_biometricos WHERE firebase_uid = ? LIMIT 1");
    $stmtUser->execute([$firebase_uid]);
    $userRow = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$userRow) {
        echo json_encode(['success' => false, 'message' => 'No tienes perfil biométrico registrado']);
        exit;
    }

    $user_descriptor = json_decode($userRow['descriptor'], true);
    if (!$user_descriptor || count($user_descriptor) !== 128) {
        throw new Exception("Error en el formato de tu biometría.");
    }

    // 3. OBTENER TODAS LAS CARAS DEL EVENTO (con miniatura)
    $stmtFaces = $pdo->prepare("
        SELECT f.id AS foto_id, f.url, m.url_miniatura, fs.descriptor 
        FROM faces fs
        INNER JOIN fotos f ON fs.foto_id = f.id
        INNER JOIN postulaciones p ON f.postulacion_id = p.id
        LEFT JOIN miniaturas m ON f.id = m.foto_id
        WHERE p.evento_id = ?
    ");
    $stmtFaces->execute([$evento_id]);
    $fotos_evento = $stmtFaces->fetchAll(PDO::FETCH_ASSOC);

    $matches    = [];
    $threshold  = 0.55;

    // 4. COMPARACIÓN MATEMÁTICA
    foreach ($fotos_evento as $f) {
        $db_descriptor = json_decode($f['descriptor'], true);
        if (!$db_descriptor || count($db_descriptor) !== 128) continue;

        $sum = 0;
        for ($i = 0; $i < 128; $i++) {
            $dif  = $db_descriptor[$i] - $user_descriptor[$i];
            $sum += $dif * $dif;
        }
        $distance = sqrt($sum);

        if ($distance < $threshold) {
            $matches[] = [
                'id'           => $f['foto_id'],
                'url'          => $f['url'],
                'url_miniatura'=> $f['url_miniatura'],
                'dist'         => $distance,
                'nivel'        => "Exacta"
            ];
        }
    }

    // 5. ORDENAR POR CERCANÍA
    usort($matches, function($a, $b) {
        return $a['dist'] <=> $b['dist'];
    });

    // 6. CACHÉ TEMPORAL
    $token  = md5(uniqid($firebase_uid, true));
    $tmpDir = __DIR__ . "/tmp";
    if (!is_dir($tmpDir)) mkdir($tmpDir, 0777, true);
    file_put_contents("$tmpDir/faces_busqueda_$token.json", json_encode($matches));

    $verMas = "ver_mas_resultados.php?token={$token}&evento_id={$evento_id}";

    // 7. RESPUESTA AL FRONTEND
    echo json_encode([
        'success' => true,
        'total'   => count($matches),
        'fotos'   => array_slice($matches, 0, 8),
        'ver_mas' => $verMas,
        'token'   => $token
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}