<?php
// ver_foto.php
ini_set('display_errors', 0); // Desactivar errores visibles en producción
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
session_start();
require 'dbfotografos.php';

$foto_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($foto_id <= 0) die('ID de foto inválido.');

// 1. CONSULTA PRINCIPAL (con miniatura)
$stmt = $pdo->prepare("
    SELECT f.id AS foto_id, f.url AS nombre_archivo, f.descripcion, 
           e.titulo AS evento_titulo, e.id AS evento_id, e.paquetes_eventos, 
           u.nombre AS fotografo_nombre, l.pais AS pais_lugar,
           m.url_miniatura
    FROM fotos f
	INNER JOIN galerias g ON f.galeria_id = g.id
    INNER JOIN postulaciones p ON g.postulacion_id = p.id
    INNER JOIN eventos e ON p.evento_id = e.id
    INNER JOIN usuarios u ON p.usuario_id = u.id
    LEFT JOIN lugares l ON e.lugar_id = l.id
    LEFT JOIN miniaturas m ON f.id = m.foto_id
    WHERE f.id=? LIMIT 1
");
$stmt->execute([$foto_id]);
$foto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$foto) die('Foto no encontrada.');

// Moneda dinámica según país del evento
$es_colombia = (isset($foto['pais_lugar']) && trim(strtolower($foto['pais_lugar'])) === 'colombia');
$moneda = $es_colombia ? 'COP' : 'USD';

$evento_id = $foto['evento_id'];
$paquetes = [];
$precio_unitario_base = 1500;

// 2. LÓGICA DE PAQUETES
$valor_crudo = $foto['paquetes_eventos'] ?? '';
$ids_limpios = preg_replace('/[^0-9,]/', '', $valor_crudo);
if (!empty($ids_limpios)) {
    $ids_array = array_filter(explode(',', $ids_limpios), 'strlen');
    if (!empty($ids_array)) {
        $placeholders = implode(',', array_fill(0, count($ids_array), '?'));
        $stmt_p = $pdo->prepare("SELECT id, nombre_paquete, unidades_incluidas, precio_por_unidad FROM paquetes_fotos WHERE id IN ($placeholders) ORDER BY precio_por_unidad DESC");
        $stmt_p->execute(array_values($ids_array));
        $paquetes = $stmt_p->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($paquetes)) $precio_unitario_base = $paquetes[0]['precio_por_unidad'];
    }
}

// Helper para formatear precio según moneda
function formatPrecio($precio, $es_colombia) {
    return $es_colombia
        ? '$' . number_format($precio, 0, ',', '.')
        : '$' . number_format($precio, 2, '.', ',') . ' USD';
}

// 3. FOTOS SIMILARES (SLIDER CON MINIATURAS)
$stmt_slider = $pdo->prepare("
    SELECT f.id, f.url, m.url_miniatura
    FROM fotos f
    LEFT JOIN miniaturas m ON f.id = m.foto_id
    WHERE f.postulacion_id IN (SELECT id FROM postulaciones WHERE evento_id = ?)
    AND f.id <> ?
    ORDER BY RAND() LIMIT 15
");
$stmt_slider->execute([$evento_id, $foto_id]);
$fotos_slider = $stmt_slider->fetchAll(PDO::FETCH_ASSOC);

// Construcción de la URL absoluta para compartir en redes
$protocolo = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$url_compartir = $protocolo . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta property="og:type" content="website">
<meta property="og:url" content="https://latincolorsports.com/ver_foto.php?id=<?= $foto_id ?>">
<meta property="og:title" content="Latin Color Sports - <?= htmlspecialchars($foto['evento_titulo']) ?>">
<meta property="og:description" content="Fotografía capturada por <?= htmlspecialchars($foto['fotografo_nombre']) ?>. ¡Consigue la tuya!">

<meta property="og:image" content="https://www.latincolorsports.com/uploads/LATIN-SPORTS.png">
<meta property="og:image:type" content="image/png">

    <title>Ver Foto - <?= htmlspecialchars($foto['evento_titulo']) ?></title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body { background:#0a0a0a; color:#eee; font-family:'Inter',sans-serif; user-select:none; -webkit-touch-callout:none; overflow-x:hidden; }
        .drawer { transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1); }

        /* SLIDER */
        .slider-scroll { display:flex; overflow-x:auto; gap:12px; scrollbar-width:none; padding-bottom:10px; }
        .slider-scroll::-webkit-scrollbar { display:none; }
        .slider-card { flex:0 0 120px; height:120px; border-radius:16px; overflow:hidden; border:1px solid #222; background:#111; }

        /* CONTENEDOR DE SEGURIDAD */
        #protection-container {
            position:relative; display:inline-block; border-radius:24px;
            overflow:hidden; background:#000; max-width:500px; width:100%;
        }
        canvas { display:block; width:100%; height:auto; transition:filter 0.15s ease; }

        /* Bloqueo */
        .locked canvas { filter:blur(40px) brightness(0.2); }
        #shield-msg {
            position:absolute; inset:0; display:flex; flex-direction:column;
            align-items:center; justify-content:center; background:rgba(0,0,0,0.85);
            opacity:0; pointer-events:none; z-index:20; transition:opacity 0.2s;
        }
        .locked #shield-msg { opacity:1; pointer-events:auto; }
    </style>
</head>
<body oncontextmenu="return false;">

<nav class="flex items-center justify-between p-4 bg-black border-b border-white/5 sticky top-0 z-40">
    <a href="https://fanpic.latincolorsports.com/panel" class="p-2 bg-white/5 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-300 hover:text-white transition-colors">← Volver</a>
    <button onclick="window.toggleCart(true)" class="relative p-2 bg-orange-600/10 rounded-xl border border-orange-600/20 flex items-center gap-2">
        <span class="material-icons text-orange-500 text-sm">shopping_cart</span>
        <span id="cartCount" class="text-[10px] font-black text-white">0</span>
    </button>
</nav>

<main class="max-w-5xl mx-auto p-4 lg:p-8">

    <div class="hidden mb-8 bg-gradient-to-br from-orange-600 via-orange-500 to-amber-500 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 border border-white/10">
        <div class="text-center md:text-left">
            <h2 class="text-white font-black text-2xl uppercase italic tracking-tighter leading-none">Pack "Todas las Fotos"</h2>
            <p class="text-orange-100 text-[10px] font-bold uppercase tracking-[0.2em] mt-1">Lleva el evento completo por un precio único</p>
        </div>
        <button onclick="window.addFullPack(<?= $evento_id ?>)" id="btnPackAction"
                class="bg-white text-orange-600 font-black px-10 py-4 rounded-2xl text-[10px] uppercase tracking-widest hover:bg-black hover:text-white transition-all shadow-xl active:scale-95">
            Adquirir Pack Completo
        </button>
    </div>

    <div class="flex flex-col items-center mb-10">
        <div id="protection-container">
            <canvas id="foto-canvas"></canvas>
            <div id="shield-msg">
                <span class="material-icons text-orange-500 text-5xl mb-2">security</span>
                <p class="text-[9px] font-black uppercase tracking-widest text-center px-6">Protección Activa</p>
            </div>
        </div>
    </div>

    <div class="max-w-2xl mx-auto bg-[#111] border border-[#222] p-8 rounded-3xl text-center shadow-2xl mb-6">
        <h1 class="text-xl font-black text-white mb-1 uppercase tracking-tighter italic"><?= htmlspecialchars($foto['evento_titulo']) ?></h1>
        <p class="text-[10px] text-gray-500 uppercase tracking-[0.3em] mb-8">Captura por: <?= htmlspecialchars($foto['fotografo_nombre']) ?></p>

        <div class="grid grid-cols-3 gap-3 mb-8">
    <?php if (!empty($paquetes)): ?>
        <?php foreach ($paquetes as $index => $p_item): 
            $total_paquete = $p_item['precio_por_unidad'] * $p_item['unidades_incluidas'];
        ?>
            <div class="<?= ($index === 1) ? 'bg-orange-600/10 border-orange-600/40' : 'bg-black/40 border-white/5' ?> p-3 rounded-2xl border transition-all">
                <p class="text-[8px] <?= ($index === 1) ? 'text-orange-500' : 'text-gray-500' ?> font-black uppercase tracking-widest mb-1">
                    <?= htmlspecialchars($p_item['nombre_paquete']) ?>
                </p>
                <p class="font-black text-white text-lg">
                    <?= formatPrecio($total_paquete, $es_colombia) ?>
                </p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <?php endif; ?>
</div>

        <?php if ($precio_unitario_base == 0): ?>
            <a href="fotos.php?id=<?= $foto_id ?>"
               class="inline-block w-full text-center px-4 py-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl backdrop-blur-sm transition-all duration-200 border border-white/10 shadow-lg text-sm font-bold uppercase tracking-widest">
                Descargar Fotos
            </a>
        <?php else: ?>
            <div class="flex flex-col gap-4">
                <p class="font-black text-white text-2xl"><?= formatPrecio($precio_unitario_base, $es_colombia) ?></p>
                <button id="addCartBtn"
                        onclick="window.addToCart(<?= $foto_id ?>)"
                        class="w-full bg-orange-600 hover:bg-orange-500 text-white font-black py-5 rounded-2xl transition-all shadow-lg active:scale-95 uppercase text-xs tracking-[3px]">
                    Agregar al carrito
                </button>
            </div>
        <?php endif; ?>
    </div>

    <div class="max-w-2xl mx-auto mb-12 px-4">
        <p class="text-[9px] text-gray-500 uppercase font-black text-center tracking-[4px] mb-4">Compartir esta fotografía</p>
        <div class="flex flex-wrap items-center justify-center gap-3">
            
            <a href="https://api.whatsapp.com/send?text=<?= urlencode('¡Mira esta increíble foto en Latin Color Sports!: ' . $url_compartir) ?>" 
               target="_blank" rel="noopener"
               class="flex items-center gap-2 px-4 py-2.5 bg-[#25D366]/10 border border-[#25D366]/20 rounded-xl text-xs font-bold text-[#25D366] hover:bg-[#25D366] hover:text-black transition-all">
               <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397 0 11.93 0c3.167.001 6.145 1.233 8.384 3.473 2.239 2.24 3.469 5.218 3.469 8.385 0 6.539-5.337 11.887-11.873 11.887-1.996-.001-3.957-.502-5.691-1.456L0 24zm5.811-3.61c1.594.946 3.518 1.446 5.483 1.448 5.568 0 10.1-4.507 10.1-10.046 0-2.684-1.044-5.207-2.939-7.104C16.567 2.791 14.05 1.747 11.382 1.747c-5.576 0-10.1-4.507-10.108 10.048 0 2.022.529 4.001 1.532 5.761l-1.01 3.693 3.823-.997z"/></svg>
               WhatsApp
            </a>

            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($url_compartir) ?>" 
               target="_blank" rel="noopener"
               class="flex items-center gap-2 px-4 py-2.5 bg-[#1877F2]/10 border border-[#1877F2]/20 rounded-xl text-xs font-bold text-[#1877F2] hover:bg-[#1877F2] hover:text-white transition-all">
               <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
               Facebook
            </a>

            <a href="https://telegram.me/share/url?url=<?= urlencode($url_compartir) ?>&text=<?= urlencode('¡Mira esta increíble foto de Latin Color Sports!') ?>" 
               target="_blank" rel="noopener"
               class="flex items-center gap-2 px-4 py-2.5 bg-[#0088cc]/10 border border-[#0088cc]/20 rounded-xl text-xs font-bold text-[#0088cc] hover:bg-[#0088cc] hover:text-white transition-all">
               <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.562 8.161c-.18 1.897-.962 6.505-1.359 8.631-.168.9-.5 1.201-.82 1.23-.702.064-1.233-.464-1.913-.91-1.065-.7-1.67-1.135-2.706-1.817-1.197-.79-1.748-1.227-2.812-1.926-.297-.196-.587-.39-.854-.538-.51-.282-.9-.434-1.236-.325-.262.085-.794.341-1.183.468-.477.155-.857.234-.824.498.017.137.203.279.558.424.417.17.844.312 1.25.426.398.111.706.075.92-.108l6.353-4.01c.29-.196.556-.09.336.105l-5.145 4.636-.2.868.597-.37 1.83 1.204c1.11.815 1.914.394 2.19-.3.265-1.25.91-5.385 1.15-7.902.04-.424-.078-.696-.341-.715-.494-.037-.966.195-1.213.435z"/></svg>
               Telegram
            </a>

            <button onclick="window.copiarEnlaceAlPortapapeles(this)"
               class="flex items-center gap-2 px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs font-bold text-gray-300 hover:bg-white/10 hover:text-white transition-all">
               <span class="material-icons text-sm">content_copy</span>
               <span id="txt-copiar">Copiar Link</span>
            </button>
        </div>
    </div>

    <div class="mt-8">
        <p class="text-[10px] text-gray-600 uppercase font-black mb-6 text-center tracking-[4px]">Más fotos del evento</p>
        <div class="slider-scroll">
            <?php
            $fotos_limitadas = array_slice($fotos_slider, 0, 4);
            foreach ($fotos_limitadas as $fs):
                $imgSrc = !empty($fs['url_miniatura'])
                    ? $fs['url_miniatura']
                    : 'minion.php?id=' . $fs['id'] . '&tipo=original';
            ?>
                <a href="ver_foto.php?id=<?= $fs['id'] ?>" class="slider-card shrink-0 block">
                    <div class="image-container relative group overflow-hidden rounded-xl shadow-lg w-full h-full" oncontextmenu="return false;">
                        <img src="<?= htmlspecialchars($imgSrc) ?>"
                             class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 relative z-0"
                             loading="lazy" draggable="false">
                        <div class="absolute inset-0 z-10 pointer-events-none"
                             style="background-image:url('uploads/watermark.png'); background-repeat:repeat; background-size:100px; user-select:none;"></div>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

</main>

<div id="overlay" class="fixed inset-0 bg-black/90 z-40 hidden" onclick="window.toggleCart(false)"></div>
<aside id="carritoContainer" class="drawer fixed inset-y-0 right-0 w-full sm:w-[380px] bg-gray-900 z-50 transform translate-x-full flex flex-col shadow-2xl">
    <div class="p-4 border-b border-white/5 flex items-center justify-between">
        <button id="btnCloseCart" class="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-all">
            <span class="material-icons text-base">arrow_back</span>
            Seguir comprando
        </button>
    </div>
    <div id="carritoContent" class="flex-1 overflow-y-auto flex flex-col"></div>
</aside>
<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// ─── SISTEMA GUEST + LOGIN ───────────────────────────────────────────────────
function getGuestUID() {
    let uid = localStorage.getItem('guest_uid');
    if (!uid) {
        uid = 'guest_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('guest_uid', uid);
    }
    return uid;
}

window.firebase_uid = getGuestUID(); 
window.guest_uid    = window.firebase_uid;

// Escuchar los cambios de autenticación usando el 'auth' importado desde tu config
onAuthStateChanged(auth, (user) => {
    if (user) {
        window.guest_uid    = window.firebase_uid; 
        window.firebase_uid = user.uid;            
    }
    loadCarrito(); 
});
// ─────────────────────────────────────────────────────────────────────────────

// ─── CANVAS Y PROTECCIÓN ─────────────────────────────────────────────────────
const canvas       = document.getElementById('foto-canvas');
const container    = document.getElementById('protection-container');
const ctx          = canvas.getContext('2d');
const imgObj       = new Image();
const watermarkObj = new Image();

imgObj.crossOrigin = "Anonymous";
imgObj.src = 'minion.php?id=<?= $foto_id ?>&tipo=<?= !empty($foto['url_miniatura']) ? 'mini' : 'original' ?>';
watermarkObj.src = 'uploads/watermark.png';

function drawCanvas() {
    canvas.width  = 1080;
    canvas.height = 600;

    const hRatio = canvas.width  / imgObj.naturalWidth;
    const vRatio = canvas.height / imgObj.naturalHeight;
    const ratio  = Math.min(hRatio, vRatio);
    const cx = (canvas.width  - imgObj.naturalWidth  * ratio) / 2;
    const cy = (canvas.height - imgObj.naturalHeight * ratio) / 2;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(imgObj, 0, 0, imgObj.naturalWidth, imgObj.naturalHeight,
                  cx, cy, imgObj.naturalWidth * ratio, imgObj.naturalHeight * ratio);

    if (watermarkObj.complete && watermarkObj.naturalWidth > 0) {
        const pattern = ctx.createPattern(watermarkObj, 'repeat');
        if (pattern) {
            // ─── NUEVA LÓGICA DE ESCALA PARA LA MARCA DE AGUA ───
            const escalaMarcaAgua = 0.35; // 0.35 significa el 35% de su tamaño original. ¡Bájalo más si la quieres aún más pequeña!
            
            // Creamos una matriz de transformación para achicar el patrón
            const matrix = new DOMMatrix();
            matrix.scaleSelf(escalaMarcaAgua, escalaMarcaAgua);
            pattern.setTransform(matrix);
            // ─────────────────────────────────────────────────────

            ctx.globalAlpha = 0.45; // Mantienes la opacidad actual
            ctx.fillStyle   = pattern;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.globalAlpha = 1.0;
        }
    }
}

Promise.all([
    new Promise(res => { imgObj.onload       = res; imgObj.onerror       = res; }),
    new Promise(res => { watermarkObj.onload = res; watermarkObj.onerror = res; })
]).then(drawCanvas);

const lock        = () => container.classList.add('locked');
const unlock      = () => container.classList.remove('locked');
const flashShield = () => { lock(); setTimeout(unlock, 1800); };

canvas.addEventListener('dragstart', (e) => { e.preventDefault(); flashShield(); });

container.addEventListener('mousedown', (e) => {
    if (e.button === 2 || e.ctrlKey || e.shiftKey) { e.preventDefault(); flashShield(); }
});

window.addEventListener('keydown', (e) => {
    if (
        e.key === 'PrintScreen' ||
        ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') ||
        (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'i') ||
        e.key === 'F12'
    ) {
        lock();
        ctx.fillStyle = "black";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        setTimeout(() => { drawCanvas(); unlock(); }, 2000);
    }
});
// ─────────────────────────────────────────────────────────────────────────────

// ─── CARRITO Y COMPARTIR ─────────────────────────────────────────────────────
window.toggleCart = (show) => {
    document.getElementById('carritoContainer').classList.toggle('translate-x-full', !show);
    document.getElementById('overlay').classList.toggle('hidden', !show);
};

async function loadCarrito() {
    const res  = await fetch(`ver_carrito.php?firebase_uid=${encodeURIComponent(window.firebase_uid)}&t=${Date.now()}`);
    const html = await res.text();
    const div  = document.getElementById('carritoContent');
    div.innerHTML = html;
    const total = div.querySelector('#total_items_real');
    document.getElementById('cartCount').innerText = total ? total.value : "0";
}

window.addToCart = async (id) => {
    await fetch(`agregarcarrito.php?firebase_uid=${encodeURIComponent(window.firebase_uid)}&foto_id=${id}`);
    await loadCarrito();
    window.toggleCart(true);
};

window.addFullPack = async (evId) => {
    const btn = document.getElementById('btnPackAction');
    const textoOriginal = btn ? btn.innerHTML : '';
    if (btn) { btn.disabled = true; btn.innerHTML = 'Añadiendo...'; }

    await fetch('agregar_evento_carrito.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `evento_id=${evId}&firebase_uid=${encodeURIComponent(window.firebase_uid)}`
    });

    await loadCarrito();
    window.toggleCart(true);
    if (btn) { btn.disabled = false; btn.innerHTML = textoOriginal; }
};

// Copiar Enlace Dinámico
window.copiarEnlaceAlPortapapeles = async function(btn) {
    const txtCopiar = document.getElementById('txt-copiar');
    const urlActual = window.location.href;

    try {
        await navigator.clipboard.writeText(urlActual);
        
        btn.classList.replace('bg-white/5', 'bg-emerald-500/20');
        btn.classList.replace('border-white/10', 'border-emerald-500/30');
        btn.classList.replace('text-gray-300', 'text-emerald-400');
        txtCopiar.innerText = "¡Copiado!";

        setTimeout(() => {
            btn.classList.replace('bg-emerald-500/20', 'bg-white/5');
            btn.classList.replace('border-emerald-500/30', 'border-white/10');
            btn.classList.replace('text-emerald-400', 'text-gray-300');
            txtCopiar.innerText = "Copiar Link";
        }, 2000);

    } catch (err) {
        console.error('No se pudo copiar el link: ', err);
    }
};

// Delegación de clicks globales para el carrito
document.addEventListener('click', async (e) => {
    if (e.target.closest('#btnCloseCart')) {
        window.toggleCart(false);
    }

    const btnDel = e.target.closest('.js-btn-eliminar');
    if (btnDel) {
        btnDel.disabled = true;
        await fetch('eliminar_item.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `id=${btnDel.dataset.id}`
        });
        await loadCarrito();
    }

    const btnDelEvento = e.target.closest('.js-btn-eliminar-evento');
    if (btnDelEvento) {
        btnDelEvento.disabled = true;
        await fetch('eliminar_pack_carrito.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `evento_id=${btnDelEvento.dataset.eventoId}&firebase_uid=${encodeURIComponent(window.firebase_uid)}`
        });
        await loadCarrito();
    }
});
// ─────────────────────────────────────────────────────────────────────────────
</script>