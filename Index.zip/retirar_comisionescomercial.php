<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'dbfotografos.php';
$pdo = conectar();
header('Content-Type: application/json; charset=utf-8');

function resp($status, $message, $extra = []) {
    echo json_encode(array_merge(['status' => $status, 'message' => $message], $extra));
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) resp('error', 'No se recibieron datos JSON');

$comisiones_ids = $input['comisiones'] ?? [];
$firebase_uid = $input['firebase_uid'] ?? null;
$tipo = 'comercial';

if (empty($comisiones_ids)) resp('error', 'No seleccionaste comisiones');
if (!$firebase_uid) resp('error', 'Usuario no identificado');

try {
    // 1. Validar que las comisiones existan en la tabla de origen
    $placeholders = str_repeat('?,', count($comisiones_ids) - 1) . '?';
    $stmtVal = $pdo->prepare("SELECT id, comercial FROM comisiones_usuario WHERE id IN ($placeholders)");
    $stmtVal->execute($comisiones_ids);
    $validados = $stmtVal->fetchAll(PDO::FETCH_ASSOC);

    if (empty($validados)) resp('error', 'Comisiones no válidas');

    $pdo->beginTransaction();
    $fecha_actual = date('Y-m-d H:i:s');

    // 2. Preparar INSERT con TUS columnas exactas
    $stmt = $pdo->prepare("
        INSERT INTO retiros_comisiones (comision_id, firebase_uid, total, fecha, retirada, tipo)
        VALUES (:com_id, :fb_uid, :total, :fecha, 1, :tipo)
        ON DUPLICATE KEY UPDATE retirada = 1, fecha = :fecha
    ");

    foreach ($validados as $c) {
        $stmt->execute([
            ':com_id' => $c['id'],
            ':fb_uid' => $firebase_uid,
            ':total'  => floatval($c['comercial']),
            ':fecha'  => $fecha_actual,
            ':tipo'   => $tipo
        ]);
    }

    $pdo->commit();
    resp('success', 'Solicitud de retiro procesada correctamente');

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    resp('error', 'Error al insertar', ['debug' => $e->getMessage()]);
}