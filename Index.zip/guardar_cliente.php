<?php
require 'dbfotografos.php';
$pdo = conectar();
$data = json_decode(file_get_contents('php://input'), true);

try {
    $pdo->beginTransaction();

    // 1. Guardar en la nueva tabla de invitados
    $stmt = $pdo->prepare("INSERT INTO clientes_invitados (nombre, email, whatsapp, compra_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$data['nombre'], $data['email'], $data['whatsapp'], $data['compra_id']]);

    // 2. Opcional: Marcar la compra como "Datos recolectados"
    $stmtUpdate = $pdo->prepare("UPDATE compras SET estado = 'Datos Recolectados' WHERE id = ?");
    $stmtUpdate->execute([$data['compra_id']]);

    $pdo->commit();
    echo json_encode(['status' => 'ok']);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}