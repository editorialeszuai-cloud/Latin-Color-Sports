<?php
header('Content-Type: application/json; charset=utf-8');
include 'dbfotografos.php';
$pdo = conectar();
$accion = $_POST['accion'] ?? '';

if ($accion === 'ver_asignaciones_fotografo') {
    try {
        $usuario_id = $_POST['usuario_id'] ?? 0;
        
        // Ahora usamos cf.partido_id para hacer JOIN directo con la tabla partidos
        $sql = "SELECT 
		cf.id AS idf,
            cf.postulacion_id AS asignacion_id,
            cf.evento_id, cf.calendario_id, cf.bloque_id, 
            cf.fecha, cf.hora,
            ev.titulo AS evento,
            ce.nombre AS calendario,
            s.titulo AS sede,
            esc.nombre AS escenario,
            d.nombre_disciplina AS disciplina,
            cbd.categoria,
            p.equipo_a,
            p.equipo_b
        FROM calendario_fotografos cf
        LEFT JOIN eventos ev ON cf.evento_id = ev.id
        LEFT JOIN calendario_evento ce ON cf.calendario_id = ce.id
        LEFT JOIN sedes s ON cf.sede_id = s.id
        LEFT JOIN escenarios esc ON cf.escenario_id = esc.id
        LEFT JOIN disciplinas d ON cf.disciplina_id = d.id
        /* Aquí usamos la nueva clave directa */
        LEFT JOIN calendario_bloque_disciplina cbd ON cbd.id = cf.bloque_dis_id
        LEFT JOIN partidos p ON p.id = cf.partido_id 
        WHERE cf.fotografo_id = ?
        ORDER BY cf.fecha, cf.hora";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$usuario_id]);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $data]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>