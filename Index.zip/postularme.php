<?php require 'navfotografo.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Postularme a Eventos</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
</head>

 
<body class="bg-gray-50">
    <br>
    <div class="container mx-auto px-4">
        <h1 class="text-3xl font-bold mb-6">Eventos Disponibles</h1>
        
        <div class="mb-6">
            <input type="text" id="buscador" 
                   placeholder="🔍 Buscar por nombre, lugar o descripción..." 
                   class="w-full p-4 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-green-500 outline-none transition-all">
        </div>

        <div id="eventosContainer" class="space-y-4">
            <p class="text-gray-500 text-center py-10">Cargando eventos...</p>
        </div>
    </div>

    <div id="modalEvento" class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50">
        <div class="bg-white rounded-2xl shadow-xl w-11/12 md:w-1/2 p-6 animate-in fade-in zoom-in duration-200">
            <h2 id="modalTitulo" class="text-2xl font-bold mb-2"></h2>
            <p id="modalFecha" class="text-gray-600 mb-1 font-medium"></p>
            <p id="modalLugar" class="text-gray-600 mb-1"></p>
            <p id="modalDescripcion" class="text-gray-700 mt-3 bg-gray-50 p-4 rounded-lg"></p>
            
            <div class="mt-6 flex justify-end space-x-3">
                <button id="cancelarBtn" class="px-5 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors">Cancelar</button>
                <button id="confirmarBtn" class="px-5 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">Confirmar Postulación</button>
            </div>
        </div>
    </div>

    <script type="module">
        import { auth } from './firebase-config.js';
        import { onAuthStateChanged, getIdToken } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

        let eventosCache = [];

        // Función para renderizar la lista de eventos
        function renderEventos(lista) {
            const container = document.getElementById('eventosContainer');
            container.innerHTML = '';

            if (lista.length === 0) {
                container.innerHTML = `<p class="text-gray-500 text-center py-10">No se encontraron eventos coincidentes.</p>`;
                return;
            }

            lista.forEach(ev => {
                const card = document.createElement('div');
                card.className = 'bg-white p-5 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center hover:shadow-md transition-shadow';
                card.innerHTML = `
                    <div>
                        <h2 class="font-bold text-xl text-gray-800">${ev.titulo}</h2>
                        <p class="text-gray-500 text-sm">${ev.fecha} | 📍 ${ev.lugar_nombre || 'Sin ubicación'}</p>
                    </div>
                    <button class="px-5 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
                            onclick="window.verEvento(${ev.id})">
                        Postularme
                    </button>
                `;
                container.appendChild(card);
            });
        }

        // Cargar eventos desde la API
        async function loadEventos(uid) {
            try {
                const token = await getIdToken(auth.currentUser);
                const res = await fetch('postulaciones_api2.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({accion: 'listar', firebase_token: token})
                });

                const data = await res.json();
                if (data.status === 'success') {
                    eventosCache = data.data;
                    renderEventos(eventosCache);
                } else {
                    document.getElementById('eventosContainer').innerHTML = `<p class="text-red-600 text-center">Error: ${data.message}</p>`;
                }
            } catch (err) {
                console.error(err);
            }
        }

        // Buscador en tiempo real
        document.getElementById('buscador').addEventListener('input', (e) => {
            const term = e.target.value.toLowerCase();
            const filtrados = eventosCache.filter(ev => 
                ev.titulo.toLowerCase().includes(term) || 
                (ev.lugar_nombre && ev.lugar_nombre.toLowerCase().includes(term)) ||
                (ev.descripcion && ev.descripcion.toLowerCase().includes(term))
            );
            renderEventos(filtrados);
        });

        // Lógica del Modal
        window.verEvento = (evento_id) => {
            const ev = eventosCache.find(e => e.id == evento_id);
            if (!ev) return;

            document.getElementById('modalTitulo').textContent = ev.titulo;
            document.getElementById('modalFecha').textContent = `📅 ${ev.fecha} ${ev.fechafin ? 'al ' + ev.fechafin : ''}`;
            document.getElementById('modalLugar').textContent = `📍 ${ev.lugar_nombre || 'No especificado'}`;
            document.getElementById('modalDescripcion').textContent = ev.descripcion || 'Sin descripción.';

            const modal = document.getElementById('modalEvento');
            modal.classList.remove('hidden');
            modal.classList.add('flex');

            document.getElementById('confirmarBtn').onclick = () => {
                postular(ev.id);
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            };
        };

        function cerrarModal() {
            document.getElementById('modalEvento').classList.add('hidden');
            document.getElementById('modalEvento').classList.remove('flex');
        }

        async function postular(evento_id) {
            const token = await getIdToken(auth.currentUser);
            const res = await fetch('postulaciones_api2.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({accion: 'postular', firebase_token: token, evento_id})
            });
            const data = await res.json();
            alert(data.message);
            if(data.status === 'success') loadEventos();
        }

        document.getElementById('cancelarBtn').addEventListener('click', cerrarModal);

        // Auth
        onAuthStateChanged(auth, (user) => {
            if (user) loadEventos(user.uid);
            else window.location.href = 'login_app.html';
        });
    </script>
</body>
</html>