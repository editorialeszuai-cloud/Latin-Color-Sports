<?php
header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);

$apiKey = "4Vj8eK4rloUd272L48hsrarnU"; // <<-- PON TU API KEY DE PAYU
$merchantId = "508029";
$referenceCode = $input['reference'];
$amount = number_format((float)$input['total'], 1, '.', ''); 
$currency = "USD"; // Asegúrate que sea la misma que en el formulario

// La fórmula de PayU: ApiKey~MerchantId~ReferenceCode~Amount~Currency
$stringFirma = $apiKey . "~" . $merchantId . "~" . $referenceCode . "~" . $amount . "~" . $currency;
$signature = md5($stringFirma);

echo json_encode(['signature' => $signature]);
?>