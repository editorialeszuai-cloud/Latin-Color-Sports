<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');
require 'dbfotografos.php';

$pdo = conectar();
$uploadDir = __DIR__ . '/uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

// ===========================
// CRUD POST (crear / editar / eliminar)
// ===========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $accion = $_POST['accion'] ?? 'crear';
    $firebase_uid = $_POST['firebase_uid'] ?? '';

    if (!$firebase_uid) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    // Obtener ID usuario
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid=:uid");
    $stmt->execute(['uid' => $firebase_uid]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    $user_id = $usuario['id'];

    // ---- Crear o Editar ----
    if ($accion === 'crear' || $accion === 'editar') {
        $banco = trim($_POST['banco'] ?? '');
        $tipo_cuenta = trim($_POST['tipo_cuenta'] ?? '');
        $numero_cuenta = trim($_POST['numero_cuenta'] ?? '');
        $titular = trim($_POST['titular'] ?? '');
        $cedula = trim($_POST['cedula'] ?? '');
        $celular = trim($_POST['celular'] ?? '');

        if (!$banco || !$tipo_cuenta || !$numero_cuenta || !$titular || !$cedula || !$celular) {
            echo json_encode(['status' => 'error', 'message' => 'Faltan campos obligatorios']);
            exit;
        }

        // Archivos opcionales
        $rut_pdf = null;
        $certificacion_pdf = null;

        if (isset($_FILES['rut_pdf']) && $_FILES['rut_pdf']['error'] === 0) {
            $ext = pathinfo($_FILES['rut_pdf']['name'], PATHINFO_EXTENSION);
            $rut_pdf = "uploads/rut_{$user_id}_" . time() . "." . $ext;
            move_uploaded_file($_FILES['rut_pdf']['tmp_name'], __DIR__ . '/' . $rut_pdf);
        }

        if (isset($_FILES['certificacion_pdf']) && $_FILES['certificacion_pdf']['error'] === 0) {
            $ext = pathinfo($_FILES['certificacion_pdf']['name'], PATHINFO_EXTENSION);
            $certificacion_pdf = "uploads/certificacion_{$user_id}_" . time() . "." . $ext;
            move_uploaded_file($_FILES['certificacion_pdf']['tmp_name'], __DIR__ . '/' . $certificacion_pdf);
        }

        try {
            if ($accion === 'crear') {
                // Crear nuevo registro
                $stmt = $pdo->prepare("
                    INSERT INTO bancos_usuarios 
                    (usuario_id, banco, tipo_cuenta, numero_cuenta, titular, cedula, celular, rut_pdf, certificacion_pdf)
                    VALUES (:user_id, :banco, :tipo_cuenta, :numero_cuenta, :titular, :cedula, :celular, :rut_pdf, :cert_pdf)
                ");
                $stmt->execute([
                    'user_id' => $user_id,
                    'banco' => $banco,
                    'tipo_cuenta' => $tipo_cuenta,
                    'numero_cuenta' => $numero_cuenta,
                    'titular' => $titular,
                    'cedula' => $cedula,
                    'celular' => $celular,
                    'rut_pdf' => $rut_pdf,
                    'cert_pdf' => $certificacion_pdf
                ]);
                echo json_encode(['status' => 'success', 'message' => 'Datos guardados correctamente']);
            } else {
                // Editar registro existente
                $id = $_POST['id'] ?? 0;

                // Recuperar archivos existentes
                $stmt2 = $pdo->prepare("SELECT rut_pdf, certificacion_pdf FROM bancos_usuarios WHERE id=:id AND usuario_id=:user_id");
                $stmt2->execute(['id' => $id, 'user_id' => $user_id]);
                $row = $stmt2->fetch(PDO::FETCH_ASSOC);

                if (!$row) {
                    echo json_encode(['status' => 'error', 'message' => 'Registro no encontrado']);
                    exit;
                }

                if (!$rut_pdf) $rut_pdf = $row['rut_pdf'];
                if (!$certificacion_pdf) $certificacion_pdf = $row['certificacion_pdf'];

                $stmt = $pdo->prepare("
                    UPDATE bancos_usuarios 
                    SET banco=:banco, tipo_cuenta=:tipo_cuenta, numero_cuenta=:numero_cuenta,
                        titular=:titular, cedula=:cedula, celular=:celular,
                        rut_pdf=:rut_pdf, certificacion_pdf=:cert_pdf
                    WHERE id=:id AND usuario_id=:user_id
                ");
                $stmt->execute([
                    'banco' => $banco,
                    'tipo_cuenta' => $tipo_cuenta,
                    'numero_cuenta' => $numero_cuenta,
                    'titular' => $titular,
                    'cedula' => $cedula,
                    'celular' => $celular,
                    'rut_pdf' => $rut_pdf,
                    'cert_pdf' => $certificacion_pdf,
                    'id' => $id,
                    'user_id' => $user_id
                ]);

                echo json_encode(['status' => 'success', 'message' => 'Datos actualizados correctamente']);
            }
        } catch (PDOException $e) {
            echo json_encode(['status' => 'error', 'message' => 'Error en base de datos: ' . $e->getMessage()]);
        }
        exit;
    }

    // ---- Eliminar ----
    if ($accion === 'eliminar') {
        $id = $_POST['id'] ?? 0;
        $stmt = $pdo->prepare("DELETE FROM bancos_usuarios WHERE id=:id AND usuario_id=:user_id");
        $stmt->execute(['id' => $id, 'user_id' => $user_id]);
        echo json_encode(['status' => 'success', 'message' => 'Registro eliminado correctamente']);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
    exit;
}

// ===========================
// Listado de registros (GET)
// ===========================
if (isset($_GET['firebase_uid'])) {
    $firebase_uid = $_GET['firebase_uid'];

    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid=:uid");
    $stmt->execute(['uid' => $firebase_uid]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    $user_id = $usuario['id'];
    $stmt = $pdo->prepare("SELECT * FROM bancos_usuarios WHERE usuario_id=:user_id ORDER BY fecha_creacion DESC");
    $stmt->execute(['user_id' => $user_id]);
    $registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($registros);
    exit;
}

// ===========================
// Si no se cumple nada
// ===========================
echo json_encode(['status' => 'error', 'message' => 'Solicitud no válida']);
exit;
?>
