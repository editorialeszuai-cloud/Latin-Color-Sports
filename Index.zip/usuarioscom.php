<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php'; // Ajusta la ruta si es necesario

// Leer el cuerpo JSON
$raw = file_get_contents("php://input");
$input = json_decode($raw, true);
if (!$input || !is_array($input)) {
    $input = $_POST;
}

$accion = $input['accion'] ?? '';

if ($accion === 'listar_comerciales') {
    try {
        $conn = conectar(); // Tu función para conectar MySQL
        $sql = "SELECT id, nombre AS nombre_comercial FROM usuarios WHERE rol = 'comercial'";
        $result = $conn->query($sql);

        $data = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
        }

        echo json_encode(['status' => 'success', 'data' => $data], JSON_UNESCAPED_UNICODE);
        $conn->close();
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Acción no válida o datos no recibidos correctamente']);
?>
