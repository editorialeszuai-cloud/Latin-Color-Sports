<?php
header('Content-Type: application/json');
include 'db.php'; // archivo con $conn = new mysqli(...);

$data = json_decode(file_get_contents('php://input'), true);

if(empty($data['postulacion_id']) || empty($data['firebase_token']) || empty($data['titulo'])){
    echo json_encode(['success'=>false, 'message'=>'Datos incompletos']);
    exit;
}

// TODO: validar firebase_token si tienes verificación en el servidor

$postulacion_id = intval($data['postulacion_id']);
$titulo = $conn->real_escape_string($data['titulo']);

// Validar que la postulación existe
$res = $conn->query("SELECT id FROM postulaciones WHERE id=$postulacion_id");
if($res->num_rows === 0){
    echo json_encode(['success'=>false, 'message'=>'Postulación no encontrada']);
    exit;
}

// Insertar galería
if($conn->query("INSERT INTO galerias (postulacion_id, titulo) VALUES ($postulacion_id, '$titulo')")){
    $galeria_id = $conn->insert_id;
    echo json_encode(['success'=>true, 'galeria_id'=>$galeria_id]);
} else {
    echo json_encode(['success'=>false, 'message'=>'Error al crear galería']);
}
?>
