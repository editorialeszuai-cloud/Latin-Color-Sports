<?php
function conectar() {
    $host = 'database-1.c8302k404lkf.us-east-1.rds.amazonaws.com';
    $db   = 'latincolors';
    $user = 'admin';
    $pass = 'DannyCruxTecnoLoad!#';
    $charset = 'utf8mb4';
	$port = 3306;


    $dsn = "mysql:host=$host;dbname=$db;port=$port;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ];

    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        die("❌ Error de conexión a la base de datos: " . $e->getMessage());
    }
}

$pdo = conectar();
?>
