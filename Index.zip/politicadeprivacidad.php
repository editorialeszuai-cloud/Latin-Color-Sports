<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidad | Latin Group SAS</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">

    <!-- Fuente moderna -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f3f4f6, #e5e7eb);
            color: #111827;
            margin: 0;
            padding: 0;
        }

        header {
            background: #1e40af;
            color: white;
            text-align: center;
            padding: 3rem 1rem 2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        header p {
            font-size: 1rem;
            opacity: 0.9;
        }

        main {
            max-width: 900px;
            margin: 2rem auto;
            background: white;
            padding: 2.5rem;
            border-radius: 16px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.1);
        }

        h2 {
            color: #1e3a8a;
            margin-top: 2rem;
            margin-bottom: 1rem;
            font-weight: 700;
            border-left: 5px solid #3b82f6;
            padding-left: 10px;
        }

        p, li {
            line-height: 1.7;
            font-size: 1rem;
            color: #374151;
        }

        ul {
            margin-left: 1.5rem;
            margin-bottom: 1rem;
        }

        a {
            color: #2563eb;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        footer {
            text-align: center;
            background: #1e40af;
            color: white;
            padding: 1.5rem 1rem;
            margin-top: 3rem;
            font-size: 0.9rem;
        }

        @media (max-width: 600px) {
            main {
                margin: 1rem;
                padding: 1.5rem;
            }
            header h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <header>
        <h1>Política de Privacidad</h1>
        <p>Latin Group SAS – Última actualización: 21 de octubre de 2025</p>
    </header>

    <main>
        <p>En <strong>Latin Group SAS</strong>, valoramos y respetamos tu privacidad. Esta Política de Privacidad describe cómo recopilamos, usamos y protegemos tu información personal al utilizar nuestra aplicación y servicios para la compra y visualización de fotografías de eventos deportivos.</p>

        <h2>1. Información que recopilamos</h2>
        <ul>
            <li><strong>Datos personales:</strong> nombre, correo electrónico, número de teléfono, país y ciudad.</li>
            <li><strong>Información de cuenta:</strong> credenciales creadas al registrarte o usar inicio de sesión con Google/Facebook.</li>
            <li><strong>Datos de compra:</strong> historial de compras y facturación (los datos de tarjeta son manejados por pasarelas de pago seguras).</li>
            <li><strong>Datos de uso:</strong> interacción con la app, dispositivo, sistema operativo y tiempo de uso.</li>
        </ul>

        <h2>2. Uso de la información</h2>
        <p>La información se utiliza para:</p>
        <ul>
            <li>Procesar tus compras y entregas de fotografías.</li>
            <li>Brindarte soporte y mejorar la experiencia del usuario.</li>
            <li>Enviar notificaciones sobre eventos, promociones o novedades (si lo autorizas).</li>
        </ul>

        <h2>3. Compartición de datos</h2>
        <p>No vendemos ni alquilamos tus datos personales. Solo los compartimos con:</p>
        <ul>
            <li>Proveedores de servicios como pasarelas de pago, almacenamiento en la nube o Firebase.</li>
            <li>Autoridades legales cuando sea requerido por ley.</li>
        </ul>

        <h2>4. Seguridad de los datos</h2>
        <p>Protegemos tu información mediante cifrado SSL, servidores seguros y controles de acceso internos. No obstante, ningún sistema es 100% infalible.</p>

        <h2>5. Retención de datos</h2>
        <p>Conservamos los datos mientras tu cuenta esté activa o por el tiempo necesario para cumplir con obligaciones legales. Puedes solicitar la eliminación de tu cuenta en cualquier momento.</p>

        <h2>6. Derechos del usuario</h2>
        <p>De acuerdo con la <strong>Ley 1581 de 2012</strong>, puedes:</p>
        <ul>
            <li>Acceder a tus datos personales.</li>
            <li>Rectificar información incorrecta.</li>
            <li>Solicitar la eliminación de tus datos.</li>
            <li>Revocar tu consentimiento de tratamiento.</li>
        </ul>
        <p>Para ejercer estos derechos, escríbenos a: <a href="mailto:privacidad@latingroupsas.com">privacidad@latingroupsas.com</a></p>

        <h2>7. Servicios de terceros</h2>
        <p>Usamos servicios externos como:</p>
        <ul>
            <li><strong>Firebase (Google LLC):</strong> autenticación y análisis de uso.</li>
            <li><strong>Facebook SDK / Google Sign-In:</strong> inicio de sesión social.</li>
            <li><strong>Pasarelas de pago:</strong> procesamiento seguro de transacciones.</li>
        </ul>

        <h2>8. Cambios en esta política</h2>
        <p>Podemos modificar esta política ocasionalmente. La versión más reciente siempre estará disponible en nuestro sitio web.</p>

        <h2>9. Contacto</h2>
        <p>Si tienes preguntas o solicitudes sobre esta política, contáctanos:</p>
        <p><strong>Latin Group SAS</strong><br>
        📍 Medellín, Colombia<br>
        📧 <a href="mailto:privacidad@latingroupsas.com">privacidad@latingroupsas.com</a><br>
        📞 +57 300 000 0000</p>
    </main>

    <footer>
        © 2025 Latin Group SAS. Todos los derechos reservados.
    </footer>
</body>
</html>
