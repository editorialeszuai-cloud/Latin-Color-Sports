<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require 'dbfotografos.php';

$mensaje = '';

// =======================
// Consultas iniciales
// =======================
try {
    $eventos = $pdo->query("SELECT * FROM eventos ORDER BY fecha ASC")->fetchAll(PDO::FETCH_ASSOC);
    $fotografos = $pdo->query("SELECT * FROM usuarios WHERE rol='fotografo' ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC);
    $asignaciones = $pdo->query("SELECT * FROM asignar_eventos")->fetchAll(PDO::FETCH_ASSOC);
    $galerias = $pdo->query("SELECT * FROM galerias ORDER BY fecha_creacion DESC")->fetchAll(PDO::FETCH_ASSOC);
    $fotos = $pdo->query("SELECT * FROM fotos")->fetchAll(PDO::FETCH_ASSOC);

    // Mapas para acceso rápido
    $asign_map = [];
    foreach ($asignaciones as $a) $asign_map[$a['evento_id']][] = $a['fotografo_id'];

    $galerias_map = [];
    foreach ($galerias as $g) $galerias_map[$g['evento_id']][$g['fotografo_id']][] = $g;

    $fotos_map = [];
    foreach ($fotos as $f) $fotos_map[$f['galeria_id']][] = $f;

} catch (Exception $e) {
    die("<p class='text-red-600 font-bold'>Error en base de datos: ".$e->getMessage()."</p>");
}

// =======================
// Procesar POST
// =======================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ===== Asignar fotógrafo =====
    if (isset($_POST['evento_id'], $_POST['fotografo_id']) && empty($_POST['eliminar'])) {
        $evento_id = (int)$_POST['evento_id'];
        $fotografo_id = (int)$_POST['fotografo_id'];

        $stmt = $pdo->prepare("SELECT 1 FROM asignar_eventos WHERE evento_id=? AND fotografo_id=?");
        $stmt->execute([$evento_id, $fotografo_id]);
        if ($stmt->rowCount() == 0) {
            $pdo->prepare("INSERT INTO asignar_eventos (evento_id, fotografo_id) VALUES (?, ?)")->execute([$evento_id, $fotografo_id]);
            $mensaje = "✅ Fotógrafo asignado.";
        } else {
            $mensaje = "⚠️ Fotógrafo ya asignado.";
        }
    }

    // ===== Eliminar fotógrafo =====
    if (isset($_POST['evento_id'], $_POST['fotografo_id'], $_POST['eliminar'])) {
        $pdo->prepare("DELETE FROM asignar_eventos WHERE evento_id=? AND fotografo_id=?")->execute([(int)$_POST['evento_id'], (int)$_POST['fotografo_id']]);
        $mensaje = "🗑️ Fotógrafo eliminado.";
    }

    // ===== Crear galería =====
    if (isset($_POST['galeria_evento_id'], $_POST['galeria_fotografo_id'], $_POST['titulo_galeria'], $_POST['precio_galeria'])) {
        $stmt = $pdo->prepare("INSERT INTO galerias (evento_id, fotografo_id, titulo, precio) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            (int)$_POST['galeria_evento_id'],
            (int)$_POST['galeria_fotografo_id'],
            $_POST['titulo_galeria'],
            (float)$_POST['precio_galeria']
        ]);
        $mensaje = "🖼️ Galería creada.";
    }

    // ===== Eliminar galería =====
    if (isset($_POST['eliminar_galeria_id'])) {
        $galeria_id = (int)$_POST['eliminar_galeria_id'];
        $stmt = $pdo->prepare("SELECT nombre_archivo FROM fotos WHERE galeria_id=?");
        $stmt->execute([$galeria_id]);
        $fotos = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($fotos as $f) if (file_exists("uploads/$f")) unlink("uploads/$f");
        $pdo->prepare("DELETE FROM fotos WHERE galeria_id=?")->execute([$galeria_id]);
        $pdo->prepare("DELETE FROM galerias WHERE id=?")->execute([$galeria_id]);
        $mensaje = "🗑️ Galería eliminada con fotos.";
    }

    // ===== Subir foto =====
    if (isset($_POST['foto_galeria_id'], $_FILES['foto']) && $_FILES['foto']['error'] === 0) {
        $galeria_id = (int)$_POST['foto_galeria_id'];
        $descripcion = $_POST['descripcion'] ?? '';
        $file = $_FILES['foto'];
        $nombre_archivo = uniqid() . '_' . basename($file['name']);
        if (!is_dir('uploads')) mkdir('uploads', 0777, true);
        if (move_uploaded_file($file['tmp_name'], 'uploads/' . $nombre_archivo)) {
            $tamano_kb = round($file['size'] / 1024, 2);
            $pdo->prepare("INSERT INTO fotos (galeria_id, nombre_archivo, descripcion, tamano_archivo, tamano_kb) VALUES (?, ?, ?, ?, ?)")
                ->execute([$galeria_id, $nombre_archivo, $descripcion, $file['size'], $tamano_kb]);
            $mensaje = "✅ Foto subida.";
        } else {
            $mensaje = "❌ Error al subir foto.";
        }
    }

    // ===== Eliminar foto =====
    if (isset($_POST['eliminar_foto_id'])) {
        $foto_id = (int)$_POST['eliminar_foto_id'];
        $stmt = $pdo->prepare("SELECT nombre_archivo FROM fotos WHERE id=?");
        $stmt->execute([$foto_id]);
        $nombre = $stmt->fetchColumn();
        if ($nombre && file_exists("uploads/$nombre")) unlink("uploads/$nombre");
        $pdo->prepare("DELETE FROM fotos WHERE id=?")->execute([$foto_id]);
        $mensaje = "🗑️ Foto eliminada.";
    }

    // Recargar arrays para reflejar cambios
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Eventos</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="p-6 bg-gray-100">

<h1 class="text-3xl font-bold mb-6">Gestión de Eventos, Fotógrafos y Galerías</h1>

<?php if ($mensaje): ?>
<p class="mb-4 p-3 bg-green-100 text-green-800 border border-green-300 rounded"><?= htmlspecialchars($mensaje) ?></p>
<?php endif; ?>

<?php if (!empty($eventos)): ?>
    <?php foreach ($eventos as $evento): ?>
        <div class="bg-white p-6 mb-6 rounded shadow">
            <h3 class="text-xl font-semibold"><?= htmlspecialchars($evento['titulo']) ?></h3>
            <p class="text-gray-600 mb-2">
                Fecha: <?= htmlspecialchars($evento['fecha']) ?> |
                Capacidad: <?= htmlspecialchars($evento['capacidad_gb']) ?> GB |
            </p>

            <!-- Listado de fotógrafos asignados -->
            <?php if (isset($asign_map[$evento['id']])): ?>
            <ul class="ml-6">
                <?php foreach ($asign_map[$evento['id']] as $fid):
                    $fotografo = array_values(array_filter($fotografos, fn($u)=>$u['id']==$fid))[0] ?? null;
                    if (!$fotografo) continue;
                ?>
                <li class="mb-3">
                    <div class="flex justify-between items-center">
                        <span class="font-medium"><?= htmlspecialchars($fotografo['nombre']) ?></span>
                        <form method="POST">
                            <input type="hidden" name="evento_id" value="<?= $evento['id'] ?>">
                            <input type="hidden" name="fotografo_id" value="<?= $fotografo['id'] ?>">
                            <input type="hidden" name="eliminar" value="1">
                            <button class="bg-red-600 text-white px-2 py-1 rounded text-sm">Eliminar</button>
                        </form>
                    </div>

                    <!-- Crear galería -->
                    <form method="POST" class="flex gap-2 mt-2 mb-2">
                        <input type="hidden" name="galeria_evento_id" value="<?= $evento['id'] ?>">
                        <input type="hidden" name="galeria_fotografo_id" value="<?= $fotografo['id'] ?>">
                        <input type="text" name="titulo_galeria" placeholder="Título de galería" required class="border p-1 flex-1 rounded">
                        <input type="number" name="precio_galeria" step="0.01" min="0" placeholder="Precio" required class="border p-1 w-32 rounded text-right">
                        <button class="bg-green-600 text-white px-3 py-1 rounded">Crear</button>
                    </form>

                    <!-- Mostrar galerías -->
                    <?php if (isset($galerias_map[$evento['id']][$fotografo['id']])): ?>
                        <?php foreach ($galerias_map[$evento['id']][$fotografo['id']] as $g): ?>
                        <div class="border rounded p-2 mb-2 bg-gray-50">
                            <div class="flex justify-between items-center">
                                <p class="font-semibold"><?= htmlspecialchars($g['titulo']) ?> <span class="text-sm text-gray-600">($<?= number_format($g['precio'], 2) ?>)</span></p>
                                <form method="POST" onsubmit="return confirm('¿Eliminar galería y todas sus fotos?')">
                                    <input type="hidden" name="eliminar_galeria_id" value="<?= $g['id'] ?>">
                                    <button class="text-red-600 text-sm">🗑️ Eliminar galería</button>
                                </form>
                            </div>

                            <!-- Subir foto -->
                            <form method="POST" enctype="multipart/form-data" class="flex gap-2 mt-2">
                                <input type="hidden" name="foto_galeria_id" value="<?= $g['id'] ?>">
                                <input type="file" name="foto" required class="border rounded p-1">
                                <input type="text" name="descripcion" placeholder="Descripción" class="border rounded p-1 flex-1">
                                <button class="bg-blue-600 text-white px-3 py-1 rounded">Subir</button>
                            </form>

                            <!-- Fotos -->
                            <?php if (isset($fotos_map[$g['id']])): ?>
                            <div class="grid grid-cols-3 gap-2 mt-2">
                                <?php foreach ($fotos_map[$g['id']] as $f): ?>
                                <div class="border rounded overflow-hidden relative group">
                                    <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>" class="w-full h-32 object-cover">
                                    <div class="p-1 text-xs text-gray-700"><?= htmlspecialchars($f['descripcion']) ?><br><span class="text-gray-400"><?= $f['tamano_kb'] ?> KB</span></div>
                                    <form method="POST" class="absolute top-1 right-1 hidden group-hover:block" onsubmit="return confirm('¿Eliminar esta foto?')">
                                        <input type="hidden" name="eliminar_foto_id" value="<?= $f['id'] ?>">
                                        <button class="bg-red-600 text-white text-xs px-2 py-1 rounded">🗑️</button>
                                    </form>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php else: ?>
                                <p class="text-gray-500 text-sm mt-1">No hay fotos.</p>
                            <?php endif; ?>

                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>

        </div>
    <?php endforeach; ?>
<?php else: ?>
<p>No hay eventos registrados.</p>
<?php endif; ?>

</body>
</html>
