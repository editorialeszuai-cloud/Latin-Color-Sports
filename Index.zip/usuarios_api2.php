<?php
header('Content-Type: application/json; charset=utf-8');
include 'dbfotografos.php';

$accion = $_POST['accion'] ?? '';

switch($accion) {

    case 'buscar_por_uid':
        try {
            $firebase_uid = $_POST['firebase_uid'] ?? '';
            if (!$firebase_uid) throw new Exception('Falta firebase_uid');

            // Verificar si el usuario ya existe
            $stmt = $pdo->prepare("SELECT id, nombre, rol, firebase_uid FROM usuarios WHERE firebase_uid = ?");
            $stmt->execute([$firebase_uid]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$usuario) {
                // Insertar automáticamente usuario nuevo
                $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, rol, firebase_uid) VALUES (?, ?, ?)");
                $stmt->execute(['Fotógrafo', 'fotografo', $firebase_uid]);
                $usuario_id = $pdo->lastInsertId();

                $usuario = [
                    'id' => $usuario_id,
                    'nombre' => 'Fotógrafo',
                    'rol' => 'fotografo',
                    'firebase_uid' => $firebase_uid
                ];
            }

            echo json_encode(['success'=>true,'data'=>$usuario]);

        } catch (Exception $e) {
            echo json_encode(['success'=>false,'message'=>$e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['success'=>false,'message'=>'Acción no válida']);
}
?>
