<?php
header('Content-Type: application/json');

$input = file_get_contents('php://input');
parse_str($input, $data);

$token = isset($data['g-recaptcha-response']) ? $data['g-recaptcha-response'] : null;

if (!$token) {
    echo json_encode(['status' => 'error', 'message' => 'Falta el token de reCAPTCHA']);
    exit;
}

$secret = getenv('6Ld6IhgtAAAAAHWE5AqdQnJ04EOFg9SCL_-CqlUu'); 

$url = 'https://www.google.com/recaptcha/api/siteverify';
$params = [
    'secret'   => $secret,
    'response' => $token
];

$options = [
    'http' => [
        'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($params)
    ]
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
$response = json_decode($result);

if ($response && isset($response->success) && $response->success) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Validación fallida con Google']);
}
?>