<?php
$urlOriginal = $_GET['img'] ?? '';
$width = isset($_GET['w']) ? intval($_GET['w']) : 600;
$urlFinal = urldecode($urlOriginal);

// 1. FORZAMOS el dominio a CloudFront
$urlFinal = str_replace(
    "fotos-latincolor-2026.s3-accelerate.amazonaws.com", 
    "d3fnhkeilwwjkl.cloudfront.net", 
    $urlFinal
);

// 2. AÑADIMOS PARÁMETROS DE COMPRESIÓN
// 'w' = ancho, 'q' = calidad (bajándola a 70 u 80 reduces mucho el peso sin perder casi calidad visual)
$sep = (strpos($urlFinal, '?') !== false) ? '&' : '?';
$urlFinal .= $sep . "w=" . $width . "&q=75&auto=compress";

// 3. Usamos cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $urlFinal);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
// Timeouts para que no se quede colgado si la imagen es muy grande
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); 
curl_setopt($ch, CURLOPT_TIMEOUT, 10);

$data = curl_exec($ch);
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($data && $httpCode == 200) {
    header("Content-Type: " . $contentType);
    // Cachear en el navegador del usuario para no recargar siempre
    header("Cache-Control: max-age=31536000, public");
    echo $data;
} else {
    header("HTTP/1.0 404 Not Found");
}
exit;
?>