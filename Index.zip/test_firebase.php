<?php
require_once __DIR__ . '/vendor/autoload.php';
use Kreait\Firebase\Factory;

$serviceAccountPath = __DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json';
$factory = (new Factory)->withServiceAccount($serviceAccountPath);
$auth = $factory->createAuth();

try {
    $user = $auth->createUser([
        'email' => 'test' . rand(100,999) . '@example.com',
        'password' => '12345678',
        'displayName' => 'Prueba Manual',
    ]);
    echo "✅ Usuario creado con UID: " . $user->uid;
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage();
}
