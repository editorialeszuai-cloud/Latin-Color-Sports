<?php
include 'dbfotografos.php';
$pdo = conectar();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    header('Content-Type: application/json');
    $accion = $_POST['accion'];

    // Obtener catálogos para los filtros
    if ($accion === 'cargar_filtros') {
        $eventos = $pdo->query("SELECT id, titulo FROM eventos ORDER BY titulo")->fetchAll(PDO::FETCH_ASSOC);
        $fotografos = $pdo->query("SELECT id, nombre FROM usuarios WHERE rol='fotografo' ORDER BY nombre")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'eventos' => $eventos, 'fotografos' => $fotografos]);
        exit;
    }

    // Listar filtrado
    if ($accion === 'listar_filtrado') {
        $evento_id = $_POST['evento_id'];
        $fotografo_id = $_POST['fotografo_id'];

        $sql = "SELECT u.nombre AS fotografo_nombre, ev.titulo AS evento, s.titulo AS sede, 
                       esc.nombre AS escenario, d.nombre_disciplina AS disciplina, 
                       p.equipo_a, p.equipo_b, cf.fecha, cf.hora
                FROM calendario_fotografos cf
                LEFT JOIN usuarios u ON cf.fotografo_id = u.id
                LEFT JOIN eventos ev ON cf.evento_id = ev.id
                LEFT JOIN sedes s ON cf.sede_id = s.id
                LEFT JOIN escenarios esc ON cf.escenario_id = esc.id
                LEFT JOIN disciplinas d ON cf.disciplina_id = d.id
                LEFT JOIN partidos p ON p.id = cf.partido_id
                WHERE 1=1";
        
        $params = [];
        if ($evento_id) { $sql .= " AND cf.evento_id = ?"; $params[] = $evento_id; }
        if ($fotografo_id) { $sql .= " AND cf.fotografo_id = ?"; $params[] = $fotografo_id; }
        
        $sql .= " ORDER BY cf.fecha DESC, cf.hora ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte con Filtros</title>
    <script src="https://cdn.tailwindcss.com"></script>
	    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-7xl mx-auto">
        <h1 class="text-3xl font-bold text-center text-orange-500 mb-8">Asignaciones Fotográficas</h1>
        
        <div class="bg-white p-4 rounded-xl shadow mb-6 flex gap-4">
            <select id="filtroEvento" class="border p-2 rounded w-1/2" onchange="cargarDatos()">
                <option value="">Todos los Eventos</option>
            </select>
            <select id="filtroFotografo" class="border p-2 rounded w-1/2" onchange="cargarDatos()">
                <option value="">Todos los Fotógrafos</option>
            </select>
        </div>

        <div class="bg-white shadow-lg rounded-xl overflow-x-auto">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-800 text-white uppercase text-xs">
                    <tr>
                        <th class="p-4">Fotógrafo</th>
                        <th class="p-4">Evento</th>
                        <th class="p-4">Sede / Escenario</th>
                        <th class="p-4">Partido</th>
                        <th class="p-4">Fecha</th>
                    </tr>
                </thead>
                <tbody id="tablaBody" class="divide-y divide-gray-200"></tbody>
            </table>
        </div>
    </div>

<script>
async function inicializarFiltros() {
    const res = await fetch('', { method: 'POST', body: new URLSearchParams({ accion: 'cargar_filtros' }) });
    const data = await res.json();
    
    const selEv = document.getElementById('filtroEvento');
    const selFot = document.getElementById('filtroFotografo');
    
    data.eventos.forEach(e => selEv.innerHTML += `<option value="${e.id}">${e.titulo}</option>`);
    data.fotografos.forEach(f => selFot.innerHTML += `<option value="${f.id}">${f.nombre}</option>`);
    cargarDatos();
}

async function cargarDatos() {
    const fd = new FormData();
    fd.append('accion', 'listar_filtrado');
    fd.append('evento_id', document.getElementById('filtroEvento').value);
    fd.append('fotografo_id', document.getElementById('filtroFotografo').value);
    
    const res = await fetch('', { method: 'POST', body: fd });
    const json = await res.json();
    
    const tbody = document.getElementById('tablaBody');
    tbody.innerHTML = json.data.map(item => `
        <tr class="hover:bg-gray-50">
            <td class="p-4 font-bold text-blue-700">${item.fotografo_nombre || 'Sin asignar'}</td>
            <td class="p-4">${item.evento}</td>
            <td class="p-4 text-xs">${item.sede}<br><span class="text-gray-400">${item.escenario}</span></td>
            <td class="p-4 font-semibold text-orange-600">${item.equipo_a ? item.equipo_a + ' vs ' + item.equipo_b : '---'}</td>
            <td class="p-4 text-xs">${item.fecha}<br>${item.hora}</td>
        </tr>
    `).join('');
}

window.onload = inicializarFiltros;
</script>


<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Función para ejecutar el cambio de rol
async function ejecutarCambioRol(nuevoRol, uid) {
    try {
        const res = await fetch('cambiar_rol.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ nuevo_rol: nuevoRol, uid: uid })
        });
        const data = await res.json();
        
        if(data.status === 'success') {
            alert(`Rol actualizado a: ${nuevoRol.toUpperCase()}`);
            window.location.reload();
        } else {
            alert("Error del servidor: " + (data.message || "No se pudo cambiar el rol"));
        }
    } catch (e) {
        console.error("Error en petición:", e);
        alert("Error de conexión con el servidor.");
    }
}







onAuthStateChanged(auth, async (user) => {
    if (user) {
        try {
            const token = await user.getIdToken();
            const res = await fetch('get_user_info.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ firebase_token: token })
            });
            
            // Verificamos si hubo error en el servidor
            if (!res.ok) {
                const text = await res.text();
                console.error("Error del servidor (PHP):", text);
                throw new Error("Error en servidor: " + text);
            }

            const data = await res.json();
            
            if (data.status === 'success') {
                const u = data.user;


                const r = (u.rol || "").toLowerCase();
                
                // Actualizar UI básica
                if(document.getElementById('userName')) document.getElementById('userName').textContent = u.nombre || "Usuario";
                if(document.getElementById('userRole')) document.getElementById('userRole').textContent = u.rol || "Sin rol";
                if(u.foto_perfil && document.getElementById('userFotoPerfil')) document.getElementById('userFotoPerfil').src = u.foto_perfil;

                // Lógica de inyección de panel
                const container = document.getElementById('roleContent');
                if (container) {
                    // SI ES ADMIN
                    if (r === 'admin') {
                        container.innerHTML = `
                            <div style="border-top: 1px solid #eee; padding-top: 20px; max-width: 600px; margin: 0 auto;">
                                <h3 style="margin-bottom:15px;">Control de Sesión Maestra</h3>
                                <div class="role-switcher" style="display: flex; gap: 10px; margin-bottom: 20px;">
                                    <button id="btnAdmin" class="btn-sw" style="background:#4f46e5; color:white; border:none; padding:10px; cursor:pointer;">MODO ADMIN</button>
                                    <button id="btnSoporte" class="btn-sw" style="background:#10b981; color:white; border:none; padding:10px; cursor:pointer;">MODO SOPORTE</button>
                                </div>
                            </div>
                        `;
                        document.getElementById('btnAdmin').addEventListener('click', () => ejecutarCambioRol('admin', u.firebase_uid));
                        document.getElementById('btnSoporte').addEventListener('click', () => ejecutarCambioRol('soporte', u.firebase_uid));
                    } 
                    // SI ES SOPORTE
                    else if (r === 'soporte') {
                        container.innerHTML = `
                            <div style="border-top: 1px solid #eee; padding-top: 20px; max-width: 600px; margin: 0 auto;">
                                <a href="revisar_postulaciones.php" style="display:block; padding:15px; background:#ecfdf5; border-radius:8px; text-decoration:none; color:#065f46; font-weight:bold; border:1px solid #10b981; text-align:center; margin-bottom:10px;">
                                    Ir a Análisis
                                </a>
                                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
                                    <button id="btnAdminSoporte" class="btn-sw" style="background:#4f46e5; color:white; border:none; padding:10px; cursor:pointer;">MODO ADMIN</button>
                                    <a href="logs_sistema.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Logs</a>
                                    <a href="nav_comercial.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Comercial</a>
                                    <a href="nav_fotografo.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Fotógrafo</a>
									<a href="nav_organizador.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Organizador</a>
                                    <a href="gestionar_todo.php" style="padding:10px; background:#f8fafc; border-radius:8px; text-decoration:none; color:#1e293b; font-size:12px; border:1px solid #e2e8f0; text-align:center;">Gestionar Todo</a>
                                                              
							   </div>
                            </div>
                        `;
                        document.getElementById('btnAdminSoporte').addEventListener('click', () => ejecutarCambioRol('admin', u.firebase_uid));
                    }
                }
            } else {
                console.warn("Datos de usuario no encontrados:", data);
            }
        } catch (error) {
            console.error("Error al obtener info del usuario:", error);
        }
    } else {
        window.location.href = 'login_app.html';
    }
});


// Logout
const logoutBtn = document.getElementById('logoutButton');
if(logoutBtn) {
    logoutBtn.onclick = () => signOut(auth);
}
</script>


<script>
// Manejo de Menús desplegables
document.addEventListener('click', (e) => {
    const item = e.target.closest('.has-submenu');
    if (item) {
        // Evita que el clic en un sub-item cierre el menú padre
        if(e.target.classList.contains('sub-nav-item')) return;
        item.classList.toggle('open');
    }
});

const openBtn = document.getElementById('openBtn');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('overlay');

openBtn.onclick = () => {
    sidebar.classList.toggle('open');
    sidebar.classList.toggle('closed');
    overlay.classList.toggle('visible');
};

overlay.onclick = () => {
    sidebar.classList.add('closed');
    sidebar.classList.remove('open');
    overlay.classList.remove('visible');
};
</script>
</body>
</html>
</body>
</html>