<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Organizador</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
  </style>
</head>
<body class="bg-gray-100">

<!-- Navbar -->
<nav class="bg-[#0b1220] shadow sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">

      <!-- Logo -->
      <div class="flex-shrink-0 flex items-center gap-2">
        <img class="h-10 w-auto" src="uploads/LATIN-SPORTS.png" alt="Logo">
        <span class="font-bold text-xl text-white">Organizador</span>
      </div>

      <!-- Menú Desktop -->
      <div class="hidden md:flex md:items-center md:space-x-6">
        <a href="nav_organizador.php" class="text-white hover:text-orange-400 font-medium transition">Home</a>
        <a href="ver_eventosorganizador.php" class="text-white hover:text-orange-400 font-medium transition">Mis Eventos</a>
        <a href="comisionor.php" class="text-white hover:text-orange-400 font-medium transition">Comisión</a>
        <a href="datos_bancarios.php" class="text-white hover:text-orange-400 font-medium transition">Datos Bancarios</a>

        <!-- Notificaciones -->
        <button class="relative ml-4 text-gray-200 hover:text-orange-400">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          <span class="absolute top-0 right-0 inline-block w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        <!-- Usuario Estático -->
        <div class="relative ml-4 flex items-center gap-2">
          <div class="flex flex-col">
            <div class="flex items-center gap-2">
              <span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-gray-200">Organizador</span>
            </div>
          </div>
        </div>

        <!-- Editar Perfil -->
        <a href="editar_perfil.php" class="ml-4 py-2 px-4 rounded-lg bg-orange-600 text-white hover:bg-gray-700 transition">Editar Perfil</a>

        <!-- Cerrar sesión -->
        <a href="login_app.html" class="ml-4 py-2 px-4 rounded-lg bg-red-600 text-white hover:bg-red-700 transition">Cerrar Sesión</a>
      </div>

      <!-- Botón Mobile -->
      <div class="md:hidden flex items-center">
        <button id="mobile-menu-button" class="text-gray-200 focus:outline-none">
          <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </div>
  </div>

  <!-- Menú Mobile -->
  <div id="mobile-menu" class="md:hidden hidden bg-[#0b1220] text-white">
    <a href="#home" class="block px-4 py-2 hover:bg-indigo-500">Home</a>
    <a href="ver_eventosorganizador.php" class="block px-4 py-2 hover:bg-orange-500">Mis Eventos</a>
    <a href="comisionor.php" class="block px-4 py-2 hover:bg-indigo-500">Comisión</a>
    <a href="datos_bancarios.php" class="block px-4 py-2 hover:bg-indigo-500">Datos Bancarios</a>

    <a href="editar_perfil.php" class="block px-4 py-2 bg-gray-600 hover:bg-blue-700 rounded-md mt-2">Editar Perfil</a>
    <a href="login_app.html" class="block px-4 py-2 bg-red-600 hover:bg-red-700 rounded-md mt-2">Cerrar Sesión</a>
  </div>
</nav>

<script>
  // Toggle mobile menu
  const mobileBtn = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');
  mobileBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
</script>

</body>
</html>
