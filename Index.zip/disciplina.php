<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Disciplinas</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<style>
h1{text-align:center;color:#333;}
form{background:#fff;padding:20px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);margin-bottom:30px;max-width:500px;margin:auto;}
label{display:block;margin-top:10px;color:#555;}
input, textarea{width:100%;padding:8px;margin-top:4px;border:1px solid #ccc;border-radius:5px;}
button{margin-top:15px;padding:10px 15px;border:none;border-radius:5px;background:orange;color:#fff;cursor:pointer;}
button:hover{background:#0056b3;}
table{width:100%;border-collapse:collapse;margin-top:20px;background:#fff;}
th, td{border:1px solid #ccc;padding:8px;text-align:left;}
th{background:orange;color:white;}
.acciones button{margin-right:5px;padding:5px 8px;}
.editar{background:#ffc107;color:#000;}
.eliminar{background:#dc3545;color:#fff;}
</style>
<style>
/* ======== NAVBAR ESTILOS ======== */
#mainNav {
  width: 100%;
  background: linear-gradient(90deg, #4f46e5, #8b5cf6, #ec4899);
  color: white;
  padding: 0.75rem 0rem;
  box-shadow: 0 2px 6px rgba(0,0,0,0.15);
  position: relative;
  z-index: 1000;
  border-radius:20px;
}

#mainNav .nav-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
}

#mainNav .logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  font-size: 1.125rem;
}

#mainNav .logo img {
  width: 2rem;
  height: 2rem;
}

#mainNav .nav-links {
  display: flex;
  gap: 1rem;
  list-style: none;
}

#mainNav .nav-links li a {
  color: white;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.2s;
}

#mainNav .nav-links li a:hover {
  text-decoration: underline;
}

/* ======== BOTÓN HAMBURGUESA ======== */
.nav-toggle {
  display: none;
  flex-direction: column;
  justify-content: space-between;
  width: 5rem;
  height: 5rem;
  font-size:25px;
  background: none;
  border: none;
  cursor: pointer;
  padding-right:20px;
}

.nav-toggle span {
  display: block;
  height: 2px;
  width: 100%;
  background: white;
  border-radius: 2px;
}

/* ======== RESPONSIVE ======== */
@media (max-width: 768px) {
  #mainNav .nav-links {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6, #ec4899);
    flex-direction: column;
    display: none;
    gap: 0;
    text-align: center;
    padding: 0.5rem 0;
  }

  #mainNav .nav-links.show {
    display: flex;
  }

  #mainNav .nav-links li {
    padding: 0.5rem 0;
  }

  .nav-toggle {
    display: flex;
  }
}
</style>

</head>
<body>



<script>
// ====== SCRIPT RESPONSIVE ======
const navToggle = document.getElementById('navToggle');
const navLinks = document.querySelector('#mainNav .nav-links');

navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('show');
});
</script>
    
    
<h1>Gestión de Disciplinas</h1>

<form id="formDisciplina">
<input type="hidden" id="idDisciplina">
<label>Nombre de la Disciplina</label>
<input type="text" id="nombre_disciplina" required>
<label>Descripci贸n</label>
<textarea id="descripcion" rows="3"></textarea>

<button type="submit">Guardar Disciplina</button>
<button type="button" id="btnCancelar" style="background:#6c757d;display:none;">Cancelar</button>
</form>

<table id="tablaDisciplinas">
<thead>
<tr><th>ID</th><th>Nombre</th><th>Acciones</th></tr>
</thead>
<tbody></tbody>
</table>

<script>
const form = document.getElementById('formDisciplina');
const btnCancelar = document.getElementById('btnCancelar');
const tabla = document.querySelector('#tablaDisciplinas tbody');

const limpiarFormulario = () => {
    form.reset();
    document.getElementById('idDisciplina').value = '';
    btnCancelar.style.display = 'none';
    form.querySelector('button[type="submit"]').textContent = 'Guardar Disciplina';
};

const cargarDisciplinas = async () => {
    const res = await fetch('disciplinas.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({accion:'listar'})
    });
    const data = await res.json();
    tabla.innerHTML='';
    if(data.status==='success'){
        data.data.forEach(d=>{
            const tr=document.createElement('tr');
            tr.innerHTML=`<td>${d.id}</td><td>${d.nombre_disciplina}</td>
            <td class="acciones">
            <button class="editar" onclick='editarDisciplina(${JSON.stringify(d)})'>Editar</button>
            <button class="eliminar" onclick="eliminarDisciplina(${d.id})">Eliminar</button></td>`;
            tabla.appendChild(tr);
        });
    }
};

form.addEventListener('submit', async e=>{
    e.preventDefault();
    const id=document.getElementById('idDisciplina').value;
    const datos={
        accion:id?'editar':'crear',
        id:id,
        nombre_disciplina:document.getElementById('nombre_disciplina').value,
        descripcion:document.getElementById('descripcion').value
    };
    const res=await fetch('disciplinas.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(datos)});
    const data=await res.json();
    alert(data.message);
    if(data.status==='success'){limpiarFormulario();cargarDisciplinas();}
});

const editarDisciplina = d=>{
    document.getElementById('idDisciplina').value=d.id;
    document.getElementById('nombre_disciplina').value=d.nombre_disciplina;
    document.getElementById('descripcion').value=d.descripcion||'';
    form.querySelector('button[type="submit"]').textContent='Actualizar Disciplina';
    btnCancelar.style.display='inline-block';
};

const eliminarDisciplina=async id=>{
    if(!confirm('驴Seguro que deseas eliminar esta disciplina?')) return;
    const res=await fetch('disciplinas.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({accion:'eliminar',id})});
    const data=await res.json();
    alert(data.message);
    if(data.status==='success') cargarDisciplinas();
};

btnCancelar.addEventListener('click',limpiarFormulario);
document.addEventListener('DOMContentLoaded',cargarDisciplinas);
</script>
</body>
</html>
