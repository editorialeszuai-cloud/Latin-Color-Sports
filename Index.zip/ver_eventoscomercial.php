
<?php
// 1. Conexión y Autoload
require_once "db.php"; // Usa tu db.php estable
require_once __DIR__ . '/vendor/autoload.php';

// 2. Lógica de procesamiento AJAX (Solo si se pide galería o lista)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    header("Content-Type: text/html; charset=utf-8");
    $uid = $_POST['uid'] ?? null;

    if (!$uid) die('<p class="text-red-500">Sesión no válida.</p>');

    try {
        // Obtener ID real del usuario desde el UID de Firebase
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
        $stmt->execute([$uid]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$usuario) die('Usuario no registrado en la base de datos.');
        $usuario_id = $usuario['id'];

        // --- CASO A: VER GALERÍA DE UN EVENTO ---
       // --- CASO A: VER GALERÍA DE UN EVENTO ---
        if (isset($_POST['evento_id'])) {
            $evento_id = intval($_POST['evento_id']);
            
            // Relación: fotos -> postulaciones -> eventos
            $stmt = $pdo->prepare("
                SELECT f.url, f.descripcion, u.nombre AS fotografo
                FROM fotos f
                INNER JOIN postulaciones p ON f.postulacion_id = p.id
                INNER JOIN usuarios u ON p.usuario_id = u.id
                WHERE p.evento_id = ?
                ORDER BY f.id DESC
            ");
            $stmt->execute([$evento_id]);
            $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if ($fotos) {
                echo '<div class="grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in">';
                foreach ($fotos as $f) {
                    $url = "" . htmlspecialchars($f['url']);
                    echo "
                    <div class='group relative bg-black rounded-2xl overflow-hidden shadow-lg aspect-square'>
                        <img src='$url' class='w-full h-full object-cover transition duration-500 group-hover:scale-110 opacity-90 group-hover:opacity-100 cursor-pointer' 
                             onclick=\"openModal('$url')\">
                        <div class='absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/80 to-transparent'>
                             <p class='text-white text-[10px] font-medium'>📷 Fotógrafo: {$f['fotografo']}</p>
                        </div>
                    </div>";
                }
                echo '</div>';
            } else {
                echo '<div class="py-12 text-center bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                        <p class="text-gray-400 font-medium">Este evento aún no tiene fotografías cargadas.</p>
                      </div>';
            }
            exit;
        }

        // --- CASO B: LISTAR EVENTOS DEL USUARIO ---
        $stmt = $pdo->prepare("SELECT id, banner, titulo, fecha FROM eventos WHERE comercial_id = ? ORDER BY fecha DESC");
        $stmt->execute([$usuario_id]);
        $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($eventos) {
            echo '<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">';
            foreach ($eventos as $ev) {
                $banner = !empty($ev['banner']) ? htmlspecialchars($ev['banner']) : 'img/default_event.jpg';
                echo "
                <div class='bg-white rounded-[2rem] shadow-xl shadow-gray-200/50 overflow-hidden border border-gray-100 hover:-translate-y-2 transition-all duration-300'>
                    <div class='h-48 overflow-hidden relative'>
                        <img src='$banner' class='w-full h-full object-cover'>
                        <div class='absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full shadow-sm'>
                            <p class='text-[10px] font-bold text-orange-600 uppercase tracking-tighter'>Activo</p>
                        </div>
                    </div>
                    <div class='p-6 text-center'>
                        <h3 class='font-black text-xl text-gray-900 mb-1'>".htmlspecialchars($ev['titulo'])."</h3>
                        <p class='text-sm text-gray-400 mb-6 flex items-center justify-center gap-2'>
                            <svg class='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'><path d='M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z'/></svg>
                            ".date('d M, Y', strtotime($ev['fecha']))."
                        </p>
                        <button onclick='verGaleria({$ev['id']})' class='group w-full bg-gray-900 text-white py-4 rounded-2xl font-bold hover:bg-orange-600 transition-all shadow-lg shadow-gray-200 flex items-center justify-center gap-2'>
                            <span>Ver Galería Profesional</span>
                            <svg class='w-5 h-5 group-hover:translate-x-1 transition-transform' fill='none' stroke='currentColor' viewBox='0 0 24 24'><path stroke-width='2' d='M13 7l5 5m0 0l-5 5m5-5H6'/></svg>
                        </button>
                    </div>
                </div>";
            }
            echo '</div>';
        } else {
            echo '<p class="text-gray-500 text-center py-20 font-medium">No tienes eventos asignados actualmente.</p>';
        }

        // --- CASO B: LISTAR EVENTOS DEL USUARIO ---
       
        exit;

    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}
?>
<?php require 'navcomercial.php'?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Eventos | Latin Color Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-20">

    <div class="max-w-6xl mx-auto px-4 py-10">
        <h1 class="text-3xl font-bold text-gray-900 mb-8 text-center">Mis Eventos Asignados</h1>
        
        <div id="eventosContainer">
            <div class="flex justify-center"><div class="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div></div>
        </div>

        <div id="galeriaContainer" class="mt-12 hidden fade-in">
            <h2 class="text-2xl font-bold text-orange-700 mb-6 border-b pb-2">Galería del Evento</h2>
            <div id="fotosContainer"></div>
        </div>
    </div>

    <div id="photoModal" class="fixed inset-0 bg-black/90 hidden z-50 items-center justify-center p-4" onclick="closeModal()">
        <img id="modalImage" class="max-w-full max-h-full rounded-lg shadow-2xl">
    </div>

    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
        import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

        // Reutiliza tu config
        const firebaseConfig = {
            apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
            authDomain: "latin-group-406b1.firebaseapp.com",
            projectId: "latin-group-406b1",
            storageBucket: "latin-group-406b1.appspot.com",
            messagingSenderId: "21494348297",
            appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
        };

        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);

        let userUID = null;

        window.openModal = (src) => {
            document.getElementById('modalImage').src = src;
            document.getElementById('photoModal').classList.replace('hidden', 'flex');
        };

        window.closeModal = () => {
            document.getElementById('photoModal').classList.replace('flex', 'hidden');
        };

        async function loadEventos(uid) {
            const fd = new FormData();
            fd.append('uid', uid);
            const res = await fetch(window.location.href, {
                method: 'POST',
                body: fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            document.getElementById('eventosContainer').innerHTML = await res.text();
        }

        window.verGaleria = async (eventoId) => {
            const fd = new FormData();
            fd.append('uid', userUID);
            fd.append('evento_id', eventoId);
            
            const res = await fetch(window.location.href, {
                method: 'POST',
                body: fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });
            
            document.getElementById('fotosContainer').innerHTML = await res.text();
            document.getElementById('galeriaContainer').classList.remove('hidden');
            window.scrollTo({ top: document.getElementById('galeriaContainer').offsetTop - 50, behavior: 'smooth' });
        };

        onAuthStateChanged(auth, async (user) => {
            if (user) {
                userUID = user.uid;
                loadEventos(user.uid);
            } else {
                window.location.href = 'login_app.html';
            }
        });
    </script>
</body>
</html>