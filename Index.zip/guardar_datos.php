<?php
require 'conexion.php';
$conn = conectar();

$nombre = $_POST['nombre'] ?? '';
$precio = $_POST['precio'] ?? 0;
$descripcion = $_POST['descripcion'] ?? '';

if ($nombre && $precio) {
  $stmt = $conn->prepare("INSERT INTO productos (nombre, precio, descripcion) VALUES (?, ?, ?)");
  $stmt->bind_param("sds", $nombre, $precio, $descripcion);
  $stmt->execute();
  echo "<script>alert('Producto guardado correctamente');window.history.back();</script>";
} else {
  echo "<script>alert('Faltan datos');window.history.back();</script>";
}
?>
