<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "dbfotografos.php"; // debe contener $pdo = new PDO(...);

header('Content-Type: application/json; charset=utf-8');

$accion = $_POST['accion'] ?? '';

switch ($accion) {
    case 'listar':
        listarCalendarios($pdo);
        break;

    case 'agregar':
        agregarCalendario($pdo);
        break;

    case 'editar':
        editarCalendario($pdo);
        break;

    case 'eliminar':
        eliminarCalendario($pdo);
        break;

    default:
        echo json_encode(["success" => false, "message" => "Acción no válida"]);
        break;
}

// ---------------------- FUNCIONES ----------------------

function listarCalendarios($pdo) {
    try {
        $stmt = $pdo->query("SELECT id, nombre AS nombre_calendario, evento_id, created_at 
                             FROM calendario_evento 
                             ORDER BY created_at DESC");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(["success" => true, "data" => $data]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Error al listar: " . $e->getMessage()]);
    }
}

function agregarCalendario($pdo) {
    $nombre = $_POST['nombre_calendario'] ?? '';
    $evento_id = $_POST['evento_id'] ?? null;

    if (!$nombre || !$evento_id) {
        echo json_encode(["success" => false, "message" => "Faltan datos requeridos"]);
        return;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO calendario_evento (nombre, evento_id) VALUES (?, ?)");
        $stmt->execute([$nombre, $evento_id]);
        $id = $pdo->lastInsertId();
        echo json_encode(["success" => true, "message" => "Calendario agregado", "id" => $id]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Error al agregar: " . $e->getMessage()]);
    }
}

function editarCalendario($pdo) {
    $id = $_POST['id'] ?? null;
    $nombre = $_POST['nombre_calendario'] ?? '';
    $evento_id = $_POST['evento_id'] ?? null;

    if (!$id) {
        echo json_encode(["success" => false, "message" => "Falta ID del calendario"]);
        return;
    }

    try {
        $stmt = $pdo->prepare("UPDATE calendario_evento SET nombre = ?, evento_id = ? WHERE id = ?");
        $stmt->execute([$nombre, $evento_id, $id]);
        echo json_encode(["success" => true, "message" => "Calendario actualizado"]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Error al editar: " . $e->getMessage()]);
    }
}

function eliminarCalendario($pdo) {
    $id = $_POST['id'] ?? null;

    if (!$id) {
        echo json_encode(["success" => false, "message" => "Falta ID del calendario"]);
        return;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM calendario_evento WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["success" => true, "message" => "Calendario eliminado"]);
    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Error al eliminar: " . $e->getMessage()]);
    }
}
