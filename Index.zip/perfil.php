<!-- registro_facial.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Biométrico - Latin Color Sports</title>
   <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        #video-container { position: relative; width: 320px; height: 240px; margin: 0 auto; }
        video { border-radius: 0.75rem; background: #000; }
        canvas { position: absolute; top: 0; left: 0; }
        .analyzing { animation: pulse 1.5s infinite; }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center justify-center py-10 px-4">

   <!-- Modal de Registro Biométrico -->
<div id="modalIA" class="fixed inset-0 z-[100] hidden flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
    <div class="bg-white rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl border-t-4 border-orange-500">
        <h3 class="text-xl font-bold text-gray-800 mb-2">Perfil Biométrico</h3>
        <p class="text-[11px] text-gray-500 mb-4">Escanea tu rostro para identificarte en los eventos de <b>Latin Color Sports</b>.</p>
        
        <div class="relative w-64 h-48 mx-auto bg-gray-900 rounded-2xl overflow-hidden mb-4 shadow-inner">
            <video id="videoIA" class="w-full h-full object-cover" autoplay muted playsinline></video>
            <!-- Línea de escaneo animada -->
            <div id="scanLine" class="absolute top-0 left-0 w-full h-1 bg-orange-500 shadow-[0_0_15px_#f97316] hidden"></div>
        </div>

        <div id="statusIA" class="text-[12px] font-semibold text-orange-600 mb-4 bg-orange-50 py-2 rounded-lg">
            Esperando cámara...
        </div>

        <div class="flex gap-2">
            <button onclick="cerrarModalIA()" class="flex-1 bg-gray-100 text-gray-600 font-bold py-3 rounded-xl text-sm">CANCELAR</button>
            <button id="btnCapturarIA" disabled class="flex-[2] bg-orange-500 text-white font-bold py-3 rounded-xl text-sm disabled:opacity-50 shadow-lg shadow-orange-200">REGISTRAR</button>
        </div>
    </div>
</div>

    <script type="module">
        // 1. IMPORTACIÓN FIREBASE
        import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
        import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

        // 2. CONFIGURACIÓN FIREBASE
        const firebaseConfig = {
            apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
            authDomain: "latin-group-406b1.firebaseapp.com",
            projectId: "latin-group-406b1",
            storageBucket: "latin-group-406b1.appspot.com",
            messagingSenderId: "21494348297",
            appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
        };

        const app = initializeApp(firebaseConfig);
        const auth = getAuth(app);

        // Elementos del DOM
        const video = document.getElementById('video');
        const status = document.getElementById('status');
        const btnCapturar = document.getElementById('btnCapturar');

        // 3. CONTROL DE ACCESO
        onAuthStateChanged(auth, (user) => {
            if (user) {
                console.log("Acceso concedido:", user.uid);
                cargarModelos();
            } else {
                alert("Debes iniciar sesión para registrar tu perfil.");
                window.location.href = 'login.php'; 
            }
        });

        // 4. CARGA DE MODELOS IA
        function cargarModelos() {
            status.innerText = "Cargando Inteligencia Artificial...";
            Promise.all([
                faceapi.nets.tinyFaceDetector.loadFromUri('../face-demo/models/'),
                faceapi.nets.faceLandmark68Net.loadFromUri('../face-demo/models/'),
                faceapi.nets.faceRecognitionNet.loadFromUri('../face-demo/models/')
            ]).then(iniciarCamara);
        }

        // 5. INICIAR CÁMARA
        function iniciarCamara() {
            navigator.mediaDevices.getUserMedia({ video: {} })
                .then(stream => {
                    video.srcObject = stream;
                    status.innerText = "IA Lista. Encuadra tu rostro.";
                    btnCapturar.disabled = false;
                })
                .catch(err => {
                    status.innerText = "Error: No se detectó cámara.";
                    console.error(err);
                });
        }

        // 6. CAPTURA Y PROCESAMIENTO
        btnCapturar.onclick = async () => {
            const user = auth.currentUser;
            if (!user) return;

            status.innerText = "Analizando facciones...";
            status.classList.add('analyzing');
            btnCapturar.disabled = true;

            // Detección con los descriptores (los 128 puntos)
            const detection = await faceapi.detectSingleFace(video, new faceapi.TinyFaceDetectorOptions())
                                          .withFaceLandmarks()
                                          .withFaceDescriptor();

            if (detection) {
                status.innerText = "¡Rostro detectado! Guardando...";
                const descriptor = JSON.stringify(Array.from(detection.descriptor));
                enviarALaBaseDeDatos(user.uid, descriptor);
            } else {
                status.innerText = "No te veo bien. Intenta de nuevo.";
                status.classList.remove('analyzing');
                btnCapturar.disabled = false;
            }
        };

        // 7. ENVÍO AL BACKEND PHP
        async function enviarALaBaseDeDatos(uid, descriptor) {
            try {
                const response = await fetch('api_guardar_biometria.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        firebase_uid: uid, 
                        descriptor: descriptor 
                    })
                });

                const result = await response.json();

                if (result.status === 'ok') {
                    status.innerText = "✅ PERFIL VINCULADO CORRECTAMENTE";
                    status.classList.remove('analyzing');
                    // Redirigir después de un momento de éxito
                    setTimeout(() => {
                        window.location.href = 'nav_usuarios.php'; 
                    }, 2500);
                } else {
                    throw new Error(result.message);
                }
            } catch (error) {
                console.error("Error en el registro:", error);
                status.innerText = "❌ Error al guardar. Reintenta.";
                status.classList.remove('analyzing');
                btnCapturar.disabled = false;
            }
        }
    </script>
</body>
</html>