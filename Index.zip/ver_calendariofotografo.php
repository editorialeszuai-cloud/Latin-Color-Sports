<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mi Calendario de Postulaciones</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen p-6">

<div class="container mx-auto">
  <h1 class="text-3xl font-bold mb-6 text-center text-blue-800">
    🏅 Mi Calendario de Postulaciones
  </h1>

  <div id="calendarioContainer" class="bg-white shadow rounded p-4 overflow-auto">
    <p class="text-gray-500 text-center">Cargando calendario...</p>
  </div>
</div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.appspot.com",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const cont = document.getElementById('calendarioContainer');

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    cont.innerHTML = '<p class="text-red-500 text-center">Debes iniciar sesión para ver tu calendario.</p>';
    return;
  }

  const firebase_uid = user.uid;
  cont.innerHTML = '<p class="text-center text-gray-500 animate-pulse">Cargando calendario...</p>';

  try {
    const res = await fetch('postulaciones_calendario.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ firebase_uid, accion: 'listar' })
    });

    const data = await res.json();

    if (!data.success) {
      cont.innerHTML = `<p class="text-red-500 text-center">${data.message || 'Error al cargar datos'}</p>`;
      return;
    }

    const postulaciones = data.postulaciones_aceptadas || [];
    if (!postulaciones.length) {
      cont.innerHTML = '<p class="text-center text-gray-500">No tienes postulaciones aceptadas.</p>';
      return;
    }

    // Agrupar por calendario y sede
    const eventos = {};
    postulaciones.forEach(c => {
      if (!eventos[c.calendario]) eventos[c.calendario] = {};
      if (!eventos[c.calendario][c.sede]) eventos[c.calendario][c.sede] = [];
      eventos[c.calendario][c.sede].push(c);
    });

    let html = '';
    Object.keys(eventos).forEach(cal => {
      html += `<div class="mb-8">
        <h2 class="text-2xl font-semibold text-blue-700 mb-2 border-b pb-1">📘 Calendario: ${cal}</h2>`;

      Object.keys(eventos[cal]).forEach(sede => {
        html += `<div class="mb-4">
          <h3 class="text-xl font-medium text-gray-800 mb-2">🏟️ Sede: ${sede}</h3>
          <table class="min-w-full border divide-y divide-gray-300 bg-white mb-4">
            <thead class="bg-blue-50">
              <tr>
                <th class="px-3 py-2 text-left">Evento</th>
                <th class="px-3 py-2 text-left">Escenario</th>
                <th class="px-3 py-2 text-left">Disciplina</th>
                <th class="px-3 py-2 text-left">Categoría</th>
                <th class="px-3 py-2 text-left">Fecha</th>
                <th class="px-3 py-2 text-left">Hora</th>
                <th class="px-3 py-2 text-left">Acción</th>
              </tr>
            </thead>
            <tbody>`;

        eventos[cal][sede].forEach(c => {
          const categoriaTexto = c.categoria === 'M' ? 'Masculino' : 'Femenino';
          const params = new URLSearchParams({
            postulacion_id: c.postulacion_id,
            evento_id: c.evento_id,
            evento: c.evento,
            fecha: c.fecha,
            hora: c.hora,
            disciplina: c.disciplina,
            categoria: c.categoria,
            escenario: c.escenario,
            sede: c.sede,
            calendario: c.calendario
          });

          html += `<tr class="hover:bg-gray-50">
            <td class="px-3 py-2 font-medium text-gray-900">${c.evento || '-'}</td>
            <td class="px-3 py-2">${c.escenario}</td>
            <td class="px-3 py-2">${c.disciplina}</td>
            <td class="px-3 py-2">${categoriaTexto}</td>
            <td class="px-3 py-2">${c.fecha}</td>
            <td class="px-3 py-2">${c.hora}</td>
            <td class="px-3 py-2 text-center">
              <button 
                onclick="window.location.href='subircontenido.php?${params.toString()}'"
                class="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded">
                📸 Subir Fotos
              </button>
            </td>
          </tr>`;
        });

        html += `</tbody></table></div>`;
      });

      html += `</div>`;
    });

    cont.innerHTML = html;

  } catch (e) {
    console.error(e);
    cont.innerHTML = '<p class="text-red-500 text-center">Error al cargar el calendario.</p>';
  }
});
</script>
</body>
</html>
