<?php
require_once "conexion.php";
$conn = conectar();

// 🔌 Verificación de conexión
if (!$conn || $conn->connect_error) {
    die("❌ Error de conexión: " . $conn->connect_error);
}

// 🔍 Cargar usuarios desde MySQL
$sql = "SELECT * FROM usuarios ORDER BY id DESC";
$result = $conn->query($sql);
if (!$result) {
    die("❌ Error al cargar los datos: " . $conn->error);
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Menú lateral responsive con Navbar</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
    
   <?php require 'menuadmin.php'; ?>

    <div id="overlay" class="app-overlay"></div>


    <div class="main-area" style="flex:1">
      <header class="topbar">
        <div class="left-topbar">
          <button class="hamburger" id="openBtn" aria-label="Abrir menú">
        
          </button>
          <div class="page-title"></div>
        </div>
        <div class="right-topbar">
          
        </div>
      </header>
      <div class="content">
        <div class="container w-full max-w-6xl mx-auto p-4">
          <div class="header flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b pb-4">
            <h2 class="text-3xl font-extrabold mb-3 md:mb-0">Gestión de Usuarios</h2>
            <div class="buttons flex gap-2 flex-wrap justify-end">
              <button id="btnAdd"
        type="button"
        onclick="window.location.href='agregarusuarios.php'"
        class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition">
  ➕ Añadir Usuario
</button>

              
              
              <form action="exportar_usuarios_csv.php" method="POST" class="inline">
                <button type="submit" class="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">📄 Exportar CSV</button>
              </form>
              <button id="btnShareWhatsapp" type="button" 
                  class="px-3 py-1 bg-green-500 text-white rounded-lg hover:bg-green-600 transition">
                💬 WhatsApp
              </button>
              <button id="btnShareEmail" type="button" 
                  class="px-3 py-1 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition">
                📧 Correo
              </button>
            </div>
          </div>
          

          <form id="usuariosForm">
            <div class="overflow-x-auto table-container">
              <table class="min-w-full divide-y divide-gray-200 text-sm">
                <thead class="bg-gray-100">
                  <tr>
                    <th class="px-4 py-3 w-10"><input type="checkbox" id="selectAll"></th>
                    <th class="px-4 py-3 w-16">Foto</th>
                    <th class="px-4 py-3">Nombre</th>
                    <th class="px-4 py-3">Email</th>
                    <th class="px-4 py-3 w-28">Rol</th>
                    <th class="px-4 py-3 w-24">Estado</th>
                    <th class="px-4 py-3 w-48 text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                  <?php while ($row = $result->fetch_assoc()): ?>
                  <tr class="hover:bg-gray-50 transition-colors">
                    <td class="px-4 py-3"><input type="checkbox" class="userCheckbox" value="<?= htmlspecialchars($row['email']) ?>"></td>
                    <td class="px-4 py-3">
                      <?php if (!empty($row['foto_perfil'])): ?>
                        <img src="uploads/<?= htmlspecialchars($row['foto_perfil']) ?>" alt="Foto" class="w-10 h-10 rounded-full object-cover border border-gray-200">
                      <?php else: ?>
                        <div class="w-10 h-10 bg-gray-200 flex items-center justify-center rounded-full text-gray-500 text-base font-semibold">👤</div>
                      <?php endif; ?>
                    </td>
                    <td class="px-4 py-3 font-medium text-gray-800"><?= htmlspecialchars($row['nombre'] ?? 'N/A') ?></td>
                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($row['email'] ?? 'N/A') ?></td>
                    <td class="px-4 py-3">
                      <span class="inline-block px-2 py-0.5 text-xs font-semibold rounded-full
                        <?= ($row['rol'] ?? 'cliente') === 'admin' ? 'bg-red-100 text-red-800' :
                           (($row['rol'] ?? 'cliente') === 'fotografo' ? 'bg-indigo-100 text-indigo-800' : 'bg-gray-100 text-gray-800') ?>">
                        <?= ucfirst(htmlspecialchars($row['rol'] ?? 'cliente')) ?>
                      </span>
                    </td>
                    <td class="px-4 py-3">
                      <span class="<?= ($row['estado'] ?? 'activo') === 'activo' ? 'text-green-600 font-semibold' : 'text-yellow-600 font-semibold' ?>">
                        <?= ucfirst(htmlspecialchars($row['estado'] ?? 'activo')) ?>
                      </span>
                    </td>
                    <td class="px-4 py-3 flex flex-wrap gap-2 justify-center table-actions">
                      <form action="acciones_usuarios.php" method="POST" class="inline">
                        <input type="hidden" name="accion" value="toggle_estado">
                        <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                        <input type="hidden" name="estado_actual" value="<?= htmlspecialchars($row['estado'] ?? 'activo') ?>">
                        <button type="submit"
                          class="<?= ($row['estado'] ?? 'activo') === 'activo'
                            ? 'bg-yellow-500 text-white px-2 py-1 rounded-lg text-xs hover:bg-yellow-600 transition'
                            : 'bg-green-600 text-white px-2 py-1 rounded-lg text-xs hover:bg-green-700 transition' ?>">
                          <?= ($row['estado'] ?? 'activo') === 'activo' ? 'Desactivar' : 'Activar' ?>
                        </button>
                      </form>

                      <a href="editar_usuario.php?id=<?= $row['id'] ?>" class="bg-blue-500 text-white px-2 py-1 rounded-lg text-xs hover:bg-blue-600 transition">Editar</a>

                      <form action="acciones_usuarios.php" method="POST" class="inline" onsubmit="return confirm('¿Está seguro de eliminar a <?= htmlspecialchars($row['nombre'] ?? 'este usuario') ?>? Esta acción es irreversible.');">
                        <input type="hidden" name="accion" value="eliminar">
                        <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                        <button type="submit" class="bg-red-600 text-white px-2 py-1 rounded-lg text-xs hover:bg-red-700 transition">Eliminar</button>
                      </form>
                    </td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </form>
        </div>

        <div id="roleContent" class="mt-8 space-y-4"></div>
      </div>
    </div>
  </div>

<script>
  // === SCRIPTS ORIGINALES (SIN MODIFICAR LA LÓGICA) ===
  const openBtn = document.getElementById("openBtn");
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("overlay");

  // Abrir/cerrar menú al hacer clic en el botón
  openBtn.addEventListener("click", () => {
    const isClosed = sidebar.classList.contains("closed");
    
    // Toggle en móvil
    if (window.innerWidth < 768) {
      const isOpen = sidebar.classList.toggle("open");
      if (isOpen) {
        overlay.classList.add("visible");
      } else {
        overlay.classList.remove("visible");
      }
    } else {
      // Toggle en desktop
      sidebar.classList.toggle("closed");
      sidebar.classList.remove("open"); // Asegurar que no tenga la clase mobile
    }
  });

  // Cerrar menú al hacer clic fuera (en el overlay)
  overlay.addEventListener("click", () => {
    sidebar.classList.remove("open");
    overlay.classList.remove("visible");
  });
</script>

<script>
  const toggleBtn = document.getElementById('toggleInfo');
  const moreInfo = document.getElementById('moreInfo');
  const userProfileToggle = document.getElementById('userProfileToggle');

  const toggleUserDetails = (e) => {
    // Evitar que el clic en el botón de toggle se propague y se active dos veces
    if (e.target.closest('#toggleInfo')) {
        return;
    }

    const isHidden = moreInfo.style.display === 'none' || moreInfo.style.display === '';
    moreInfo.style.display = isHidden ? 'block' : 'none';
    toggleBtn.querySelector('span').textContent = isHidden ? '▴' : '▾';
  };

  userProfileToggle.addEventListener('click', toggleUserDetails);
  toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation(); // Evita que se propague el evento al padre
      toggleUserDetails(e);
  });
</script>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const dashboardContainer = document.getElementById('dashboardContainer');
const loadingMessage = document.getElementById('loadingMessage');
const errorMessage = document.getElementById('errorMessage');
const logoutButton = document.getElementById('logoutButton');
const userRoleSpan = document.getElementById('userRole');
const userManagement = document.getElementById('userManagement');
const roleContentDiv = document.getElementById('roleContent');
const userFotoImg = document.getElementById('userFotoPerfil'); // Foto de perfil

function showError(msg) {
  errorMessage.textContent = msg;
  errorMessage.classList.remove('hidden');
}

function updateUI(uid, email, nombre, rol, foto){
  document.getElementById('userId').textContent = uid;
  document.getElementById('userEmail').textContent = email;
  document.getElementById('userName').textContent = nombre;

  // Actualizar la foto de perfil
  if(foto && foto.trim() !== ''){
      userFotoImg.src = foto; // URL real de la foto
  } else {
      userFotoImg.src = 'uploads/perfil.jpg'; // fallback si no tiene foto
  }

  userRoleSpan.textContent = rol;
  userRoleSpan.className = `role-${rol}`;
  
  // Mostrar dashboard y ocultar mensaje de carga
  if(dashboardContainer) dashboardContainer.classList.remove('hidden');
  if(loadingMessage) loadingMessage.classList.add('hidden');

  // Control de secciones según rol
  if (rol === 'admin') {
    if(userManagement) userManagement.classList.remove('hidden');
  } else {
    if(userManagement) userManagement.classList.add('hidden');
    if(roleContentDiv) roleContentDiv.innerHTML = `<p>Acceso restringido a administradores.</p>`;
  }
}

// Cerrar sesión
logoutButton.addEventListener('click', async () => {
  await signOut(auth);
  window.location.href = 'login_app.html';
});

// Detectar estado de autenticación
onAuthStateChanged(auth, async (user) => {
  if (user) {
    try {
      const token = await user.getIdToken();
      const res = await fetch('get_user_info.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ firebase_token: token })
      });
      const data = await res.json();

      if (data.status === 'success' && data.user) {
        updateUI(
          data.user.firebase_uid, 
          data.user.email, 
          data.user.nombre, 
          data.user.rol, 
          data.user.foto_perfil // <-- se pasa la foto correctamente
        );
      } else {
        showError('Usuario no registrado en la base de datos.');
      }
    } catch (err) {
      console.error(err);
      showError('Error al obtener datos del usuario.');
    }
  } else {
    // Si no hay usuario, redirigir al login
    window.location.href = 'login_app.html';
  }
});
</script>
<script>
// === 📤 COMPARTIR USUARIOS SELECCIONADOS ===
const selectAll = document.getElementById('selectAll');
const checkboxes = document.querySelectorAll('.userCheckbox');
const btnWhatsapp = document.getElementById('btnShareWhatsapp');
const btnEmail = document.getElementById('btnShareEmail');

// Función para seleccionar/deseleccionar todos
selectAll.addEventListener('change', () => {
    checkboxes.forEach(chk => {
        chk.checked = selectAll.checked;
    });
});

// Actualizar el estado de "Seleccionar todos"
checkboxes.forEach(chk => {
    chk.addEventListener('change', () => {
        if (!chk.checked) {
            selectAll.checked = false;
        } else if (document.querySelectorAll('.userCheckbox:checked').length === checkboxes.length) {
            selectAll.checked = true;
        }
    });
});


function obtenerUsuariosSeleccionados() {
  const seleccionados = [];
  checkboxes.forEach(chk => {
    if (chk.checked) {
      const fila = chk.closest('tr');
      // Acceder a los datos de la fila de la tabla
      const nombre = fila.querySelector('td:nth-child(3)')?.innerText.trim() || '';
      const email = fila.querySelector('td:nth-child(4)')?.innerText.trim() || '';
      seleccionados.push({ nombre, email });
    }
  });
  return seleccionados;
}

btnWhatsapp.addEventListener('click', () => {
  const seleccionados = obtenerUsuariosSeleccionados();
  if (seleccionados.length === 0) {
    alert('⚠️ Debes seleccionar al menos un usuario.');
    return;
  }

  // Creamos el mensaje
  let mensaje = "👋 Hola! Estos son los usuarios seleccionados:\n\n";
  seleccionados.forEach(u => mensaje += `• ${u.nombre} (${u.email})\n`);

  // Codificamos el texto para WhatsApp
  const textoCodificado = encodeURIComponent(mensaje);
  // Usar el API universal de WhatsApp sin número predefinido
  const url = `https://wa.me/?text=${textoCodificado}`; 
  window.open(url, '_blank');
});

btnEmail.addEventListener('click', () => {
  const seleccionados = obtenerUsuariosSeleccionados();
  if (seleccionados.length === 0) {
    alert('⚠️ Debes seleccionar al menos un usuario.');
    return;
  }

  // Armamos lista de destinatarios (en el campo 'to')
  const emails = seleccionados.map(u => u.email).join(',');
  const subject = encodeURIComponent('Lista de usuarios seleccionados');
  const body = encodeURIComponent(
    "Hola,\n\nAquí tienes los usuarios seleccionados:\n\n" +
    seleccionados.map(u => `• ${u.nombre} (${u.email})`).join('\n')
  );

  // Abrimos el cliente de correo
  window.location.href = `mailto:?bcc=${emails}&subject=${subject}&body=${body}`; // Usar bcc para enviar a múltiples correos
});
</script>

<script>
    // Lógica para el Submenú de Usuarios
document.addEventListener('DOMContentLoaded', () => {
    // ... [Tu código existente de openBtn, sidebar, overlay, etc.] ...

    const usuariosNavItem = document.getElementById('usuariosNavItem');
    
    if (usuariosNavItem) {
        // Seleccionamos el enlace principal para el evento click
        const usuariosNavLink = usuariosNavItem.querySelector('.nav-link');

        usuariosNavLink.addEventListener('click', (e) => {
            // El enlace principal no debe navegar, solo debe desplegar el submenú
            e.preventDefault(); 
            
            // Alternar la clase 'open' para desplegar/contraer
            usuariosNavItem.classList.toggle('open');
        });
    }
});
</script>
</body>
</html>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const btnAdd = document.getElementById('btnAdd');
    const addUserModal = document.getElementById('addUserModal');
    const closeModal = document.getElementById('closeModal');
    const cancelAddUser = document.getElementById('cancelAddUser');

    // Abrir modal
    btnAdd.addEventListener('click', () => {
        addUserModal.classList.remove('hidden');
    });

    // Cerrar modal al hacer clic en "×"
    closeModal.addEventListener('click', () => {
        addUserModal.classList.add('hidden');
    });

    // Cerrar modal al presionar "Cancelar"
    cancelAddUser.addEventListener('click', () => {
        addUserModal.classList.add('hidden');
    });

    // Cerrar modal al hacer clic fuera del contenido
    addUserModal.addEventListener('click', (e) => {
        if(e.target === addUserModal){
            addUserModal.classList.add('hidden');
        }
    });
});
</script>
