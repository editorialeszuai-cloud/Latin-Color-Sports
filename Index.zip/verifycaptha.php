<?php

header('Content-Type: application/json');

$secret = "6LdxMucsAAAAAHSJyhX87wjh9Td5UK01dnhW5Csv";

$token = $_POST['token'] ?? '';

if(empty($token)){

    echo json_encode([
        "success" => false,
        "error" => "TOKEN VACIO"
    ]);

    exit;
}

$url = "https://www.google.com/recaptcha/api/siteverify";

$data = [
    'secret' => $secret,
    'response' => $token
];

$options = [
    'http' => [
        'header' =>
        "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    ]
];

$context =
stream_context_create($options);

$result =
file_get_contents(
    $url,
    false,
    $context
);

$response =
json_decode($result, true);

echo json_encode($response);