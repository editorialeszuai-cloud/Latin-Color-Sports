<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require 'dbfotografos.php';
$pdo = conectar();

// 1. Obtener eventos para el filtro
$eventos = $pdo->query("SELECT id, titulo FROM eventos ORDER BY titulo ASC")->fetchAll(PDO::FETCH_ASSOC);
$evento_id = $_GET['evento_id'] ?? '';

// 2. Cadena Analítica SQL (Ruta: ventas -> fotos -> galerias -> postulaciones -> usuarios)
$sql = "
    SELECT 
        COALESCE(u.nombre, 'Sin Fotógrafo') AS fotografo,
        COUNT(dc.id_foto) AS total_vendidas,
        COALESCE(SUM(dc.precio), 0) AS total_facturado
    FROM detalle_compras dc
    JOIN compras c ON dc.id_compra = c.id
    LEFT JOIN fotos f ON dc.id_foto = f.id
    LEFT JOIN galerias g ON f.galeria_id = g.id
    -- Movemos el filtro del evento aquí dentro del JOIN
    LEFT JOIN postulaciones p ON g.postulacion_id = p.id " . ($evento_id ? "AND p.evento_id = :evento_id" : "") . "
    LEFT JOIN usuarios u ON p.usuario_id = u.id
    WHERE c.estado = 'APPROVED'
    GROUP BY u.id, u.nombre
    ORDER BY total_facturado DESC";

$q = $pdo->prepare($sql);
if ($evento_id) $q->execute([':evento_id' => $evento_id]);
else $q->execute();
$reportFotos = $q->fetchAll(PDO::FETCH_ASSOC);

// 3. Paquetes (Independientes)
$wherePaq = $evento_id ? "AND dcp.evento_id = :evento_id" : "";
$qP = $pdo->prepare("SELECT COUNT(*) as cant, COALESCE(SUM(total),0) as val 
                     FROM compras_paquetes c 
                     JOIN detalle_compras_paquetes dcp ON dcp.id_compra = c.id 
                     WHERE c.estado='Pagado' $wherePaq");
$qP->execute($evento_id ? [':evento_id' => $evento_id] : []);
$dataPaq = $qP->fetch(PDO::FETCH_ASSOC);

$totalFacturadoFotos = array_sum(array_column($reportFotos, 'total_facturado'));
$totalGeneral = $totalFacturadoFotos + $dataPaq['val'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Analítico Global</title>
    <script src="https://cdn.tailwindcss.com"></script>
	    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
</head>
<body class="bg-slate-50 text-slate-900">
    <?php require 'menuadmin.php'; ?>

    <main class="max-w-7xl mx-auto p-6">
        <h1 class="text-3xl font-black mb-6">Dashboard Analítico</h1>

        <form method="GET" class="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6 flex gap-4 items-end">
            <div>
                <label class="block text-[10px] font-bold text-slate-400 uppercase">Evento</label>
                <select name="evento_id" class="mt-1 border-slate-300 rounded-lg text-sm w-64">
                    <option value="">-- Todos los eventos --</option>
                    <?php foreach ($eventos as $ev): ?>
                        <option value="<?= $ev['id'] ?>" <?= $evento_id == $ev['id'] ? 'selected' : '' ?>><?= $ev['titulo'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button class="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700">Filtrar</button>
        </form>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded-2xl border shadow-sm">
                <h2 class="text-[10px] font-bold text-slate-400 uppercase">Paquetes</h2>
                <p class="text-3xl font-black"><?= number_format($dataPaq['cant']) ?></p>
            </div>
            <div class="bg-white p-6 rounded-2xl border shadow-sm">
                <h2 class="text-[10px] font-bold text-slate-400 uppercase">Facturación Total</h2>
                <p class="text-3xl font-black text-blue-600">$<?= number_format($totalGeneral, 2) ?></p>
            </div>
            <div class="bg-white p-6 rounded-2xl border shadow-sm">
                <h2 class="text-[10px] font-bold text-slate-400 uppercase">Utilidad 40%</h2>
                <p class="text-3xl font-black text-emerald-600">$<?= number_format($totalGeneral * 0.40, 2) ?></p>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                    <tr><th class="p-4">Fotógrafo</th><th class="p-4">Fotos Vendidas</th><th class="p-4 text-right">Facturado</th></tr>
                </thead>
                <tbody class="divide-y divide-slate-100">
                    <?php foreach ($reportFotos as $r): ?>
                    <tr class="hover:bg-slate-50 transition text-sm">
                        <td class="p-4 font-bold text-slate-800"><?= htmlspecialchars($r['fotografo']) ?></td>
                        <td class="p-4 text-slate-600"><?= number_format($r['total_vendidas']) ?></td>
                        <td class="p-4 font-bold text-blue-700 text-right">$<?= number_format($r['total_facturado'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>