<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require_once 'dbfotografos.php';
$pdo = conectar();

// Datos recibidos de ePayco
$data = $_POST ?: $_GET;

$x_id_invoice    = $data['x_id_invoice'] ?? ''; // referencia interna (ref_local)
$x_ref_payco     = $data['x_ref_payco'] ?? '';  // referencia real ePayco
$x_amount        = $data['x_amount'] ?? '';
$x_currency_code = $data['x_currency_code'] ?? '';
$x_response      = $data['x_response'] ?? '';
$x_cod_response  = $data['x_cod_response'] ?? '';
$x_test_request  = $data['x_test_request'] ?? 'FALSE';
$p_key           = "8b119b0507c746f6f8a9493c7f9e817b3f9c29a2";
$p_cust_id_cliente = "1566237";

// --- Validar firma (ignorar en modo prueba) ---
$signature_ok = ($x_test_request === 'TRUE');
if(!$signature_ok){
    $sig_local = hash('sha256', trim($p_cust_id_cliente)."~".trim($p_key)."~".trim($x_id_invoice)."~".trim($x_amount)."~".trim($x_currency_code));
    $signature_ok = hash_equals($sig_local, $data['x_signature'] ?? '');
}

if(!$signature_ok){
    file_put_contents("callback_log.txt","[".date("Y-m-d H:i:s")."] Firma inválida ref_invoice=$x_id_invoice\n",FILE_APPEND);
    http_response_code(400);
    die("Firma inválida");
}

// Determinar estado de la compra
$estado = match ($x_cod_response){
    '1' => 'Aprobada',
    '2' => 'Rechazada',
    '3' => 'Pendiente',
    '4' => 'Fallida',
    default => 'Desconocido'
};

// Buscar compra por referencia interna
$stmt = $pdo->prepare("SELECT id, firebase_uid FROM compras WHERE referencia=?");
$stmt->execute([$x_id_invoice]);
$compra = $stmt->fetch(PDO::FETCH_ASSOC);

if($compra){
    $id_compra = $compra['id'];

    // Actualizar solo estado, método de pago y x_transaction_id
    $pdo->prepare("
        UPDATE compras
        SET estado=?, metodo_pago=?, x_transaction_id=?, fecha_compra=NOW()
        WHERE id=?
    ")->execute([$estado, $x_response, $data['x_transaction_id'] ?? '', $id_compra]);

    file_put_contents("callback_log.txt","[".date("Y-m-d H:i:s")."] Compra actualizada: ref_invoice=$x_id_invoice, estado=$estado\n",FILE_APPEND);

} else {
    file_put_contents("callback_log.txt","[".date("Y-m-d H:i:s")."] Compra NO encontrada: ref_invoice=$x_id_invoice\n",FILE_APPEND);
}

// Responder a ePayco
http_response_code(200);
echo "OK";

