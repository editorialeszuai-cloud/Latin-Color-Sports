<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

try {
    require 'dbfotografos.php';

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Método no permitido");
    }

    $descriptor_json = $_POST['descriptor'] ?? null;
    $evento_id = $_POST['evento_id'] ?? null;

    if (!$descriptor_json || !$evento_id) {
        throw new Exception("Faltan parámetros");
    }

    $user_descriptor = json_decode($descriptor_json, true);
    if (!$user_descriptor || !is_array($user_descriptor) || count($user_descriptor) !== 128) {
        throw new Exception("Descriptor inválido");
    }

    // El threshold determina qué tan estricta es la comparación
    $threshold = 0.75; 

    // Consulta para obtener las caras del evento seleccionado
    $stmt = $pdo->prepare("
        SELECT f.id AS foto_id, f.url, fs.descriptor 
        FROM faces fs
        INNER JOIN fotos f ON fs.foto_id = f.id
        INNER JOIN postulaciones p ON f.postulacion_id = p.id
        WHERE p.evento_id = ?
    ");
    $stmt->execute([$evento_id]);
    $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $matches = [];

    foreach ($fotos as $f) {
        $db_descriptor = json_decode($f['descriptor'], true);
        if (!$db_descriptor || count($db_descriptor) !== 128) continue;

        // Calcular Similitud del Coseno
        $dotProduct = 0;
        $normA = 0;
        $normB = 0;

        for ($i = 0; $i < 128; $i++) {
            $dotProduct += ($db_descriptor[$i] * $user_descriptor[$i]);
            $normA += pow($db_descriptor[$i], 2);
            $normB += pow($user_descriptor[$i], 2);
        }

        $normA = sqrt($normA);
        $normB = sqrt($normB);

        // Evitar división por cero
        if ($normA == 0 || $normB == 0) continue;

        $cosineSimilarity = $dotProduct / ($normA * $normB);

        // Si supera el umbral, se añade a resultados
        if ($cosineSimilarity > $threshold) {
            $matches[] = [
                'id' => $f['foto_id'],
                'url' => $f['url'],
                'similarity' => round($cosineSimilarity, 4)
            ];
        }
    }

    // Ordenar por mayor similitud (el valor más alto primero)
    usort($matches, function($a, $b) {
        return $b['similarity'] <=> $a['similarity'];
    });

    echo json_encode([
        'success' => true,
        'fotos' => $matches,
        'total' => count($matches),
        'threshold' => $threshold
    ]);
    exit;

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    exit;
}