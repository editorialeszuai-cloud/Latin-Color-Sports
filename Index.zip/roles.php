<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'dbini.php';

$response = [
    'status' => 'error',
    'message' => 'Error desconocido',
    'rol' => 'cliente'
];

try {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
        throw new Exception("JSON inválido o cuerpo vacío.");
    }

    if (empty($data['idToken'])) {
        throw new Exception("No se recibió token de autorización.");
    }

    $firebaseUid = $data['firebase_uid'] ?? '';
    $email = $data['email'] ?? '';
    $nombre = $data['nombre'] ?? '';
    $fotoPerfil = $data['foto_perfil'] ?? '';
    $rolFormulario = trim($data['rol'] ?? '');

    if (empty($firebaseUid) || empty($email)) {
        throw new Exception("Datos incompletos del usuario.");
    }

    $rolesPermitidos = ['cliente', 'fotografo', 'organizador', 'comercial'];
    if (!in_array($rolFormulario, $rolesPermitidos)) {
        $rolFormulario = 'cliente';
    }

    $pdo = getDbConnection();
    $currentDateTime = date('Y-m-d H:i:s');

    // Verificar si el usuario existe
    $stmt = $pdo->prepare("SELECT rol FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$firebaseUid]);
    $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($existingUser) {
        // Mantener el rol existente o actualizarlo si se envía uno nuevo
        $rolFinal = $rolFormulario ?: $existingUser['rol'];

        $stmt = $pdo->prepare("
            UPDATE usuarios 
            SET nombre = ?, foto_perfil = ?, ultima_sesion = ?
            WHERE firebase_uid = ?
        ");
        $stmt->execute([$nombre, $fotoPerfil, $currentDateTime, $firebaseUid]);

        $response['message'] = "Inicio de sesión exitoso.";
    } else {
        // Nuevo usuario
        $rolFinal = $rolFormulario ?: 'cliente';

        $stmt = $pdo->prepare("
            INSERT INTO usuarios 
            (firebase_uid, email, nombre, foto_perfil, rol, fecha_registro, ultima_sesion, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'activo')
        ");
        $stmt->execute([
            $firebaseUid, $email, $nombre, $fotoPerfil,
            $rolFinal, $currentDateTime, $currentDateTime
        ]);

        $response['message'] = "Nuevo usuario registrado exitosamente.";
    }

    // 🔎 Verificar el rol directamente en la base de datos antes de responder
    $stmt = $pdo->prepare("SELECT rol FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$firebaseUid]);
    $rolVerificado = $stmt->fetchColumn();

    if (!$rolVerificado) {
        throw new Exception("No se pudo verificar el rol del usuario.");
    }

    $response['status'] = 'success';
    $response['rol'] = $rolVerificado;

} catch (Exception $e) {
    error_log("Error en roles.php: " . $e->getMessage());
    $response['status'] = 'error';
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>
