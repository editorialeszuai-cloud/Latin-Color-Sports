<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);
ob_start();

require_once 'dbfotografos.php';
require 'vendor/autoload.php';
use Kreait\Firebase\Factory;
use Kreait\Firebase\Exception\Auth\FailedToVerifyToken;
use Kreait\Firebase\Exception\AuthException;

// Evitar duplicar encabezado
$response = ['status' => 'error', 'message' => 'Error desconocido'];

try {
    // 1️⃣ Conexión PDO
    try {
        $conn = conectar();
        if (!$conn) {
            throw new Exception("No se pudo conectar con la base de datos (conectarPDO() devolvió null).");
        }
        // Opciones de depuración en PDO
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        throw new Exception("Error de conexión PDO: " . $e->getMessage());
    }

    // 2️⃣ Inicializar Firebase
    $serviceAccountPath = __DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json';
    if (!file_exists($serviceAccountPath)) {
        throw new Exception("Archivo de credenciales Firebase no encontrado: $serviceAccountPath");
    }

    $factory = (new Factory)->withServiceAccount($serviceAccountPath);
    $auth = $factory->createAuth();

    // 3️⃣ Validar solicitud POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Método no permitido (usa POST)");
    }

    if (empty($_POST['action']) || $_POST['action'] !== 'register') {
        throw new Exception("Acción inválida o no especificada");
    }

    // 4️⃣ Token de Firebase
    $idToken = $_POST['idToken'] ?? '';
    if (!$idToken) {
        throw new Exception("Token de autenticación faltante");
    }

    try {
        $verifiedToken = $auth->verifyIdToken($idToken);
        $firebase_uid = $verifiedToken->claims()->get('sub');
    } catch (FailedToVerifyToken | AuthException $e) {
        throw new Exception("Token inválido o expirado: " . $e->getMessage());
    }

    // 5️⃣ Datos usuario
    $user_name = trim($_POST['nombre'] ?? '');
    $user_email = trim($_POST['email'] ?? '');
    $role = trim($_POST['role'] ?? 'cliente');

    if (!$user_name || !$user_email) {
        throw new Exception("Faltan datos obligatorios (nombre o email)");
    }

    // 6️⃣ Procesar foto
    $foto_perfil = null;
    if (!empty($_FILES['foto_perfil']['name']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
        $uploadsDir = __DIR__ . '/uploads';
        if (!is_dir($uploadsDir)) mkdir($uploadsDir, 0777, true);
        $nombreArchivo = time() . "_" . basename($_FILES['foto_perfil']['name']);
        $rutaDestino = $uploadsDir . "/" . $nombreArchivo;
        if (move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $rutaDestino)) {
            $foto_perfil = "uploads/" . $nombreArchivo;
        } else {
            throw new Exception("Error al guardar la foto de perfil");
        }
    }

    // 7️⃣ Verificar si ya existe usuario
    $check = $conn->prepare("SELECT COUNT(*) FROM usuarios WHERE email = :email");
    $check->bindParam(':email', $user_email);
    $check->execute();
    $count = $check->fetchColumn();

    if ($count > 0) {
        throw new Exception("Ya existe un usuario registrado con este email");
    }

    // 8️⃣ Insertar nuevo usuario
    // 8️⃣ Insertar nuevo usuario con fecha, última sesión y estado
$sql = "INSERT INTO usuarios 
        (nombre, email, rol, foto_perfil, firebase_uid, fecha_registro, ultima_sesion, estado)
        VALUES 
        (:nombre, :email, :rol, :foto_perfil, :firebase_uid, NOW(), NOW(), 'Activo')";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':nombre', $user_name);
$stmt->bindParam(':email', $user_email);
$stmt->bindParam(':rol', $role);
$stmt->bindParam(':foto_perfil', $foto_perfil);
$stmt->bindParam(':firebase_uid', $firebase_uid);

$stmt->execute();

$response = [
    'status' => 'success',
    'message' => '✅ Usuario registrado correctamente en la base de datos',
    'user' => [
        'nombre' => $user_name,
        'email' => $user_email,
        'rol' => $role,
        'foto_perfil' => $foto_perfil,
        'firebase_uid' => $firebase_uid,
        'fecha_registro' => date('Y-m-d H:i:s'),
        'ultima_sesion' => date('Y-m-d H:i:s'),
        'estado' => 'Activo'
    ]
];


} catch (PDOException $e) {
    // Error de base de datos
    $response = [
        'status' => 'error',
        'message' => '💥 Error en la base de datos PDO: ' . $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ];
} catch (Exception $e) {
    // Otro tipo de error
    $response = [
        'status' => 'error',
        'message' => '⚠️ ' . $e->getMessage()
    ];
}

// 9️⃣ Enviar JSON limpio
ob_clean();
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
exit;
