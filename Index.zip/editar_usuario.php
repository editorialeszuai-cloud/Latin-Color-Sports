<?php
header("Cache-Control: no-cache, must-revalidate");
header("Expires: Sat, 1 Jul 2000 05:00:00 GMT");
header("Pragma: no-cache");

require_once "conexion.php";
$conn = conectar();

// Validar ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de usuario no v��lido.");
}
$id = (int)$_GET['id'];

// Obtener usuario
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Usuario no encontrado.");
}

$usuario = $result->fetch_assoc();
$mensaje = "";

// ====== Procesar POST ======
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nombre = trim($_POST['nombre']);
    $email  = trim($_POST['email']);
    $rol    = $_POST['rol'];

    // Validaciones b��sicas
    if (empty($nombre) || empty($email)) {
        $mensaje = "?? Nombre y email son obligatorios.";
    } else {
        // Subida de foto
        $foto_perfil = $usuario['foto_perfil'];
        if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === 0) {
            $ext = strtolower(pathinfo($_FILES['foto_perfil']['name'], PATHINFO_EXTENSION));
            $permitidas = ['jpg','jpeg','png','gif'];
            if (!in_array($ext, $permitidas)) {
                $mensaje = "?? Formato de imagen no permitido.";
            } else {
                $nuevo_nombre = uniqid() . '.' . $ext;
                if (!is_dir('uploads')) mkdir('uploads', 0777, true);
                if (move_uploaded_file($_FILES['foto_perfil']['tmp_name'], 'uploads/'.$nuevo_nombre)) {
                    // Eliminar foto anterior
                    if (!empty($foto_perfil) && file_exists('uploads/'.$foto_perfil)) {
                        unlink('uploads/'.$foto_perfil);
                    }
                    $foto_perfil = $nuevo_nombre;
                } else {
                    $mensaje = "?? Error al subir la foto.";
                }
            }
        }

        // Actualizar datos en BD
        if (empty($mensaje)) {
            $stmt = $conn->prepare("UPDATE usuarios SET nombre=?, email=?, rol=?, foto_perfil=? WHERE id=?");
            $stmt->bind_param("ssssi", $nombre, $email, $rol, $foto_perfil, $id);
            $stmt->execute();
            $mensaje = "?? Usuario actualizado correctamente.";
            // Refrescar datos
            $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $usuario = $stmt->get_result()->fetch_assoc();
         // Redireccionar a usuarios.php despu��s de guardar
    header("Location: usuarios.php");
    exit;
}
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Editar Usuario</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

<div class="bg-white p-6 rounded-lg shadow-lg w-96">
    <h2 class="text-xl font-semibold mb-4 text-gray-800">Editar Usuario</h2>

    <?php if (!empty($mensaje)): ?>
        <div class="mb-4 p-3 rounded <?= strpos($mensaje,'??')!==false?'bg-green-100 text-green-800':'bg-red-100 text-red-800' ?>">
            <?= htmlspecialchars($mensaje) ?>
        </div>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data" class="space-y-4">
        <div>
            <label class="block text-sm font-medium text-gray-700">Nombre</label>
            <input type="text" name="nombre" value="<?= htmlspecialchars($usuario['nombre']) ?>" required
                   class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Email</label>
            <input type="email" name="email" value="<?= htmlspecialchars($usuario['email']) ?>" required
                   class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Rol</label>
            <select name="rol" class="mt-1 w-full border rounded-lg p-2">
                <option value="cliente" <?= $usuario['rol']==='cliente'?'selected':'' ?>>Cliente</option>
              <option value="organizador" <?= $usuario['rol']==='organizador'?'selected':'' ?>>Organizador</option>
                      <option value="fotografo" <?= $usuario['rol']==='fotografo'?'selected':'' ?>>Fotografo</option>
                        <option value="comercial" <?= $usuario['rol']==='comercial'?'selected':'' ?>>Comercial</option>
            </select>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Foto de perfil</label>
            <?php if(!empty($usuario['foto_perfil']) && file_exists('uploads/'.$usuario['foto_perfil'])): ?>
                <img src="uploads/<?= htmlspecialchars($usuario['foto_perfil']) ?>" alt="Foto de perfil"
                     class="w-24 h-24 object-cover rounded-full mb-2">
            <?php endif; ?>
            <input type="file" name="foto_perfil" accept="image/*"
                   class="mt-1 w-full border rounded-lg p-2">
        </div>

        <div class="flex justify-between mt-4">
            <a href="usuarios.php" class="bg-gray-400 text-white px-3 py-1 rounded hover:bg-gray-500">Cancelar</a>
            <button type="submit" class="bg-indigo-600 text-white px-3 py-1 rounded hover:bg-indigo-700">Guardar</button>
        </div>
    </form>
</div>

</body>
</html>
