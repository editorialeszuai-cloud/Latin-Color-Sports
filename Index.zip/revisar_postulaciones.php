<?php
require 'dbfotografos.php';

// Habilitar errores para ver si algo más falla
ini_set('display_errors', 1);
error_reporting(E_ALL);

try {
    // Consulta con JOINs para traer nombres de otras tablas
    $sql = "SELECT 
                p.id, 
                u.nombre AS nombre_fotografo, 
                e.titulo AS evento_nombre, 
                p.creado_en AS fecha_registro,
                (SELECT COUNT(*) FROM fotos WHERE postulacion_id = p.id) as total_fotos,
                (SELECT COUNT(*) FROM fotos f JOIN faces fa ON f.id = fa.foto_id WHERE f.postulacion_id = p.id) as fotos_analizadas
            FROM postulaciones p
            INNER JOIN usuarios u ON p.usuario_id = u.id
            INNER JOIN eventos e ON p.evento_id = e.id
            ORDER BY p.id DESC";

    $stmt = $pdo->query($sql);
    $postulaciones = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Postulaciones | Latin Color Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-[#020617] text-slate-200 p-8">
    
    <div class="max-w-7xl mx-auto px-4 mt-12 mb-8">
    <div class="flex justify-center">
        <a href="soporte.php" class="flex items-center gap-2 text-gray-500 hover:text-orange-600 font-bold uppercase tracking-widest text-xs transition-all">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Volver a Soporte
        </a>
    </div>
</div>

    <div class="max-w-6xl mx-auto">
        <header class="mb-10">
            <h1 class="text-3xl font-black italic uppercase tracking-tighter text-white">
                Gestión de <span class="text-orange-500">Postulaciones</span>
            </h1>
            <p class="text-slate-500 text-sm">Selecciona una postulación para iniciar el análisis de rostros por IA.</p>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($postulaciones as $p): 
                $porcentaje = ($p['total_fotos'] > 0) ? round(($p['fotos_analizadas'] / $p['total_fotos']) * 100) : 0;
            ?>
                <div class="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-orange-500/50 transition-all group shadow-xl">
                    <div class="flex justify-between items-start mb-4">
                        <div class="bg-orange-500/10 text-orange-500 p-3 rounded-2xl">
                            <i class="fas fa-camera-retro text-xl"></i>
                        </div>
                        <span class="text-[10px] font-bold bg-slate-800 px-3 py-1 rounded-full text-slate-400 uppercase">
                            ID: #<?= $p['id'] ?>
                        </span>
                    </div>

                    <h3 class="text-white font-bold text-lg mb-1 leading-tight"><?= htmlspecialchars($p['nombre_fotografo']) ?></h3>
                    <p class="text-slate-500 text-xs mb-4 flex items-center gap-1">
                        <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($p['evento_nombre']) ?>
                    </p>

                    <div class="bg-slate-950/50 rounded-2xl p-4 mb-6 border border-white/5">
                        <div class="flex justify-between items-end mb-2">
                            <span class="text-[10px] font-bold text-slate-500 uppercase">Progreso IA</span>
                            <span class="text-xs font-black text-orange-500"><?= $porcentaje ?>%</span>
                        </div>
                        <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                            <div class="h-full bg-orange-500 transition-all duration-500" style="width: <?= $porcentaje ?>%"></div>
                        </div>
                        <div class="flex justify-between mt-3 text-[10px] font-bold">
                            <span class="text-slate-400"><?= $p['total_fotos'] ?> FOTOS</span>
                            <span class="text-slate-500"><?= $p['fotos_analizadas'] ?> ANALIZADAS</span>
                        </div>
                    </div>

                    <a href="revisar_analisis.php?postulacion_id=<?= $p['id'] ?>" 
                       class="block w-full text-center bg-white text-black hover:bg-orange-500 hover:text-white py-3 rounded-xl font-bold text-xs uppercase transition-all transform group-hover:scale-[1.02]">
                        <i class="fas fa-microscope mr-2"></i> Abrir Analizador
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</body>

<script>
    // Verificar si alguna postulación tiene fotos pero 0 analizadas
    const fotosPendientes = <?= json_encode(array_filter($postulaciones, fn($p) => $p['total_fotos'] > 0 && $p['fotos_analizadas'] == 0)) ?>;
    
    if (fotosPendientes.length > 0) {
        document.title = `(${fotosPendientes.length}) Nuevas Postulaciones | Latin Color`;
        console.log("¡Tienes postulaciones esperando análisis!");
    }
</script>
</html>