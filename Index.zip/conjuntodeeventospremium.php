<?php
require_once 'usuariopremium.php';
require_once 'dbfotografos.php';
header('Content-Type: text/html; charset=utf-8');

// ... (Mismo código PHP de consulta que ya tienes) ...
$search = $_GET['search'] ?? '';
$tipo = $_GET['tipo_evento'] ?? '';

$sql = "
    SELECT 
        e.*, 
        l.ciudad, 
        l.pais,
        COUNT(f.id) AS total_fotos,
        GROUP_CONCAT(DISTINCT u.nombre SEPARATOR ', ') AS fotografos
    FROM eventos e
    LEFT JOIN lugares l ON e.lugar_id = l.id
    LEFT JOIN postulaciones p ON p.evento_id = e.id
    LEFT JOIN fotos f ON f.postulacion_id = p.id
    LEFT JOIN usuarios u ON p.usuario_id = u.id
    WHERE 1=1
";

$params = [];
if (!empty($search)) { $sql .= " AND e.titulo LIKE ? "; $params[] = "%$search%"; }
if (!empty($tipo)) { $sql .= " AND e.tipo_evento = ? "; $params[] = $tipo; }

$sql .= " GROUP BY e.id ORDER BY e.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$tiposStmt = $pdo->query("SELECT DISTINCT tipo_evento FROM eventos WHERE tipo_evento IS NOT NULL AND tipo_evento <> '' ORDER BY tipo_evento ASC");
$tipos = $tiposStmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos | Latin Color Sports</title>
		<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f3f4f6; }
        .line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    </style>
</head>
<body class="pb-10">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        <h1 class="text-2xl md:text-4xl font-black mb-8 text-center text-gray-900 uppercase tracking-tighter">
            Eventos <span class="text-orange-600">Disponibles</span>
        </h1>

        <form method="GET" class="mb-10 bg-white p-4 rounded-2xl shadow-sm border border-gray-100 max-w-4xl mx-auto">
            <div class="flex flex-col md:flex-row gap-3">
                <div class="relative flex-1">
                    <input 
                        type="text" 
                        name="search" 
                        value="<?= htmlspecialchars($search) ?>" 
                        placeholder="Nombre del evento..." 
                        class="w-full pl-4 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-sm"
                    >
                </div>

                <select 
                    name="tipo_evento" 
                    class="w-full md:w-48 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-sm appearance-none"
                >
                    <option value="">Todos los tipos</option>
                    <?php foreach ($tipos as $t): ?>
                        <option value="<?= htmlspecialchars($t) ?>" <?= ($t === $tipo) ? 'selected' : '' ?>>
                            <?= htmlspecialchars(ucfirst($t)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="w-full md:w-auto bg-orange-600 hover:bg-orange-700 text-white font-bold px-8 py-3 rounded-xl transition-all shadow-lg shadow-orange-200 text-sm">
                    BUSCAR
                </button>
            </div>

            <?php if ($search || $tipo): ?>
                <div class="text-center mt-3">
                    <a href="conjuntodeventos.php" class="text-xs text-gray-400 hover:text-orange-600 font-bold uppercase tracking-widest">Limpiar filtros</a>
                </div>
            <?php endif; ?>
        </form>

        <?php if(empty($eventos)): ?>
            <div class="bg-white rounded-3xl p-12 text-center shadow-sm border border-gray-100">
                <p class="text-gray-400 font-bold italic">No se encontraron eventos que coincidan con tu búsqueda.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">

                <?php foreach ($eventos as $e): 
                    $banner = $e['banner'] ?? '';
                    $icono = $e['icono_foto'] ?? '';
                ?>

                <div class="group bg-white rounded-2xl shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 overflow-hidden flex flex-col">
                    
                    <div class="relative h-52 overflow-hidden">
                        <?php if($banner): ?>
                            <img src="<?= htmlspecialchars($banner) ?>" alt="<?= htmlspecialchars($e['titulo']) ?>" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                        <?php else: ?>
                            <div class="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400 text-xs uppercase font-bold tracking-widest">Sin Imagen</div>
                        <?php endif; ?>
                        
                        <?php if(!empty($e['tipo_evento'])): ?>
                            <div class="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-lg uppercase tracking-wider">
                                <?= htmlspecialchars($e['tipo_evento']) ?>
                            </div>
                        <?php endif; ?>

                        <?php if($icono): ?>
                            <img src="<?= htmlspecialchars($icono) ?>" class="absolute -bottom-4 right-4 w-12 h-12 rounded-2xl border-4 border-white shadow-lg z-10 bg-white">
                        <?php endif; ?>
                    </div>

                    <div class="p-6 flex-1 flex flex-col">
                        <div class="mb-4">
                            <h2 class="text-xl font-extrabold text-gray-900 group-hover:text-orange-600 transition-colors leading-tight mb-2 uppercase italic">
                                <?= htmlspecialchars($e['titulo']) ?>
                            </h2>
                            
                            <div class="flex items-center gap-4 text-gray-400 text-[11px] font-bold uppercase tracking-widest">
                                <span class="flex items-center gap-1">
                                    <svg class="w-3 h-3 text-orange-500" fill="currentColor" viewBox="0 0 20 20"><path d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z"/></svg>
                                    <?= date('d M, Y', strtotime($e['fecha'])) ?>
                                </span>
                                <span class="flex items-center gap-1">
                                    <svg class="w-3 h-3 text-orange-500" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/></svg>
                                    <?= htmlspecialchars($e['ciudad']) ?>
                                </span>
                            </div>
                        </div>

                        <p class="text-gray-500 text-sm mb-6 line-clamp-2 leading-relaxed font-medium">
                            <?= htmlspecialchars($e['descripcion'] ?? 'Sin descripción disponible.') ?>
                        </p>

                        <div class="mt-auto pt-4 border-t border-gray-50 flex items-center justify-between">
                            <div class="text-[10px] text-gray-400 uppercase font-black tracking-tighter">
                                <span class="text-orange-600 block text-lg leading-none"><?= (int)$e['total_fotos'] ?></span>
                                FOTOS
                            </div>
                            
                            <a href="galeria.php?evento_id=<?= (int)$e['id'] ?>" class="bg-gray-900 hover:bg-orange-600 text-white text-[10px] font-black px-5 py-3 rounded-xl transition-all uppercase tracking-widest shadow-lg active:scale-95">
                                Ver Galería
                            </a>
                        </div>
                    </div>
                </div>

                <?php endforeach; ?>

            </div>
        <?php endif; ?>
    </div>

</body>
</html>