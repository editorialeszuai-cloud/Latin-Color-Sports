<?php
define('ACCESO_PERMITIDO', true);
require_once 'dbfotografos.php';

// Consulta para fotos ocultas
$stmt = $pdo->prepare("SELECT f.id, f.url FROM fotos f INNER JOIN fotos_moderacion fm ON f.id = fm.foto_id WHERE fm.accion = 'ocultada' ORDER BY f.id DESC");
$stmt->execute();
$fotos_ocultas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Control | Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
			<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        body { background: #0a0a0a; color: #e2e8f0; font-family: 'Inter', sans-serif; }
        .card-dark { background: #111; border: 1px solid #222; border-radius: 1rem; }
        .foto-container { background: #000; border-radius: 0.75rem; overflow: hidden; aspect-ratio: 3/4; position: relative; }
        .lazy-img { width: 100%; height: 100%; object-fit: cover; opacity: 0; transition: opacity 0.6s ease-in; }
        .lazy-img.loaded { opacity: 0.6; }
        #mainContent { display: none; }
    </style>
</head>
<body class="p-4 md:p-8">

<div id="mainContent" class="max-w-7xl mx-auto">
    <header class="card-dark p-6 mb-8 border-l-4 border-orange-500 flex items-center justify-between">
    <div class="flex flex-col gap-1">
        <h1 class="text-2xl font-black uppercase text-orange-500 leading-none">Dashboard</h1>
        <div id="userInfo" class="text-xs text-gray-400 font-mono">Verificando sesión...</div>
    </div>

    <button onclick="history.back()" class="inline-flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-black border border-orange-500 rounded-xl transition-all hover:bg-orange-600 hover:text-white active:scale-95 shadow-lg shadow-orange-500/10">
        <span class="material-icons text-base">arrow_back</span>
        <span>Atrás</span>
    </button>
</header>

    <div class="card-dark p-6 mb-8">
        <h2 class="text-lg font-bold text-white mb-4">🔍 Buscador Biométrico IA</h2>
        <form id="buscadorForm" class="flex gap-4">
            <input type="file" name="foto" id="fileInput" class="hidden" accept="image/*">
            <button type="button" onclick="document.getElementById('fileInput').click()" class="bg-gray-800 px-6 py-3 rounded-lg border border-gray-700">Seleccionar</button>
            <button type="submit" class="bg-orange-600 px-8 py-3 rounded-lg font-bold hover:bg-orange-500 transition">Analizar</button>
        </form>
        <div id="loading" class="mt-4 text-orange-500 font-bold hidden italic">Procesando... Espero un momento</div>
		 
    </div>

    <h3 id="tituloGaleria" class="text-xl font-bold mb-6 text-white">Fotos Ocultas</h3>
    <div id="galeriaPrincipal" class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-4">
        <?php foreach ($fotos_ocultas as $foto): ?>
            <div id="card-oculta-<?= $foto['id'] ?>" class="card-dark overflow-hidden group relative">
                <div class="foto-container group">
    <img src="minion.php?id=<?= $foto['id'] ?>&tipo=mini" 
         class="lazy-img" 
         onload="this.classList.add('loaded')" 
         loading="lazy">
    
    <span class="absolute top-2 left-2 bg-black/60 backdrop-blur-md text-white text-[10px] px-2 py-1 rounded-md font-bold border border-white/10 z-10">
        ID: <?= $foto['id'] ?>
    </span>
</div>
                <div class="absolute inset-0 flex flex-col items-center justify-center bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onclick="restaurarFoto(<?= $foto['id'] ?>)" class="bg-orange-600 p-4 rounded-full text-white"><span class="material-icons">settings_backup_restore</span></button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

onAuthStateChanged(auth, async (user) => {
    if (!user) { window.location.href = 'login_app.html'; return; }
    const res = await fetch('get_user_info.php', { method: 'POST', body: JSON.stringify({ firebase_token: await user.getIdToken() }) });
    const data = await res.json();
    if (data.status === 'success') {
        document.getElementById('userInfo').textContent = `Usuario: ${data.user.nombre} | Rol: ${data.user.rol}`;
        document.getElementById('mainContent').style.display = 'block';
    } else { window.location.href = 'login_app.html'; }
});
</script>

<script>
// Lógica de IA - Muestra resultados en el mismo grid principal
document.getElementById('buscadorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const galeria = document.getElementById('galeriaPrincipal');
    document.getElementById('tituloGaleria').innerText = "Resultados de Búsqueda";
    galeria.innerHTML = "Cargando resultados...";
    
    const data = await (await fetch('https://api.latincolorsports.com/buscars', { method: 'POST', body: new FormData(e.target) })).json();
    galeria.innerHTML = "";
    
    data.matches.forEach(f => {
        galeria.innerHTML += `
            <div class="card-dark p-2 animate-in fade-in">
                <div class="foto-container"><img src="minion.php?id=${f.id}&tipo=mini" class="lazy-img" onload="this.classList.add('loaded')" loading="lazy"></div>
                <p class="text-center text-xs mt-2 text-orange-500 font-bold">ID: ${f.id} (${f.similitud}%)</p>
            </div>`;
    });
});

async function restaurarFoto(id) {
    if(!confirm('¿Restaurar foto?')) return;
    const res = await fetch('gestionar_fotos_ia.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ action: 'restaurar', foto_id: id }) });
    if((await res.json()).success) document.getElementById(`card-oculta-${id}`).remove();
}
</script>
</body>
</html>