<?php
require_once 'navusuario.php';
require_once 'dbfotografos.php';
$pdo = conectar();

$evento_id = isset($_GET['evento_id']) ? (int)$_GET['evento_id'] : 0;

if ($evento_id > 0) {
    try {
        // Obtenemos todas las fotos del pack del evento
        $sql = "SELECT f.id as foto_id, f.url as nombre_archivo, e.titulo as evento_nombre 
                FROM fotos f
                INNER JOIN postulaciones p ON f.postulacion_id = p.id
                INNER JOIN eventos e ON p.evento_id = e.id
                WHERE e.id = ? ORDER BY f.id DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$evento_id]);
        $todasLasFotos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die("Error en la base de datos: " . $e->getMessage());
    }
} else {
    die("Evento no válido.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Fotos - Latin Color Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <style>
        body { background:#0a0a0a; color:#eee; font-family:'Inter',sans-serif; }
        .card-foto { background:#111; border:1px solid #222; border-radius:16px; overflow:hidden; transition: 0.3s; position: relative; }
        .card-foto:hover { border-color: #f59e0b; transform: translateY(-4px); }
        
        #galeria {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            gap: 12px;
        }

        @keyframes pulse-orange { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
        .analyzing { animation: pulse-orange 1.5s infinite; }

        .check-foto {
            position: absolute; top: 10px; left: 10px; z-index: 30;
            width: 22px; height: 22px; accent-color: #ea580c; cursor: pointer;
            border: 2px solid white; border-radius: 4px;
        }
    </style>
</head>
<body class="p-4 lg:p-8">

<nav class="flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
    <div class="flex flex-col">
        <span class="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">Mi Galería Personal de Evento</span>
    </div>
    
    <div class="flex items-center gap-4">
        <button id="btnSelectAll" class="hidden flex items-center gap-2 bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-xl text-xs font-black uppercase transition-all border border-white/10">
            <span class="material-icons text-sm">done_all</span> <span id="txtSelectAll">Seleccionar Todo</span>
        </button>
        <button onclick="location.reload()" class="flex items-center gap-2 text-gray-500 hover:text-white px-2 py-2 text-xs font-black uppercase transition-all">
            <span class="material-icons text-sm">restart_alt</span> Resetear
        </button>
    </div>
</nav>

<div class="max-w-2xl mx-auto mb-12">
    <div class="bg-[#111] border border-[#222] p-2 rounded-2xl shadow-2xl flex items-center gap-3">
        <label for="faceInput" class="flex items-center gap-4 cursor-pointer p-2 flex-1">
            <div id="previewContainer" class="w-14 h-14 rounded-2xl border-2 border-dashed border-gray-700 overflow-hidden bg-black flex items-center justify-center shrink-0">
                <img id="facePreview" class="w-full h-full object-cover hidden">
                <span id="faceIcon" class="material-icons text-gray-600 text-3xl">account_circle</span>
            </div>
            <div class="flex flex-col">
                <span class="text-[10px] font-black text-orange-500 uppercase tracking-[0.2em]">Buscador Inteligente</span>
                <span id="fileName" class="text-sm font-bold text-gray-400">Sube una selfie para encontrarte</span>
                <input type="file" id="faceInput" accept="image/*" class="hidden">
            </div>
        </label>
        <button id="btnSearch" class="bg-orange-600 hover:bg-orange-500 text-white font-black px-8 py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-orange-900/20">
            Analizar Rostro
        </button>
    </div>
    <div id="statusArea" class="text-center text-[10px] font-black text-gray-600 mt-4 uppercase tracking-[0.3em]">Cargando motores de IA...</div>
</div>

<div id="galeria"></div>

<div id="loading-trigger" class="w-full flex justify-center py-20">
    <div class="flex flex-col items-center gap-3">
        <div class="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-orange-600"></div>
        <span class="text-[9px] font-bold text-gray-600 uppercase tracking-widest">Cargando fotos</span>
    </div>
</div>

<div id="bulk-download-bar" class="fixed bottom-8 right-8 z-50 hidden">
    <button id="btn-bulk" onclick="descargarSeleccion()" class="group bg-orange-600 hover:bg-orange-500 text-white w-20 h-20 rounded-full shadow-[0_0_40px_rgba(234,88,12,0.4)] flex items-center justify-center transition-all transform hover:scale-110 active:scale-90">
        <span class="material-icons text-3xl">file_download</span>
        <span id="selected-count" class="absolute -top-1 -right-1 bg-white text-orange-600 font-black text-sm w-8 h-8 flex items-center justify-center rounded-full border-4 border-orange-600 shadow-xl">0</span>
    </button>
</div>

<script>
    // Inyectamos las fotos desde PHP
    const TODAS_LAS_FOTOS = <?php echo json_encode($todasLasFotos); ?>;
    let fotosAMostrar = [...TODAS_LAS_FOTOS]; 
    let paginaActual = 0;
    const fotosPorPagina = 24;
    
    const galeria = document.getElementById('galeria');
    const loader = document.getElementById('loading-trigger');
    const statusIA = document.getElementById('statusArea');
    const btnSelectAll = document.getElementById('btnSelectAll');

    // 1. CARGAR MODELOS DE FACE-API
    async function loadIAModels() {
        try {
            const MODEL_PATH = '../face-demo/models/'; // Asegúrate que esta ruta sea correcta
            await Promise.all([
                faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_PATH),
                faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_PATH),
                faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_PATH)
            ]);
            statusIA.innerText = "IA LISTA - PUEDES BUSCAR TU ROSTRO";
        } catch (e) { 
            console.error(e);
            statusIA.innerText = "ERROR AL CARGAR IA"; 
        }
    }

    // 2. RENDERIZADO CON INFINITE SCROLL
    function cargarMasFotos() {
        const inicio = paginaActual * fotosPorPagina;
        const fin = inicio + fotosPorPagina;
        const bloque = fotosAMostrar.slice(inicio, fin);

        if (bloque.length === 0) {
            loader.style.display = 'none';
            return;
        }

        if (fotosAMostrar.length > 0) btnSelectAll.classList.remove('hidden');

       bloque.forEach(f => {
    // Usamos f.nombre_archivo directamente, ya que contiene la URL completa
    const ruta_directa = f.nombre_archivo; 

    const html = `
        <div class="card-foto animate-in fade-in slide-in-from-bottom-4 duration-500">
            <input type="checkbox" class="check-foto js-check" data-url="${ruta_directa}" onchange="actualizarContador()">
            <div class="aspect-square w-full h-52 overflow-hidden bg-black relative">
                <img src="${ruta_directa}" 
                     class="w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity" 
                     loading="lazy"
                     onerror="this.style.display='none'">
            </div>
            <div class="p-3 bg-[#111] flex justify-between items-center">
                <span class="text-[9px] font-bold text-gray-600 uppercase">#${f.foto_id}</span>
                <a href="${ruta_directa}" download class="text-orange-500 hover:text-white transition-colors">
                    <span class="material-icons text-xl">download</span>
                </a>
            </div>
        </div>`;
    galeria.insertAdjacentHTML('beforeend', html);
});
        paginaActual++;
    }

    // 3. OBSERVER PARA EL SCROLL
    const observer = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            setTimeout(cargarMasFotos, 200);
        }
    }, { threshold: 0.1 });
    observer.observe(loader);

    // 4. LÓGICA DE BÚSQUEDA POR ROSTRO
    document.getElementById('btnSearch').onclick = async () => {
        const input = document.getElementById('faceInput');
        if (!input.files[0]) { alert("Selecciona una foto primero"); return; }

        statusIA.innerText = "ANALIZANDO TU ROSTRO...";
        statusIA.classList.add('analyzing');

        try {
            const img = await faceapi.bufferToImage(input.files[0]);
            const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();

            if (!detection) {
                statusIA.innerText = "NO DETECTAMOS UN ROSTRO - PRUEBA OTRA FOTO";
                statusIA.classList.remove('analyzing');
                return;
            }

            const fd = new FormData();
            fd.append('evento_id', "<?= $evento_id ?>");
            fd.append('descriptor', JSON.stringify(Array.from(detection.descriptor)));

            const res = await fetch('buscar_rostro.php', { method: 'POST', body: fd });
            const data = await res.json();

            if (data.success) {
                const idsEncontrados = data.fotos.map(f => parseInt(f.id));
                fotosAMostrar = TODAS_LAS_FOTOS.filter(f => idsEncontrados.includes(parseInt(f.foto_id)));
                
                // Reiniciar vista
                galeria.innerHTML = "";
                paginaActual = 0;
                loader.style.display = 'flex';
                cargarMasFotos();
                
                statusIA.innerText = `RESULTADO: ${data.total} FOTOS ENCONTRADAS`;
                document.getElementById('txtSelectAll').innerText = "Seleccionar Todo";
            }
        } catch (e) {
            console.error(e);
            statusIA.innerText = "ERROR EN EL SERVIDOR";
        }
        statusIA.classList.remove('analyzing');
    };

    // 5. SELECCIONAR TODO (Respetando búsqueda)
    btnSelectAll.onclick = function() {
        const checks = document.querySelectorAll('.js-check');
        const todosMarcados = Array.from(checks).every(c => c.checked);
        
        checks.forEach(c => c.checked = !todosMarcados);
        
        this.querySelector('span:last-child').innerText = !todosMarcados ? "Deseleccionar" : "Seleccionar Todo";
        this.querySelector('.material-icons').innerText = !todosMarcados ? "close" : "done_all";
        
        actualizarContador();
    };

    // 6. UI HELPERS
    document.getElementById('faceInput').onchange = (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (ev) => {
                document.getElementById('facePreview').src = ev.target.result;
                document.getElementById('facePreview').classList.remove('hidden');
                document.getElementById('faceIcon').classList.add('hidden');
                document.getElementById('fileName').innerText = "Foto lista para analizar";
            };
            reader.readAsDataURL(file);
        }
    };

    function actualizarContador() {
        const seleccionados = document.querySelectorAll('.js-check:checked');
        document.getElementById('selected-count').innerText = seleccionados.length;
        document.getElementById('bulk-download-bar').classList.toggle('hidden', seleccionados.length === 0);
    }

    // 7. DESCARGA SECUENCIAL (Para no bloquear el navegador)
    async function descargarSeleccion() {
        const seleccionados = document.querySelectorAll('.js-check:checked');
        const btn = document.getElementById('btn-bulk');
        
        if(!confirm(`¿Deseas descargar ${seleccionados.length} fotos?`)) return;

        btn.disabled = true;
        btn.classList.add('opacity-50', 'animate-pulse');
        
        for (let i = 0; i < seleccionados.length; i++) {
            const url = seleccionados[i].getAttribute('data-url');
            const link = document.createElement('a');
            link.href = url;
            link.download = `Foto_LatinColor_${i+1}.jpg`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Pausa de 400ms entre descargas para estabilidad
            await new Promise(r => setTimeout(r, 400));
        }
        
        btn.disabled = false;
        btn.classList.remove('opacity-50', 'animate-pulse');
    }

    // Iniciar carga de modelos al cargar la página
    window.onload = loadIAModels;
</script>

</body>
</html>