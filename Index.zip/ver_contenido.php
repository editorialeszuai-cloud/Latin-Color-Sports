<?php
require 'dbfotografos.php';

// =======================
// Obtener eventos, fotógrafos, asignaciones, galerías y fotos
// =======================
$eventos = $pdo->query("SELECT * FROM eventos ORDER BY fecha ASC")->fetchAll();
$fotografos = $pdo->query("SELECT * FROM usuarios WHERE rol='fotografo' ORDER BY nombre ASC")->fetchAll();

$asignaciones = $pdo->query("SELECT * FROM asignar_eventos")->fetchAll();
$asign_map = [];
foreach($asignaciones as $a){
    $asign_map[$a['evento_id']][] = $a['fotografo_id'];
}

$galerias = $pdo->query("SELECT * FROM galerias ORDER BY fecha_creacion DESC")->fetchAll();
$galerias_map = [];
foreach($galerias as $g){
    $galerias_map[$g['evento_id']][$g['fotografo_id']][] = $g;
}

$fotos = $pdo->query("SELECT * FROM fotos")->fetchAll();
$fotos_map = [];
foreach($fotos as $f){
    $fotos_map[$f['galeria_id']][] = $f;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Visualización de Eventos y Fotógrafos</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="p-6 bg-gray-100">

<h1 class="text-3xl font-bold mb-6">Visualización de Eventos y Fotógrafos</h1>

<?php foreach($eventos as $evento): ?>
<div class="bg-white p-6 mb-6 rounded shadow">
    <h2 class="text-2xl font-semibold"><?= htmlspecialchars($evento['titulo']) ?> (<?= htmlspecialchars($evento['fecha']) ?>)</h2>

    <?php if(isset($asign_map[$evento['id']])): ?>
        <?php foreach($asign_map[$evento['id']] as $fid): 
            $filtro = array_filter($fotografos, fn($u)=>$u['id']==$fid);
            $fotografo = array_values($filtro)[0];

            $galerias_fotografo = $galerias_map[$evento['id']][$fotografo['id']] ?? [];
        ?>
        <div class="border p-4 mt-4 rounded bg-gray-50">
            <h3 class="font-semibold text-lg"><?= htmlspecialchars($fotografo['nombre']) ?></h3>

            <?php if($galerias_fotografo): ?>
                <?php foreach($galerias_fotografo as $g): ?>
                    <div class="mt-2">
                        <p class="font-medium"><?= htmlspecialchars($g['titulo']) ?></p>
                        <?php if(isset($fotos_map[$g['id']])): ?>
                            <div class="grid grid-cols-3 gap-2 mt-1">
                                <?php foreach($fotos_map[$g['id']] as $f): ?>
                                    <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>" 
                                         alt="<?= htmlspecialchars($f['descripcion']) ?>"
                                         class="w-full h-32 object-cover cursor-pointer rounded"
                                         onclick="openModal('uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>', '<?= htmlspecialchars(addslashes($f['descripcion'])) ?>')">
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-gray-500 text-sm mt-1">No hay fotos en esta galería.</p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-gray-500 text-sm mt-1">Este fotógrafo aún no ha creado galerías.</p>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p class="text-gray-500 mt-2">No hay fotógrafos asignados a este evento.</p>
    <?php endif; ?>
</div>
<?php endforeach; ?>

<!-- Modal -->
<div id="photoModal" class="fixed inset-0 bg-black bg-opacity-70 hidden items-center justify-center z-50">
    <div class="relative bg-white rounded shadow-lg max-w-3xl w-full p-4">
        <button class="absolute top-2 right-2 text-gray-700 text-xl font-bold" onclick="closeModal()">×</button>
        <img id="modalImage" src="" class="w-full h-auto rounded">
        <p id="modalDesc" class="mt-2 text-gray-700"></p>
    </div>
</div>

<script>
function openModal(src, desc){
    document.getElementById('modalImage').src = src;
    document.getElementById('modalDesc').innerText = desc;
    document.getElementById('photoModal').classList.remove('hidden');
    document.getElementById('photoModal').classList.add('flex');
}

function closeModal(){
    document.getElementById('photoModal').classList.add('hidden');
    document.getElementById('photoModal').classList.remove('flex');
}
</script>

</body>
</html>

