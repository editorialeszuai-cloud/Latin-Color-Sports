<?php
$urlOriginal = $_GET['img'] ?? '';
$width = isset($_GET['w']) ? intval($_GET['w']) : 600;

if (empty($urlOriginal)) { http_response_code(400); exit; }

$nombreHash = md5($urlOriginal) . '.avif';
$directorio = __DIR__ . '/miniatura/';
$rutaFinal = $directorio . $nombreHash;

if (file_exists($rutaFinal)) {
    header("Content-Type: image/avif");
    readfile($rutaFinal);
    exit;
}

// Descarga con cURL y User-Agent para evitar el 403 de CloudFront
$tempFile = tempnam(sys_get_temp_dir(), 'img_');
$ch = curl_init($urlOriginal);
$fp = fopen($tempFile, 'wb');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Timeout más rápido
curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
fclose($fp);

if ($httpCode === 200 && filesize($tempFile) > 0) {
    $img = @imagecreatefromstring(file_get_contents($tempFile));
    @unlink($tempFile);

    if ($img) {
        $imgMiniatura = imagescale($img, $width);
        if (!is_dir($directorio)) mkdir($directorio, 0755, true);
        imageavif($imgMiniatura, $rutaFinal, 85);
        header("Content-Type: image/avif");
        readfile($rutaFinal);
        imagedestroy($img);
        imagedestroy($imgMiniatura);
        exit;
    }
}

// Si llega aquí, algo falló. Damos 404 para que el navegador deje de pedirlo.
@unlink($tempFile);
http_response_code(404);
exit;
?>