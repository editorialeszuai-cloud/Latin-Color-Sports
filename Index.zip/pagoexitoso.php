<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>¡Pago Exitoso! | Latin Color Sports</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@400;500;700;900&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<style>
    :root {
        --orange1: #f8a700;
        --orange2: #f56c1e;
        --red: #e4312a;
        --bg: #060608;
        --surface: #101013;
        --stub: #0a0a0c;
        --text: #fafafa;
        --muted: rgba(255,255,255,.4);
        --line: rgba(255,255,255,.14);
        --green: #4ade80;
    }

    * { box-sizing: border-box; }

    body {
        font-family: 'DM Sans', sans-serif;
        background:
            radial-gradient(ellipse 60% 40% at 50% 0%, rgba(245,108,30,.14), transparent 60%),
            var(--bg);
        color: var(--text);
        margin: 0;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 32px 20px;
    }

    /* ---------- TICKET ---------- */

    .ticket {
        position: relative;
        width: 100%;
        max-width: 380px;
        opacity: 0;
        transform: translateY(18px) scale(.97);
        animation: rise .7s cubic-bezier(.19,1,.22,1) .1s forwards;
    }

    @keyframes rise {
        to { opacity: 1; transform: translateY(0) scale(1); }
    }

    .ticket-body {
        background: var(--surface);
        border: 1px solid var(--line);
        border-radius: 20px 20px 0 0;
        padding: 38px 30px 28px;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .ticket-body::before {
        content: "";
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 4px;
        background: linear-gradient(90deg, var(--orange1), var(--orange2), var(--red));
    }

    .eyebrow {
        font-family: 'Space Mono', monospace;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: .28em;
        text-transform: uppercase;
        color: var(--orange2);
        margin: 0 0 22px;
    }

    .check-wrap {
        width: 64px;
        height: 64px;
        margin: 0 auto 20px;
        border-radius: 50%;
        background: rgba(74,222,128,.1);
        border: 1px solid rgba(74,222,128,.35);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .check-wrap svg {
        width: 30px;
        height: 30px;
    }

    .check-wrap circle {
        fill: none;
        stroke: rgba(74,222,128,.35);
        stroke-width: 2;
    }

    .check-wrap path {
        fill: none;
        stroke: var(--green);
        stroke-width: 3;
        stroke-linecap: round;
        stroke-linejoin: round;
        stroke-dasharray: 30;
        stroke-dashoffset: 30;
        animation: draw .5s ease .55s forwards;
    }

    @keyframes draw { to { stroke-dashoffset: 0; } }

    h1 {
        font-family: 'Bebas Neue';
        font-size: 2.1rem;
        letter-spacing: .03em;
        margin: 0 0 12px;
        color: #fff;
        line-height: 1;
    }

    h1 span { color: var(--orange2); }

    p.desc {
        color: var(--muted);
        font-size: .9rem;
        line-height: 1.65;
        margin: 0;
        max-width: 300px;
        margin-inline: auto;
    }

    /* ---------- PERFORATED DIVIDER WITH NOTCHES ---------- */

    .perforation {
        position: relative;
        height: 0;
        background: var(--surface);
    }

    .perforation::before,
    .perforation::after {
        content: "";
        position: absolute;
        top: -13px;
        width: 26px;
        height: 26px;
        border-radius: 50%;
        background: var(--bg);
        z-index: 2;
    }

    .perforation::before { left: -13px; }
    .perforation::after { right: -13px; }

    .dashes {
        border-top: 2px dashed var(--line);
        margin: 0 26px;
        position: relative;
        top: 0;
    }

    /* ---------- STUB ---------- */

    .stub {
        background: var(--stub);
        border: 1px solid var(--line);
        border-top: none;
        border-radius: 0 0 20px 20px;
        padding: 22px 30px 26px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
    }

    .stub-field {
        text-align: left;
    }

    .stub-field .label {
        font-family: 'Space Mono', monospace;
        font-size: 8px;
        letter-spacing: .18em;
        text-transform: uppercase;
        color: var(--muted);
        margin-bottom: 4px;
    }

    .stub-field .value {
        font-family: 'Space Mono', monospace;
        font-size: 12px;
        color: var(--text);
        font-weight: 700;
        letter-spacing: .04em;
    }

    .barcode {
        height: 34px;
        flex: 1;
        max-width: 110px;
        background: repeating-linear-gradient(
            90deg,
            #fff 0px, #fff 2px,
            transparent 2px, transparent 3px,
            #fff 3px, #fff 4px,
            transparent 4px, transparent 7px,
            #fff 7px, #fff 8px,
            transparent 8px, transparent 9px,
            #fff 9px, #fff 12px,
            transparent 12px, transparent 14px
        );
        opacity: .85;
        border-radius: 2px;
    }

    /* ---------- CTA ---------- */

    .btn {
        display: block;
        text-align: center;
        margin-top: 22px;
        background: linear-gradient(90deg, var(--orange1), var(--red));
        color: #fff;
        padding: 14px 25px;
        border-radius: 12px;
        text-decoration: none;
        font-weight: 900;
        text-transform: uppercase;
        font-size: .78rem;
        letter-spacing: .1em;
        transition: transform .2s, box-shadow .2s;
        box-shadow: 0 10px 24px rgba(245,108,30,.25);
    }

    .btn:hover { transform: translateY(-2px); box-shadow: 0 14px 30px rgba(245,108,30,.35); }

    .footnote {
        text-align: center;
        margin-top: 16px;
        font-size: 10px;
        letter-spacing: .12em;
        text-transform: uppercase;
        color: var(--muted);
        font-weight: 700;
    }

    .footnote span { color: var(--orange2); }

    @media (prefers-reduced-motion: reduce) {
        .ticket, .check-wrap path { animation: none !important; opacity: 1 !important; transform: none !important; stroke-dashoffset: 0 !important; }
    }
</style>
</head>
<body>

<div>
    <div class="ticket">
        <div class="ticket-body">
            <p class="eyebrow">Latin Color Sports</p>

            <div class="check-wrap">
                <svg viewBox="0 0 36 36">
                    <circle cx="18" cy="18" r="16"></circle>
                    <path d="M11 18.5 L15.5 23 L25 12.5"></path>
                </svg>
            </div>

            <h1>Pago<br><span>Confirmado</span></h1>
            <p class="desc">
                Gracias por tu compra. Estamos validando el pago y en unos minutos recibirás el acceso a tus fotos en el correo registrado.
            </p>
        </div>

        <div class="perforation"><div class="dashes"></div></div>

        <div class="stub">
            <div class="stub-field">
                <div class="label">Estado</div>
                <div class="value" style="color:var(--green)">Aprobado</div>
            </div>
            <div class="barcode"></div>
        </div>
    </div>

    <p class="footnote">Latin <span>Color</span> Sports</p>
</div>

</body>
</html>