<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once 'dbfotografos.php';
header('Content-Type: application/json');

try {
    $evento_id = isset($_GET['evento_id']) ? intval($_GET['evento_id']) : 0;
    $offset    = isset($_GET['offset'])    ? intval($_GET['offset'])    : 0;
    $limit     = 40;

    $stmt = $pdo->prepare("
        SELECT f.id, f.url, m.url_miniatura
        FROM fotos f
        INNER JOIN postulaciones p ON f.postulacion_id = p.id
        LEFT JOIN miniaturas m ON f.id = m.foto_id
        WHERE p.evento_id = :evento_id
        ORDER BY f.id DESC
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindValue(':evento_id', $evento_id, PDO::PARAM_INT);
    $stmt->bindValue(':limit',     $limit,     PDO::PARAM_INT);
    $stmt->bindValue(':offset',    $offset,    PDO::PARAM_INT);

    $stmt->execute();
    $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($fotos);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}