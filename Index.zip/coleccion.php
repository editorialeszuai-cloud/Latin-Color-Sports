<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'dbfotografos.php';
header('Content-Type: text/html; charset=utf-8');

// Obtener galerías y fotos
$galerias = $pdo->query("
  SELECT g.*, e.id AS evento_id, e.titulo AS evento_nombre, e.paquetes_eventos
  FROM galerias g
  LEFT JOIN eventos e ON g.evento_id = e.id
  ORDER BY g.fecha_creacion DESC
")->fetchAll(PDO::FETCH_ASSOC);

$fotos = $pdo->query("SELECT * FROM fotos")->fetchAll(PDO::FETCH_ASSOC);

// Mapear fotos por galería
$fotos_map = [];
foreach ($fotos as $f) $fotos_map[$f['galeria_id']][] = $f;

// Calcular precio dinámico según paquetes_fotos
foreach ($galerias as &$g) {
    $g['precio_mostrado'] = 15000;
    $g['detalle_paquete'] = "Sin paquete asignado";

    if (!empty($g['evento_id'])) {
        $stmt = $pdo->prepare("SELECT paquetes_eventos FROM eventos WHERE id = ? LIMIT 1");
        $stmt->execute([$g['evento_id']]);
        $evento = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($evento && !empty($evento['paquetes_eventos'])) {
            $ids_pf = json_decode($evento['paquetes_eventos'], true);
            if (!is_array($ids_pf)) $ids_pf = [$evento['paquetes_eventos']];

            $total_unidades = 0;
            $precio_unidad = null;
            $nombres_paquetes = [];

            foreach ($ids_pf as $id_pf) {
                $stmt2 = $pdo->prepare("SELECT nombre_paquete, precio_por_unidad, unidades_incluidas FROM paquetes_fotos WHERE id = ? LIMIT 1");
                $stmt2->execute([$id_pf]);
                $pf = $stmt2->fetch(PDO::FETCH_ASSOC);
                if ($pf) {
                    $total_unidades += (int)$pf['unidades_incluidas'];
                    $precio_unidad = $pf['precio_por_unidad'];
                    $nombres_paquetes[] = $pf['nombre_paquete'];
                }
            }

            if ($total_unidades > 5) {
                $g['precio_mostrado'] = $precio_unidad ?? 15000;
                $g['detalle_paquete'] = implode(', ', $nombres_paquetes) . " ({$total_unidades} fotos incluidas)";
            } else {
                $g['precio_mostrado'] = 15000;
                $g['detalle_paquete'] = "Foto individual (hasta 5 unidades)";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Galerías</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="p-6 bg-gray-100">

<!-- Carrito flotante -->
<div class="fixed top-4 right-6 bg-green-600 text-white px-3 py-1 rounded shadow">
  🛒 Carrito: <span id="cartCount">0</span>
</div>

<h1 class="text-3xl font-bold mb-6">Galerías Disponibles</h1>
<div class="grid grid-cols-3 gap-4">
<?php foreach($galerias as $g): ?>
  <div class="bg-white p-3 rounded shadow">
    <h2 class="font-semibold">
      <?= htmlspecialchars($g['titulo']) ?> 
      - <span class="text-green-600 font-bold">$<?= number_format($g['precio_mostrado'],0) ?></span>
      <div class="text-sm text-gray-500 italic"><?= htmlspecialchars($g['detalle_paquete']) ?></div>
    </h2>
    <div class="grid grid-cols-3 gap-1 mt-2">
      <?php foreach($fotos_map[$g['id']] ?? [] as $f): ?>
        <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>" class="w-full h-24 object-cover rounded">
      <?php endforeach; ?>
    </div>
    <button class="bg-amber-600 text-white px-2 py-1 mt-2 w-full rounded hover:bg-amber-700 add-cart-btn" data-gid="<?= $g['id'] ?>">🛒 Agregar al carrito</button>
  </div>
<?php endforeach; ?>
</div>

<!-- Contenedor para mensajes -->
<div id="msgBox" class="fixed bottom-4 right-4 bg-red-600 text-white px-4 py-2 rounded shadow hidden"></div>

<!-- Contenedor del carrito -->
<div id="carritoContainer" class="fixed top-16 right-6 w-80 bg-white rounded shadow p-3 z-50">
  <div id="carritoItems"></div>
  <br>
  <a id="btnPagar" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 opacity-50" href="#">💳 Comprar</a>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

let firebase_uid = '';

onAuthStateChanged(auth, async (user) => {
  if(user){
    const token = await user.getIdToken();
    const res = await fetch('get_user_info.php',{
      method:'POST', 
      headers:{'Content-Type':'application/json'}, 
      body: JSON.stringify({firebase_token: token})
    });
    const data = await res.json();
    if(data.status==='success') { 
      firebase_uid = data.user.firebase_uid; 
      activarBotones(); 
      actualizarCarrito();
      cargarCarrito(); 
      
      // Activar botón de pago
      const btn = document.getElementById('btnPagar');
      btn.href = `checkout.php?firebase_uid=${firebase_uid}`;
      btn.classList.remove('opacity-50');
    }
  } else {
    document.getElementById('carritoItems').innerHTML = '<p class="text-red-600">Inicia sesión para ver tu carrito.</p>';
  }
});

function mostrarMensaje(msg, tipo='error'){
  const box = document.getElementById('msgBox');
  box.textContent = msg;
  box.className = `fixed bottom-4 right-4 px-4 py-2 rounded shadow text-white ${tipo==='ok'?'bg-green-600':'bg-red-600'}`;
  box.classList.remove('hidden');
  setTimeout(()=>box.classList.add('hidden'),3000);
}

function activarBotones(){
  document.querySelectorAll('.add-cart-btn').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      if(!firebase_uid){ mostrarMensaje('Debes iniciar sesión'); return; }

      btn.disabled = true; 
      btn.textContent = '⏳ Agregando...';

      const url = `agregar_carrito.php?firebase_uid=${encodeURIComponent(firebase_uid)}&galeria_id=${btn.dataset.gid}`;
      try{
        const res = await fetch(url); // GET para evitar 403
        const data = await res.json();
        if(data.status==='ok') mostrarMensaje('✅ Agregado al carrito','ok');
        else mostrarMensaje('❌ '+(data.msg||'No se pudo agregar'));
        actualizarCarrito();
        cargarCarrito();
      }catch{
        mostrarMensaje('⚠️ Error al agregar');
      }

      btn.disabled=false; 
      btn.textContent='🛒 Agregar al carrito';
    });
  });
}

// Contador de carrito
async function actualizarCarrito(){
  if(!firebase_uid) return;
  try{
    const res = await fetch(`contar_carrito.php?firebase_uid=${encodeURIComponent(firebase_uid)}`);
    const data = await res.json();
    document.getElementById('cartCount').innerText = data.count || 0;
  }catch{}
}

// Cargar carrito
async function cargarCarrito(){
    if(!firebase_uid) return;
    try{
        const res = await fetch(`ver_carrito.php?firebase_uid=${firebase_uid}`);
        const html = await res.text();
        document.getElementById('carritoItems').innerHTML = html;

        const count = document.querySelectorAll('#carritoItems .carrito-item').length;
        document.getElementById('cartCount').innerText = count;

        const carrito = document.getElementById('carritoContainer');
        carrito.style.display = count > 0 ? 'block' : 'none';

        const btnPagar = document.getElementById('btnPagar');
        btnPagar.href = `checkout.php?firebase_uid=${firebase_uid}`;
        btnPagar.classList.toggle('opacity-50', count === 0);

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = btn.dataset.id;
                if(!confirm('¿Deseas eliminar este item?')) return;
                try{
                    const res2 = await fetch(`eliminar_carrito.php?id=${id}`);
                    const data2 = await res2.json();
                    if(data2.status==='ok') cargarCarrito();
                    else alert('No se pudo eliminar');
                } catch { alert('Error al eliminar'); }
            });
        });

    } catch(e){ console.error(e); }
}

</script>
</body>
</html>
