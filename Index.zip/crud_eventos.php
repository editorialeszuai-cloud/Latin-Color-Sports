<?php
require_once "conexion.php";
$conn = conectar();

$accion = $_POST['accion'] ?? '';

if ($accion === 'crear') {
  $titulo = $_POST['titulo'] ?? '';
  $descripcion = $_POST['descripcion'] ?? '';
  $fecha = $_POST['fecha'] ?? '';
  $lugar = $_POST['lugar'] ?? '';

  if ($titulo && $fecha && $lugar) {
    $stmt = $conn->prepare("INSERT INTO eventos (titulo, descripcion, fecha, lugar) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $titulo, $descripcion, $fecha, $lugar);
    $stmt->execute();
  }
  header("Location: dashboard.html");
  exit;

} elseif ($accion === 'eliminar') {
  $id = intval($_POST['id'] ?? 0);
  if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM eventos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
  }
  header("Location: dashboard.php");
  exit;
}
?>
