<?php
require_once 'dbfotografos.php';

$evento_id = isset($_GET['evento_id']) ? intval($_GET['evento_id']) : 0;
$firebase_uid = isset($_GET['firebase_uid']) ? $_GET['firebase_uid'] : '';

if ($evento_id && $firebase_uid) {
    try {
        // Borramos el registro donde coincidan el UID y el evento_id
        $stmt = $pdo->prepare("DELETE FROM carrito WHERE firebase_uid = ? AND evento_id = ?");
        $stmt->execute([$firebase_uid, $evento_id]);
        
        echo "ok";
    } catch (PDOException $e) {
        echo "error";
    }
} else {
    echo "datos_invalidos";
}