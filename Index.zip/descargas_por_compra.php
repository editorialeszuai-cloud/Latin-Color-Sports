<?php
session_start();
require 'dbfotografos.php';
$pdo = conectar();

// Evitar cualquier salida accidental
ob_start();

// Mostrar errores de PHP en desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

try {
    // Obtener descargas de fotos por compra_id
    $stmt = $pdo->prepare("
        SELECT d.compra_id,
               d.foto_id,
               d.tipo_descarga,
               COUNT(*) AS veces
        FROM descargas d
        INNER JOIN compras_paquetes c ON d.compra_id = c.id
        GROUP BY d.compra_id, d.foto_id, d.tipo_descarga
        ORDER BY d.compra_id ASC, d.foto_id ASC
    ");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Agrupar por compra_id
    $descargas_por_compra = [];
    foreach($rows as $r) {
        $compra_id = $r['compra_id'];
        if(!isset($descargas_por_compra[$compra_id])) {
            $descargas_por_compra[$compra_id] = ['compra_id'=>$compra_id, 'fotos'=>[]];
        }
        $descargas_por_compra[$compra_id]['fotos'][] = [
            'foto_id' => $r['foto_id'],
            'tipo_descarga' => $r['tipo_descarga'],
            'veces' => intval($r['veces'])
        ];
    }

    echo json_encode(['status'=>'success', 'descargas_por_compra'=>array_values($descargas_por_compra)]);

} catch (Exception $e) {
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}

ob_end_flush();
