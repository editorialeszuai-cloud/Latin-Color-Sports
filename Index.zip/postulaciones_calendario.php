<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');
require_once "dbfotografos.php";

$accion = $_POST['accion'] ?? '';

switch ($accion) {
    case 'listar':
        listarPostulaciones($pdo);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
        break;
}

function listarPostulaciones($pdo) {
    $firebase_uid = $_POST['firebase_uid'] ?? '';

    if (!$firebase_uid) {
        echo json_encode(['success' => false, 'message' => 'UID de Firebase no proporcionado']);
        return;
    }

    try {
        // 🔍 Obtener ID del usuario
        $stmt = $pdo->prepare("SELECT id, nombre FROM usuarios WHERE firebase_uid = :firebase_uid LIMIT 1");
        $stmt->execute(['firebase_uid' => $firebase_uid]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$usuario) {
            echo json_encode(['success' => false, 'message' => 'Usuario no encontrado']);
            return;
        }

        $usuario_id = $usuario['id'];

        // 🔹 Consultar todas las postulaciones
        $stmt = $pdo->prepare("SELECT * FROM postulaciones WHERE usuario_id = :usuario_id");
        $stmt->execute(['usuario_id' => $usuario_id]);
        $todas_postulaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 🔹 Consultar solo postulaciones aceptadas
        $sql = "SELECT 
                    p.id AS postulacion_id,
                    f.id AS evento_id,
                    f.titulo AS evento,
                    ce.nombre AS calendario,
                    s.titulo AS sede,
                    e.nombre AS escenario,
                    d.nombre_disciplina AS disciplina,
                    cbd.categoria,
                    cb.fecha,
                    cb.hora
                FROM postulaciones p
                LEFT JOIN calendario_evento ce ON ce.id = p.calendario_id
                LEFT JOIN calendario_bloque cb ON cb.calendario_id = ce.id
                LEFT JOIN calendario_bloque_sede cbs ON cbs.bloque_id = cb.id
                LEFT JOIN sedes s ON s.id = cbs.sede_id
                LEFT JOIN calendario_bloque_escenario cbe ON cbe.bloque_sede_id = cbs.id
                LEFT JOIN escenarios e ON e.id = cbe.escenario_id
                LEFT JOIN calendario_bloque_disciplina cbd ON cbd.escenario_id = e.id
                LEFT JOIN disciplinas d ON d.id = cbd.disciplina_id
                LEFT JOIN eventos f ON f.id = ce.evento_id
                WHERE p.usuario_id = :usuario_id
                  AND p.estado = 'aceptado'
                ORDER BY ce.nombre, s.titulo, cb.fecha, cb.hora";

        $stmt = $pdo->prepare($sql);
        $stmt->execute(['usuario_id' => $usuario_id]);
        $aceptadas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'usuario' => [
                'id' => $usuario_id,
                'nombre' => $usuario['nombre'],
                'firebase_uid' => $firebase_uid
            ],
            'total_postulaciones' => count($todas_postulaciones),
            'postulaciones_aceptadas' => $aceptadas,
            'todas_postulaciones' => $todas_postulaciones
        ], JSON_PRETTY_PRINT);

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error en la base de datos: ' . $e->getMessage()]);
    }
}
?>
