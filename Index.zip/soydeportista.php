<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deportista - LatinColorSports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root {
            --red-latin: #ed1c24;
            --orange-latin: #f7941d;
            --yellow-latin: #ffc72c;
            --dark-blue: #001a33;
        }

        body { 
            margin: 0; 
            padding: 0; 
            font-family: 'Montserrat', sans-serif; 
            overflow-x: hidden;
        }

        /* --- WHATSAPP --- */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 30px;
            right: 30px;
            background-color: #25d366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            z-index: 9999;
            animation: pulse-whatsapp 2s infinite;
        }
        .whatsapp-float img { width: 35px; height: 35px; }
        
        @keyframes pulse-whatsapp {
            0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(37, 211, 102, 0); }
            100% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
        }

        /* --- OVERLAY --- */
        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(4px);
            visibility: hidden;
            opacity: 0;
            transition: 0.4s;
            z-index: 4000;
        }
        .menu-overlay.active { visibility: visible; opacity: 1; }

        /* --- HEADER --- */
        .header-lcs {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f56c1e 60%, #e4312a 100%);
            border-top: 6px solid white;
            border-bottom: 6px solid white;
            height: 75px;
            position: sticky;
            top: 0;
            z-index: 5000;
        }

        .logo-lcs a { display: flex; align-items: center; text-decoration: none; }
        .logo-lcs img { height: 35px; width: auto; }

        .right-side {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        /* --- NAVEGACIÓN --- */
        .nav-links { display: flex; align-items: center; gap: 15px; }
        .nav-links a {
            text-decoration: none;
            color: white;
            font-weight: 800;
            font-size: 11px;
            text-transform: uppercase;
        }

        .btn-login-lcs {
            background-color: var(--yellow-latin) !important;
            color: #000 !important;
            padding: 8px 12px !important;
            border-radius: 4px;
            transform: skewX(-12deg);
            display: inline-block;
        }
        .btn-login-lcs span { display: inline-block; transform: skewX(12deg); font-weight: 900; }

        .hamburger {
            display: none;
            cursor: pointer;
            flex-direction: column;
            gap: 5px;
            width: 30px;
            z-index: 5100;
        }
        .hamburger span {
            display: block;
            width: 100%;
            height: 3px;
            background-color: white;
            border-radius: 2px;
            transition: 0.4s;
        }

        /* --- RESPONSIVE MENU --- */
        @media (max-width: 1100px) {
            .nav-links {
                position: fixed;
                top: 0;
                left: -100%;
                width: 280px;
                height: 100vh;
                background: var(--red-latin);
                flex-direction: column;
                justify-content: flex-start;
                align-items: flex-start;
                padding: 100px 0 0 40px;
                gap: 25px;
                transition: 0.5s cubic-bezier(0.7, 0, 0.3, 1);
                z-index: 4500;
            }
            .nav-links.active { left: 0; }
            .nav-links a { font-size: 1.2rem; }
            .hamburger { display: flex; }
            
            .hamburger.open span:nth-child(1) { transform: translateY(8px) rotate(45deg); }
            .hamburger.open span:nth-child(2) { opacity: 0; }
            .hamburger.open span:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }
        }

        /* --- HERO & CONTENT --- */
        .hero { text-align: center; padding: 40px 20px; max-width: 900px; margin: 0 auto; }
        .hero h1 {
            color: #fff;
            font-weight: 800;
            background-color: var(--red-latin);
            display: inline-block;
            padding: 5px 40px;
            border-radius: 0 20px 20px 0;
            margin-bottom: 20px;
            font-style: italic;
            font-size: 2.5rem;
            transform: translateX(-20px);
        }
        .hero .intro-text { font-size: 1.2rem; font-weight: 600; margin-bottom: 30px; }
        .hero h2.comprar { color: var(--red-latin); font-weight: 800; font-size: 1.8rem; }

        .btn-reconocimiento {
            background-color: var(--yellow-latin);
            color: #000;
            font-weight: 700;
            padding: 15px 30px;
            border-radius: 15px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .main-container { max-width: 1100px; margin: 0 auto; padding: 20px; }
        .info-box {
            background: #f4f4f4;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            text-align: center;
            font-weight: 600;
        }

        .grid-layout {
            display: grid;
            grid-template-columns: 1fr 1.5fr 1fr;
            gap: 20px;
            align-items: start;
        }

        .card-red { background: var(--red-latin); color: #fff; padding: 25px; border-radius: 15px; font-weight: 700; }
        .center-content { text-align: center; }
        .center-content img { width: 100%; border-radius: 10px; margin-bottom: 15px; }
        
        .btn-empezar {
            background: var(--orange-latin);
            color: #fff;
            border: none;
            padding: 12px 40px;
            border-radius: 25px;
            font-weight: 800;
            text-transform: uppercase;
            cursor: pointer;
        }

        .card-white { border: 2px solid var(--red-latin); border-radius: 15px; padding: 20px; background: #fff; }
        .circle-pack {
            background: var(--red-latin);
            color: #fff;
            width: 140px;
            height: 140px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            font-size: 0.85rem;
            font-weight: 700;
            margin: 20px auto;
            padding: 10px;
        }

        footer { background: #222; color: #fff; text-align: center; padding: 25px; margin-top: 40px; }

        @media (max-width: 768px) {
            .grid-layout { grid-template-columns: 1fr; }
            .hero h1 { font-size: 1.8rem; transform: none; border-radius: 10px; }
        }
    </style>
</head>
<body>

    <div class="menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>

    <a href="https://wa.me/573142958463" class="whatsapp-float" target="_blank">
        <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp" />
    </a>

    <header class="header-lcs">
        <div class="logo-lcs">
            <a href="index.php">
          <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;height:auto;">
                <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="margin-left: 5px;width:85px;height:auto;">
            </a>
        </div>

        <div class="right-side">
            <nav class="nav-links" id="navLinks">
                <a href="conjuntodeventos.php">EVENTOS</a>
                <a href="soyorganizador.php">ORGANIZADOR</a>
                <a href="soyfotografo.php">FOTÓGRAFO</a>
                <a href="soydeportista.php">DEPORTISTA</a>
                <a href="soypatrocinador.php">PATROCINADORES</a>
                <a href="marcas.php">ESCUELA</a>
                <a href="login_app.html" class="btn-login-lcs"><span>INICIAR SESIÓN</span></a>
            </nav>

            <div class="idiomas">
                <img src="imagenes/idioma-02.webp" width="22px" alt="ES" style="cursor:pointer;">
            </div>

            <div class="hamburger" id="hamburger" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </header>

    <section class="hero">
        <h1>Deportista</h1>
        <p class="intro-text">
            Ofrecemos una <strong>experiencia profesional, inclusiva y emocionalmente poderosa</strong>, 
            donde la fotografía se convierta en un recuerdo y en un canal de visibilidad.
        </p>
        
        <h2 class="comprar">Comprar mis fotos</h2>
        <a href="conjuntodeventos.php" class="btn-reconocimiento">
            <i class="fa-solid fa-face-viewfinder"></i> Reconocimiento facial
        </a>
        <span class="sub-text" style="display:block; margin-top:10px; font-size:0.9rem;">Sube tu foto en primerísimo primer plano (solo rostro)</span>
    </section>

    <div class="main-container">
        <div class="info-box">
            ¿Quieres conservar y compartir los momentos más emocionantes de tu carrera, sentir orgullo y reconocimiento?<br>
            Compra rápida y segura de fotos y videos, búsqueda automática por <strong>reconocimiento facial / dorsal o por filtros.</strong>
        </div>

        <div class="grid-layout">
            <div class="card-red">
                Tienes 3 opciones para encontrar tus fotos:
                <ol style="padding-left:20px; margin-top:15px;">
                    <li>Por evento</li>
                    <li>Por reconocimiento facial o dorsal</li>
                    <li>Por filtros detallados de tu competencia</li>
                </ol>
            </div>

            <div class="center-content">
                <img src="../imagenes/deportista.webp" alt="Atletas">
                <div style="text-align:center;">
                    <i class="fa-regular fa-face-smile" style="font-size: 80px; color: var(--red-latin); display: block; margin-bottom: 10px;"></i>
                    <button class="btn-empezar">Empezar</button>
                </div>
                <p style="font-weight: 700; margin-top: 20px;">Tú vives el momento. Nosotros lo convertimos en historia. Latin Color Sports inmortaliza tu pasión.</p>
            </div>

            <div>
                <div class="card-white">
                    <ul style="padding-left:20px; font-weight:700;">
                        <li style="margin-bottom:10px;">Interfaz inclusiva, accesible y personalizada.</li>
                        <li>Compra rápida y segura de fotos y videos.</li>
                    </ul>
                </div>
                <div class="circle-pack">
                    Paquete de fotos y videos listos para Instagram y TikTok
                </div>
            </div>
        </div>

        <div style="text-align:center; margin:40px 0;">
            <h3 style="color:var(--red-latin); font-size:2rem; font-weight:800; font-style:italic;">“Comparte tu logro con el mundo”</h3>
        </div>
    </div>

    <footer>
        © 2026 LatinColorSports. Todos los derechos reservados.
    </footer>

    <script>
        function toggleMenu() {
            const nav = document.getElementById('navLinks');
            const burger = document.getElementById('hamburger');
            const overlay = document.getElementById('menuOverlay');
            
            const isOpen = nav.classList.toggle('active');
            burger.classList.toggle('open');
            overlay.classList.toggle('active');
            
            document.body.style.overflow = isOpen ? 'hidden' : 'auto';
        }
    </script>
</body>
</html>