<?php
// getRole.php
ob_start(); // Previene que cualquier eco accidental rompa el JSON
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require_once 'dbfotografos.php'; 

$uid = $_GET['uid'] ?? '';

if (empty($uid)) {
    echo json_encode(['status' => 'error', 'message' => 'UID vacio']);
    exit;
}

try {
    // Usamos fetch(PDO::FETCH_OBJ) para ser más directos
    $stmt = $pdo->prepare("SELECT rol FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmt->execute([$uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && isset($user['rol']) && !empty($user['rol'])) {
        echo json_encode([
            'status' => 'success', 
            'rol' => strtolower(trim($user['rol']))
        ]);
    } else {
        // Log para depuración (opcional)
        // error_log("UID no encontrado en MySQL: " . $uid);
        echo json_encode(['status' => 'not_found', 'rol' => null]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
ob_end_flush();