<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Pago Latin Color Sports</title>
    <script src="https://www.paypal.com/sdk/js?client-id=AWC4NGZ_IpYbIx6NxINHoby3IxB21Ea5cw9GVQP4x47Yr9S_ZSFRMOwDnTejlXUa54soxOh9Bm0AoKrn&currency=USD"></script>
</head>
<body>

    <div id="paypal-button-container"></div>
<script>
    // URL de tu API
    const API_URL = "https://api.latincolorsports.com";

    // Función para renderizar los botones de PayPal
    function renderPayPalButtons() {
        paypal.Buttons({
            // 1. Crear la orden llamando a tu API
            createOrder: async () => {
                try {
                    const response = await fetch(`${API_URL}/create-order`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        // Puedes enviar el total dinámico aquí si lo necesitas
                        body: JSON.stringify({ total: "0.99" }) 
                    });

                    if (!response.ok) throw new Error("Error en el servidor al crear la orden");
                    
                    const orderData = await response.json();
                    
                    if (!orderData.id) throw new Error("No se obtuvo ID de orden");
                    
                    return orderData.id;
                } catch (error) {
                    console.error("Error en createOrder:", error);
                    alert("No se pudo iniciar el pago. Intenta de nuevo.");
                    throw error;
                }
            },

            // 2. Capturar el pago tras la aprobación
            onApprove: async (data) => {
                try {
                    const response = await fetch(`${API_URL}/capture-order`, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ orderID: data.orderID })
                    });

                    const result = await response.json();
                    
                    if (result.status === "COMPLETED") {
                        alert("¡Pago exitoso!");
                        console.log("Transacción completa:", result);
                        // Opcional: Redireccionar al usuario
                        // window.location.href = "success.php";
                    } else {
                        throw new Error("La captura falló o no fue completada");
                    }
                } catch (err) {
                    console.error("Error en onApprove:", err);
                    alert("Hubo un problema al finalizar el pago.");
                }
            },

            // 3. Manejo de errores del botón
            onError: (err) => {
                console.error("Error crítico de PayPal:", err);
                alert("Ocurrió un error inesperado con PayPal.");
            }
        }).render('#paypal-button-container');
    }

    // Asegurarse de que el SDK de PayPal cargue antes de renderizar
    if (typeof paypal !== 'undefined') {
        renderPayPalButtons();
    } else {
        console.error("El SDK de PayPal no se ha cargado.");
    }
</script>
</body>
</html>