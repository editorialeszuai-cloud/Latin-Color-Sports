<?php
// miniatura.php?img=foto.jpg&w=100
$archivo = $_GET['img'] ?? '';
$w = isset($_GET['w']) ? (int)$_GET['w'] : 180;

$original = __DIR__ . "/uploads/" . basename($archivo);
$destinoDir = __DIR__ . "/uploads/thumbs_lowres/";
$destino = $destinoDir . basename($archivo);

if (!file_exists($original)) {
  header("HTTP/1.1 404 Not Found");
  exit;
}

if (!is_dir($destinoDir)) mkdir($destinoDir, 0755, true);

// Si ya existe la miniatura, servimos
if (file_exists($destino)) {
  header("Content-Type: image/jpeg");
  readfile($destino);
  exit;
}

// Crear miniatura
$info = getimagesize($original);
$tipo = $info[2];
switch ($tipo) {
  case IMAGETYPE_JPEG: $src = imagecreatefromjpeg($original); break;
  case IMAGETYPE_PNG:  $src = imagecreatefrompng($original); break;
  case IMAGETYPE_WEBP: $src = imagecreatefromwebp($original); break;
  default: header("HTTP/1.1 415 Unsupported Media Type"); exit;
}

$ancho = imagesx($src);
$alto = imagesy($src);

$nuevoAncho = $w;
$nuevoAlto = intval($alto * ($w / $ancho));

$thumb = imagecreatetruecolor($nuevoAncho, $nuevoAlto);

// �� ESTA L�0�1NEA ES CLAVE PARA EVITAR BORROSIDAD
imageantialias($thumb, true);

// Escalado de ALTA CALIDAD (bic��bico real)
imagecopyresampled(
  $thumb, $src,
  0, 0, 0, 0,
  $nuevoAncho, $nuevoAlto,
  $ancho, $alto
);

// Compresi��n alta calidad (85 �� Instagram)
imagejpeg($thumb, $destino, 85);

// Env��o al navegador
header("Content-Type: image/jpeg");
imagejpeg($thumb, null, 85);

imagedestroy($src);
imagedestroy($thumb);
