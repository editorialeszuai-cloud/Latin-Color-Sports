<?php
define('ACCESO_PERMITIDO', true);
require_once 'dbfotografos.php';
$evento_id = isset($_GET['evento_id']) ? intval($_GET['evento_id']) : 1;

// 1. Obtener fotos
$stmt = $pdo->prepare("SELECT f.id, f.url, MIN(p2.equipo_a) AS equipo_a, MIN(p2.equipo_b) AS equipo_b FROM fotos f INNER JOIN postulaciones p ON f.postulacion_id = p.id LEFT JOIN calendario_fotografos cf ON cf.postulacion_id = p.id LEFT JOIN partidos p2 ON cf.partido_id = p2.id 
LEFT JOIN fotos_moderacion fm ON f.id = fm.foto_id WHERE p.evento_id = ? AND fm.foto_id IS NULL GROUP BY f.id ORDER BY f.id DESC");
$stmt->execute([$evento_id]);
$fotos_iniciales = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 2. Obtener nombre del evento
$stmtEv = $pdo->prepare("SELECT titulo FROM eventos WHERE id = ?");
$stmtEv->execute([$evento_id]);
$eventoInfo = $stmtEv->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> <?= htmlspecialchars($eventoInfo['titulo'] ?? 'Evento Deportivo') ?> - Latin Color Sports</title>
	  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;900&display=swap');
        body { background: #050505; color: #fafafa; font-family: 'Inter', sans-serif; }
        .glass { background: rgba(15, 15, 15, 0.75); backdrop-filter: blur(14px); border: 1px solid rgba(255, 255, 255, 0.08); }
        .foto-card { background: #0f0f0f; border: 1px solid #1a1a1a; transition: all .3s; }
        .foto-card:hover { border-color: #f56c1e; transform: translateY(-5px); }
        #carritoContainer { transition: transform 0.3s ease-in-out; }
        
        .watermark-layer { position: relative; display: block; }
        .watermark-layer::after { 
            content: ""; position: absolute; inset: 0; 
            background-image: url('uploads/watermark.png'); 
            background-repeat: repeat; background-size: 120px; 
            opacity: 0.5; pointer-events: none; z-index: 10; 
        }
    </style>
</head>
<body>

<header class="flex-none fixed top-0 left-0 right-0 z-50 px-2">
    <div class="flex justify-between items-center py-3 px-4 w-full rounded-2xl shadow-lg" 
         style="background:linear-gradient(90deg,#f8a700 0%,#f56c1e 50%,#e4312a 100%);">
        
        <a href="index.php" class="shrink-0">
            <img src="../uploads/LATIN-SPORTS.png" alt="Logo" style="width:46px;">
        </a>

        <div class="hidden md:flex flex-grow justify-center px-4">
            <span class="text-white font-black uppercase italic tracking-tight truncate max-w-md">
                <?= htmlspecialchars($eventoInfo['titulo'] ?? 'Evento Deportivo') ?>
            </span>
        </div>

        <div class="flex items-center gap-2 shrink-0">
            <a href="conjuntodeventos.php" class="bg-white/20 hover:bg-white text-white hover:text-orange-600 p-2 rounded-full transition-all border border-white/20">
                <span class="material-icons text-sm">home</span>
            </a>
            
           <button onclick="toggleModal(true)" class="bg-white/20 hover:bg-white text-white hover:text-orange-600 px-6 py-3 rounded-full font-bold text-sm md:text-base flex items-center gap-2 transition-all border border-white/20 shadow-md hover:shadow-lg hover:scale-105 active:scale-95">
    <span class="material-icons text-xl md:text-2xl">face_retouching_natural</span>
    <span class="hidden md:inline">¿No encuentras tu foto?</span>
    <span class="md:hidden">Buscar foto</span>
</button>

            <button id="btnOpenCart" class="bg-white/20 hover:bg-white text-white hover:text-orange-600 px-3 py-2 rounded-full font-bold text-[10px] flex items-center gap-1 transition-all border border-white/20">
                <span class="material-icons text-sm">shopping_cart</span>
                <span id="cartCount">0</span>
            </button>
        </div>
    </div>
</header>

<div class="h-20"></div>


<div id="overlay" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 hidden"></div>

<div id="carritoContainer" class="fixed top-0 right-0 h-full w-full md:w-96 glass z-50 translate-x-full p-6 overflow-y-auto">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-xl font-black uppercase">Tu Carrito</h2>
        <button onclick="window.toggleCarrito(false)" class="material-icons">close</button>
    </div>
    <div id="carritoContent"></div>
</div>



<div class="max-w-7xl mx-auto">
  <button onclick="toggleModal(true)" class="fixed bottom-6 right-6 z-50 bg-orange-600 p-4 rounded-full shadow-2xl hover:scale-110 transition-all">
    <span class="material-icons text-white text-3xl">face_retouching_natural</span>
</button>

<div id="modalBuscador" class="fixed inset-0 z-50 flex items-center justify-center p-4 hidden">
    <div class="absolute inset-0 bg-black/80 backdrop-blur-md" onclick="toggleModal(false)"></div>
    
    <div class="glass w-full max-w-xl p-8 rounded-3xl relative z-10 animate-in fade-in zoom-in duration-300">
        <button onclick="toggleModal(false)" class="absolute top-4 right-4 text-slate-500 hover:text-white">
            <span class="material-icons">close</span>
        </button>
        
        <h2 class="text-2xl font-black uppercase mb-6 text-center">Escuentra tu foto en este Evento</h2>
        
        <form id="buscadorForm" class="space-y-4">
            <input type="file" id="fileInput" name="foto" class="hidden" accept="image/*" onchange="document.getElementById('txtFile').innerText = this.files[0].name">
            <div class="border-2 border-dashed border-white/10 p-8 text-center cursor-pointer hover:border-orange-500 transition-colors" onclick="document.getElementById('fileInput').click()">
                <span class="material-icons text-4xl text-orange-500">add_photo_alternate</span>
                <p id="txtFile" class="text-xs uppercase font-bold mt-2">Seleccionar rostro para búsqueda</p>
            </div>
            <button type="submit" class="w-full bg-orange-600 py-4 rounded-xl font-black uppercase tracking-widest hover:bg-orange-500 transition-all">Iniciar Escaneo</button>
        </form>

        <div id="search-meta" class="mt-4 text-center text-sm text-slate-400 hidden"></div>
        <div id="loading" class="hidden mt-4 text-center text-orange-500 font-bold">
            <span class="material-icons animate-spin align-middle">sync</span> Analizando... espere un momento
        </div>
    </div>
</div>

    <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4" id="galeria">
        <?php foreach ($fotos_iniciales as $foto): ?>
         <div id="card-foto-<?= $foto['id'] ?>" class="foto-card rounded-2xl overflow-hidden group">
    <a href="ver_foto.php?id=<?= $foto['id'] ?>" class="block watermark-layer aspect-[3/4] relative overflow-hidden">
        <img src="minion.php?id=<?= $foto['id'] ?>&tipo=mini" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105">
    </a>

    <button onclick="addToCart(<?= $foto['id'] ?>)" class="absolute top-4 left-4 z-20 bg-orange-600 hover:bg-orange-500 text-white p-4 rounded-full shadow-[0_0_20px_rgba(245,108,30,0.6)] transition-all hover:scale-110 active:scale-90 border border-white/20 backdrop-blur-md">
        <span class="material-icons text-2xl">add_shopping_cart</span>
    </button>

    <div class="p-3 bg-black/40 flex justify-between items-center">
        <span class="text-[10px] opacity-50 font-mono">ID: #<?= $foto['id'] ?></span>
        
        <div class="flex gap-2">
            <a href="https://wa.me/?text=¡Mira esta foto! https://www.latincolorsports.com/ver_foto.php?id=<?= $foto['id'] ?>" 
               target="_blank" 
               class="text-green-400 hover:text-green-300 transition-colors">
                <span class="material-icons text-base">chat</span>
            </a>
            
            <a href="https://www.facebook.com/sharer/sharer.php?u=https://www.latincolorsports.com/ver_foto.php?id=<?= $foto['id'] ?>" 
               target="_blank" 
               class="text-blue-400 hover:text-blue-300 transition-colors">
                <span class="material-icons text-base">facebook</span>
            </a>
        </div>
    </div>
</div>
        <?php endforeach; ?>
    </div>
</div>

<script>
    window.firebase_uid = 'invitado';

    // UI Toggle
    window.toggleCarrito = (show) => {
        document.getElementById('carritoContainer').classList.toggle('translate-x-full', !show);
        document.getElementById('overlay').classList.toggle('hidden', !show);
    };

    document.getElementById('btnOpenCart').onclick = () => window.toggleCarrito(true);
    document.getElementById('overlay').onclick = () => window.toggleCarrito(false);

    // Carrito Logic
    window.loadCarrito = async () => {
        const res = await fetch(`ver_carrito.php?firebase_uid=${window.firebase_uid}`);
        document.getElementById('carritoContent').innerHTML = await res.text();
        const total = document.getElementById('total_items_real');
        document.getElementById('cartCount').innerText = total ? total.value : '0';
    };

    window.addToCart = async (id) => {
        const btn = event.currentTarget;
        btn.innerHTML = '<span class="material-icons text-2xl">check</span>';
        await fetch(`agregarcarrito.php?firebase_uid=${window.firebase_uid}&foto_id=${id}`);
        await window.loadCarrito();
        window.toggleCarrito(true);
        setTimeout(() => btn.innerHTML = '<span class="material-icons text-2xl">add_shopping_cart</span>', 1500);
    };

    // Buscador IA
    // Buscador IA - Actualizado
document.getElementById('buscadorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const galeria = document.getElementById('galeria');
    const loading = document.getElementById('loading');
    const meta = document.getElementById('search-meta');
    
    galeria.innerHTML = "";
    loading.classList.remove('hidden');
    
    try {
        const res = await fetch('https://api.latincolorsports.com/buscar', { method: 'POST', body: new FormData(e.target) });
        const data = await res.json();
        loading.classList.add('hidden');
        
        if(data.matches?.length > 0) {
            meta.innerHTML = `✅ ${data.matches.length} coincidencias encontradas`;
            meta.style.display = 'block';
            data.matches.forEach(foto => {
                galeria.innerHTML += `
                    <div class="foto-card rounded-2xl overflow-hidden group">
                        <div class="watermark-layer aspect-[3/4] relative">
                            <img src="${foto.url}?w=400" class="w-full h-full object-cover">
                            <button onclick="addToCart(${foto.id})" class="absolute top-4 left-4 z-20 bg-orange-600 p-4 rounded-full text-white shadow-lg"><span class="material-icons text-2xl">add_shopping_cart</span></button>
                        </div>
                        <div class="p-3 bg-black/40 text-[10px] text-emerald-400">🎯 ${foto.similitud}%</div>
                    </div>`;
            });
        } else {
            galeria.innerHTML = `<p class="col-span-full text-center">No hay coincidencias.</p>`;
        }
        
        // --- AQUÍ ESTÁ EL CAMBIO: Cierra el modal tras procesar resultados ---
        toggleModal(false);
        
    } catch(err) { 
        loading.classList.add('hidden'); 
        alert("Error en IA"); 
        // También cerramos el modal si hay error para que el usuario no se quede bloqueado
        toggleModal(false); 
    }
});

    // Delegación eliminación carrito
    document.addEventListener('click', async (e) => {
        const el = e.target.closest('.js-btn-eliminar');
        if (el) {
            el.disabled = true;
            await fetch('eliminar_item.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`id=${el.dataset.id}` });
            window.loadCarrito();
        }
    });

    document.addEventListener('DOMContentLoaded', window.loadCarrito);
</script>
<script>
    function toggleModal(show) {
        const modal = document.getElementById('modalBuscador');
        modal.classList.toggle('hidden', !show);
        document.body.style.overflow = show ? 'hidden' : 'auto';
    }

    // Ajuste en el submit para cerrar el modal después de obtener resultados
    document.getElementById('buscadorForm').addEventListener('submit', async (e) => {
        // ... (tu código de búsqueda existente) ...
        
        // Si quieres que el modal se cierre al finalizar la carga:
        // setTimeout(() => toggleModal(false), 2000); 
    });
</script>
</body>
</html>