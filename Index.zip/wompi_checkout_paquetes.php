<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require_once 'dbfotografos.php';
$pdo = conectar();

// Datos de la compra
$compra_id = $_GET['compra_id'] ?? 0;
if (!$compra_id) die("<p style='color:red'>Compra de paquetes no encontrada.</p>");

// Obtener info de la compra
$stmt = $pdo->prepare("SELECT * FROM compras_paquetes WHERE id = ?");
$stmt->execute([$compra_id]);
$compra = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$compra) die("<p style='color:red'>Compra de paquetes no encontrada.</p>");

// Obtener items
$stmt = $pdo->prepare("
    SELECT e.titulo AS nombre_evento, d.precio
    FROM detalle_compras_paquetes d
    INNER JOIN eventos e ON d.evento_id = e.id
    WHERE d.id_compra = ?
");
$stmt->execute([$compra_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calcular total
$total = 0;
foreach ($items as $item) $total += $item['precio'];

// Configuración Wompi
$public_key = "pub_prod_qDvUDoTJtgy1bVkcuQJ7rcgkOM4oxbLw";
$secret_key = "prod_integrity_BWG58peE6yhM382mYETKtAjra3xNEARl";
$transaccion_id = $compra['referencia'];
$callback_url = "https://latincolorsports.com/response_paquetes.php";
$amount_in_cents = intval($total * 100);
$currency = "COP";
$firma = hash("sha256", $transaccion_id . $amount_in_cents . $currency . $secret_key);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Checkout Wompi | Paquetes - Latin Color Sports</title>
<style>
body { font-family: Arial, sans-serif; background: #0b1220; color: #fff; text-align: center; padding: 40px;}
ul { list-style:none; padding:0;}
li { background:#1b2435; margin:10px auto; padding:12px; border-radius:10px; width: 85%; text-align:left;}
li strong { color:#ff9800;}
h1,h2 { color:#fff; }
.total { color:#00e676; font-weight:bold; font-size:22px; }
</style>
</head>
<body>

<h1>Confirma tu compra de paquetes</h1>

<ul>
<?php foreach($items as $item): ?>
    <li>
        <strong><?= htmlspecialchars($item['nombre_evento']) ?></strong><br>
        Precio: $<?= number_format($item['precio'],0) ?> COP
    </li>
<?php endforeach; ?>
</ul>

<h2>Total: <span class="total">$<?= number_format($total,0) ?> COP</span></h2>

<div style="text-align:center; margin-top:20px;">
    <script
        src="https://checkout.wompi.co/widget.js"
        data-render="button"
        data-public-key="<?= htmlspecialchars($public_key) ?>"
        data-currency="<?= htmlspecialchars($currency) ?>"
        data-amount-in-cents="<?= htmlspecialchars($amount_in_cents) ?>"
        data-reference="<?= htmlspecialchars($transaccion_id) ?>"
        data-redirect-url="<?= htmlspecialchars($callback_url) ?>"
        data-signature:integrity="<?= htmlspecialchars($firma) ?>"
    ></script>
</div>

</body>
</html>
