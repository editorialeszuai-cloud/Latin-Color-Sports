<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Comisiones - Paquetes</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">

<div class="max-w-7xl mx-auto">
    <h1 class="text-3xl font-bold text-center mb-6">Mis Comisiones - Paquetes</h1>

    <table class="min-w-full bg-white rounded-lg shadow overflow-hidden" id="tablaComisionesPaquetes">
        <thead class="bg-indigo-600 text-white">
            <tr>
                <th class="px-4 py-2">ID Comisión</th>
                <th class="px-4 py-2">Compra ID</th>
                <th class="px-4 py-2">Foto ID</th>
                <th class="px-4 py-2">Veces Descargada</th>
                <th class="px-4 py-2">Comisión</th>
            </tr>
        </thead>
        <tbody id="tbodyComisionesPaquetes">
            <tr><td colspan="5" class="text-center py-4">Cargando...</td></tr>
        </tbody>
    </table>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const tbody = document.getElementById('tbodyComisionesPaquetes');

function mostrarErrorTabla(msg) {
    tbody.innerHTML = `<tr><td colspan="5" class="text-center py-4 text-red-600">${msg}</td></tr>`;
}

onAuthStateChanged(auth, async (user) => {
    if (!user) {
        window.location.href = 'login_app.html';
        return;
    }

    try {
        const token = await user.getIdToken();

        // Obtener info del usuario desde DB
        const resUser = await fetch('get_user_info.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({firebase_token: token})
        });
        const userData = await resUser.json();

        if(userData.status !== 'success' || !userData.user) {
            mostrarErrorTabla('Usuario no registrado en DB');
            return;
        }

        const firebase_uid = userData.user.firebase_uid;

        // Obtener comisiones del fotógrafo
        const resCom = await fetch('get_comisiones_por_fotografo.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({firebase_uid})
        });
        const dataCom = await resCom.json();

        tbody.innerHTML = '';

        if(dataCom.status === 'success' && dataCom.detalle_comisiones.length > 0) {
            dataCom.detalle_comisiones.forEach(c => {
                tbody.innerHTML += `
                    <tr class="border-b hover:bg-gray-50">
                        <td class="px-4 py-2">${c.comision_id}</td>
                        <td class="px-4 py-2">${c.compra_id}</td>
                        <td class="px-4 py-2">${c.foto_id}</td>
                        <td class="px-4 py-2">${c.veces_descargada}</td>
                        <td class="px-4 py-2">${c.comision.toFixed(2)}</td>
                    </tr>
                `;
            });
        } else {
            mostrarErrorTabla(dataCom.message || "No hay comisiones disponibles");
        }

    } catch(err) {
        console.error("Error JS:", err);
        mostrarErrorTabla('Error cargando comisiones');
    }
});
</script>
</body>
</html>
