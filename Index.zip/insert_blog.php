<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once "db.php";
require_once __DIR__ . '/vendor/autoload.php';

use Firebase\Auth\Token\Exception\InvalidToken;
use Firebase\Auth\Token\Verifier;

$rawInput = file_get_contents("php://input");
$data = json_decode($rawInput, true);
if (!$data && isset($_POST['firebase_token'])) { $data = $_POST; }

$firebaseToken = $data['firebase_token'] ?? null;
if (!$firebaseToken) {
    echo json_encode(["status"=>"error","message"=>"Token no recibido."]);
    exit;
}

try {
    $verifier = new Verifier('latin-group-406b1');
    $verifiedToken = $verifier->verifyIdToken($firebaseToken);
    $uid = $verifiedToken->claims()->get('sub');

    $conn = conectar();
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE firebase_uid=? LIMIT 1");
    $stmt->bind_param("s", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    if (!$user = $result->fetch_assoc()) {
        echo json_encode(["status"=>"error","message"=>"Usuario no encontrado."]);
        exit;
    }
    $usuario_id = $user['id'];

    $titulo    = $data['titulo'] ?? '';
    $resumen   = $data['resumen'] ?? '';
    $contenido = $data['contenido'] ?? '';
    $categoria = $data['categoria'] ?? '';
    $estado    = $data['estado'] ?? 'borrador';

    $stmt = $conn->prepare("INSERT INTO blogs (usuario_id,titulo,resumen,contenido,categoria,estado) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param("isssss",$usuario_id,$titulo,$resumen,$contenido,$categoria,$estado);
    if ($stmt->execute()) {
        echo json_encode(["status"=>"success","message"=>"Blog creado correctamente."]);
    } else {
        echo json_encode(["status"=>"error","message"=>"Error al insertar blog."]);
    }
    $stmt->close();
    $conn->close();

} catch (InvalidToken $e) {
    http_response_code(401);
    echo json_encode(["status"=>"error","message"=>"Token inv��lido o expirado.","debug"=>$e->getMessage()]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(["status"=>"error","message"=>"Error interno del servidor.","debug"=>$e->getMessage()]);
}
?>
