<?php
// Asegúrate de que las librerías están cargadas
require 'vendor/autoload.php';
use Aws\S3\S3Client;

// Cargar variables desde tu archivo 'claves.env'
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

// Configuración del cliente usando las variables de entorno
$s3 = new S3Client([
    'version' => 'latest',
    'region'  => 'us-east-1', // Asegúrate que sea la región real de tu bucket
    'credentials' => [
        'key'    => $_ENV['AWS_KEY'],
        'secret' => $_ENV['AWS_SECRET'],
    ],
]);

// Nombre del bucket definido en tu archivo de claves
$bucket = $_ENV['AWS_BUCKET'];
?>