<?php
define('ACCESO_PERMITIDO', true);
require_once 'dbfotografos.php';

$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;

$stmt = $pdo->prepare("
    SELECT f.id, f.url FROM fotos f 
    LEFT JOIN fotos_moderacion fm ON f.id = fm.foto_id 
    WHERE fm.foto_id IS NULL 
    ORDER BY f.id DESC LIMIT 30 OFFSET :offset
");
$stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));