from flask import Flask, request, jsonify
from buscar_rostro import buscar_rostros  # tu función de búsqueda de rostros

app = Flask(__name__)

@app.route('/buscar', methods=['POST'])
def buscar():
    if 'foto' not in request.files:
        return jsonify({"error": "No se envió ninguna foto"}), 400
    foto = request.files['foto']
    
    # buscar_rostros debe devolver una lista de foto_ids
    resultados = buscar_rostros(foto)
    
    return jsonify({"fotos_ids": resultados})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
