<?php
require 'dbfotografos.php';
$pdo = conectar();

try {
    // Usamos LEFT JOIN para que, si falta la foto o el evento, 
    // la fila de la comisión (comisiones_usuario) no se pierda.
    $stmt = $pdo->query("
        SELECT 
            cu.id AS comision_id,
            cu.compra_id,
            cu.admin AS comision_admin,
            cu.fotografo AS comision_fotografo,
            cu.soporte AS comision_soporte,
            cu.organizador AS comision_organizador, 
            cu.comercial AS comision_comercial,
            dc.id_foto AS foto_id,
            f.url AS nombre_archivo,
            COALESCE(e.titulo, 'Evento no disponible') AS evento_titulo
        FROM comisiones_usuario cu
        INNER JOIN compras c ON cu.compra_id = c.id
        INNER JOIN detalle_compras dc ON dc.id_compra = cu.compra_id
        LEFT JOIN fotos f ON f.id = dc.id_foto
        LEFT JOIN postulaciones p ON f.postulacion_id = p.id
        LEFT JOIN eventos e ON e.id = p.evento_id
        WHERE c.estado = 'APPROVED'
        ORDER BY cu.id ASC
    ");

    $comisiones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'comisiones' => $comisiones]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}