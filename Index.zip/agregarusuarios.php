<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registro Usuarios Firebase + PHP (Depuraci��n)</title>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.message { margin-top:10px; padding:5px; border-radius:5px; }
.message.success { background: #D1FAE5; color: #065F46; }
.message.error { background: #FEE2E2; color: #991B1B; }
</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

<div class="bg-white p-6 rounded-lg shadow-lg w-96">
<h2 class="text-xl font-semibold mb-4 text-gray-800">Registro de Usuario</h2>

<form id="registerForm" enctype="multipart/form-data" class="space-y-4">
    <input type="hidden" name="action" value="register">
    <input type="text" id="nombre" name="nombre" placeholder="Nombre" class="mt-1 w-full border rounded-lg p-2" required>
    <input type="email" id="email" name="email" placeholder="Email" class="mt-1 w-full border rounded-lg p-2" required>
    <input type="password" id="password" name="password" placeholder="Contrase�0�9a" class="mt-1 w-full border rounded-lg p-2" required>
    <select id="userRole" name="role" class="mt-1 w-full border rounded-lg p-2">
        <option value="cliente">Cliente</option>
        <option value="Comercial">Comercial</option>
        <option value="fotografo">Fotografo</option>
        <option value="organizador">Organizador</option>
    </select>
    <input type="file" id="foto_perfil" name="foto_perfil" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
    <div class="flex justify-between mt-4">
        <button type="submit" class="bg-indigo-600 text-white px-3 py-1 rounded hover:bg-indigo-700">Registrar Email</button>
        <button type="button" id="googleRegister" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700">Google</button>
        <button type="button" id="facebookRegister" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">Facebook</button>
    </div>
</form>

<div id="message" class="message" style="display:none;"></div>
</div>

<script>
console.log("�9�7 Iniciando script...");

const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

console.log("Inicializando Firebase...");
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

const form = document.getElementById('registerForm');
const messageDiv = document.getElementById('message');

function showMessage(msg,type){
    console.log(`[UI Message] ${type.toUpperCase()}: ${msg}`);
    messageDiv.textContent = msg;
    messageDiv.className=`message ${type}`;
    messageDiv.style.display='block';
}

// Enviar usuario al backend PHP
async function sendUserToPHP(idToken){
  const formData = new FormData(form);
  formData.append('idToken', idToken);

  try {
    const res = await fetch('agregarusuarios_api.php', { method:'POST', body:formData });
    const text = await res.text();
    console.log("�9�4 Respuesta del servidor:", text); 
    
    const data = JSON.parse(text);
    
    if (data.status === 'success') {
      showMessage("Registro exitoso. Redirigiendo...", "success");
      
      // Esperamos un segundo para que el usuario vea el mensaje de ��xito y luego redirigimos
      setTimeout(() => {
        window.location.href = 'menu.php';
      }, 1500);
      
    } else {
      showMessage(data.message, 'error');
    }
  } catch(e) {
    console.error("�7�2�1�5 Error al parsear JSON o conectar:", e);
    showMessage("Error en el servidor (ver consola o pesta�0�9a Network)", "error");
  }
}


// Registro con Email y Password
form.addEventListener('submit', async e => {
    e.preventDefault();
    console.log("�0�8 Formulario enviado (email/password)");
    const email = form.email.value.trim();
    const password = form.password.value.trim();
    if(!email || !password) {
        showMessage('Rellena todos los campos', 'error');
        return;
    }

    console.log("Creando usuario con Firebase Auth...");
    auth.createUserWithEmailAndPassword(email,password)
        .then(u=>{
            console.log("�7�3 Usuario creado:", u.user.email);
            return u.user.getIdToken();
        })
        .then(token=>{
            console.log("�9�7 Token obtenido, enviando a PHP...");
            return sendUserToPHP(token);
        })
        .catch(err=>{
            console.error("�7�4 Error en Firebase Auth:", err);
            showMessage(err.message,'error');
            alert("Error Firebase: " + err.message);
        });
});

// Google
document.getElementById('googleRegister').addEventListener('click', ()=>{
    console.log("�9�4 Iniciando registro con Google...");
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then(res=>{
            console.log("�7�3 Usuario Google:", res.user.email);
            return res.user.getIdToken();
        })
        .then(token=>{
            console.log("�9�7 Token Google, enviando a PHP...");
            return sendUserToPHP(token);
        })
        .catch(err=>{
            console.error("�7�4 Error Google Auth:", err);
            showMessage(err.message,'error');
            alert("Error Google: " + err.message);
        });
});

// Facebook
document.getElementById('facebookRegister').addEventListener('click', ()=>{
    console.log("�9�0 Iniciando registro con Facebook...");
    const provider = new firebase.auth.FacebookAuthProvider();
    auth.signInWithPopup(provider)
        .then(res=>{
            console.log("�7�3 Usuario Facebook:", res.user.email);
            return res.user.getIdToken();
        })
        .then(token=>{
            console.log("�9�7 Token Facebook, enviando a PHP...");
            return sendUserToPHP(token);
        })
        .catch(err=>{
            console.error("�7�4 Error Facebook Auth:", err);
            showMessage(err.message,'error');
            alert("Error Facebook: " + err.message);
        });
});
</script>

</body>
</html>
