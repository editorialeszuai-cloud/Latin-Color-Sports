<?php
require_once "conexion.php";
require_once "vendor/autoload.php"; // SDK Firebase Admin

use Firebase\Auth\Token\Exception\InvalidToken;
use Kreait\Firebase\Factory;

header('Content-Type: application/json');

// 🟦 1. Leer JSON de entrada
$input = json_decode(file_get_contents("php://input"), true);

if (!$input || empty($input['firebase_token'])) {
    echo json_encode(['status' => 'error', 'message' => '❌ Token Firebase no recibido.']);
    exit;
}

try {
    // 🟨 2. Ruta correcta del Service Account
    $serviceAccountPath = __DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json';
    if (!file_exists($serviceAccountPath)) {
        echo json_encode(['status' => 'error', 'message' => '❌ No se encuentra el archivo de credenciales Firebase.']);
        exit;
    }

    // 🔑 3. Inicializar Firebase Admin SDK
    $factory = (new Factory())->withServiceAccount($serviceAccountPath);
    $auth = $factory->createAuth();

    // 🔍 4. Verificar el token
    $verified = $auth->verifyIdToken($input['firebase_token']);
    $firebase_uid = $verified->claims()->get('user_id');
    $email = $verified->claims()->get('email') ?? '';
    $nombre = trim($input['nombre'] ?? '');
    $rol = $input['rol'] ?? 'cliente';

    // 🧠 Validaciones
    if (empty($email) || empty($nombre)) {
        echo json_encode(['status' => 'error', 'message' => '⚠️ Faltan datos obligatorios (nombre o email).']);
        exit;
    }

    $conn = conectar();

    // 🛑 5. Verificar si el usuario ya existe
    $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => '⚠️ Este correo ya existe en la base de datos.']);
        exit;
    }

    // 🟢 6. Insertar nuevo usuario
    $stmt = $conn->prepare("
        INSERT INTO usuarios (firebase_uid, email, nombre, rol, fecha_registro, ultima_sesion, estado)
        VALUES (?, ?, ?, ?, NOW(), NOW(), 'activo')
    ");
    $stmt->bind_param("ssss", $firebase_uid, $email, $nombre, $rol);
    $stmt->execute();

    echo json_encode(['status' => 'success', 'message' => '✅ Usuario registrado correctamente.']);

} catch (InvalidToken $e) {
    echo json_encode(['status' => 'error', 'message' => '❌ Token Firebase inválido.']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => '⚠️ Error: ' . $e->getMessage()]);
}
