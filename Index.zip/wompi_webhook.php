<?php
require_once 'dbfotografos.php';
$pdo = conectar();

// Leer POST JSON de Wompi
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) exit;

// Datos de la transacci贸n
$transaction = $data['data']['transaction'] ?? [];
$reference = $transaction['reference'] ?? '';
$status = $transaction['status'] ?? '';

if ($reference) {
    $stmt = $pdo->prepare("UPDATE compras SET estado = ? WHERE referencia = ?");
    $stmt->execute([$status, $reference]);
}

// Responder OK a Wompi
http_response_code(200);
