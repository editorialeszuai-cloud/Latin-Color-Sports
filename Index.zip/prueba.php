<?php
require_once 'dbfotografos.php';
require_once 'usuariopremium.php';
session_start();

$evento_id = isset($_GET['evento_id']) ? intval($_GET['evento_id']) : 1;
$firebase_uid_session = $_SESSION['firebase_uid'] ?? null;

function getKeyPair($pdo, $sql) {
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $result = [];
    foreach($rows as $r) $result[$r['id']] = $r['titulo'] ?? $r['nombre'] ?? $r['nombre_disciplina'] ?? $r['nombre_escenario'] ?? $r['fotografo_nombre'] ?? '';
    return $result;
}

// Filtros para el panel lateral
$galerias = getKeyPair($pdo, "SELECT DISTINCT g.id, g.titulo FROM fotos f LEFT JOIN galerias g ON g.id=f.galeria_id INNER JOIN postulaciones p ON f.postulacion_id=p.id WHERE p.evento_id=$evento_id");
$fotografos = getKeyPair($pdo, "SELECT DISTINCT u.id, u.nombre AS fotografo_nombre FROM usuarios u INNER JOIN postulaciones p ON u.id=p.usuario_id WHERE p.evento_id=$evento_id");
$disciplinas = getKeyPair($pdo, "SELECT DISTINCT d.id, d.nombre_disciplina FROM disciplinas d INNER JOIN calendario_fotografos cf ON cf.disciplina_id=d.id INNER JOIN fotos f ON f.postulacion_id=cf.postulacion_id INNER JOIN postulaciones p ON f.postulacion_id=p.id WHERE p.evento_id=$evento_id");
$sedes = getKeyPair($pdo, "SELECT DISTINCT se.id, se.titulo AS nombre_sede FROM sedes se INNER JOIN calendario_fotografos cf ON cf.sede_id=se.id INNER JOIN fotos f ON f.postulacion_id=cf.postulacion_id INNER JOIN postulaciones p ON f.postulacion_id=p.id WHERE p.evento_id=$evento_id");
$fechas = $pdo->query("SELECT DISTINCT cf.fecha FROM calendario_fotografos cf INNER JOIN fotos f ON f.postulacion_id=cf.postulacion_id INNER JOIN postulaciones p ON f.postulacion_id=p.id WHERE p.evento_id=$evento_id ORDER BY cf.fecha DESC")->fetchAll(PDO::FETCH_COLUMN);

// Carga inicial (Primeras 40 fotos)
$stmt = $pdo->prepare("SELECT f.id, f.url FROM fotos f INNER JOIN postulaciones p ON f.postulacion_id=p.id WHERE p.evento_id = ? ORDER BY f.id DESC LIMIT 40");
$stmt->execute([$evento_id]);
$fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);
$fotosJson = json_encode($fotos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscador Pro - Latin Colors</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <style>
        body { background:#0a0a0a; color:#eee; font-family:'Inter',sans-serif; }
        .foto-card { background:#111; border:1px solid #222; border-radius:12px; overflow:hidden; transition: 0.3s; }
        .foto-card:hover { border-color: #f59e0b; transform: translateY(-4px); }
        .drawer { transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1); }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #444; border-radius: 10px; }
        .loading-shimmer { background: linear-gradient(90deg, #111 25%, #222 50%, #111 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; }
        @keyframes shimmer { 0% { background-position: 200% 0; } 100% { background-position: -200% 0; } }
    </style>
</head>
<body class="overflow-x-hidden">

<nav class="flex items-center justify-between p-4 bg-[#0d0d0d] border-b border-[#1a1a1a] sticky top-0 z-40">
    <div class="flex items-center gap-4">
        <button id="btnOpenFilters" class="p-2 bg-white/5 rounded-lg lg:hidden">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>
        </button>
        <span class="text-xl font-black italic text-orange-500 tracking-tighter">LATIN COLOR SPORTS</span>
    </div>

    <button id="btnOpenCart" class="relative group p-2 bg-orange-600/10 hover:bg-orange-600 transition-colors rounded-xl border border-orange-600/20">
        <span class="flex items-center gap-2">
            <span class="text-lg">🛒</span>
            <span id="cartCount" class="font-bold text-orange-500 group-hover:text-white">0</span>
        </span>
    </button>
</nav>

<div class="flex h-[calc(100vh-69px)] overflow-hidden">
    
    <div id="overlay" class="fixed inset-0 bg-black/80 z-40 hidden"></div>

    <aside id="sidebarFiltros" class="drawer fixed inset-y-0 left-0 w-72 bg-[#0d0d0d] p-6 border-r border-[#1a1a1a] z-50 transform -translate-x-full lg:relative lg:translate-x-0 overflow-y-auto">
        <div class="flex items-center justify-between mb-8 lg:hidden">
            <span class="font-black text-white text-xs tracking-widest">FILTROS</span>
            <button id="btnCloseFilters" class="text-gray-500 uppercase text-[10px] font-bold">Cerrar</button>
        </div>
        
        <form id="filtrosForm" class="space-y-4">
            <input type="hidden" name="evento_id" value="<?= $evento_id ?>">
            <?php 
            $selects = ['galeria' => $galerias, 'fotografo' => $fotografos, 'disciplina' => $disciplinas, 'sede' => $sedes];
            foreach($selects as $name => $data): ?>
                <div>
                    <label class="text-[10px] text-gray-500 uppercase font-bold ml-1"><?= $name ?></label>
                    <select name="<?= $name ?>" class="bg-[#1a1a1a] border border-[#333] p-2.5 rounded-xl w-full text-sm text-gray-300 focus:border-orange-500 outline-none transition appearance-none">
                        <option value="">-- Todos --</option>
                        <?php foreach($data as $id=>$val): ?>
                            <option value="<?= $id ?>"><?= htmlspecialchars($val) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endforeach; ?>
            <div>
                <label class="text-[10px] text-gray-500 uppercase font-bold ml-1">Fecha</label>
                <select name="fecha" class="bg-[#1a1a1a] border border-[#333] p-2.5 rounded-xl w-full text-sm text-gray-300 focus:border-orange-500 outline-none appearance-none">
                    <option value="">-- Todas --</option>
                    <?php foreach($fechas as $f): ?> <option value="<?= $f ?>"><?= $f ?></option> <?php endforeach; ?>
                </select>
            </div>
        </form>

        <button id="btnBulkCart" class="w-full bg-orange-600 hover:bg-orange-500 text-white font-black py-4 rounded-xl mt-8 hidden transition-all active:scale-95 text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20">
            AGREGAR SELECCIONADOS
        </button>
    </aside>

    <main class="flex-1 p-4 lg:p-6 overflow-y-auto relative">
        <div class="flex flex-col md:flex-row gap-4 mb-6 sticky top-0 z-0 bg-[#0a0a0a]/80 backdrop-blur-md py-2">
            <div class="flex-1 flex items-center gap-3 bg-[#111] border border-[#222] p-2 rounded-2xl">
                <label for="faceInput" class="flex items-center gap-3 cursor-pointer p-1">
                    <div id="previewContainer" class="w-10 h-10 rounded-full border-2 border-dashed border-gray-600 overflow-hidden bg-black flex items-center justify-center shrink-0">
                        <img id="facePreview" class="w-full h-full object-cover hidden">
                        <span id="faceIcon">📷</span>
                    </div>
                    <div class="flex flex-col">
                        <span id="fileName" class="text-[10px] font-black text-gray-400 uppercase tracking-tighter">Buscar por Rostro</span>
                        <input type="file" id="faceInput" accept="image/*" class="hidden">
                    </div>
                </label>
                <button id="btnRemovePhoto" class="hidden text-red-500 px-2 font-bold text-xl">&times;</button>
                <button id="btnSearch" class="ml-auto bg-orange-600 hover:bg-orange-500 text-white font-black px-8 py-3 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-orange-600/10">Buscar</button>
            </div>
        </div>

        <div id="statusArea" class="mb-4 flex items-center justify-between text-[10px] font-bold px-2">
            <span id="resultadoIA" class="text-orange-500 uppercase tracking-widest">Iniciando Galería...</span>
            <button id="btnResetAll" class="text-gray-500 hover:text-white uppercase tracking-tighter">Limpiar Filtros</button>
        </div>

        <div id="galeria" class="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4"></div>

        <div class="mt-12 mb-20 flex justify-center">
            <button id="btnLoadMore" class="bg-[#111] border border-[#222] hover:border-orange-500 text-gray-500 hover:text-white px-12 py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all active:scale-95 shadow-2xl">
                Cargar más fotografías
            </button>
        </div>
    </main>

    <aside id="carritoContainer" class="drawer fixed inset-y-0 right-0 w-full sm:w-80 bg-[#0d0d0d] border-l border-[#1a1a1a] z-50 transform translate-x-full overflow-hidden flex flex-col shadow-2xl">
        <div class="p-6 border-b border-white/5 flex justify-between items-center bg-[#111]">
            <h3 class="text-[10px] font-black text-orange-500 uppercase tracking-[0.2em]">Mi Selección</h3>
            <button id="btnCloseCart" class="text-gray-500 hover:text-white text-[10px] font-black tracking-widest p-2">CERRAR</button>
        </div>
        <div id="carritoContent" class="flex-1 overflow-y-auto p-4 space-y-3"></div>
        <div class="p-6 bg-[#111] border-t border-white/5">
            <button class="w-full bg-orange-600 hover:bg-orange-500 text-white font-black py-5 rounded-2xl shadow-xl transition-transform active:scale-95 text-xs tracking-widest uppercase">
                Finalizar Compra
            </button>
        </div>
    </aside>
</div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.appspot.com",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
let firebase_uid = "<?= $firebase_uid_session ?>";

// VARIABLES DE ESTADO
let currentFotos = <?= $fotosJson ?>;
let seleccionados = new Set();
let offset = 40;
const limit = 40;
let isFaceSearch = false;

// UI SELECTORS
const sideFiltros = document.getElementById('sidebarFiltros');
const sideCarrito = document.getElementById('carritoContainer');
const overlay = document.getElementById('overlay');
const cartCount = document.getElementById('cartCount');
const btnLoadMore = document.getElementById('btnLoadMore');

const toggleUI = (el, show) => {
    el.classList.toggle('-translate-x-full', !show && el === sideFiltros);
    el.classList.toggle('translate-x-full', !show && el === sideCarrito);
    overlay.classList.toggle('hidden', !show);
};

document.getElementById('btnOpenFilters').onclick = () => toggleUI(sideFiltros, true);
document.getElementById('btnCloseFilters').onclick = () => toggleUI(sideFiltros, false);
document.getElementById('btnOpenCart').onclick = () => toggleUI(sideCarrito, true);
document.getElementById('btnCloseCart').onclick = () => toggleUI(sideCarrito, false);
overlay.onclick = () => { toggleUI(sideFiltros, false); toggleUI(sideCarrito, false); };

onAuthStateChanged(auth, (user) => {
    if (user) { firebase_uid = user.uid; loadCarrito(); }
});

// CARRITO
async function loadCarrito() {
    if (!firebase_uid) return;
    const content = document.getElementById('carritoContent');
    try {
        const res = await fetch(`ver_carrito.php?firebase_uid=${encodeURIComponent(firebase_uid)}`);
        const html = await res.text();
        content.innerHTML = html;
        const count = content.querySelectorAll('.delete-btn').length;
        cartCount.innerText = count;
        
        content.querySelectorAll('.delete-btn').forEach(btn => btn.onclick = async () => {
            await fetch(`eliminar_carrito.php?id=${btn.dataset.id}`, { method: 'POST' });
            loadCarrito();
        });
    } catch (e) { console.error(e); }
}

window.addToCart = async (id) => {
    if(!firebase_uid) return alert("Inicia sesión primero");
    await fetch(`agregarcarrito.php?firebase_uid=${firebase_uid}&foto_id=${id}&precio=10000`);
    loadCarrito();
};

// RENDERIZADO
function renderGaleria(append = false) {
    const galeria = document.getElementById('galeria');
    const html = currentFotos.length ? currentFotos.map(f => `
        <div class="foto-card relative group animate-in fade-in duration-500">
            <div class="absolute top-3 left-3 z-10">
                <input type="checkbox" id="chk-${f.id}" value="${f.id}" class="hidden peer" onchange="window.toggleSelection(this)">
                <label for="chk-${f.id}" class="w-6 h-6 border-2 border-white/20 rounded-lg block cursor-pointer peer-checked:bg-orange-600 peer-checked:border-orange-600 bg-black/40 backdrop-blur-sm transition-all"></label>
            </div>
            <a href="ver_foto.php?id=${f.id}">
                <img src="foto_watermark.php?img=${encodeURIComponent(f.url)}" class="w-full h-56 object-cover" loading="lazy">
            </a>
            <button onclick="window.addToCart(${f.id})" class="absolute bottom-3 right-3 bg-orange-600 text-white p-3 rounded-xl opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0 shadow-lg">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-width="3" d="M12 4v16m8-8H4"/></svg>
            </button>
        </div>
    `).join('') : (append ? '' : '<div class="col-span-full text-center text-gray-500 py-20 uppercase text-xs tracking-widest">Sin resultados encontrados</div>');

    if (append) galeria.insertAdjacentHTML('beforeend', html);
    else galeria.innerHTML = html;
}

window.toggleSelection = (el) => {
    el.checked ? seleccionados.add(el.value) : seleccionados.delete(el.value);
    const btn = document.getElementById('btnBulkCart');
    btn.classList.toggle('hidden', seleccionados.size === 0);
    btn.innerText = `AGREGAR ${seleccionados.size} AL CARRITO`;
};

document.getElementById('btnBulkCart').onclick = async () => {
    for(let id of seleccionados) await fetch(`agregarcarrito.php?firebase_uid=${firebase_uid}&foto_id=${id}&precio=10000`);
    seleccionados.clear();
    document.getElementById('btnBulkCart').classList.add('hidden');
    loadCarrito();
    renderGaleria();
};

// IA Y BUSCADOR
window.addEventListener('load', async () => {
    const URL = '../face-demo/models/';
    try {
        await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri(URL),
            faceapi.nets.faceLandmark68Net.loadFromUri(URL),
            faceapi.nets.faceRecognitionNet.loadFromUri(URL)
        ]);
        document.getElementById('resultadoIA').textContent = "Sistema IA Listo";
    } catch(e) { document.getElementById('resultadoIA').textContent = "IA offline"; }
});

async function realizarBusqueda(isMore = false) {
    const resLabel = document.getElementById('resultadoIA');
    const faceInput = document.getElementById('faceInput');
    const fd = new FormData(document.getElementById('filtrosForm'));
    
    if(!isMore) {
        offset = 0;
        btnLoadMore.innerText = "Cargar más fotografías";
        btnLoadMore.classList.remove('opacity-50');
    }

    fd.append('offset', offset);
    fd.append('limit', limit);

    resLabel.textContent = "Buscando...";

    if (faceInput.files[0]) {
        isFaceSearch = true;
        const img = await faceapi.bufferToImage(faceInput.files[0]);
        const detection = await faceapi.detectSingleFace(img, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks().withFaceDescriptor();
        
        if (!detection) {
            alert('No se detectó rostro en la foto subida');
            resLabel.textContent = "Error: Rostro no detectado";
            return;
        }
        
        fd.append('foto', faceInput.files[0]);
        fd.append('descriptors', JSON.stringify(Array.from(detection.descriptor)));
        
        const res = await fetch('buscar_rosto.php', { method:'POST', body:fd });
        const data = await res.json();
        currentFotos = data.fotos || [];
    } else {
        isFaceSearch = false;
        const res = await fetch('buscar_fotos_filtros.php', { method:'POST', body:fd });
        currentFotos = await res.json();
    }

    renderGaleria(isMore);
    offset += limit;
    resLabel.textContent = (isMore ? "Galería extendida" : currentFotos.length + " resultados");
    
    if(currentFotos.length < limit) {
        btnLoadMore.innerText = "Fin de la galería";
        btnLoadMore.classList.add('opacity-50');
    }
}

document.getElementById('btnSearch').onclick = () => realizarBusqueda(false);
btnLoadMore.onclick = () => realizarBusqueda(true);

// MANEJO UI FILE
document.getElementById('faceInput').onchange = (e) => {
    const file = e.target.files[0];
    if(file) {
        document.getElementById('facePreview').src = URL.createObjectURL(file);
        document.getElementById('facePreview').classList.remove('hidden');
        document.getElementById('faceIcon').classList.add('hidden');
        document.getElementById('btnRemovePhoto').classList.remove('hidden');
        document.getElementById('fileName').innerText = "Rostro Seleccionado";
    }
};

document.getElementById('btnRemovePhoto').onclick = () => {
    document.getElementById('faceInput').value = "";
    document.getElementById('facePreview').classList.add('hidden');
    document.getElementById('faceIcon').classList.remove('hidden');
    document.getElementById('btnRemovePhoto').classList.add('hidden');
    document.getElementById('fileName').innerText = "Buscar por Rostro";
};

document.getElementById('btnResetAll').onclick = () => {
    document.getElementById('filtrosForm').reset();
    document.getElementById('btnRemovePhoto').click();
    realizarBusqueda(false);
};

// INICIO
renderGaleria();
</script>
</body>
</html>