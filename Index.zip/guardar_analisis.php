<?php
require 'dbfotografos.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'guardar_analisis') {
    $foto_id = $_POST['foto_id'] ?? null;
    $color_dominante = $_POST['color_dominante'] ?? null;
    $objetos_detectados = $_POST['objetos_detectados'] ?? null;

    if ($foto_id) {
        $stmt = $pdo->prepare("UPDATE foto_analisis SET color_dominante=?, objetos_detectados=? WHERE foto_id=?");
        if ($stmt->execute([$color_dominante, $objetos_detectados, $foto_id])) {
            echo "Análisis guardado correctamente";
        } else {
            echo "Error al guardar análisis";
        }
    } else {
        echo "foto_id requerido";
    }
} else {
    echo "Acción no válida";
}
