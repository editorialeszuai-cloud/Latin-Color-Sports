<?php
// Desactivar salida de errores para no romper el JSON, pero registrarlos
ini_set('display_errors', 0);
error_reporting(E_ALL);

require 'dbfotografos.php';
header('Content-Type: application/json');

function resp($status, $message, $extra = []) {
    // Limpiar cualquier salida accidental previa
    if (ob_get_length()) ob_clean();
    echo json_encode(array_merge([
        'status' => $status,
        'message' => $message
    ], $extra));
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$comisiones_ids = $input['comisiones'] ?? [];
$firebase_uid   = $input['firebase_uid'] ?? null;

if (empty($comisiones_ids) || !$firebase_uid) {
    resp('error', 'Datos incompletos (UID o Comisiones faltantes)');
}

try {
    // 1. Obtener el ID interno del usuario desde el firebase_uid para validar propiedad
    $stmtUser = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmtUser->execute([$firebase_uid]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) resp('error', 'Usuario no autorizado');
    $usuario_id_interno = $user['id'];

    // 2. VALIDAR PROPIEDAD Y OBTENER MONTOS
    // Solo permitimos comisiones que pertenezcan a fotos vinculadas a postulaciones de este usuario
    $placeholders = implode(',', array_fill(0, count($comisiones_ids), '?'));
    
    $sqlVal = "
        SELECT cu.id, cu.fotografo AS monto
        FROM comisiones_usuario cu
        INNER JOIN fotos f ON cu.foto_id = f.id
        INNER JOIN postulaciones p ON f.postulacion_id = p.id
        WHERE cu.id IN ($placeholders) 
        AND p.usuario_id = ?
    ";

    $stmtVal = $pdo->prepare($sqlVal);
    // Combinamos los IDs de comisiones con el ID del usuario para el �ltimo "?"
    $params = array_merge($comisiones_ids, [$usuario_id_interno]);
    $stmtVal->execute($params);
    $validados = $stmtVal->fetchAll(PDO::FETCH_ASSOC);

    if (empty($validados)) {
        resp('error', 'No se encontraron comisiones v�lidas que te pertenezcan');
    }

    // 3. PROCESAR RETIRO EN TRANSACCI�N
    $pdo->beginTransaction();

    $fecha = date('Y-m-d H:i:s');
    $total_solicitado = 0;

    $stmtInsert = $pdo->prepare("
        INSERT INTO retiros_comisiones
        (comision_id, tipo, retirada, firebase_uid, total, fecha)
        VALUES (:id, 'fotografo', 1, :uid, :monto, :fecha)
        ON DUPLICATE KEY UPDATE 
            retirada = 1, 
            fecha = VALUES(fecha),
            total = VALUES(total)
    ");

    foreach ($validados as $c) {
        $total_solicitado += $c['monto'];
        $stmtInsert->execute([
            'id'    => $c['id'],
            'uid'   => $firebase_uid,
            'monto' => $c['monto'],
            'fecha' => $fecha
        ]);
    }

    $pdo->commit();

    resp('success', 'Solicitud de retiro procesada', [
        'cantidad_items' => count($validados),
        'total_suma'     => round($total_solicitado, 2),
        'fecha'          => $fecha
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    resp('error', 'Error en el proceso', ['detalle' => $e->getMessage()]);
}