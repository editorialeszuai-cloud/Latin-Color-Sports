// login.js
import {
  getAuth,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  FacebookAuthProvider,
  signInWithPopup
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

import { app } from "./firebase-configrol.js";

const auth = getAuth(app);

// --- Referencias del DOM ---
const emailInput = document.getElementById('loginEmail');
const passwordInput = document.getElementById('loginPassword');
const loginButton = document.getElementById('loginButton');
const googleLoginButton = document.getElementById('googleLogin');
const facebookLoginButton = document.getElementById('facebookLogin');
const messageDiv = document.getElementById('message');

// --- Mostrar mensajes ---
function showMessage(text, type = 'info') {
  messageDiv.textContent = text;
  messageDiv.className = `message ${type}`;
  messageDiv.style.display = 'block';
}

// --- Enviar token al backend PHP ---
async function sendTokenToPHP() {
  const user = auth.currentUser;
  if (!user) {
    showMessage("Error interno: usuario no autenticado.", "error");
    return;
  }

  const idToken = await user.getIdToken();

  const response = await fetch("login.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${idToken}`
    }
  });

  const data = await response.json();

  if (data.status === "success") {
    showMessage("Inicio de sesión exitoso. Redirigiendo...", "success");
    setTimeout(() => {
      window.location.href = "dashboard.php";
    }, 1200);
  } else {
    showMessage(`Error del servidor: ${data.message}`, "error");
  }
}

// --- 1. Login con Email y Password ---
loginButton.addEventListener('click', async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!email || !password) {
    showMessage("Por favor, ingresa tu correo y contraseña.", "error");
    return;
  }

  try {
    await signInWithEmailAndPassword(auth, email, password);

    const user = auth.currentUser;
    if (!user.emailVerified) {
      showMessage("Por favor, verifica tu correo electrónico antes de iniciar sesión.", "error");
      return;
    }

    await sendTokenToPHP();

  } catch (error) {
    console.error("Error al iniciar sesión:", error.code, error.message);
    let userMessage = "Error al iniciar sesión: ";
    switch (error.code) {
      case "auth/invalid-email":
        userMessage += "Correo inválido.";
        break;
      case "auth/user-disabled":
        userMessage += "Usuario deshabilitado.";
        break;
      case "auth/user-not-found":
        userMessage += "No existe una cuenta con ese correo.";
        break;
      case "auth/wrong-password":
        userMessage += "Contraseña incorrecta.";
        break;
      default:
        userMessage += error.message;
    }
    showMessage(userMessage, "error");
  }
});

// --- 2. Login con Google ---
googleLoginButton.addEventListener('click', async () => {
  try {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
    await sendTokenToPHP();
  } catch (error) {
    showMessage("Error con Google: " + error.message, "error");
  }
});

// --- 3. Login con Facebook ---
facebookLoginButton.addEventListener('click', async () => {
  try {
    const provider = new FacebookAuthProvider();
    await signInWithPopup(auth, provider);
    await sendTokenToPHP();
  } catch (error) {
    showMessage("Error con Facebook: " + error.message, "error");
  }
});
