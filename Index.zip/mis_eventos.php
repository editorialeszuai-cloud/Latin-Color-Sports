<?php
require 'dbfotografos.php';
$conn = conectar();
$pdo = $conn;

// Inicializamos arrays
$eventos = [];
$fotografos = [];
$asign_map = [];
$galerias_map = [];
$fotos_map = [];

// UID del usuario autenticado (recibido desde JS)
$uid = $_POST['uid'] ?? null;

if ($uid) {

    // 1️⃣ Buscar el usuario por firebase_uid
    $stmt = $pdo->prepare("SELECT id, nombre, email, rol FROM usuarios WHERE firebase_uid = :uid");
    $stmt->execute(['uid' => $uid]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuario no encontrado.');
    }

    $fotografo_id = $usuario['id']; // ID interno del usuario

    // 2️⃣ Buscar los IDs de eventos asignados a este fotógrafo
    $stmt = $pdo->prepare("SELECT evento_id FROM asignar_eventos WHERE fotografo_id = :fid");
    $stmt->execute(['fid' => $fotografo_id]);
    $asignaciones_fotografo = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if ($asignaciones_fotografo) {
        // 3️⃣ Obtener los eventos correspondientes
        $in = str_repeat('?,', count($asignaciones_fotografo) - 1) . '?';
    $stmt = $pdo->prepare("SELECT * FROM eventos WHERE id IN ($in) AND fecha >= CURDATE() ORDER BY fecha ASC");

        $stmt->execute($asignaciones_fotografo);
        $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // 4️⃣ Cargar fotógrafos, galerías y fotos
    $fotografos = $pdo->query("SELECT * FROM usuarios ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC);

    $asignaciones = $pdo->query("SELECT * FROM asignar_eventos")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($asignaciones as $a) {
        $asign_map[$a['evento_id']][] = $a['fotografo_id'];
    }

    $galerias = $pdo->query("SELECT * FROM galerias ORDER BY fecha_creacion DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($galerias as $g) {
        $galerias_map[$g['evento_id']][$g['fotografo_id']][] = $g;
    }

    $fotos = $pdo->query("SELECT * FROM fotos")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($fotos as $f) {
        $fotos_map[$f['galeria_id']][] = $f;
    }

    // 5️⃣ Si la petición es AJAX, solo devolvemos el HTML de los eventos
    if (
        isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
    ) {
        ob_start();

        if ($eventos):
            foreach ($eventos as $evento):
                ?>
                <div class="bg-white p-6 mb-6 rounded shadow">
                    <h2 class="text-2xl font-semibold">
                        <?= htmlspecialchars($evento['titulo']) ?>
                        <span class="text-gray-500 text-base">(<?= htmlspecialchars($evento['fecha']) ?>)</span>
                    </h2>

                    <?php if (isset($asign_map[$evento['id']])): ?>
                        <?php foreach ($asign_map[$evento['id']] as $fid):
                            $filtro = array_filter($fotografos, fn($u) => $u['id'] == $fid);
                            $fotografo = $filtro ? array_values($filtro)[0] : null;
                            $galerias_fotografo = $galerias_map[$evento['id']][$fid] ?? [];
                        ?>
                            <?php if ($fotografo): ?>
                                <div class="border p-4 mt-4 rounded bg-gray-50">
                                    <h3 class="font-semibold text-lg text-indigo-700">
                                        <?= htmlspecialchars($fotografo['nombre']) ?>
                                    </h3>

                                    <?php if ($galerias_fotografo): ?>
                                        <?php foreach ($galerias_fotografo as $g): ?>
                                            <div class="mt-3">
                                                <p class="font-medium text-gray-800"><?= htmlspecialchars($g['titulo']) ?></p>
                                                <?php if (isset($fotos_map[$g['id']])): ?>
                                                    <div class="grid grid-cols-3 gap-2 mt-2">
                                                        <?php foreach ($fotos_map[$g['id']] as $f): ?>
                                                            <img src="uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>"
                                                                 alt="<?= htmlspecialchars($f['descripcion']) ?>"
                                                                 class="w-full h-32 object-cover cursor-pointer rounded"
                                                                 onclick="openModal('uploads/<?= htmlspecialchars($f['nombre_archivo']) ?>','<?= htmlspecialchars(addslashes($f['descripcion'])) ?>')">
                                                        <?php endforeach; ?>
                                                    </div>
                                                <?php else: ?>
                                                    <p class="text-gray-500 text-sm mt-2">No hay fotos en esta galería.</p>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-gray-500 text-sm mt-2">Aún no has creado galerías para este evento.</p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-gray-500 mt-2">No hay fotógrafos asignados a este evento.</p>
                    <?php endif; ?>
                </div>
                <?php
            endforeach;
        else:
            echo '<p class="text-gray-500">No tienes eventos disponibles.</p>';
        endif;

        echo ob_get_clean();
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Eventos</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<meta name="viewport" content="width=device-width,initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- 🌐 BOTÓN DE PANEL -->
<div class="fixed top-4 right-4 z-50">
  <button id="toggleDashboard" class="bg-indigo-600 text-white px-4 py-2 rounded-lg shadow hover:bg-indigo-700 transition">
    ☰ Panel Usuario
  </button>
</div>

<!-- 📋 PANEL DE USUARIO -->
<div id="dashboardContainer"
  class="fixed top-0 right-0 h-full w-80 bg-white shadow-2xl transform translate-x-full transition-transform duration-300 ease-in-out z-40 overflow-y-auto">

  <div class="flex justify-between items-center p-6 border-b">
    <h1 class="text-2xl font-bold text-gray-900">Panel Usuario</h1>
    <button id="closeDashboard" class="text-gray-500 hover:text-gray-800 text-2xl leading-none">&times;</button>
  </div>

  <div class="p-6 space-y-4">
    <p class="text-gray-600">Información obtenida desde <strong>Firebase</strong> y <strong>MySQL</strong>.</p>

    <div class="bg-indigo-50 p-4 rounded-lg border border-indigo-200 shadow-inner">
      <h2 class="text-lg font-semibold text-indigo-700 mb-3">Detalles del Usuario</h2>
      <div class="space-y-1 text-gray-700 text-sm">
        <p><strong>UID:</strong> <span id="userId" class="font-mono block">Cargando...</span></p>
        <p><strong>Email:</strong> <span id="userEmail">Cargando...</span></p>
        <p><strong>Nombre:</strong> <span id="userName">Cargando...</span></p>
        <p><strong>Rol:</strong>
          <span id="userRole" class="inline-block px-2 py-1 text-xs font-semibold rounded-full bg-indigo-100 text-indigo-800">Cargando...</span>
        </p>
      </div>
    </div>

    <div id="roleContent" class="space-y-3 mt-4 text-gray-700"></div>

    <button id="logoutButton"
      class="w-full mt-4 bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 transition font-medium">
      Cerrar Sesión
    </button>
  </div>
</div>

<!-- CONTENEDOR DE EVENTOS -->
<div class="container w-full max-w-6xl mx-auto mt-10 p-4">
  <h1 class="text-3xl font-bold mb-6">Mis Eventos Disponibles</h1>
  <div id="eventosContainer">
    <p class="text-gray-500">Cargando eventos... espera a que se autentique el usuario.</p>
  </div>
</div>

<!-- Modal de fotos -->
<div id="photoModal" class="fixed inset-0 bg-black bg-opacity-70 hidden items-center justify-center z-50">
    <div class="relative bg-white rounded shadow-lg max-w-3xl w-full p-4">
        <button class="absolute top-2 right-2 text-gray-700 text-xl font-bold" onclick="closeModal()">×</button>
        <img id="modalImage" src="" class="w-full h-auto rounded">
        <p id="modalDesc" class="mt-2 text-gray-700"></p>
    </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// --- Panel de usuario ---
const dashboard = document.getElementById('dashboardContainer');
document.getElementById('toggleDashboard').addEventListener('click', () => dashboard.classList.toggle('translate-x-full'));
document.getElementById('closeDashboard').addEventListener('click', () => dashboard.classList.add('translate-x-full'));

// --- Logout ---
document.getElementById('logoutButton').addEventListener('click', async () => {
  await signOut(auth);
  window.location.href = 'login_app.html';
});

function updateUI(uid, email, nombre, rol) {
  document.getElementById('userId').textContent = uid;
  document.getElementById('userEmail').textContent = email;
  document.getElementById('userName').textContent = nombre;
  document.getElementById('userRole').textContent = rol;

  if (rol !== 'fotografo') {
    document.getElementById('roleContent').innerHTML = `<p class="text-red-600 font-bold">Acceso restringido a organizadores.</p>`;
  }
}

// --- Modal de fotos ---
function openModal(src, desc){
    document.getElementById('modalImage').src = src;
    document.getElementById('modalDesc').innerText = desc;
    document.getElementById('photoModal').classList.remove('hidden');
    document.getElementById('photoModal').classList.add('flex');
}
function closeModal(){
    document.getElementById('photoModal').classList.add('hidden');
    document.getElementById('photoModal').classList.remove('flex');
}

// --- Cargar eventos dinámicamente ---
async function loadEventos(uid){
  const form = new FormData();
  form.append('uid', uid);

  const res = await fetch(window.location.href, {
    method:'POST',
    body: form,
    headers: {'X-Requested-With':'XMLHttpRequest'}
  });
  const html = await res.text();
  document.getElementById('eventosContainer').innerHTML = html;
}

// --- Detectar usuario logueado ---
onAuthStateChanged(auth, async (user) => {
  if(user){
    try{
      const token = await user.getIdToken();
      const res = await fetch('get_user_info.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({firebase_token: token})
      });
      const data = await res.json();
      if(data.status==='success'){
        const {firebase_uid, email, nombre, rol} = data.user;
        updateUI(firebase_uid,email,nombre,rol);
        // cargar eventos dinámicamente
        loadEventos(firebase_uid);
      } else{
        alert('⚠️ Error: '+data.message);
      }
    } catch(e){
      alert('⚠️ Error Firebase: '+e.message);
      console.error(e);
    }
  } else{
    window.location.href = 'login_app.html';
  }
});
</script>

</body>
</html>


<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// --- Panel de usuario ---
const dashboard = document.getElementById('dashboardContainer');
document.getElementById('toggleDashboard').addEventListener('click', () => dashboard.classList.toggle('translate-x-full'));
document.getElementById('closeDashboard').addEventListener('click', () => dashboard.classList.add('translate-x-full'));

// --- Logout ---
document.getElementById('logoutButton').addEventListener('click', async () => {
  await signOut(auth);
  window.location.href = 'login_app.html';
});

function updateUI(uid, email, nombre, rol) {
  document.getElementById('userId').textContent = uid;
  document.getElementById('userEmail').textContent = email;
  document.getElementById('userName').textContent = nombre;
  document.getElementById('userRole').textContent = rol;

  if (rol !== 'fotografo') {
    document.getElementById('roleContent').innerHTML = `<p class="text-red-600 font-bold">Acceso restringido a organizadores.</p>`;
  }
}

// --- Modal de fotos ---
function openModal(src, desc){
    document.getElementById('modalImage').src = src;
    document.getElementById('modalDesc').innerText = desc;
    document.getElementById('photoModal').classList.remove('hidden');
    document.getElementById('photoModal').classList.add('flex');
}
function closeModal(){
    document.getElementById('photoModal').classList.add('hidden');
    document.getElementById('photoModal').classList.remove('flex');
}

// --- Cargar eventos dinámicamente ---
async function loadEventos(uid){
  const form = new FormData();
  form.append('uid', uid);

  const res = await fetch(window.location.href, {
    method:'POST',
    body: form,
    headers: {'X-Requested-With':'XMLHttpRequest'}
  });
  const html = await res.text();
  document.getElementById('eventosContainer').innerHTML = html;
}

// --- Detectar usuario logueado ---
onAuthStateChanged(auth, async (user) => {
  if(user){
    try{
      const token = await user.getIdToken();
      const res = await fetch('get_user_info.php',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({firebase_token: token})
      });
      const data = await res.json();
      if(data.status==='success'){
        const {firebase_uid, email, nombre, rol} = data.user;
        updateUI(firebase_uid,email,nombre,rol);
        // cargar eventos dinámicamente
        loadEventos(firebase_uid);
      } else{
        alert('⚠️ Error: '+data.message);
      }
    } catch(e){
      alert('⚠️ Error Firebase: '+e.message);
      console.error(e);
    }
  } else{
    window.location.href = 'login_app.html';
  }
});
</script>

</body>
</html>
