<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Compras Filtradas por Estado</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="max-w-7xl mx-auto p-6">
    <h1 class="text-3xl font-bold text-center mb-6">Compras Filtradas por Estado</h1>

    <!-- Filtro por estado -->
    <div class="mb-4 flex items-center space-x-2">
        <label for="filtroEstado" class="font-semibold">Filtrar por estado:</label>
        <select id="filtroEstado" class="border rounded px-3 py-2">
            <option value="">Todos</option>
            <option value="APPROVED">APPROVED</option>
            <option value="DECLINED">CANCELLED</option>
            <option value="ERROR">ERROR</option>
			 <option value="Pendiente">Pendiente</option>
        </select>
    </div>

    <table class="min-w-full bg-white rounded-lg shadow overflow-hidden" id="tablaCompras">
        <thead class="bg-orange-600 text-white">
            <tr>
                <th class="px-4 py-2">ID Compra</th>
                <th class="px-4 py-2">Usuario</th>
                <th class="px-4 py-2">Estado</th>
                <th class="px-4 py-2">Total</th>
                <th class="px-4 py-2">ID Detalle</th>
                <th class="px-4 py-2">ID Foto</th>
                <th class="px-4 py-2">Foto</th>
            </tr>
        </thead>
        <tbody id="tbodyCompras">
            <tr><td colspan="7" class="text-center py-4">Cargando...</td></tr>
        </tbody>
        <tfoot id="tfootTotales"></tfoot>
    </table>
</div>

<script>
async function cargarCompras(estadoFiltro = '') {
    const tbody = document.getElementById('tbodyCompras');
    const tfoot = document.getElementById('tfootTotales');
    tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Cargando...</td></tr>';
    tfoot.innerHTML = '';

    try {
        const res = await fetch('get_compras2.php');
        const data = await res.json();

        if(data.status === 'success' && data.compras.length > 0){
            tbody.innerHTML = '';
            let totalFiltrado = 0;

            data.compras.forEach(c => {
                if(estadoFiltro && c.estado !== estadoFiltro) return; // Filtrar solo el estado seleccionado

                totalFiltrado += parseFloat(c.total);

                if(c.detalles && c.detalles.length > 0){
                    c.detalles.forEach((d, index) => {
                        tbody.innerHTML += `
                            <tr class="border-b hover:bg-gray-50">
                                <td class="px-4 py-2">${index === 0 ? c.id : ''}</td>
                                <td class="px-4 py-2">${index === 0 ? c.usuario_nombre : ''}</td>
                                <td class="px-4 py-2">${index === 0 ? c.estado : ''}</td>
                                <td class="px-4 py-2">${index === 0 ? c.total : ''}</td>
                                <td class="px-4 py-2">${d.id}</td>
                                <td class="px-4 py-2">${d.id_foto}</td>
                                <td class="px-4 py-2">
                                    ${d.nombre_archivo ? `<img src="${d.nombre_archivo}" class="w-16 h-16 object-cover rounded border" alt="Foto ${d.id_foto}">` : '-'}
                                </td>
                            </tr>
                        `;
                    });
                } else {
                    tbody.innerHTML += `
                        <tr class="border-b hover:bg-gray-50">
                            <td class="px-4 py-2">${c.id}</td>
                            <td class="px-4 py-2">${c.usuario_nombre}</td>
                            <td class="px-4 py-2">${c.estado}</td>
                            <td class="px-4 py-2">${c.total}</td>
                            <td colspan="3" class="text-center">No hay detalles</td>
                        </tr>
                    `;
                }
            });

            // Mostrar solo total de la vista filtrada
            tfoot.innerHTML = `
                <tr class="bg-gray-300 font-bold text-lg">
                    <td colspan="3" class="px-4 py-2 text-right">Total ${estadoFiltro || 'General'}:</td>
                    <td class="px-4 py-2">${totalFiltrado.toFixed(2)}</td>
                    <td colspan="3"></td>
                </tr>
            `;

        } else {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">No hay compras registradas para este estado.</td></tr>';
        }
    } catch(err){
        console.error('Error fetch:', err);
        tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4 text-red-600">Error al cargar compras</td></tr>';
    }
}

// Evento para filtro por select
document.getElementById('filtroEstado').addEventListener('change', (e) => {
    cargarCompras(e.target.value);
});

// Carga inicial
cargarCompras();
</script>

</body>
</html>
