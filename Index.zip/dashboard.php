<?php
// ================================================================
// ARCHIVO: index.php
// ================================================================
// No hay lógica PHP pesada aquí, solo genera el HTML y los scripts del cliente.
// Los datos sensibles del usuario se cargan a través de AJAX después de que el usuario se autentica en el cliente.
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenida - LatinGroup</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background-color: #f4f4f4;
      color: #333;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      min-height: 90vh;
    }
    .container {
      max-width: 800px;
      width: 100%;
      padding: 20px 40px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      box-sizing: border-box;
      margin-bottom: 20px;
    }
    h1, h2 {
      text-align: center;
      color: #0056b3;
      margin-bottom: 25px;
    }
    .section {
      padding: 15px 0;
      border-bottom: 1px solid #eee;
    }
    .section:last-of-type {
      border-bottom: none;
    }
    button {
      background-color: #007bff;
      color: white;
      padding: 10px 15px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
      margin-right: 10px;
    }
    button:hover {
      background-color: #0056b3;
    }
    #logoutButton {
        background-color: #dc3545; /* Rojo para cerrar sesión */
    }
    #logoutButton:hover {
        background-color: #c82333;
    }
    #message {
      background-color: #e2f0fb;
      color: #31708f;
      border: 1px solid #bce8f1;
      border-radius: 4px;
      padding: 10px;
      margin-top: 20px;
      text-align: center;
      display: none;
      font-weight: bold;
    }
    #message.success { background-color: #d4edda; color: #155724; border-color: #c3e6cb; }
    #message.error { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb; }
  </style>

  <!-- Carga los SDK de Firebase de forma modular desde CDN -->
  <script type="module" src="https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js"></script>
  <script type="module" src="https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js"></script>
  
  <!-- Tu script de configuración de Firebase local -->
  <script type="module" src="./firebase-config.js"></script>
</head>
<body>
  <div class="container">
    <header>
      <h1>Bienvenido a LatinGroup</h1>
    </header>

    <main>
      <!-- Contenido visible para TODOS (incluso si no han iniciado sesión) -->
      <section id="publicContent" class="section">
        <h2>Explora Nuestros Servicios</h2>
        <p>Descubre eventos, busca fotógrafos y organiza tus próximos proyectos. ¡Todo en un solo lugar!</p>
        <p>Para acceder a funcionalidades avanzadas, inicia sesión o regístrate.</p>
        <button onclick="window.location.href='./login_app.html'">Iniciar Sesión</button>
        <button onclick="window.location.href='./index.html'">Registrarse</button>
      </section>

      <!-- Contenido visible solo para usuarios LOGUEADOS -->
      <section id="loggedInContent" class="section" style="display: none;">
        <h2>Tu Panel Personal</h2>
        <p id="welcomeMessage">Cargando información del usuario...</p>
        
        <!-- Div para la información personalizada obtenida de PHP -->
        <div id="customUserInfo" style="display: none;">
            <h3>Información Adicional (desde PHP):</h3>
            <p id="phpUserName">Nombre: </p>
            <p id="phpUserRole">Rol: </p>
            <p id="phpUserSince">Miembro desde: </p>
        </div>

        <button id="logoutButton">Cerrar Sesión</button>
      </section>

      <!-- Div para mostrar mensajes al usuario -->
      <div id="message" style="display: none;"></div>
    </main>
  </div>

  <!-- Tu script de lógica JavaScript para manejar la UI y la comunicación con PHP -->
  <script type="module" src="./index.js"></script>
</body>
</html>
