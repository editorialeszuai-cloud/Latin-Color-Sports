<?php
// cambiar_rol.php
header('Content-Type: application/json');

// --- CONFIGURACIÓN DE TU SERVIDOR (Jaguar cPanel) ---
$host = 'database-1.c8302k404lkf.us-east-1.rds.amazonaws.com';
$db   = 'latincolors'; // <--- CAMBIA ESTO
$user = 'admin';      // <--- CAMBIA ESTO
$pass = 'DannyCruxTecnoLoad!#';     // <--- CAMBIA ESTO
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Recibir datos del frontend
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!isset($data['nuevo_rol']) || !isset($data['uid'])) {
        echo json_encode(['status' => 'error', 'message' => 'Datos incompletos']);
        exit;
    }

    $nuevoRol = $data['nuevo_rol'];
    $uid = $data['uid'];

    // Ejecutamos la actualización basada en tu tabla 'usuarios'
    $stmt = $pdo->prepare("UPDATE usuarios SET rol = ? WHERE firebase_uid = ?");
    $result = $stmt->execute([$nuevoRol, $uid]);

    if ($result) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No se pudo actualizar']);
    }

} catch (\PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión: ' . $e->getMessage()]);
}
?>