<?php
require 'dbfotografos.php';
$pdo = conectar();

$compra_id = $_GET['compra_id'] ?? '';
if (!$compra_id) {
    die('<p style="color:red; text-align:center; padding:20px;">Error: ID de compra no especificado.</p>');
}

try {
    $stmt = $pdo->prepare("SELECT * FROM compras WHERE id = ?");
    $stmt->execute([$compra_id]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$compra) die('Error: Orden no encontrada.');

    $stmt = $pdo->prepare("
        SELECT d.precio, d.id_foto, d.evento_id AS detalle_evento_id, 
               f.url AS foto_url, e.titulo AS evento_titulo, l.pais
        FROM detalle_compras d
        LEFT JOIN fotos f ON d.id_foto = f.id
        LEFT JOIN postulaciones p ON f.postulacion_id = p.id
        LEFT JOIN eventos e ON (d.evento_id = e.id OR p.evento_id = e.id)
        LEFT JOIN lugares l ON e.lugar_id = l.id
        WHERE d.id_compra = ?
    ");
    $stmt->execute([$compra_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $pais_evento = 'Desconocido';
    foreach ($items as $item) {
        if (!empty($item['detalle_evento_id'])) {
            $stmtLugar = $pdo->prepare("SELECT l.pais FROM eventos e JOIN lugares l ON e.lugar_id = l.id WHERE e.id = ?");
            $stmtLugar->execute([$item['detalle_evento_id']]);
            $resLugar = $stmtLugar->fetch(PDO::FETCH_ASSOC);
            if ($resLugar) {
                $pais_evento = $resLugar['pais'];
                break;
            }
        }
        if ($pais_evento === 'Desconocido' && !empty($item['pais'])) {
            $pais_evento = $item['pais'];
        }
    }
    
    $es_colombia = (strcasecmp(trim((string)$pais_evento), 'Colombia') === 0);
    $total_precio = (float)$compra['total'];
    $transaccion_id = $compra['referencia'];

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Checkout | Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php if (!$es_colombia): ?>
	<script src="https://www.paypal.com/sdk/js?client-id=Aa68foa36e57VmIGOuZZgPPawQwUZfozju0iWa7CXCbhUOf4GP8Ux9TS1_RaHOotgTD6CQgMF2dRHtJh&currency=USD"></script>
   <?php endif; ?>
</head>
<body class="bg-[#050505] text-white font-sans min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-[#0f0f0f] border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
        <div class="p-6 border-b border-white/5 bg-black/40 text-center">
            <h1 class="text-xl font-black italic uppercase tracking-tighter">Latin Color <span class="text-orange-500">Sports</span></h1>
        </div>

        <div class="p-6">
            <div class="space-y-3 max-h-48 overflow-y-auto custom-scroll pr-2 mb-6">
                <?php foreach($items as $item): ?>
                    <div class="flex items-center gap-3 bg-white/5 p-2 rounded-xl border border-white/5">
                        <img src="<?= htmlspecialchars($item['foto_url'] ?? 'uploads/idevento.jpg') ?>" class="w-10 h-10 object-cover rounded-lg">
                        <div class="flex-1 min-w-0">
                            <p class="text-[9px] text-gray-500 truncate uppercase font-bold"><?= htmlspecialchars($item['evento_titulo'] ?? 'Evento') ?></p>
                            <p class="text-[11px]"><?= $item['id_foto'] ? "Foto #".$item['id_foto'] : "Pack Completo" ?></p>
                        </div>
                        <p class="text-xs font-bold">
                            $<?= number_format((float)$item['precio'], 2, ',', '.') ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="text-center mb-8">
                <p class="text-[11px] text-gray-500 uppercase font-black mb-1">Total a pagar</p>
                <div class="text-3xl font-black">
                    <?= number_format($total_precio, 2, ',', '.') ?> <span class="text-sm text-gray-500"><?= $es_colombia ? 'COP' : 'USD' ?></span>
                </div>
            </div>

            <div id="paypal-button-container">
                <?php if ($es_colombia): ?>
                    <p class="text-center text-gray-500 text-xs">Pago disponible en moneda local.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
	
	<div id="wallet_container"></div>

    <?php if (!$es_colombia): ?>
	
	

	<script>
    const totalCompra = "<?php echo number_format((float)$total_precio, 2, '.', ''); ?>";
    const idCompra = "<?php echo (int)$compra_id; ?>";

    paypal.Buttons({
    // --- ESTA ES LA PARTE QUE DEBES AGREGAR/MODIFICAR ---
    funding: {
        allowed: [ 
            paypal.FUNDING.PAYPAL 
        ],
        disallowed: [ 
            paypal.FUNDING.CARD,
            paypal.FUNDING.CREDIT,
            paypal.FUNDING.VENMO
        ]
    },

        createOrder: async () => {
            const response = await fetch("paypal_logic.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ 
                    action: "create", 
                    total: totalCompra,
                    compra_id: idCompra // Asegúrate de enviarlo
                })
            });
            const orderData = await response.json();
            return orderData.id;
        },

        onApprove: async (data) => {
            const response = await fetch("paypal_logic.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ 
                    action: "capture", 
                    orderID: data.orderID,
                    compra_id: idCompra 
                })
            });
            const result = await response.json();

            if (result.status === "COMPLETED") {
                window.location.href = `responsepaypal.php?id=${idCompra}&ref=${data.orderID}`;
            } else {
                // Si falla la captura, mostramos el error detallado
                alert("El pago no fue capturado por PayPal. Motivo: " + (result.details?.[0]?.description || "Error desconocido"));
            }
        },

        // MANEJO ESPECÍFICO DEL ERROR DE FORMULARIO
        onError: function (err) {
            console.error("PayPal Error:", err);
            alert("Hubo un error con el método de pago seleccionado. Por favor intenta de nuevo o usa otro método.");
        }
    }).render("#paypal-button-container");
</script>
    <?php endif; ?>
</body>
</html>