<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard de Usuario</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <!-- TailwindCSS -->
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    body { font-family: 'Inter', sans-serif; background-color: #f3f4f6; }

    /* Estilos según el rol */
    .role-admin { background-color: #fecaca; color: #7f1d1d; }
    .role-cliente { background-color: #bfdbfe; color: #1e3a8a; }
    .role-usuario_basico { background-color: #bbf7d0; color: #064e3b; }
  </style>
</head>

<body class="flex items-center justify-center min-h-screen p-4">

  <div id="dashboardContainer" class="w-full max-w-2xl bg-white p-8 rounded-xl shadow-xl hidden">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-3xl font-bold text-gray-900">Panel de Usuario</h1>
      <button id="logoutButton"
        class="py-2 px-4 rounded-lg bg-red-600 text-white hover:bg-red-700 transition">
        Cerrar Sesión
      </button>
    </div>

    <p class="text-gray-600 mb-6">
      Tu información ha sido obtenida desde Firebase y la base de datos MySQL.
    </p>

    <!-- Datos del usuario -->
    <div class="bg-indigo-50 p-6 rounded-lg border border-indigo-200 shadow-inner">
      <h2 class="text-xl font-semibold text-indigo-700 mb-4">Detalles del Usuario</h2>
      <div class="space-y-2 text-gray-700">
        <p><strong>UID:</strong> <span id="userId" class="font-mono text-sm block">Cargando...</span></p>
        <p><strong>Email:</strong> <span id="userEmail" class="font-medium">Cargando...</span></p>
        <p><strong>Nombre:</strong> <span id="userName" class="font-medium">Cargando...</span></p>
        <p><strong>Rol:</strong>
          <span id="userRole" class="inline-block px-3 py-1 text-xs font-semibold rounded-full">
            Cargando...
          </span>
        </p>
      </div>
    </div>

    <div id="roleContent" class="mt-8 space-y-4"></div>

    <p id="loadingMessage" class="mt-8 text-center text-gray-500">Verificando sesión...</p>
  </div>

  <script type="module">
    // ==========================
    // CONFIGURACIÓN DE FIREBASE
    // ==========================
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
    import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

    const firebaseConfig = {
      apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
      authDomain: "latin-group-406b1.firebaseapp.com",
      projectId: "latin-group-406b1",
      storageBucket: "latin-group-406b1.appspot.com",
      messagingSenderId: "21494348297",
      appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
    };

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);

    // ==========================
    // ELEMENTOS DEL DOM
    // ==========================
    const dashboardContainer = document.getElementById('dashboardContainer');
    const userIdSpan = document.getElementById('userId');
    const userEmailSpan = document.getElementById('userEmail');
    const userNameSpan = document.getElementById('userName');
    const userRoleSpan = document.getElementById('userRole');
    const roleContentDiv = document.getElementById('roleContent');
    const loadingMessage = document.getElementById('loadingMessage');
    const logoutButton = document.getElementById('logoutButton');

    // ==========================
    // FUNCIÓN: Obtener info desde PHP
    // ==========================
    async function fetchUserInfo(user) {
      try {
        const token = await user.getIdToken();

        const response = await fetch('get_user_info.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ firebase_token: token })
        });

        if (!response.ok) throw new Error(`Error del servidor: ${response.status}`);
        const data = await response.json();
        console.log("Respuesta del backend:", data);

        if (data.status === 'success' && data.user) {
          const u = data.user;
          updateUI(u.firebase_uid, u.email, u.nombre, u.rol);
          renderRoleContent(u.rol);
        } else {
          throw new Error('No se encontró el usuario en la base de datos.');
        }

      } catch (err) {
        console.error("Error al obtener datos:", err);
        updateUI(user.uid, user.email, "Desconocido", "cliente");
        renderRoleContent("cliente");
      }
    }

    // ==========================
    // FUNCIÓN: Actualiza UI
    // ==========================
    function updateUI(uid, email, nombre, rol) {
      dashboardContainer.classList.remove('hidden');
      loadingMessage.classList.add('hidden');
      userIdSpan.textContent = uid;
      userEmailSpan.textContent = email || "Sin correo";
      userNameSpan.textContent = nombre || "Sin nombre";
      userRoleSpan.textContent = rol || "cliente";
      userRoleSpan.className = `inline-block px-3 py-1 text-xs font-semibold rounded-full role-${rol}`;
    }

    // ==========================
    // FUNCIÓN: Contenido según rol
    // ==========================
    function renderRoleContent(rol) {
      let html = '';
      if (rol === 'admin') {
        html = `<?php require 'usuarios.php'; ?>`;
      } else {
        html = `
          <div class="bg-blue-100 border-l-4 border-blue-600 p-4 rounded">
            <p class="font-bold">Panel de Cliente</p>
            <p>Acceso básico a tu cuenta y perfil personal.</p>
          </div>`;
      }
      roleContentDiv.innerHTML = html;
    }

    // ==========================
    // CERRAR SESIÓN
    // ==========================
    logoutButton.addEventListener('click', async () => {
      try {
        await signOut(auth);
        window.location.href = 'login_app.html';
      } catch (error) {
        console.error("Error al cerrar sesión:", error);
      }
    });

    // ==========================
    // LISTENER DE SESIÓN
    // ==========================
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        console.log("Usuario autenticado:", user.email);
        await fetchUserInfo(user);
      } else {
        console.log("No autenticado. Redirigiendo...");
        window.location.href = 'login_app.html';
      }
    });
  </script>
</body>
</html>
