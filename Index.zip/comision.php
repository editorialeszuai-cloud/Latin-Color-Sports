<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Todas las Comisiones de Latin Colors Sports</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
<br>
<div class="max-w-6xl mx-auto">
    <h1 class="text-3xl font-bold text-center mb-6">Todas las Comisiones</h1>

    <table class="min-w-full bg-white rounded-lg shadow overflow-hidden" id="tablaComisiones">
        <thead class="bg-orange-600 text-white">
            <tr>
                <th class="px-4 py-2">ID Comisi��n</th>
                <th class="px-4 py-2">Compra ID</th>
                <th class="px-4 py-2">C. Admin</th>
                <th class="px-4 py-2">C. Fotografo</th>
                <th class="px-4 py-2">C. Comercial</th>
                <th class="px-4 py-2">C. Organizador</th>
                <th class="px-4 py-2">C. Soporte</th>
                <th class="px-4 py-2">Total</th>
                <th class="px-4 py-2">Foto</th>
                <th class="px-4 py-2">Evento</th>
            </tr>
        </thead>
        <tbody id="tbodyComisiones">
            <tr><td colspan="7" class="text-center py-4">Cargando...</td></tr>
        </tbody>
    </table>
</div>
<script>
function formatoMoneda(valor) {
    // Aseguramos que sea un n�mero (float)
    const num = parseFloat(valor) || 0;
    // Formato con punto como decimal y coma para miles
    return '$' + num.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

async function cargarComisiones() {
    const tbody = document.getElementById('tbodyComisiones');
    try {
        const res = await fetch('get_comisiones2.php');
        const data = await res.json();

    // ... dentro del try { ...
if(data.status === 'success' && data.comisiones.length > 0){
    let htmlRows = ''; 
    let t = { admin: 0, foto: 0, com: 0, org: 0, sop: 0, gen: 0 };
    
    // Filtro para IDs �nicos
    const idsProcesados = new Set(); 

// ... (dentro de if(data.status === 'success' ... )

    data.comisiones.forEach(c => {
        // ... (tu l�gica de limpieza y suma dentro del forEach sigue igual)
        if (idsProcesados.has(c.comision_id)) return;
        idsProcesados.add(c.comision_id);

        let a = parseFloat(String(c.comision_admin).replace(',', '.')) || 0;
        a = Math.max(0, a - 0.01); 
        
        const f = parseFloat(String(c.comision_fotografo).replace(',', '.')) || 0;
        const co = parseFloat(String(c.comision_comercial).replace(',', '.')) || 0;
        const o = parseFloat(String(c.comision_organizador).replace(',', '.')) || 0;
        const s = parseFloat(String(c.comision_soporte).replace(',', '.')) || 0;
        
        const totalFila = a + f + co + o + s;

        t.admin = Math.round((t.admin + a) * 100) / 100;
        t.foto  = Math.round((t.foto + f) * 100) / 100;
        t.com   = Math.round((t.com + co) * 100) / 100;
        t.org   = Math.round((t.org + o) * 100) / 100;
        t.sop   = Math.round((t.sop + s) * 100) / 100;
        t.gen   = Math.round((t.gen + totalFila) * 100) / 100;

        htmlRows += `
            <tr class="border-b hover:bg-gray-50">
                <td class="px-4 py-2">${c.comision_id}</td>
                <td class="px-4 py-2">${c.compra_id}</td>
                <td class="px-4 py-2">${formatoMoneda(a)}</td>
                <td class="px-4 py-2">${formatoMoneda(f)}</td>
                <td class="px-4 py-2">${formatoMoneda(co)}</td>
                <td class="px-4 py-2">${formatoMoneda(o)}</td>
                <td class="px-4 py-2">${formatoMoneda(s)}</td>
                <td class="px-4 py-2 font-bold">${formatoMoneda(totalFila)}</td>
                <td class="px-4 py-2">${c.nombre_archivo ? `<img src="${c.nombre_archivo}" class="w-10 h-10 object-cover rounded">` : '-'}</td>
                <td class="px-4 py-2 text-xs">${c.evento_titulo}</td>
            </tr>`;
    });

    // --- AGREGA ESTO AQU�: La fila de totales ---
    htmlRows += `
        <tr class="bg-orange-600 text-white font-bold">
            <td colspan="2" class="px-4 py-3 text-center">TOTALES</td>
            <td class="px-4 py-3">${formatoMoneda(t.admin)}</td>
            <td class="px-4 py-3">${formatoMoneda(t.foto)}</td>
            <td class="px-4 py-3">${formatoMoneda(t.com)}</td>
            <td class="px-4 py-3">${formatoMoneda(t.org)}</td>
            <td class="px-4 py-3">${formatoMoneda(t.sop)}</td>
            <td class="px-4 py-3">${formatoMoneda(t.gen)}</td>
            <td colspan="2"></td>
        </tr>`;

    tbody.innerHTML = htmlRows; // Ahora actualiza todo de golpe
        } else {
            tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4">No hay datos.</td></tr>';
        }
    } catch(err) { 
        console.error(err); 
        tbody.innerHTML = '<tr><td colspan="10" class="text-center py-4 text-red-500">Error al cargar datos.</td></tr>';
    }
}
cargarComisiones();
</script>