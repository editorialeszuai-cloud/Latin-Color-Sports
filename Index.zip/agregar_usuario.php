<?php
// Backend PHP en la misma hoja
require_once 'conexion.php';
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;

$conn = conectar();
$factory = (new Factory)->withServiceAccount(__DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json');
$auth = $factory->createAuth();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'register') {
        $idToken = $_POST['idToken'] ?? '';
        $role = $_POST['role'] ?? 'cliente';

        try {
            $verifiedToken = $auth->verifyIdToken($idToken);
            $firebase_uid = $verifiedToken->claims()->get('sub');

            $user_name = $_POST['nombre'] ?? '';
            $user_email = $_POST['email'] ?? '';

            $foto_perfil = null;
            if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
                $nombreArchivo = time() . "_" . basename($_FILES['foto_perfil']['name']);
                $rutaDestino = "uploads/" . $nombreArchivo;
                if (move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $rutaDestino)) {
                    $foto_perfil = $rutaDestino;
                }
            }

            $stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, rol, foto_perfil, firebase_uid) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $user_name, $user_email, $role, $foto_perfil, $firebase_uid);

            if ($stmt->execute()) {
                echo json_encode(['status' => 'success', 'message' => 'Usuario registrado correctamente']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Error al guardar usuario']);
            }

        } catch (\Kreait\Firebase\Exception\AuthException $e) {
            echo json_encode(['status'=>'error','message'=>'Token inválido: '.$e->getMessage()]);
        }
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Registro Usuarios Firebase + PHP</title>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.message { margin-top:10px; padding:5px; border-radius:5px; }
.message.success { background: #D1FAE5; color: #065F46; }
.message.error { background: #FEE2E2; color: #991B1B; }
</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

<div class="bg-white p-6 rounded-lg shadow-lg w-96">
<h2 class="text-xl font-semibold mb-4 text-gray-800">Registro de Usuario</h2>

<form id="registerForm" enctype="multipart/form-data" class="space-y-4">
    <input type="hidden" name="action" value="register">
    <div>
        <label class="block text-sm font-medium text-gray-700">Nombre</label>
        <input type="text" id="nombre" name="nombre" class="mt-1 w-full border rounded-lg p-2" required>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Email</label>
        <input type="email" id="email" name="email" class="mt-1 w-full border rounded-lg p-2" required>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Contraseña</label>
        <input type="password" id="password" name="password" class="mt-1 w-full border rounded-lg p-2" required>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Rol</label>
        <select id="userRole" name="role" class="mt-1 w-full border rounded-lg p-2">
            <option value="cliente">Cliente</option>
            <option value="admin">Administrador</option>
            <option value="fotografo">Fotógrafo</option>
            <option value="organizador">Organizador</option>
        </select>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700">Foto de Perfil</label>
        <input type="file" id="foto_perfil" name="foto_perfil" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
    </div>

    <div class="flex justify-between mt-4">
        <button type="submit" class="bg-indigo-600 text-white px-3 py-1 rounded hover:bg-indigo-700">Registrar Email</button>
        <button type="button" id="googleRegister" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700">Google</button>
        <button type="button" id="facebookRegister" class="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700">Facebook</button>
    </div>
</form>

<div id="message" class="message" style="display:none;"></div>
</div>

<script>
// Config Firebase
const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.appspot.com",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

const nombreInput = document.getElementById('nombre');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const userRoleSelect = document.getElementById('userRole');
const registerForm = document.getElementById('registerForm');
const googleButton = document.getElementById('googleRegister');
const facebookButton = document.getElementById('facebookRegister');
const messageDiv = document.getElementById('message');

function showMessage(msg,type){messageDiv.textContent=msg;messageDiv.className=`message ${type}`;messageDiv.style.display='block';}

// Enviar datos a PHP
async function sendUserToPHP(idToken){
    const formData = new FormData(registerForm);
    formData.append('idToken', idToken);

    const response = await fetch('', { method:'POST', body: formData });
    const data = await response.json();
    showMessage(data.message, data.status==='success'?'success':'error');
}

// Registro Email/Password
registerForm.addEventListener('submit', async e=>{
    e.preventDefault();
    const nombre = nombreInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();
    if(!nombre||!email||!password){showMessage('Rellena todos los campos','error'); return;}
    auth.createUserWithEmailAndPassword(email,password)
        .then(userCredential=>{
            const user = userCredential.user;
            return user.updateProfile({displayName:nombre}).then(()=>{
                return user.sendEmailVerification().then(()=>{
                    showMessage('Registro exitoso, verifica tu correo','success');
                    return user.getIdToken().then(sendUserToPHP);
                });
            });
        }).catch(error=>{showMessage(error.message,'error');});
});

// Google
googleButton.addEventListener('click', ()=>{
    const provider = new firebase.auth.GoogleAuthProvider();
    auth.signInWithPopup(provider)
        .then(result=>result.user.getIdToken())
        .then(sendUserToPHP)
        .catch(error=>showMessage(error.message,'error'));
});

// Facebook
facebookButton.addEventListener('click', ()=>{
    const provider = new firebase.auth.FacebookAuthProvider();
    auth.signInWithPopup(provider)
        .then(result=>result.user.getIdToken())
        .then(sendUserToPHP)
        .catch(error=>showMessage(error.message,'error'));
});
</script>

</body>
</html>
