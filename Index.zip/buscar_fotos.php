<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'dbfotografos.php';
header('Content-Type: application/json; charset=utf-8');

$evento_id         = $_POST['evento_id'] ?? 0;
$filtroDisciplina  = $_POST['disciplina'] ?? '';
$filtroEscenario   = $_POST['escenario'] ?? '';
$filtroSede        = $_POST['sede'] ?? '';
$filtroFecha       = $_POST['fecha'] ?? '';
$filtroHora        = $_POST['hora'] ?? '';
$filtroDescripcion = $_POST['descripcion'] ?? '';
$filtroEtiqueta    = $_POST['etiqueta'] ?? '';
$filtroGaleria     = $_POST['galeria'] ?? '';
$filtroFotografo   = $_POST['fotografo'] ?? '';

if($evento_id <= 0){
    echo json_encode(['error'=>'ID de evento inválido']);
    exit;
}

// Consulta base
$sql = "
SELECT 
    f.id AS id,
    f.url,
    f.descripcion AS foto_descripcion,
    f.galeria_id,
    fa.etiqueta AS etiquetas
FROM fotos f
INNER JOIN postulaciones p ON f.postulacion_id = p.id
LEFT JOIN calendario_fotografos cf ON cf.postulacion_id = f.postulacion_id
LEFT JOIN disciplinas d ON d.id = cf.disciplina_id
LEFT JOIN escenarios es ON es.id = cf.escenario_id
LEFT JOIN sedes se ON se.id = cf.sede_id
LEFT JOIN analisis_fotos fa ON fa.foto_id = f.id
WHERE p.evento_id = ?
";

$params = [$evento_id];

// Filtros
if($filtroDescripcion){
    $sql .= " AND f.descripcion LIKE ? ";
    $params[] = "%$filtroDescripcion%";
}
if($filtroDisciplina){
    $sql .= " AND cf.disciplina_id = ? ";
    $params[] = $filtroDisciplina;
}
if($filtroEscenario){
    $sql .= " AND cf.escenario_id = ? ";
    $params[] = $filtroEscenario;
}
if($filtroSede){
    $sql .= " AND cf.sede_id = ? ";
    $params[] = $filtroSede;
}
if($filtroFecha){
    $sql .= " AND cf.fecha = ? ";
    $params[] = $filtroFecha;
}
if($filtroHora){
    $sql .= " AND cf.hora = ? ";
    $params[] = $filtroHora;
}
if($filtroEtiqueta){
    $sql .= " AND fa.etiqueta LIKE ? ";
    $params[] = "%$filtroEtiqueta%";
}
if($filtroGaleria){
    $sql .= " AND f.galeria_id = ? ";
    $params[] = $filtroGaleria;
}
if($filtroFotografo){
    $sql .= " AND p.usuario_id = ? ";
    $params[] = $filtroFotografo;
}

$sql .= " ORDER BY f.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Agregar descriptores de cada foto
foreach($fotos as &$f){
    $stmtFaces = $pdo->prepare("SELECT descriptor FROM faces WHERE foto_id = ?");
    $stmtFaces->execute([$f['id']]);
    $faces = $stmtFaces->fetchAll(PDO::FETCH_ASSOC);

    $descriptors = [];
    foreach($faces as $row){
        $desc = json_decode($row['descriptor'], true);
        if($desc && is_array($desc)){
            $descriptors[] = array_values($desc);
        }
    }
    $f['descriptors'] = $descriptors;
}

// Devolver JSON
echo json_encode(['fotos'=>$fotos]);
