<?php
// --- MODO TRIGGER: Ejecución desde Task Scheduler ---
if (php_sapi_name() === 'cli') {
    require 'dbfotografos.php';
    // El Trigger mantiene el registro limpio y sincronizado
    $pdo->query("INSERT IGNORE INTO log_procesamiento (foto_id) 
                 SELECT id FROM fotos WHERE id NOT IN (SELECT foto_id FROM log_procesamiento)");
    exit;
}

// --- MODO ROBOT: Ejecución desde Navegador ---
require 'dbfotografos.php';
if (isset($_GET['get_pendientes'])) {
    header('Content-Type: application/json');
    $stmt = $pdo->query("SELECT f.id, f.url FROM fotos f 
                         WHERE NOT EXISTS (SELECT 1 FROM log_procesamiento lp WHERE lp.foto_id = f.id) 
                         LIMIT 5");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Robot Scanner Pro | Global</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-[#020617] text-white min-h-screen p-8">

<div class="max-w-6xl mx-auto">
    <div class="flex justify-between items-center mb-10">
        <div>
            <h1 class="text-4xl font-black italic uppercase">Robot <span class="text-orange-500">Scanner</span></h1>
            <p id="status-text" class="text-slate-500 font-bold uppercase tracking-widest text-xs">Cargando motores de IA...</p>
        </div>
        <div id="badge-status" class="bg-slate-900 border border-slate-700 px-4 py-2 rounded-full text-xs font-bold text-orange-500">
            <i class="fas fa-spinner fa-spin mr-2"></i> INICIALIZANDO
        </div>
    </div>

    <div id="galeria-ia" class="grid grid-cols-2 md:grid-cols-5 gap-4"></div>

    <div id="finish-msg" class="hidden flex flex-col items-center justify-center py-20 bg-slate-900/30 rounded-3xl border-2 border-dashed border-slate-800">
        <i class="fas fa-check-circle text-5xl text-green-500 mb-4"></i>
        <h2 class="text-xl font-bold uppercase">Sistema al día</h2>
        <p class="text-slate-500 text-xs">No hay fotos pendientes. El robot sigue vigilando...</p>
    </div>
</div>

<script>
    const MODEL_PATH = '../face-demo/models/';
    
    async function initIA() {
        await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_PATH);
        await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_PATH);
        await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_PATH);
        
        document.getElementById('badge-status').innerHTML = "✅ IA ONLINE";
        document.getElementById('status-text').innerText = "ESPERANDO TAREAS...";
        runScanner();
    }

    async function runScanner() {
        const res = await fetch('?get_pendientes=1');
        const fotos = await res.json();

        if (fotos.length === 0) {
            document.getElementById('finish-msg').classList.remove('hidden');
            setTimeout(runScanner, 5000);
            return;
        }

        document.getElementById('finish-msg').classList.add('hidden');
        document.getElementById('status-text').innerText = "PROCESANDO LOTE...";

        for (let f of fotos) {
            const card = document.createElement('div');
            card.className = "bg-slate-900 p-2 rounded-2xl border border-slate-700 animate-pulse";
            card.innerHTML = `<img src="imganalisis.php?img=${encodeURIComponent(f.url)}&w=100" class="w-full h-32 object-cover rounded-lg">`;
            document.getElementById('galeria-ia').appendChild(card);

            const img = card.querySelector('img');
            if (!img.complete) await new Promise(r => img.onload = r);

            const dets = await faceapi.detectAllFaces(img).withFaceLandmarks().withFaceDescriptors();
            
            // Guardar resultados
            for (let d of dets) {
                let fd = new FormData();
                fd.append('action', 'guardar_rostro');
                fd.append('foto_id', f.id);
                fd.append('descriptor', JSON.stringify(Array.from(d.descriptor)));
                await fetch(window.location.href, { method: 'POST', body: fd });
            }

            // Marcar como procesada
            let fdLog = new FormData();
            fdLog.append('action', 'marcar_escaneada');
            fdLog.append('foto_id', f.id);
            await fetch(window.location.href, { method: 'POST', body: fdLog });
            
            card.remove();
        }
        runScanner(); // Siguiente lote
    }

    window.onload = initIA;
</script>
</body>
</html>