<?php
// api_guardar_biometria.php
require_once 'dbfotografos.php'; // Tu conexión PDO
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$uid = $input['firebase_uid'] ?? null;
$descriptor = $input['descriptor'] ?? null;

if ($uid && $descriptor) {
    try {
        // Usamos INSERT ... ON DUPLICATE KEY UPDATE por si el usuario decide actualizar su foto
        $sql = "INSERT INTO perfiles_biometricos (firebase_uid, descriptor) 
                VALUES (:uid, :desc) 
                ON DUPLICATE KEY UPDATE descriptor = VALUES(descriptor)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':uid'  => $uid,
            ':desc' => $descriptor
        ]);

        echo json_encode(['status' => 'ok', 'message' => 'Perfil actualizado']);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Faltan parámetros']);
}