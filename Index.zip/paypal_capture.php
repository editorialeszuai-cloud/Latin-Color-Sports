<?php
// paypal_capture.php
require 'paypal_logic.php'; // Aquí tienes la función getPayPalAccessToken()

header('Content-Type: application/json');

// Obtener el ID de la orden desde el cuerpo de la petición (JSON)
$input = json_decode(file_get_contents('php://input'), true);
$orderID = $input['orderID'] ?? null;

if (!$orderID) {
    echo json_encode(['error' => 'No se recibió el orderID']);
    exit;
}

$accessToken = getPayPalAccessToken();

// URL de PayPal para capturar el pago
$url = "https://api-m.paypal.com/v2/checkout/orders/$orderID/capture";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $accessToken"
]);

$result = curl_exec($ch);
curl_close($ch);

echo $result; // Esto devuelve el resultado de la captura a tu JavaScript
exit;
?>