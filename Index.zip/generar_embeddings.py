import os
import json
from PIL import Image
import face_recognition  # pip install face_recognition

# Carpeta donde están tus fotos
UPLOADS_DIR = "uploads"

# Archivo donde se guardarán los embeddings
OUTPUT_FILE = "embeddings.json"

embeddings = {}

# Recorrer todas las imágenes en uploads/
for filename in os.listdir(UPLOADS_DIR):
    if not filename.lower().endswith((".jpg", ".jpeg", ".png")):
        continue

    filepath = os.path.join(UPLOADS_DIR, filename)
    
    try:
        image = face_recognition.load_image_file(filepath)
        face_locations = face_recognition.face_locations(image)
        face_encodings = face_recognition.face_encodings(image, face_locations)

        if face_encodings:
            # Guardar solo el primer rostro detectado
            embeddings[filename] = face_encodings[0].tolist()
        else:
            print(f"No se detectó rostro en {filename}")

    except Exception as e:
        print(f"Error procesando {filename}: {e}")

# Guardar embeddings en JSON
with open(OUTPUT_FILE, "w") as f:
    json.dump(embeddings, f)

print(f"Embeddings guardados en {OUTPUT_FILE}")
