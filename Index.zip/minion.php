<?php
// minion.php
require_once 'dbfotografos.php';

// Bloqueo de acceso directo desde el navegador (Por ejemplo, usando Referer)
$dominioPermitido = 'latincolorsports.com'; 
if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], $dominioPermitido) === false) {
    header('HTTP/1.0 403 Forbidden');
    echo "Acceso denegado.";
    exit;
}

$fotoId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$tipo   = $_GET['tipo'] ?? 'original'; // Captura si se pide miniatura u original

if ($fotoId > 0) {
    if ($tipo === 'mini') {
        // 1. Consultar la ruta de la miniatura en la base de datos
        $stmt = $pdo->prepare("SELECT url_miniatura FROM miniaturas WHERE foto_id = ? LIMIT 1");
        $stmt->execute([$fotoId]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($res && !empty($res['url_miniatura'])) {
            // Suponiendo que tus miniaturas están locales o en CloudFront, las sirves:
            // Si es una ruta local:
            $rutaMiniatura = __DIR__ . '/' . $res['url_miniatura'];
            
            if (file_exists($rutaMiniatura)) {
                header('Content-Type: image/avif'); // O el tipo mime correcto (avif, webp, jpeg)
                readfile($rutaMiniatura);
                exit;
            }
        }
    } else {
        // Lógica actual que ya tienes para redirigir/servir la foto original desde CloudFront
        $stmt = $pdo->prepare("SELECT url FROM fotos WHERE id = ? LIMIT 1");
        $stmt->execute([$fotoId]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($res) {
            $urlCloudFront = str_replace(
                "fotos-latincolor-2026.s3-accelerate.amazonaws.com", 
                "d3fnhkeilwwjkl.cloudfront.net", 
                $res['url']
            );
            header("Location: " . $urlCloudFront . "?w=5");
            exit;
        }
    }
}

http_response_code(404);
echo "Recurso no encontrado.";