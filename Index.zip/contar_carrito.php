<?php
require_once 'dbfotografos.php';
$uid = $_POST['firebase_uid'] ?? '';
$count = 0;
if($uid){
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM carrito WHERE firebase_uid=?");
    $stmt->execute([$uid]);
    $count = $stmt->fetchColumn();
}
echo json_encode(['count' => $count]);
