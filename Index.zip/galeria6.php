<iframe 
    src="https://api.latincolorsports.com/panel"
    width="100%"
    height="800px"
></iframe>