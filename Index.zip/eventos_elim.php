<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
ini_set("log_errors", 1);
ini_set("error_log", __DIR__ . "/error.log");

require_once "conexion.php";

$conn = conectar();

// Recibir datos JSON
$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? null;

header('Content-Type: application/json');

if (!$id) {
    echo json_encode(['status' => 'error', 'message' => 'ID de evento no proporcionado']);
    exit;
}

try {
    // Obtener archivos asociados para eliminarlos
    $stmtSelect = $conn->prepare("SELECT logo, banner, icono_foto FROM eventos WHERE id = ?");
    $stmtSelect->bind_param("i", $id);
    $stmtSelect->execute();
    $result = $stmtSelect->get_result();

    if ($row = $result->fetch_assoc()) {
        foreach (['logo', 'banner', 'icono_foto'] as $file) {
            if (!empty($row[$file]) && file_exists($row[$file])) {
                unlink($row[$file]);
            }
        }
    }

    // Eliminar evento
    $stmtDelete = $conn->prepare("DELETE FROM eventos WHERE id = ?");
    $stmtDelete->bind_param("i", $id);
    $stmtDelete->execute();

    echo json_encode(['status' => 'success', 'message' => 'Evento eliminado correctamente']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
