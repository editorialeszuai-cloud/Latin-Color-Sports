<?php
require_once __DIR__ . '/vendor/autoload.php'; // Carga el autoload de Composer

use Firebase\Auth\Token\Exception\InvalidToken;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Auth;

// 🔥 Inicializa Firebase con tu archivo de credenciales real
$serviceAccountPath = __DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json';

$factory = (new Factory)
    ->withServiceAccount($serviceAccountPath);

$auth = $factory->createAuth();

/**
 * Verifica un ID Token de Firebase y devuelve el UID si es válido
 * 
 * @param string $idToken
 * @return string|false Retorna el UID o false si el token no es válido
 */
function verifyFirebaseToken($idToken)
{
    global $auth;

    try {
        $verifiedIdToken = $auth->verifyIdToken($idToken);
        return $verifiedIdToken->claims()->get('sub'); // UID del usuario
    } catch (InvalidToken $e) {
        error_log('Token inválido: ' . $e->getMessage());
        return false;
    } catch (\InvalidArgumentException $e) {
        error_log('Token malformado: ' . $e->getMessage());
        return false;
    } catch (\Throwable $e) {
        error_log('Error al verificar token: ' . $e->getMessage());
        return false;
    }
}
?>
