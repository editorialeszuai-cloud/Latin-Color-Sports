<?php
require_once 'navusuriopre.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Colecciones </title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<style>
.card { 
    transition: all 0.3s ease; 
    border-radius: 16px; 
    overflow: hidden; 
    text-align: center; 
    border: 1px solid #eee; 
    background: #ff9800; 
}
.card:hover { 
    transform: translateY(-5px); 
    box-shadow: 0 8px 18px rgba(0,0,0,0.2); 
}
.card img { 
    width: 150px; 
    height: 150px; 
    object-fit: cover; 
    border-radius: 12px; 
    border: 2px solid #fff; 
    transition: transform 0.3s ease; 
}
.card img:hover { 
    transform: scale(1.05); 
}
.card a.button { 
    display: inline-flex; 
    align-items: center; 
    justify-content: center; 
    gap: 5px; 
    margin-top: 10px; 
    padding: 8px 14px; 
    background-color:black; 
    color: white; 
    border-radius: 50px; 
    text-decoration: none; 
    font-size: 0.9rem; 
    transition: background 0.3s, transform 0.2s; 
}
.card a.button:hover { 
    background: linear-gradient(90deg,#1e40af,#1d4ed8); 
    transform: scale(1.05); 
}
.footer-info { 
    font-size: 0.8rem; 
    color: #777; 
    margin-top: 10px; 
}
</style>
</head>
<body class="bg-gray-100 p-6">

<h1 class="text-3xl font-bold text-center text-gray-800">Mis Colecciones</h1>

<div id="fotosContainer" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-6">
    <p class="text-center text-gray-600 col-span-full">Cargando tus fotos...</p>
</div>

<script>
const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

async function cargarGaleria(uid) {
    try {
        const res = await fetch('mis_galeria_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ firebase_uid: uid })
        });
        const data = await res.json();
        const container = document.getElementById('fotosContainer');
        container.innerHTML = '';

        if (!data.success) {
            container.innerHTML = `<p class="text-center text-red-600 col-span-full">${data.message}</p>`;
            return;
        }

        if (!data.fotos || data.fotos.length === 0) {
            container.innerHTML = '<p class="text-center text-gray-600 col-span-full">No has agregado fotos a tu galería aún.</p>';
            return;
        }

        data.fotos.forEach(f => {
            const div = document.createElement('div');
            div.className = 'card p-4';
            div.innerHTML = `
                <img src="uploads/${f.nombre_archivo}" alt="Foto ${f.foto_id}">
                <h2 class="text-lg font-bold text-gray-800 mt-2">${f.evento_titulo}</h2>
                <a href="fotos.php?id=${f.foto_id}" class="button">Ver Imagen</a>
                <div class="footer-info">${new Date(f.fecha_creacion).toLocaleString()}</div>
            `;
            container.appendChild(div);
        });

    } catch(e) {
        console.error(e);
        document.getElementById('fotosContainer').innerHTML = '<p class="text-center text-red-600 col-span-full">Error al cargar las fotos.</p>';
    }
}

auth.onAuthStateChanged(user => {
    const container = document.getElementById('fotosContainer');
    if (user) {
        cargarGaleria(user.uid);
    } else {
        container.innerHTML = `
            <div class="col-span-full flex flex-col items-center justify-center min-h-[60vh] relative overflow-hidden rounded-3xl border border-gray-100 shadow-2xl bg-white">
                
                <div class="absolute -top-24 -left-24 w-64 h-64 bg-orange-100 rounded-full blur-3xl opacity-50"></div>
                <div class="absolute -bottom-24 -right-24 w-80 h-80 bg-orange-200 rounded-full blur-3xl opacity-30"></div>

                <div class="relative z-10 flex flex-col items-center p-8 text-center">
                    <div class="w-20 h-20 bg-orange-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-orange-200 transform rotate-3">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </div>

                    <h2 class="text-3xl font-extrabold text-gray-800 mb-2">Tus recuerdos te esperan</h2>
                    <p class="text-gray-500 max-w-sm mb-8 leading-relaxed">
                        Inicia sesión para descubrir las fotografías exclusivas de tus eventos y elige tus favoritas para llevar a casa.
                    </p>

                    <div class="flex flex-col sm:flex-row gap-4 w-full justify-center">
                        <button onclick="window.location.href='login_app.html'" 
                            class="bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-10 rounded-2xl transition-all hover:scale-105 active:scale-95 shadow-xl shadow-orange-200 flex items-center justify-center gap-2">
                            <span>Ingresar a mi cuenta</span>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                              <path fill-rule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V3zm9 7a1 1 0 000-2H6a1 1 0 000 2h6z" clip-rule="evenodd" />
                            </svg>
                        </button>
                    </div>

                    <div class="mt-12 flex gap-3 opacity-20 grayscale">
                        <div class="w-16 h-16 bg-gray-300 rounded-lg"></div>
                        <div class="w-16 h-16 bg-gray-400 rounded-lg"></div>
                        <div class="w-16 h-16 bg-gray-300 rounded-lg"></div>
                    </div>
                </div>
            </div>
        `;
    }
});
</script>

</body>
</html>
