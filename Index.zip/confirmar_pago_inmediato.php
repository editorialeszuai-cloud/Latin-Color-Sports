<?php
// confirmar_pago_inmediato.php
header('Content-Type: application/json');

// Solo verificamos que el request llegó bien
$input = json_decode(file_get_contents('php://input'), true);
if (isset($input['referencia'])) {
    // Respondemos OK para que el JS sepa que puede redirigir
    echo json_encode(['status' => 'OK']);
} else {
    echo json_encode(['status' => 'ERROR']);
}
exit;