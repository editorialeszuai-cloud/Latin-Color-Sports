```html
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Latin Color Sports - Dashboard Fotografo</title>

<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">

<style>

:root{
    --sidebar-width:270px;
    --dark:#0b1220;
    --dark-2:#141d2f;
    --primary:#ff416c;
    --secondary:#ff4b2b;
    --bg:#f5f7fb;
    --white:#ffffff;
    --text:#1f2937;
    --muted:#6b7280;
    --border:#e5e7eb;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Inter,Arial,sans-serif;
}

body{
    background:var(--bg);
    color:var(--text);
    overflow-x:hidden;
}

/* TOPBAR */

.topbar{
    position:fixed;
    top:0;
    left:0;
    right:0;
    height:70px;
    background:white;
    border-bottom:1px solid var(--border);
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:0 20px;
    z-index:1000;
}

.left-topbar{
    display:flex;
    align-items:center;
    gap:15px;
}

.hamburger{
    background:none;
    border:none;
    cursor:pointer;
    font-size:24px;
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;
}

.logo img{
    width:45px;
    height:45px;
    border-radius:10px;
}

.logo span{
    font-weight:700;
}

.user-info{
    display:flex;
    align-items:center;
    gap:10px;
}

.user-info img{
    width:42px;
    height:42px;
    border-radius:50%;
    object-fit:cover;
}

/* SIDEBAR */

.sidebar{
    position:fixed;
    left:0;
    top:70px;
    width:var(--sidebar-width);
    height:calc(100vh - 70px);
    background:linear-gradient(180deg,var(--dark),var(--dark-2));
    color:white;
    overflow-y:auto;
    transition:.3s;
}

.sidebar-menu{
    padding:20px 12px;
}

.sidebar-title{
    font-size:13px;
    color:#9ca3af;
    margin:15px 10px;
    text-transform:uppercase;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    text-decoration:none;
    color:white;
    padding:14px;
    border-radius:12px;
    margin-bottom:5px;
    transition:.3s;
}

.sidebar a:hover{
    background:rgba(255,255,255,.08);
}

.sidebar a.active{
    background:linear-gradient(90deg,var(--primary),var(--secondary));
}

/* CONTENT */

.main{
    margin-left:var(--sidebar-width);
    margin-top:20px;
    padding:25px;
    transition:.3s;
}

/* HERO */

.hero{
    background:white;
    border-radius:24px;
    padding:40px;
    box-shadow:0 4px 20px rgba(0,0,0,.05);
}

.hero h1{
    font-size:42px;
    margin-bottom:10px;

    background:linear-gradient(
        90deg,
        #FF416C,
        #FF4B2B,
        #FFD700,
        #24C6DC
    );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.hero p{
    color:var(--muted);
    line-height:1.8;
    max-width:700px;
}

.hero-btn{
    display:inline-block;
    margin-top:20px;
    background:linear-gradient(
        90deg,
        var(--primary),
        var(--secondary)
    );
    color:white;
    text-decoration:none;
    padding:14px 24px;
    border-radius:50px;
    font-weight:bold;
}

/* CARDS */

.cards{
    margin-top:25px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}

.card{
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.05);
}

.card h3{
    font-size:15px;
    color:var(--muted);
}

.card .number{
    font-size:34px;
    font-weight:bold;
    margin-top:12px;
}

/* EVENTOS */

.section{
    margin-top:25px;
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.05);
}

.section h2{
    margin-bottom:20px;
}

.event{
    display:flex;
    justify-content:space-between;
    padding:15px 0;
    border-bottom:1px solid #eee;
}

.event:last-child{
    border-bottom:none;
}

/* MOBILE */

.overlay{
    display:none;
}

@media(max-width:900px){

    .sidebar{
        transform:translateX(-100%);
        z-index:1001;
    }

    .sidebar.show{
        transform:translateX(0);
    }

    .main{
        margin-left:0;
        padding:15px;
    }

    .hero{
        padding:25px;
    }

    .hero h1{
        font-size:30px;
    }

    .overlay{
        position:fixed;
        inset:0;
        background:rgba(0,0,0,.4);
        display:none;
        z-index:1000;
    }

    .overlay.show{
        display:block;
    }

}
#logoutButton{
    width:100%;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    padding:12px 16px;
    border:none;
    border-radius:12px;
    background:linear-gradient(135deg,#ef4444,#dc2626);
    color:#fff;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    transition:all .25s ease;
    box-shadow:0 4px 12px rgba(239,68,68,.25);
}

#logoutButton:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 18px rgba(239,68,68,.35);
    background:linear-gradient(135deg,#dc2626,#b91c1c);
}

#logoutButton:active{
    transform:scale(.97);
}

#logoutButton svg{
    width:18px;
    height:18px;
}

@media(max-width:768px){

    #logoutButton{
        padding:14px;
        font-size:15px;
    }

}

</style>
</head>
<body>

<div class="overlay" id="overlay"></div>

<header class="topbar">

    <div class="left-topbar">

        <button class="hamburger" id="menuBtn">
            ☰
        </button>

        <div class="logo">
            <img src="../uploads/LATIN-SPORTS.png">
            <span>Latin Color Sports</span>
        </div>

    </div>

    <div class="user-info">

        <img id="userFotoPerfil"
             src="uploads/perfil.jpg">

        <div>
		
            <div id="userName">Cargando...</div>
            <small id="userRole">Fotografo</small>
			
        </div>

    </div>

</header>

<aside class="sidebar" id="sidebar">

    <div class="sidebar-menu">

        <div class="sidebar-title">
            Navegacion
        </div>

        <a class="active" href="menu_fotografo.php">
            Inicio
        </a>

        <a href="postularme.php">
            Eventos Disponibles
        </a>

        <a href="postulaciones_aceptadas.php">
            Mis Postulaciones
        </a>

        <a href="miseventos.php">
            Eventos Pasados
        </a>

        <a href="ver_calendario_fotografo.php">
            Calendario
        </a>

        <a href="misfotografias.php">
            Mis Galerias
        </a>

        <a href="comisionesfo.php">
            Comisiones
        </a>

        <a href="datos_bancarios.php">
            Datos Bancarios
        </a>

        <a href="editar_perfil.php">
            Editar Perfil
        </a>

<button id="logoutButton">
    Cerrar Sesion
</button>
    </div>

</aside>

<main class="main">

    <section class="hero">

        <h1>Bienvenido Fotografo</h1>

    </section>

</main>

<script>

const menuBtn=document.getElementById("menuBtn");
const sidebar=document.getElementById("sidebar");
const overlay=document.getElementById("overlay");

menuBtn.addEventListener("click",()=>{

    sidebar.classList.toggle("show");
    overlay.classList.toggle("show");

});

overlay.addEventListener("click",()=>{

    sidebar.classList.remove("show");
    overlay.classList.remove("show");

});

</script>
<script type="module">

import { auth } from './firebase-config.js';

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const userFotoPerfil = document.getElementById('userFotoPerfil');
const userName = document.getElementById('userName');
const userRole = document.getElementById('userRole');
const logoutButton = document.getElementById('logoutButton');

function actualizarPerfil(data){

    userName.textContent =
        data.user.nombre || 'Fotografo';

    userRole.textContent =
        data.user.rol || 'Usuario';

    if(
        data.user.foto_perfil &&
        data.user.foto_perfil.trim() !== ''
    ){

        userFotoPerfil.src =
            `uploads/${data.user.foto_perfil}`;

    }else{

        userFotoPerfil.src =
            'uploads/perfil.jpg';

    }

}

onAuthStateChanged(auth, async (user)=>{

    if(!user){

        window.location.href =
            'login_app.html';

        return;
    }

    try{

        const token =
            await user.getIdToken();

        const response =
            await fetch(
                'get_user_info.php',
                {
                    method:'POST',
                    headers:{
                        'Content-Type':
                        'application/json'
                    },
                    body:JSON.stringify({
                        firebase_token:token
                    })
                }
            );

        const data =
            await response.json();

        if(
            data.status === 'success'
        ){

            actualizarPerfil(data);

        }else{

            alert(
                'Usuario no registrado'
            );

        }

    }catch(error){

        console.error(error);

        alert(
            'Error cargando perfil'
        );

    }

});

logoutButton.addEventListener(
    'click',
    async ()=>{

        try{

            await signOut(auth);

            window.location.href =
                'login_app.html';

        }catch(error){

            console.error(error);

        }

    }
);

</script>


</body>
</html>
```
