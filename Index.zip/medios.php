<style>
    .payment-section { margin: 30px 0; text-align: center; }
    .payment-title { 
        color: #888; font-size: 12px; font-weight: 700; 
        text-transform: uppercase; letter-spacing: 1px; margin-bottom: 20px; 
    }
    .payment-grid { display: flex; justify-content: center; gap: 20px; flex-wrap: wrap; }
    
    .payment-option {
        background: #fff; /* Cambiado a blanco para que los logos se vean bien */
        padding: 10px 20px;
        border-radius: 12px;
        transition: all 0.3s ease;
        cursor: pointer;
        display: flex;
        align-items: center;
        border: 2px solid transparent;
    }
    
    .payment-option:hover {
        transform: translateY(-4px);
        border-color: #e30052; /* Fucsia Clave Prod */
    }
    
    .payment-option img {
        height: 30px;
        width: auto;
        /* ELIMINAMOS EL FILTRO PARA QUE SE VEAN LOS COLORES ORIGINALES */
        filter: none; 
    }
</style>

<div class="payment-section">
    <div class="payment-title">Métodos de pago aceptados</div>
    
    <div class="payment-grid">
        <div class="payment-option">
            <img src="uploads/visa.jpg" alt="Visa">
        </div>
        
        <div class="payment-option">
            <img src="uploads/mastercard.png" alt="Mastercard">
        </div>
        
        <div class="payment-option">
            <img src="uploads/amex.png" alt="American Express">
        </div>
    </div>
</div>