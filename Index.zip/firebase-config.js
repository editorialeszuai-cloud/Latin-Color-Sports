// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
// ✅ importa getAuth



// Tu configuraci車n de Firebase Web App (VALORES DE EJEMPLO)
const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

const app = initializeApp(firebaseConfig);

// Inicializar Auth
export const auth = getAuth(app);
