<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
require 'conexion.php';

$input = json_decode(file_get_contents('php://input'), true);

if(!isset($input['firebase_uid'])){
    echo json_encode(['success'=>false,'message'=>'Falta firebase_uid']);
    exit;
}

$uid = $input['firebase_uid'];
$conn = conectar();

$stmt = $conn->prepare("SELECT id,nombre,email FROM usuarios WHERE firebase_uid=?");
$stmt->bind_param("s",$uid);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
if(!$user){
    echo json_encode(['success'=>false,'message'=>'Usuario no encontrado']);
    exit;
}

// Obtener postulaciones aceptadas
$stmt2 = $conn->prepare("
    SELECT p.id, c.evento_nombre, c.fecha, c.hora
    FROM postulaciones p
    JOIN calendarios c ON c.id_calendarios = p.calendario_id
    WHERE p.usuario_id=? AND p.estado='aceptado'
");
$stmt2->bind_param("i",$user['id']);
$stmt2->execute();
$res2 = $stmt2->get_result();
$postulaciones = $res2->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    'success'=>true,
    'user'=>$user,
    'postulaciones'=>$postulaciones
]);
exit;
