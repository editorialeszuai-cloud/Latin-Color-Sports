<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gesti&oacute;n de Postulaciones</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- NAVBAR -->

<div class="container mx-auto">
  <h1 class="text-3xl font-bold mb-6">Postulaciones de Eventos</h1>

  <div id="postulacionesContainer" class="bg-white rounded shadow p-4">
    <p class="text-gray-500">Cargando postulaciones...</p>
  </div>
</div>

<!-- MODAL EDICI??N -->
<div id="modalCalendario" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
  <div class="bg-white rounded-lg p-6 w-full max-w-lg relative">
    <button id="cerrarModalBtn" class="absolute top-2 right-2 text-xl font-bold">&times;</button>
    <h2 class="text-xl font-semibold mb-4">Editar Postulaci��n</h2>

    <form id="formCalendario" class="space-y-4">
      <input type="hidden" id="modal_postulacion_id">
      <input type="hidden" id="calendario_id" value="0">

      <div>
        <label class="block font-medium mb-1">Capacidad (MB)</label>
        <input type="number" id="capacidad_mb" class="w-full border p-2 rounded" min="0" value="0" required>
      </div>

      <div>
        <label class="block font-medium mb-1">Unidad de Fotos</label>
        <input type="text" id="unidad_fotos" class="w-full border p-2 rounded" placeholder="Ejemplo: MB, GB, fotos" required>
      </div>

      <div class="flex justify-end space-x-2">
        <button type="button" id="cancelModalBtn" class="px-4 py-2 bg-gray-400 rounded hover:bg-gray-500">Cancelar</button>
        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Guardar Cambios</button>
      </div>
    </form>
  </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

let user_role = null;

onAuthStateChanged(auth, async (user) => {
    if (user) {
        try {
            const token = await user.getIdToken();
            const res = await fetch('get_user_info.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firebase_token: token })
            });
            const data = await res.json();
            if (data.status === 'success') {
                user_role = data.user.rol;
                listarPostulaciones();
            }
        } catch (e) {
            console.error("Error de autenticaci��n:", e);
        }
    } else {
        window.location.href = 'login_app.html';
    }
});

async function apiCall(payload) {
    try {
        const res = await fetch('postulaciones_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const text = await res.text(); // Leemos como texto primero para evitar el SyntaxError
        try {
            return JSON.parse(text);
        } catch (err) {
            console.error("Servidor devolvi�� algo que no es JSON:", text);
            throw new Error("Respuesta inv��lida del servidor");
        }
    } catch (e) {
        alert("Error de conexi��n: " + e.message);
        return { success: false };
    }
}

async function listarPostulaciones() {
    const data = await apiCall({ accion: 'listar' });
    const container = document.getElementById('postulacionesContainer');
    
    if (!data.success) {
        container.innerHTML = `<p class="p-4 text-red-500">Error: ${data.message}</p>`;
        return;
    }

   let html = `<table class="min-w-full bg-white border text-sm">
        <thead class="bg-gray-200">
            <tr>
                ${user_role === 'admin' ? '<th class="p-2 border">Fot&oacute;grafo</th>' : ''}
                <th class="p-2 border">Evento</th>
                <th class="p-2 border">Estado</th>
                <th class="p-2 border">Capacidad</th>
                <th class="p-2 border">Acciones</th>
            </tr>
        </thead>
        <tbody>`;

    data.data.forEach(p => {
        html += `<tr class="border-t hover:bg-gray-50">
            ${user_role === 'admin' ? `<td class="p-2">${escapeHtml(p.usuario_nombre)}</td>` : ''}
            <td class="p-2">${escapeHtml(p.evento_nombre)}</td>
            <td class="p-2 text-center font-bold">${p.estado}</td>
            <td class="p-2 text-center">${p.capacidad_mb} MB</td>
            <td class="p-2 text-center space-x-1">`;

        if (user_role === 'admin') {
    // Usamos &check; para el check y &times; para la X
    html += `<button class="bg-blue-500 text-white px-2 py-1 rounded" onclick="abrirModal(${p.id}, ${p.capacidad_mb}, '${p.unidad_fotos}')">Editar</button>`;
    html += `<button class="bg-green-500 text-white px-2 py-1 rounded" onclick="cambiarEstado(${p.id}, 'aceptado')">&check;</button>`;
    html += `<button class="bg-red-500 text-white px-2 py-1 rounded" onclick="cambiarEstado(${p.id}, 'rechazado')">&times;</button>`;
}

        html += `</td></tr>`;
    });
    container.innerHTML = html + `</tbody></table>`;
}

window.cambiarEstado = async (id, nuevoEstado) => {
    const data = await apiCall({ accion: 'editar', id, estado: nuevoEstado });
    if (data.success) listarPostulaciones();
};

document.getElementById('formCalendario').addEventListener('submit', async (e) => {
    e.preventDefault();
    const payload = {
        accion: 'editar',
        id: document.getElementById('modal_postulacion_id').value,
        estado: 'aceptado',
        capacidad_mb: document.getElementById('capacidad_mb').value,
        unidad_fotos: document.getElementById('unidad_fotos').value
    };
    const data = await apiCall(payload);
    if (data.success) {
        cerrarModal();
        listarPostulaciones();
    }
});

function escapeHtml(str) {
    if (!str) return "";
    return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

window.abrirModal = (id, cap, uni) => {
    document.getElementById('modal_postulacion_id').value = id;
    document.getElementById('capacidad_mb').value = cap;
    document.getElementById('unidad_fotos').value = uni;
    document.getElementById('modalCalendario').classList.replace('hidden', 'flex');
};

window.cerrarModal = () => {
    document.getElementById('modalCalendario').classList.replace('flex', 'hidden');
};
</script>

</body>
</html>
