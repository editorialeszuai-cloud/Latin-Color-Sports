<?php
require 'dbfotografos.php';
header('Content-Type: application/json; charset=utf-8');

// Depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Recibir parámetros
$firebase_uid = $_GET['firebase_uid'] ?? '';
$evento_id = isset($_GET['evento_id']) ? (int)$_GET['evento_id'] : 0;
$precio = isset($_GET['precio']) ? (int)$_GET['precio'] : 0;

// Debug inicial
$debug = [
    'GET' => $_GET,
    'parsed' => [
        'firebase_uid' => $firebase_uid,
        'evento_id' => $evento_id,
        'precio' => $precio
    ]
];

// Validación
if(empty($firebase_uid) || $evento_id <= 0 || $precio <= 0){
    $debug['error'] = 'Datos incompletos';
    echo json_encode(['status'=>'error','msg'=>'Datos incompletos','debug'=>$debug]);
    exit;
}

// Verificar si el paquete ya está en el carrito
try {
    $stmt = $pdo->prepare("SELECT id FROM carrito_paquetes WHERE firebase_uid=? AND evento_id=?");
    $stmt->execute([$firebase_uid, $evento_id]);
    if($stmt->fetch()){
        echo json_encode(['status'=>'ok','msg'=>'Ya está en el carrito de paquetes','debug'=>$debug]);
        exit;
    }
} catch (PDOException $e){
    $debug['exception'] = $e->getMessage();
    echo json_encode(['status'=>'error','msg'=>'Error al verificar carrito de paquetes','debug'=>$debug]);
    exit;
}

// Insertar nuevo paquete
try {
    $stmt = $pdo->prepare("INSERT INTO carrito_paquetes (firebase_uid, evento_id, precio, fecha) VALUES (?, ?, ?, NOW())");
    $success = $stmt->execute([$firebase_uid, $evento_id, $precio]);
    if($success){
        echo json_encode(['status'=>'ok','msg'=>'✅ Paquete agregado al carrito','debug'=>$debug]);
    } else {
        $debug['error_info'] = $stmt->errorInfo();
        echo json_encode(['status'=>'error','msg'=>'No se pudo agregar el paquete','debug'=>$debug]);
    }
} catch(PDOException $e){
    $debug['exception'] = $e->getMessage();
    echo json_encode(['status'=>'error','msg'=>'Error al insertar en carrito de paquetes','debug'=>$debug]);
}
