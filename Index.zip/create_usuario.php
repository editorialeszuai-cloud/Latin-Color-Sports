<?php
header('Content-Type: application/json; charset=utf-8');
include 'dbfotografos.php';
$pdo = conectar(); // tu función para conectar a MySQL

// API Key de Firebase (desde Project Settings → General → Web API Key)
$FIREBASE_API_KEY = 'TU_FIREBASE_API_KEY';

$data = json_decode(file_get_contents('php://input'), true);

$email = $data['email'] ?? '';
$password = $data['password'] ?? '';
$nombre = $data['nombre'] ?? '';
$rol = $data['rol'] ?? 'cliente';

if(!$email || !$password){
    echo json_encode(['success'=>false, 'message'=>'Email y contraseña son requeridos']);
    exit;
}

// =====================
// Crear usuario en Firebase via REST API
// =====================
$firebase_url = "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$FIREBASE_API_KEY";

$payload = json_encode([
    "email" => $email,
    "password" => $password,
    "returnSecureToken" => true
]);

$ch = curl_init($firebase_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if(isset($result['error'])){
    echo json_encode(['success'=>false, 'message'=>$result['error']['message']]);
    exit;
}

$firebase_uid = $result['localId']; // UID generado por Firebase

// =====================
// Insertar usuario en MySQL
// =====================
try {
    $stmt = $pdo->prepare("INSERT INTO usuarios (firebase_uid, email, nombre, rol, fecha_registro, ultima_sesion, estado)
        VALUES (?, ?, ?, ?, NOW(), NOW(), 'activo')");
    $stmt->execute([$firebase_uid, $email, $nombre, $rol]);

    echo json_encode(['success'=>true, 'firebase_uid'=>$firebase_uid]);
} catch(Exception $e){
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
