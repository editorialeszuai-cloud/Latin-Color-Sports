<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">

<title>Fotografo | Latin Color Sports</title>

<style>

:root{
    --bg-dark:#0b1220;
    --bg-light:#f6f8fb;
    --accent:#FF416C;
    --accent2:#FF4B2B;
    --text-light:#ffffff;
    --text-dark:#0f1724;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Inter,Arial,sans-serif;
}

body{
    background:var(--bg-light);
    color:var(--text-dark);
}

/* =========================
   TOPBAR
========================= */

.topbar{
    height:70px;
    background:var(--bg-dark);
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 24px;
    color:white;
    position:sticky;
    top:0;
    z-index:999;
}

.logo-title{
    display:flex;
    align-items:center;
    gap:12px;
}

.logo-title img{
    width:48px;
    height:48px;
    border-radius:10px;
}

.logo-title h2{
    font-size:20px;
    font-weight:700;
}

/* =========================
   MENU
========================= */

.menu-toggle{
    display:none;
    background:none;
    border:none;
    color:white;
    font-size:30px;
    cursor:pointer;
}

.nav-menu{
    display:flex;
    align-items:center;
    gap:10px;
}

.nav-menu a{
    color:white;
    text-decoration:none;
    padding:10px 14px;
    border-radius:8px;
    transition:.3s;
    font-size:15px;
}

.nav-menu a:hover{
    background:rgba(255,255,255,.08);
    color:#FFD700;
}

/* =========================
   SEPARADOR
========================= */

.separator{
    height:4px;
    background:linear-gradient(
        90deg,
        #FF416C,
        #FF4B2B,
        #24C6DC
    );
}

/* =========================
   CONTENIDO
========================= */

.container{
    max-width:1300px;
    margin:auto;
    padding:30px 20px;
}

/* =========================
   HERO
========================= */

.welcome-section{
    background:white;
    border-radius:20px;
    padding:60px 30px;
    text-align:center;
    box-shadow:0 5px 20px rgba(0,0,0,.06);
}

.welcome-section h1{
    background:linear-gradient(
        90deg,
        #FF416C,
        #FF4B2B,
        #F9D423,
        #24C6DC
    );

    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;

    font-size:56px;
    text-transform:uppercase;
    margin-bottom:15px;
    letter-spacing:2px;
}

.welcome-section h2{
    font-size:24px;
    font-weight:400;
    margin-bottom:20px;
}

.welcome-section p{
    max-width:700px;
    margin:auto;
    color:#4b5563;
    line-height:1.8;
}

.btn-primary{
    display:inline-block;
    margin-top:30px;
    padding:14px 28px;
    border-radius:50px;
    text-decoration:none;
    color:white;
    font-weight:700;
    background:linear-gradient(
        90deg,
        var(--accent),
        var(--accent2)
    );
    transition:.3s;
}

.btn-primary:hover{
    transform:translateY(-2px);
    box-shadow:0 8px 25px rgba(255,65,108,.3);
}

/* =========================
   TARJETAS
========================= */

.cards{
    margin-top:30px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
}

.card{
    background:white;
    border-radius:18px;
    padding:25px;
    box-shadow:0 5px 15px rgba(0,0,0,.05);
}

.card h3{
    color:#6b7280;
    margin-bottom:10px;
}

.card .value{
    font-size:36px;
    font-weight:700;
}

/* =========================
   TABLA EVENTOS
========================= */

.section{
    margin-top:30px;
    background:white;
    border-radius:20px;
    padding:25px;
    box-shadow:0 5px 15px rgba(0,0,0,.05);
}

.section h2{
    margin-bottom:20px;
}

.table-responsive{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

table th{
    background:#f3f4f6;
    padding:14px;
    text-align:left;
}

table td{
    padding:14px;
    border-bottom:1px solid #eee;
}

/* =========================
   FOOTER
========================= */

.footer{
    text-align:center;
    padding:30px;
    color:#6b7280;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .menu-toggle{
        display:block;
    }

    .nav-menu{
        position:absolute;
        top:70px;
        left:0;
        right:0;
        background:var(--bg-dark);
        display:none;
        flex-direction:column;
        align-items:flex-start;
        padding:15px;
        gap:5px;
    }

    .nav-menu.active{
        display:flex;
    }

    .nav-menu a{
        width:100%;
    }

    .welcome-section h1{
        font-size:36px;
    }

}

@media(max-width:600px){

    .logo-title h2{
        display:none;
    }

    .welcome-section{
        padding:40px 20px;
    }

    .welcome-section h1{
        font-size:28px;
    }

    .welcome-section h2{
        font-size:18px;
    }

}

</style>
</head>
<body>

<header class="topbar">

    <div class="logo-title">
        <img src="../uploads/LATIN-SPORTS.png" alt="Logo">
        <h2>Latin Color Sports</h2>
    </div>

    <button class="menu-toggle" id="menuToggle">
        ☰
    </button>

    <nav class="nav-menu" id="navMenu">

        <a href="nav_publicidad.php">Inicio</a>

        <a href="editar_perfil.php">
            Mi Perfil
        </a>

        <a href="ayuda.php">
            Ayuda
        </a>

    </nav>

</header>

<div class="separator"></div>


<script>

const menuToggle =
document.getElementById('menuToggle');

const navMenu =
document.getElementById('navMenu');

menuToggle.addEventListener('click',()=>{

    navMenu.classList.toggle('active');

});

</script>

</body>
</html>