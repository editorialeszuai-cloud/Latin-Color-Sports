<?php
require 'vendor/autoload.php';
use Aws\S3\S3Client;
use Dotenv\Dotenv;

// Cargar variables
$dotenv = Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

try {
    $s3 = new S3Client([
        'version' => 'latest',
        'region'  => 'us-east-1',
        'credentials' => [
            'key'    => $_ENV['AWS_KEY'],
            'secret' => $_ENV['AWS_SECRET'],
        ],
    ]);

    // Intentar listar los archivos del bucket para probar conexión
    $result = $s3->listObjectsV2([
        'Bucket' => $_ENV['AWS_BUCKET'],
        'MaxKeys' => 1
    ]);

    echo "<h1>¡Conexión Exitosa!</h1>";
    echo "<p>El SDK de AWS pudo conectar con el bucket: " . $_ENV['AWS_BUCKET'] . "</p>";
    echo "<pre>Estado del bucket: " . ($result ? 'Accesible' : 'Error') . "</pre>";

} catch (Exception $e) {
    echo "<h1>Error de conexión</h1>";
    echo "<p>Detalles del error: " . $e->getMessage() . "</p>";
}
?>