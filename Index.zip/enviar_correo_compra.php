<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Asegúrate de que estas rutas sean 100% correctas
require_once __DIR__ . '/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/src/SMTP.php';

function enviarCorreoCompra($emailCliente, $referencia, $total, $carrito, $id_compra) {
    $rutaPlantilla = __DIR__ . '/plantilla_compra.php';
    
    if (!file_exists($rutaPlantilla)) {
        error_log("Error: No existe plantilla_compra.php en " . $rutaPlantilla);
        return false;
    }

    $filas = '';
    foreach ($carrito as $item) {
        $nombre = !empty($item['nombre_foto']) ? $item['nombre_foto'] : ($item['evento_titulo'] ?? 'Producto');
        $precio = !empty($item['precio_unitario']) ? $item['precio_unitario'] : ($item['precio'] ?? 0);
        $filas .= "<tr>
                    <td style='padding:10px; border-bottom:1px solid #eee;'>{$nombre}</td>
                    <td style='padding:10px; border-bottom:1px solid #eee; text-align:right;'>$" . number_format($precio, 0, ',', '.') . "</td>
                  </tr>";
    }

    $linkCheckout = "https://latincolorsports.com/wompi_checkout.php?compra_id=" . $id_compra;
    $html = file_get_contents($rutaPlantilla);
    $html = str_replace(['{{REFERENCIA}}', '{{TOTAL}}', '{{FILAS_FOTOS}}', '{{LINK_PAGO}}'], 
                        [$referencia, number_format($total, 0, ',', '.'), $filas, $linkCheckout], 
                        $html);

    $mail = new PHPMailer(true);

    try {
        // --- CONFIGURACIÓN DE DEPURACIÓN ---
        // Cambia a 2 para ver detalles en pantalla, 0 para producción
        $mail->SMTPDebug = 2; 
        
        $mail->isSMTP();
        $mail->Host       = 'kirby.nocdirect.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'notificaciones@latincolorgroup.com';
        $mail->Password   = '3Eoi@u=_b4LdCMwj';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // SSL
        $mail->Port       = 465;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom('notificaciones@latincolorgroup.com', 'Latin Color Group');
        $mail->addAddress($emailCliente);
        $mail->addBCC('notificaciones@latincolorgroup.com');
        $mail->addBCC('lolaela1960@hotmail.com');

        $mail->isHTML(true);
        $mail->Subject = "Latin Colors Sports Compra Tus Fotos - Ref: $referencia";
        $mail->Body    = $html;

        $mail->send();
        return true;
    } catch (Exception $e) {
        // Esto aparecerá en el error_log de tu servidor
        error_log("Error PHPMailer: " . $mail->ErrorInfo);
        echo "Error al enviar: {$mail->ErrorInfo}"; // Para verlo en vivo mientras pruebas
        return false;
    }
}