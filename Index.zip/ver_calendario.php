<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendario Olímpico</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">

<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6 text-center text-orange-800">🏅 Calendario Olímpico</h1>

    <div class="bg-white shadow rounded p-4 mb-6">
        <label class="block font-semibold text-gray-700 mb-2">Seleccionar Evento</label>
        <select id="eventoSelect" class="border rounded w-full p-2 mb-3"></select>
        <button onclick="cargarCalendario()" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
            🔍 Ver Calendario
        </button>
    </div>

    <div id="calendarioContainer" class="bg-white shadow rounded p-4 overflow-auto">
        <p class="text-gray-500 text-center">Selecciona un evento para visualizar su calendario...</p>
    </div>
</div>

<div id="modalFotografo" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-2xl p-6 w-96 shadow-lg">
        <h2 class="text-xl font-bold mb-2 text-blue-700">📸 Asignar Fotógrafo</h2>
        <p class="text-sm mb-4 text-gray-600">
            Escenario: <span id="modalEscenario" class="font-semibold"></span><br>
            Fecha: <span id="modalFecha" class="font-semibold"></span>
        </p>
        <select id="fotografoSelect" class="w-full border rounded p-2 mb-4"></select>
        <div class="flex justify-end gap-2">
            <button class="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500" onclick="cerrarModal()">Cancelar</button>
            <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700" onclick="guardarAsignacion()">Guardar</button>
        </div>
    </div>
</div>

<script>
let datosAsignacion = {};

async function cargarEventos() {
    try {
        const res = await fetch('calendaris_api.php', { method: 'POST', body: new URLSearchParams({ accion: 'listar_eventos' }) });
        const data = await res.json();
        const sel = document.getElementById('eventoSelect');
        sel.innerHTML = '<option value="">-- Selecciona un evento --</option>';
        if (data.success && data.data.length) {
            data.data.forEach(e => {
                const opt = document.createElement('option');
                opt.value = e.id;
                opt.textContent = e.titulo;
                sel.appendChild(opt);
            });
        }
    } catch(e) { console.error(e); }
}
cargarEventos();

async function cargarCalendario() {
    const eventoId = document.getElementById('eventoSelect').value;
    const cont = document.getElementById('calendarioContainer');
    if (!eventoId) { cont.innerHTML = '<p class="text-center text-red-500">⚠️ Selecciona un evento.</p>'; return; }
    cont.innerHTML = '<p class="text-center text-gray-500 animate-pulse">Cargando...</p>';

    try {
        const res = await fetch('calendaris_api.php', {
            method: 'POST',
            body: new URLSearchParams({ accion: 'listar', evento_id: eventoId })
        });
        const data = await res.json();
        if (!data.success || !data.data.length) { cont.innerHTML = '<p class="text-center text-gray-500">No hay registros.</p>'; return; }

        const eventos = {};
        data.data.forEach(c => {
            if (!eventos[c.calendario]) eventos[c.calendario] = {};
            if (!eventos[c.calendario][c.sede]) eventos[c.calendario][c.sede] = [];
            eventos[c.calendario][c.sede].push(c);
        });

        let html = '';
        Object.keys(eventos).forEach(cal => {
            html += `<div class="mb-8"><h2 class="text-2xl font-semibold text-blue-700 mb-2 border-b pb-1">📘 Calendario: ${cal}</h2>`;
            Object.keys(eventos[cal]).forEach(sede => {
                html += `<div class="mb-4"><h3 class="text-xl font-medium text-gray-800 mb-2">🏟️ Sede: ${sede}</h3>
                    <table class="min-w-full border divide-y divide-gray-300 bg-white mb-4">
                        <thead class="bg-blue-50">
                            <tr><th>Escenario</th><th>Disciplina</th><th>Categoría</th><th>Encuentro</th><th>Fecha</th><th>Hora</th><th>Acción</th></tr>
                        </thead><tbody>`;

                eventos[cal][sede].forEach(c => {
                    const cat = c.categoria === 'M' ? 'Masculino' : (c.categoria === 'F' ? 'Femenino' : c.categoria);
                    const encuentro = (c.equipo_a && c.equipo_b) ? `${c.equipo_a} vs ${c.equipo_b}` : '---';
                    
                    html += `<tr class="hover:bg-gray-50 text-sm">
                        <td>${c.escenario}</td><td>${c.disciplina}</td><td>${cat}</td>
                        <td class="font-bold text-orange-700">${encuentro}</td>
                        <td>${c.fecha}</td><td>${c.hora}</td>
                        <td class="text-center">
                            <button class="bg-green-600 text-white px-2 py-1 rounded hover:bg-green-700"
                                onclick="abrirModalFotografo(${c.evento_id}, ${c.calendario_id}, ${c.bloque_id}, ${c.sede_id}, ${c.escenario_id}, ${c.disciplina_id}, ${c.bloque_dis_id || 0}, ${c.partido_id || 0}, '${c.escenario}', '${c.fecha}', '${c.hora}')">
                                📸 Asignar
                            </button>
                        </td>
                    </tr>`;
                });
                html += `</tbody></table></div>`;
            });
            html += `</div>`;
        });
        cont.innerHTML = html;
    } catch(e) { cont.innerHTML = '<p class="text-red-500">Error cargando calendario.</p>'; }
}

async function abrirModalFotografo(evento_id, calendario_id, bloque_id, sede_id, escenario_id, disciplina_id, bloque_dis_id, partido_id, escenario, fecha, hora) {
    datosAsignacion = { evento_id, calendario_id, bloque_id, sede_id, escenario_id, disciplina_id, bloque_dis_id, partido_id, escenario, fecha, hora };
    document.getElementById('modalEscenario').textContent = escenario;
    document.getElementById('modalFecha').textContent = fecha;
    document.getElementById('modalFotografo').classList.remove('hidden');
    
    const res = await fetch('calendaris_api.php', { method: 'POST', body: new URLSearchParams({ accion: 'listar_fotografos' }) });
    const data = await res.json();
    document.getElementById('fotografoSelect').innerHTML = '<option value="">-- Selecciona --</option>' + data.data.map(f => `<option value="${f.id}">${f.nombre}</option>`).join('');
}

function cerrarModal() { document.getElementById('modalFotografo').classList.add('hidden'); }

async function guardarAsignacion() {
    const fotografo_id = document.getElementById('fotografoSelect').value;
    if (!fotografo_id) return alert("Selecciona fotógrafo");
    
    const res = await fetch('calendaris_api.php', { 
        method: 'POST', 
        body: new URLSearchParams({ accion: 'asignar_fotografo', ...datosAsignacion, fotografo_id }) 
    });
    const data = await res.json();
    alert(data.message);
    if(data.success) cerrarModal();
}
</script>
</body>
</html>