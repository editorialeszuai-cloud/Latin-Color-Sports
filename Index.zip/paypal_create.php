<?php
// paypal_create.php
require 'paypal_logic.php';

$accessToken = getPayPalAccessToken();

$data = json_encode([
    "intent" => "CAPTURE",
    "purchase_units" => [[
        "amount" => ["currency_code" => "USD", "value" => "1.00"] // Ajusta este valor dinámicamente según tu base de datos
    ]]
]);

$ch = curl_init("https://api-m.paypal.com/v2/checkout/orders");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $accessToken"
]);

$result = curl_exec($ch);
curl_close($ch);

header('Content-Type: application/json');
echo $result; // Esto le devuelve el JSON al JavaScript
?>