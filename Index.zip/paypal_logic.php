<?php
header('Content-Type: application/json');
ini_set('display_errors', 0); // Evita que errores PHP rompan el JSON

// Configuración
$clientId = 'Aa68foa36e57VmIGOuZZgPPawQwUZfozju0iWa7CXCbhUOf4GP8Ux9TS1_RaHOotgTD6CQgMF2dRHtJh';
$secret = 'EKttZBFgisLEzaFojxdJUDj_RmlrOcJwaaut69hYTpS72lpsy4OElDVTzjwg44rPShv-FzAV6kY_o4hz';
$baseUrl = 'https://api-m.paypal.com';

require_once __DIR__ . '/dbfotografos.php';
$pdo = conectar();

function getAccessToken($clientId, $secret, $baseUrl) {
    $ch = curl_init("$baseUrl/v1/oauth2/token");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$secret");
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'grant_type=client_credentials');
    $response = json_decode(curl_exec($ch), true);
    curl_close($ch);
    return $response['access_token'] ?? null;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// --- ACCIÓN: CREAR ORDEN ---
if ($action === 'create') {
    $token = getAccessToken($clientId, $secret, $baseUrl);
    
    // DEFINIR VARIABLES AQUÍ
    $total = number_format((float)($input['total'] ?? 0), 2, '.', '');
    $compraID = $input['compra_id'] ?? '0'; // <--- ESTO FALTABA
    
    $orderData = [
        "intent" => "CAPTURE",
        "purchase_units" => [
            [
                "amount" => [
                    "currency_code" => "USD",
                    "value" => $total
                ],
                "custom_id" => (string)$compraID // Ahora sí está definida
            ]
        ]
    ];

    $ch = curl_init("$baseUrl/v2/checkout/orders");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json", 
        "Authorization: Bearer $token"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($orderData));
    
    $response = curl_exec($ch);
    curl_close($ch);
    echo $response; // Esto devolverá el JSON de PayPal al JS
    exit;
}

// --- ACCIÓN: CAPTURAR ORDEN ---
if ($action === 'capture') {
    $token = getAccessToken($clientId, $secret, $baseUrl);
    $orderID = $input['orderID'];
    $compraID = $input['compra_id'];

    $ch = curl_init("$baseUrl/v2/checkout/orders/$orderID/capture");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json", 
        "Authorization: Bearer $token"
    ]);
    
    $response = curl_exec($ch);
    $result = json_decode($response, true);
    curl_close($ch);

    if (($result['status'] ?? '') === 'COMPLETED') {
        $stmt = $pdo->prepare("UPDATE compras 
                               SET estado = 'APPROVED', 
                                   x_transaction_id = ?, 
                                   metodo_pago = 'PayPal' 
                               WHERE id = ?");
        $stmt->execute([$orderID, $compraID]);
    }
    
    echo $response;
    exit;
}
?>