<?php
// auditoria.php
require_once 'dbfotografos.php';
date_default_timezone_set('America/Bogota');

// 1. Manejo de Filtros
$fecha_inicio = $_GET['fecha_inicio'] ?? date('Y-m-01');
$fecha_fin    = $_GET['fecha_fin'] ?? date('Y-m-d');

// 2. Consulta de Ranking por IP (con filtro)
$sql = "SELECT 
            ip_acceso, 
            COUNT(*) as total_visitas, 
            MAX(fecha_hora) as ultima_conexion, 
            MAX(nombre_usuario) as usuario_referencia,
            MAX(rol) as ultimo_rol
        FROM auditoria_navegacion 
        WHERE DATE(fecha_hora) BETWEEN ? AND ?
        GROUP BY ip_acceso 
        ORDER BY total_visitas DESC 
        LIMIT 100";

$stmt = $pdo->prepare($sql);
$stmt->execute([$fecha_inicio, $fecha_fin]);
$logs = $stmt->fetchAll();

// 3. Estadísticas Generales
$total_mes = $pdo->query("SELECT COUNT(*) FROM auditoria_navegacion WHERE MONTH(fecha_hora) = MONTH(CURRENT_DATE()) AND YEAR(fecha_hora) = YEAR(CURRENT_DATE())")->fetchColumn();
$total_historico = $pdo->query("SELECT COUNT(*) FROM auditoria_navegacion")->fetchColumn();

// 4. Conteo Diario (Últimos 7 días)
$sql_diario = "SELECT DATE(fecha_hora) as dia, COUNT(*) as cuenta 
               FROM auditoria_navegacion 
               GROUP BY dia ORDER BY dia DESC LIMIT 7";
$diarios = $pdo->query($sql_diario)->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auditoría de Tráfico | Latin Color Sports</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-slate-950 p-4 md:p-10 text-slate-200">

    <div class="max-w-6xl mx-auto">
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black uppercase tracking-tighter text-white italic">
                    Auditoría de <span class="text-orange-500">Accesos</span>
                </h1>
                <p class="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Análisis de tráfico por IP y fechas</p>
            </div>
            <a href="soporte.php" class="bg-slate-800 hover:bg-slate-700 px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-slate-700">Volver</a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <div class="bg-slate-900 p-6 rounded-3xl border border-slate-800">
                <p class="text-[10px] uppercase text-slate-500 font-black tracking-[0.2em]">Visitas este Mes</p>
                <p class="text-3xl font-black text-white mt-1"><?= number_format($total_mes) ?></p>
            </div>
            <div class="bg-slate-900 p-6 rounded-3xl border border-slate-800">
                <p class="text-[10px] uppercase text-slate-500 font-black tracking-[0.2em]">Total Histórico</p>
                <p class="text-3xl font-black text-orange-500 mt-1"><?= number_format($total_historico) ?></p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <form method="GET" class="lg:col-span-2 bg-slate-900 p-6 rounded-3xl border border-slate-800 flex flex-wrap gap-4 items-end">
                <div class="flex-1">
                    <label class="block text-[9px] uppercase font-black text-slate-500 mb-2">Desde</label>
                    <input type="date" name="fecha_inicio" value="<?= $fecha_inicio ?>" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange-500 outline-none">
                </div>
                <div class="flex-1">
                    <label class="block text-[9px] uppercase font-black text-slate-500 mb-2">Hasta</label>
                    <input type="date" name="fecha_fin" value="<?= $fecha_fin ?>" class="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-sm focus:ring-2 focus:ring-orange-500 outline-none">
                </div>
                <button type="submit" class="bg-orange-600 hover:bg-orange-500 px-8 py-3.5 rounded-xl text-[10px] font-black uppercase tracking-widest text-white transition-all shadow-lg shadow-orange-900/20">
                    Filtrar
                </button>
            </form>

            <div class="bg-slate-900 p-6 rounded-3xl border border-slate-800">
                <p class="text-[9px] font-black text-slate-500 uppercase mb-4 tracking-widest">Actividad Reciente (Días)</p>
                <div class="flex gap-2">
                    <?php foreach($diarios as $d): ?>
                        <div class="flex-1 bg-slate-950 p-2 rounded-lg text-center border border-slate-800">
                            <span class="block text-[8px] text-slate-600"><?= date('d/m', strtotime($d['dia'])) ?></span>
                            <span class="font-bold text-xs text-orange-500"><?= $d['cuenta'] ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-2xl">
            <table id="tablaLogsIP" class="w-full text-sm text-left">
                <thead>
                    <tr class="text-slate-500 border-b border-slate-800">
                        <th class="p-4 uppercase tracking-wider text-[10px]">Dirección IP</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Visitas</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Último Usuario</th>
                        <th class="p-4 uppercase tracking-wider text-[10px]">Última Conexión</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-800">
                    <?php foreach($logs as $log): ?>
                    <tr class="hover:bg-slate-800/50 transition-all">
                        <td class="p-4 font-mono font-bold text-slate-100"><i class="fas fa-network-wired text-orange-500/50 mr-2"></i><?= $log['ip_acceso'] ?></td>
                        <td class="p-4"><span class="bg-orange-500/10 text-orange-500 px-3 py-1 rounded-lg font-black text-xs"><?= $log['total_visitas'] ?></span></td>
                        <td class="p-4">
                            <div class="flex flex-col">
                                <span class="text-slate-200 font-bold text-sm"><?= htmlspecialchars($log['usuario_referencia'] ?? 'Invitado') ?></span>
                                <span class="text-[9px] text-slate-500 uppercase font-black tracking-widest"><?= $log['ultimo_rol'] ?? 'N/A' ?></span>
                            </div>
                        </td>
                        <td class="p-4 text-xs font-mono text-slate-400"><?= $log['ultima_conexion'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tablaLogsIP').DataTable({
                order: [[1, 'desc']],
                pageLength: 20,
                language: { url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' },
                drawCallback: function() {
                    $('.dataTables_wrapper').addClass('text-slate-400');
                    $('input[type="search"]').addClass('bg-slate-950 border-slate-700 rounded-lg p-2 text-slate-200 px-3 mb-4');
                }
            });
        });
    </script>
</body>
</html>