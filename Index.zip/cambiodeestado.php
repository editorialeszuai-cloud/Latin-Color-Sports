<?php
require 'dbfotografos.php';
$pdo = conectar();

// 1. LÓGICA DE APROBACIÓN (Si se recibe el POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aprobar_id'])) {
    $stmt = $pdo->prepare("UPDATE compras SET estado = 'APPROVED' WHERE id = ?");
    $stmt->execute([$_POST['aprobar_id']]);
    header("Location: cambiodeestado.php"); // Recargar para limpiar el POST
    exit;
}

// 2. OBTENER DATOS PARA MOSTRAR
$sql = "
    SELECT 
        c.id, c.estado, c.total, 
        COALESCE(u.nombre, ci.nombre, 'Invitado') AS usuario_nombre,
        COALESCE(u.id, ci.id) AS usuario_id
    FROM compras c
    LEFT JOIN usuarios u ON c.firebase_uid = u.firebase_uid
    LEFT JOIN clientes_invitados ci ON c.id = ci.compra_id
    WHERE c.estado NOT IN ('Aceptada', 'APPROVED') -- Corregido: elementos separados
      -- Filtra para excluir el email de ambas tablas si existe
      AND (u.email IS NULL OR u.email != 'editorialeszuai@gmail.com')
      AND (ci.email IS NULL OR ci.email != 'editorialeszuai@gmail.com')
    ORDER BY c.id ASC
";
$compras = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<head>
    <style>
        body { background: #0f0f0f; color: white; font-family: sans-serif; padding: 20px; }
        .card { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); 
                border: 1px solid rgba(255, 0, 255, 0.3); padding: 15px; border-radius: 15px; 
                margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; }
        button { background: #ff9900; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-weight: bold; }
        .neon-text { color: #ff00ff; text-shadow: 0 0 5px #ff00ff; }
    </style>
</head>
<body>
    <h2 class="neon-text">Gestión de Compras</h2>
    
    <?php foreach ($compras as $c): ?>
        <div class="card">
            <div>
                <strong><?= htmlspecialchars($c['usuario_nombre']) ?></strong> - Total: $<?= number_format($c['total']) ?>
                <br><small>Orden #<?= $c['id'] ?></small>
            </div>
            <form method="POST">
                <input type="hidden" name="aprobar_id" value="<?= $c['id'] ?>">
                <button type="submit">Aprobar</button>
            </form>
        </div>
    <?php endforeach; ?>

    <?php if (empty($compras)): ?>
        <p>No hay compras pendientes.</p>
    <?php endif; ?>
</body>
</html>