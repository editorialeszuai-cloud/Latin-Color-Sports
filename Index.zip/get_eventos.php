<?php
require 'dbfotografos.php'; // Tu conexión a BD
header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, titulo, fecha FROM eventos ORDER BY id DESC");
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'eventos' => $eventos]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>