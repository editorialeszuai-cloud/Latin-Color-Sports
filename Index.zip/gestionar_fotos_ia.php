<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'dbfotografos.php';

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? null;
$foto_id = isset($data['foto_id']) ? intval($data['foto_id']) : null;

if (!$action || !$foto_id) {
    echo json_encode(['success' => false, 'error' => 'Parámetros insuficientes o inválidos.']);
    exit;
}

try {
    $pdo->beginTransaction();

    if ($action === 'eliminar') {
        $stmtLog = $pdo->prepare("INSERT INTO fotos_moderacion (foto_id, accion) VALUES (?, 'eliminada')");
        $stmtLog->execute([$foto_id]);
        
        $stmtDel = $pdo->prepare("DELETE FROM fotos WHERE id = ?");
        $stmtDel->execute([$foto_id]);
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Foto eliminada físicamente.']);
        exit;

    } elseif ($action === 'ocultar') {
        $stmtCheck = $pdo->prepare("SELECT id FROM fotos_moderacion WHERE foto_id = ? AND accion = 'ocultada'");
        $stmtCheck->execute([$foto_id]);
        
        if (!$stmtCheck->fetch()) {
            $stmtLog = $pdo->prepare("INSERT INTO fotos_moderacion (foto_id, accion) VALUES (?, 'ocultada')");
            $stmtLog->execute([$foto_id]);
        }
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'La foto ahora está oculta.']);
        exit;

    } elseif ($action === 'restaurar') {
        // --- NUEVA LÓGICA DE RESTAURACIÓN ---
        // Eliminamos el registro de 'ocultada' para que la foto vuelva a ser visible
        $stmtRest = $pdo->prepare("DELETE FROM fotos_moderacion WHERE foto_id = ? AND accion = 'ocultada'");
        $stmtRest->execute([$foto_id]);
        
        $pdo->commit();
        echo json_encode(['success' => true, 'message' => 'Foto restaurada a la galería pública.']);
        exit;
    }

    echo json_encode(['success' => false, 'error' => 'Acción no soportada.']);

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}