<?php
// auth.php
require 'db.php';
require 'vendor/autoload.php'; // Para Firebase Admin SDK

use Firebase\Auth\Token\Exception\InvalidToken;
use Firebase\Auth\Token\HttpKeyStore;
use Firebase\Auth\Token\Verifier;

$firebase_token = $_POST['firebase_token'] ?? ''; // Asume que el token viene por POST

if (!$firebase_token) {
    die("Token de Firebase no recibido");
}

try {
    // Inicializa el verificador (usar tu project ID de Firebase)
    $verifier = new Verifier('latin-group-406b1'); // 👈 ¡CORREGIDO!
    $verifiedToken = $verifier->verifyIdToken($firebase_token);

    $firebase_uid = $verifiedToken->getClaim('sub');

    // CONSEJO: Reemplaza la lógica de MySQLi con PDO si estás usando db.php
    // Usaremos la conexión PDO de db.php para la revisión
    $pdo = getDbConnection();

    // Verificar si el usuario existe en la tabla
    $stmt = $pdo->prepare("SELECT rol, nombre FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$firebase_uid]);
    $user = $stmt->fetch();

    if ($user) {
        echo "Bienvenido " . $user['nombre'] . ". Tu rol es " . $user['rol'] . ".";
        // Aquí podrías iniciar sesión PHP o devolver un JWT propio
    } else {
        echo "Usuario no registrado en la base de datos.";
    }

} catch (InvalidToken $e) {
    die("Token inválido: " . $e->getMessage());
} catch (Exception $e) {
    die("Error de servidor: " . $e->getMessage());
}
?>