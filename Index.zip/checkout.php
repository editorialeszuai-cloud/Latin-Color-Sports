<?php
ob_start();
// Ocultar errores en producción, pero mantener el control
ini_set('display_errors', 0);
error_reporting(E_ALL);

require_once 'dbfotografos.php'; 
$pdo = conectar();

$firebase_uid = $_GET['firebase_uid'] ?? '';

if (!$firebase_uid) {
    die("Error: Usuario no identificado. Inicia sesión.");
}

try {
    // 1. Obtener items del carrito
    $stmt = $pdo->prepare("SELECT foto_id, evento_id, precio FROM carrito WHERE firebase_uid = ?");
    $stmt->execute([$firebase_uid]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$items) die("Carrito vacío.");

    $total = array_sum(array_column($items, 'precio'));
    // Referencia única y profesional
    $referencia = "LCS-" . time() . "-" . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));

    $pdo->beginTransaction();

    // 2. Crear Compra
    $stmt_c = $pdo->prepare("INSERT INTO compras (firebase_uid, referencia, total, estado, fecha_compra) VALUES (?, ?, ?, 'Pendiente', NOW())");
    $stmt_c->execute([$firebase_uid, $referencia, $total]);
    $id_compra = $pdo->lastInsertId();

    // 3. Preparar sentencias fuera del bucle (más eficiente)
    $s_det = $pdo->prepare("INSERT INTO detalle_compras (id_compra, id_foto, evento_id, precio) VALUES (:cid, :fid, :eid, :pre)");
    
    // Incluimos los porcentajes como constantes para evitar errores de tipo
    $s_com = $pdo->prepare("INSERT INTO comisiones_usuario (admin, fotografo, organizador, soporte, comercial, compra_id, foto_id, evento_id) 
                            VALUES (:adm, :fot, :org, :sop, :com, :cid, :fid, :eid)");

    foreach ($items as $item) {
        $v = (float)$item['precio'];
        $f = !empty($item['foto_id']) ? $item['foto_id'] : null;
        $e = !empty($item['evento_id']) ? $item['evento_id'] : null;

        // Insertar detalle
        $s_det->execute([':cid'=>$id_compra, ':fid'=>$f, ':eid'=>$e, ':pre'=>$v]);
        
        // Calcular comisiones usando montos exactos
        $s_com->execute([
            ':adm' => $v * 0.27,
            ':fot' => $v * 0.50,
            ':org' => $v * 0.10,
            ':sop' => $v * 0.03,
            ':com' => $v * 0.10,
            ':cid' => $id_compra,
            ':fid' => $f,
            ':eid' => $e
        ]);
    }

    // 4. Vaciar carrito tras la compra exitosa
    $s_del = $pdo->prepare("DELETE FROM carrito WHERE firebase_uid = ?");
    $s_del->execute([$firebase_uid]);

    $pdo->commit();
    
    ob_end_clean();
    header("Location: wompi_checkout.php?compra_id=" . $id_compra);
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    // En producción, usa un log en lugar de die()
    die("Error en el proceso de compra: " . $e->getMessage());
}