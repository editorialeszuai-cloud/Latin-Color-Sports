<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require_once 'dbfotografos.php';
$pdo = conectar();

// Obtener firebase_uid
$firebase_uid = $_GET['firebase_uid'] ?? $_POST['firebase_uid'] ?? '';
if (!$firebase_uid) {
    die("<p style='color:red'>Usuario no identificado o carrito vac赤o.</p>");
}

// Obtener items del carrito (foto_id)
$stmt = $pdo->prepare("
    SELECT 
        c.id AS carrito_id,
        c.precio AS precio_unitario,
        f.id AS foto_id,
        f.url AS nombre_archivo,
        f.descripcion AS nombre_foto,
        e.id AS evento_id,
        e.titulo AS evento_titulo
    FROM carrito c
    INNER JOIN fotos f ON c.foto_id = f.id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    INNER JOIN eventos e ON p.evento_id = e.id
    WHERE c.firebase_uid = ?
    ORDER BY c.fecha_agregado DESC
");
$stmt->execute([$firebase_uid]);
$carrito = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$carrito) {
    die("<p style='color:red'>Tu carrito est芍 vac赤o.</p>");
}

// Calcular total y descripci車n
$total = 0;
$descripcion_items = [];
foreach ($carrito as $item) {
    $total += $item['precio_unitario'];
    $descripcion_items[] = $item['nombre_foto'];
}

// Generar referencia 迆nica
$ref_local = "EC-" . time();

// Insertar compra pendiente
$stmt = $pdo->prepare("INSERT INTO compras (firebase_uid, referencia, total, estado) VALUES (?, ?, ?, 'Pendiente')");
$stmt->execute([$firebase_uid, $ref_local, $total]);
$id_compra = $pdo->lastInsertId();

// Insertar detalle_compras
foreach ($carrito as $item) {
    $stmt = $pdo->prepare("
        INSERT INTO detalle_compras (id_compra, id_foto, precio)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$id_compra, $item['foto_id'], $item['precio_unitario']]);
}

// Insertar comisiones (ajustar % si quieres que sumen 100%)
foreach ($carrito as $item) {
    $precio = $item['precio_unitario'];
    $stmt = $pdo->prepare("
        INSERT INTO comisiones_usuario (compra_id, admin, fotografo, organizador, soporte, comercial)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $id_compra,
        $precio * 0.65, // admin 65%
        $precio * 0.05, // fotografo 5%
        $precio * 0.10, // organizador 10%
        $precio * 0.10, // soporte 10%
        $precio * 0.10  // comercial 10%
    ]);
}

// Configuraci車n ePayco
$epayco_public_key = "6f4f055542257a5c97242a3ac28d996d";
$url_response = "https://latincolorsports.com/response.php?ref_local=$ref_local";
$url_confirmation = "https://latincolorsports.com/callback.php";
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Checkout | Latin Color Sports</title>
<script src="https://checkout.epayco.co/checkout.js"></script>
<style>
body { font-family: 'Poppins', sans-serif; background: #0b1220; color: #fff; text-align: center; padding: 30px; }
ul { list-style: none; padding: 0; }
li { background: #1b2435; margin: 10px auto; padding: 12px; border-radius: 10px; width: 85%; text-align: left; }
li strong { color: #ff9800; }
button { background: #ff7b00; color: #fff; padding: 12px 25px; font-size: 18px; border: none; border-radius: 8px; cursor: pointer; margin-top: 20px; transition: background 0.3s ease; }
button:hover { background: #ffa31a; }
h1,h2 { color: #fff; }
.total { color: #00e676; font-weight: bold; font-size: 22px; }
</style>
</head>
<body>

<h1>Medio de Pago Epayco</h1>
<p>Confirma tu compra antes de pagar</p>

<ul>
<?php foreach ($carrito as $item): ?>
    <li>
        <strong><?= htmlspecialchars($item['nombre_foto']) ?></strong><br>
        Evento: <?= htmlspecialchars($item['evento_titulo']) ?><br>
        <span style="color:#ffb84d;">Precio: $<?= number_format($item['precio_unitario'], 0) ?></span>
    </li>
<?php endforeach; ?>
</ul>

<h2>Total a pagar: <span class="total">$<?= number_format($total, 0) ?> COP</span></h2>

<button id="boton-pago">Pagar ahora</button>

<script>
var handler = ePayco.checkout.configure({
    key: '<?= $epayco_public_key ?>',
    test: true
});

document.getElementById('boton-pago').addEventListener('click', function(e){
    e.preventDefault();
    handler.open({
        name: "Latin Color Sports",
        description: "Compra de: <?= htmlspecialchars(implode(', ', $descripcion_items)) ?>",
        amount: <?= $total ?>,
        currency: "COP",
        invoice: "<?= $ref_local ?>",
        tax_base: <?= $total ?>,
        tax: 0,
        country: "CO",
        lang: "es",
        external: "false",
        response: "<?= $url_response ?>",
        confirmation: "<?= $url_confirmation ?>",
        methodsDisable: ["CASH","SP"]
    });
});
</script>

</body>
</html>
