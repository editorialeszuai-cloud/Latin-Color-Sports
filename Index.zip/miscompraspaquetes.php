<?php
require_once 'navusuriopre.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mis Paquetes Comprados</title>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

<style>
.progress-bar{position:relative;height:6px;width:100%;background:rgba(255,255,255,.3);border-radius:4px;overflow:hidden;margin-top:8px;display:none}
.progress-bar-fill{height:100%;width:0;background:#22c55e;transition:width .2s ease}
body{font-family:Inter,sans-serif;background:#f3f4f6}
.card{background:#ff9800;border-radius:16px;padding:20px;margin-bottom:30px;box-shadow:0 4px 12px rgba(0,0,0,.1)}
.fotos-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px}
.foto-item{position:relative;aspect-ratio:1/1;overflow:hidden;border-radius:12px;border:2px solid #fff;box-shadow:0 3px 6px rgba(0,0,0,.1);cursor:pointer;transition:transform .2s}
.foto-item img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s}
.foto-item:hover img{transform:scale(1.05)}
.foto-checkbox{position:absolute;top:8px;left:8px;transform:scale(1.5);z-index:2;cursor:pointer}
#overlayControles{position:fixed;bottom:0;left:0;width:100%;background:rgba(0,0,0,.6);backdrop-filter:blur(5px);padding:15px;display:flex;justify-content:center;gap:15px;z-index:1000}
#overlayControles button{color:#fff;font-weight:700;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;box-shadow:0 3px 6px rgba(0,0,0,.2);transition:transform .2s}
#overlayControles button:hover{transform:scale(1.05)}
#seleccionarTodas{background:#22c55e}
#descargarSeleccionadas{background:#ef4444}
</style>
</head>
<body>

<h1 class="text-3xl font-bold text-center mb-6 text-gray-900">Mis Paquetes Comprados</h1>

<div id="paquetesContainer" class="max-w-6xl mx-auto p-4">
  <p class="text-center text-gray-600">Cargando tus paquetes...</p>
</div>

<!-- Overlay inferior -->
<div id="overlayControles" style="display:none;">
  <button id="seleccionarTodas">Seleccionar Todas</button>
  <div class="flex flex-col items-center">
    <button id="descargarSeleccionadas" disabled>Descargar Ahora</button>
    <div class="progress-bar" id="progressBar">
      <div class="progress-bar-fill" id="progressBarFill"></div>
    </div>
  </div>
</div>

<script>
/* =============================
   CONFIG FIREBASE
============================= */
firebase.initializeApp({
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
});

const auth = firebase.auth();
let firebase_uid = '';
let fotosSeleccionadas = [];

auth.onAuthStateChanged(user => {
  const container = document.getElementById('paquetesContainer');
  if (user) {
    firebase_uid = user.uid;
    cargarPaquetes(user.uid);
  } else {
    container.innerHTML = `
      <div class="col-span-full flex flex-col items-center justify-center p-4">
        <div class="w-full max-w-lg bg-gradient-to-br from-gray-900 to-gray-800 rounded-[2rem] overflow-hidden shadow-2xl relative">
          
          <div class="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <div class="absolute bottom-0 left-0 w-24 h-24 bg-orange-500/20 rounded-full -ml-12 -mb-12 blur-xl"></div>

          <div class="relative z-10 p-8 sm:p-12 text-center">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-tr from-orange-400 to-orange-600 shadow-lg mb-6 transform -rotate-2">
              <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
            </div>

            <h2 class="text-3xl font-bold text-white mb-4 tracking-tight">Tus Paquetes Especiales</h2>
            <p class="text-gray-400 mb-10 leading-relaxed">
              Descubre las ofertas y paquetes que tenemos preparados para ti. Inicia sesi��n para canjear tus fotos o adquirir nuevos beneficios.
            </p>

            <button onclick="window.location.href='login_app.html'" 
              class="group relative w-full inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-orange-500 font-pj rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 hover:bg-orange-600 shadow-lg shadow-orange-500/30">
              <span class="relative flex items-center gap-2">
                Iniciar Sesi��n Ahora
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
            </button>
            
            <div class="mt-8 pt-8 border-t border-gray-700/50 flex justify-center gap-6">
              <div class="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-widest">
                <span class="w-2 h-2 rounded-full bg-orange-500"></span> Ofertas
              </div>
              <div class="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-widest">
                <span class="w-2 h-2 rounded-full bg-orange-500"></span> Preventas
              </div>
              <div class="flex items-center gap-2 text-xs text-gray-500 uppercase tracking-widest">
                <span class="w-2 h-2 rounded-full bg-orange-500"></span> Galer��a
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
});
/* =============================
   CARGA DE PAQUETES
============================= */
async function cargarPaquetes(uid){
  const container = document.getElementById('paquetesContainer');
  container.innerHTML = '<p class="text-center text-gray-600">Cargando paquetes...</p>';

  try{
    const res = await fetch('mis_paquetes_api.php',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({firebase_uid:uid})
    });
    const data = await res.json();
    container.innerHTML = '';

    if(!data.success){ container.innerHTML = `<p class="text-center text-red-600">${data.message}</p>`; return; }
    if(!data.paquetes?.length){ container.innerHTML = '<p class="text-center text-gray-600">No hay paquetes comprados a��n.</p>'; return; }

    document.getElementById('overlayControles').style.display = 'flex';
    const frag = document.createDocumentFragment();

    // �9�7 Renderiza por lotes
    data.paquetes.forEach(p=>{
      p.eventos.forEach(ev=>{
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `<h2 class="text-xl font-semibold mb-4 text-center text-white">${ev.evento_titulo}</h2>`;

        const grid = document.createElement('div');
        grid.className = 'fotos-grid';

        if(ev.fotos?.length){
          ev.fotos.forEach(f=>{
            const rutaWatermark = `foto_watermark.php?img=${encodeURIComponent(f.nombre_archivo)}&w=400`;
            const rutaOriginal = `uploads/${f.nombre_archivo}`;
            const div = document.createElement('div');
            div.className = 'foto-item';
            div.innerHTML = `
              <input type='checkbox' class='foto-checkbox' 
                     data-src-original='${rutaOriginal}' 
                     data-id='${f.foto_id}'>
              <img data-src='${rutaWatermark}' alt='Foto ${f.foto_id}'>
            `;
            grid.appendChild(div);
          });
        }
        card.appendChild(grid);
        card.insertAdjacentHTML('beforeend', `<div class='footer-info text-sm text-white/80 mt-2 text-center'>Compra #${p.compra_id} - ${p.fecha_registro}</div>`);
        frag.appendChild(card);
      });
    });

    container.appendChild(frag);
    inicializarLazyLoad();
    inicializarCheckboxes();

  }catch(e){
    container.innerHTML = `<p class='text-center text-red-600'>Error al cargar paquetes: ${e.message}</p>`;
  }
}

/* =============================
   LAZY LOAD DE IM�0�9GENES
============================= */
function inicializarLazyLoad(){
  const imgs = document.querySelectorAll('img[data-src]');
  const observer = new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        const img = entry.target;
        img.src = img.dataset.src;
        observer.unobserve(img);
      }
    });
  }, {rootMargin:'200px'});
  imgs.forEach(img=>observer.observe(img));
}

/* =============================
   MANEJO DE CHECKBOXES
============================= */
function inicializarCheckboxes(){
  document.querySelectorAll('.foto-checkbox').forEach(c=>{
    c.addEventListener('change',()=>toggleSeleccion(c));
  });
}

/* =============================
   SELECCI�0�7N DE FOTOS
============================= */
function toggleSeleccion(checkbox){
  const srcOriginal = checkbox.dataset.srcOriginal;
  if(checkbox.checked){
    if(!fotosSeleccionadas.includes(srcOriginal)) fotosSeleccionadas.push(srcOriginal);
  }else{
    fotosSeleccionadas = fotosSeleccionadas.filter(f=>f!==srcOriginal);
  }
  actualizarBotones();
}

function actualizarBotones(){
  const total = document.querySelectorAll('.foto-checkbox').length;
  const seleccionadas = document.querySelectorAll('.foto-checkbox:checked').length;
  const btnDescargar = document.getElementById('descargarSeleccionadas');
  const btnSeleccionar = document.getElementById('seleccionarTodas');

  btnDescargar.disabled = seleccionadas===0;
  btnDescargar.style.opacity = seleccionadas>0 ? '1' : '0.6';
  btnDescargar.textContent = seleccionadas>0 ? `Descargar (${seleccionadas})` : 'Descargar Ahora';
  btnSeleccionar.textContent = (seleccionadas===total)?'Deseleccionar Todas':'Seleccionar Todas';
}

/* =============================
   BOTONES DE ACCI�0�7N
============================= */
document.getElementById('seleccionarTodas').addEventListener('click',()=>{
  const checkboxes = document.querySelectorAll('.foto-checkbox');
  const todasMarcadas = [...checkboxes].every(c=>c.checked);
  checkboxes.forEach(c=>{c.checked=!todasMarcadas; toggleSeleccion(c);});
});

/* =============================
   DESCARGA DE FOTOS
============================= */
document.getElementById('descargarSeleccionadas').addEventListener('click',async()=>{
  if(!fotosSeleccionadas.length) return;

  const btn=document.getElementById('descargarSeleccionadas');
  const bar=document.getElementById('progressBar');
  const fill=document.getElementById('progressBarFill');

  btn.disabled=true;
  btn.textContent='Preparando...';
  bar.style.display='block';
  fill.style.width='0%';

  const zip=new JSZip();
  const folder=zip.folder('fotos');
  const total=fotosSeleccionadas.length;

  let count=0;
  for(const url of fotosSeleccionadas){
    try{
      const res=await fetch(url);
      const blob=await res.blob();
      folder.file(url.split('/').pop(),blob);
    }catch(err){console.error('Error',url,err);}
    count++;
    const prog=Math.round((count/total)*100);
    fill.style.width=`${prog}%`;
    btn.textContent=`Descargando (${prog}%)`;
  }

  btn.textContent='Comprobando archivos...';
  const content=await zip.generateAsync({type:'blob'});
  saveAs(content,'fotos_seleccionadas.zip');

  // Reset
  btn.disabled=false;
  bar.style.display='none';
  fill.style.width='0%';
  btn.textContent='Descargar Ahora';
});
</script>

</body>
</html>
