<?php
// ================================================================
// ARCHIVO: db_mysqli.php
// ================================================================
// Este script establece la conexión a la base de datos MySQL utilizando la extensión MySQLi.
// Exporta el objeto de conexión '$mysqli' para ser utilizado por otros scripts PHP.

// --- Configuración de la base de datos MySQL ---
// Estas credenciales son para tu base de datos MySQL.
// ¡¡¡REEMPLAZA LOS VALORES POR LOS DE TU CONFIGURACIÓN REAL!!!
$dbHost = 'localhost';          // El host de tu base de datos (normalmente 'localhost' si está en el mismo servidor)
$dbUser = 'database-1.c8302k404lkf.us-east-1.rds.amazonaws.com';       // <--- !!! REEMPLAZA CON EL NOMBRE DE USUARIO DE TU DB !!!
$dbPass = 'DannyCruxTecnoLoad!#';   // <--- !!! REEMPLAZA CON LA CONTRASEÑA DE TU DB !!!
$dbName = 'latincolors';     // <--- !!! REEMPLAZA CON EL NOMBRE DE TU BASE DE DATOS !!!

// Variable que contendrá el objeto de conexión MySQLi
$mysqli = null; 

try {
    // Intentar establecer la conexión a la base de datos
    // La función 'new mysqli()' es el constructor de la clase MySQLi
    $mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    // Verificar si la conexión fue exitosa
    if ($mysqli->connect_error) {
        // Si hay un error de conexión, lanzamos una excepción para que sea capturada
        throw new Exception("Error de conexión a la base de datos MySQLi: " . $mysqli->connect_error);
    }

    // Establecer el conjunto de caracteres a UTF-8 para evitar problemas de codificación
    // Esto es muy importante para manejar correctamente caracteres especiales.
    $mysqli->set_charset("utf8mb4");

    // Opcional: Para depuración, puedes registrar que la conexión fue exitosa
    // error_log("Conexión a la DB MySQLi exitosa.");

} catch (Throwable $e) { // Usamos Throwable para capturar también errores (no solo excepciones)
    // Si la conexión falla o hay cualquier otro error durante la inicialización de MySQLi
    error_log("Error CRÍTICO al conectar a la base de datos: " . $e->getMessage()); // Registra el error en los logs del servidor
    
    // Enviamos una respuesta JSON de error al frontend y terminamos la ejecución
    header('Content-Type: application/json'); // Asegurarse de que el header sea JSON
    http_response_code(500); // Código de estado HTTP 500 (Internal Server Error)
    echo json_encode([
        'status' => 'error',
        'message' => 'Error crítico de conexión a la base de datos. Por favor, contacta al administrador.',
        'debug' => 'Verifica las credenciales de la base de datos en db_mysqli.php y el estado del servidor MySQL. Error: ' . $e->getMessage()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit(); // Detenemos la ejecución del script si no hay conexión a la DB
}
