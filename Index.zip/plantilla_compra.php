<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <title>Resumen de Compra - Latin Color Sports</title>
    <style>
        body { font-family: 'Segoe UI', Helvetica, Arial, sans-serif; background-color:#111111; padding:0; margin:0; color: #333; }
        .container { background-color:#ffffff; max-width:600px; margin:20px auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        
        /* Header con Branding */
        .header { background-color: #000000; padding: 30px; text-align: center; border-bottom: 4px solid #FF6600; }
        .header img { max-width: 180px; height: auto; }
        
        .content { padding: 30px; }
        h2 { color: #1a1a1a; text-transform: uppercase; font-size: 24px; margin-bottom: 5px; text-align: center; }
        .subtitle { text-align: center; color: #666; margin-bottom: 25px; }
        
        /* Detalles de Referencia */
        .ref-box { background-color: #f8f8f8; border-left: 4px solid #FF6600; padding: 15px; margin-bottom: 20px; }
        .ref-box p { margin: 5px 0; font-size: 14px; }
        
        /* Tabla Deportiva */
        table { width:100%; border-collapse:collapse; margin-top:20px; }
        th { background-color: #1a1a1a; color: #ffffff; padding: 12px; text-align: left; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; }
        td { padding: 15px 12px; border-bottom: 1px solid #eeeeee; font-size: 14px; }
        
        .total-row { background-color: #fff5ed; }
        .total-label { text-align: right; font-weight: bold; text-transform: uppercase; }
        .total-amount { color: #FF6600; font-size: 22px; font-weight: 900; text-align: right; }
        
        /* Bot��n de Acci��n Call-to-Action */
        .btn-container { text-align: center; margin: 40px 0 20px 0; }
        .btn { background-color: #FF6600; color: #ffffff !important; padding: 16px 35px; text-decoration: none; border-radius: 50px; font-weight: bold; font-size: 16px; display: inline-block; transition: background 0.3s; border: none; box-shadow: 0 4px 10px rgba(255, 102, 0, 0.3); }
        
        .footer { background-color: #1a1a1a; color: #888888; font-size: 11px; padding: 25px; text-align: center; }
        .footer a { color: #FF6600; text-decoration: none; }
    </style>
</head>
<body>

<div class="container">
 <div class="header" style="background-color: #000000; padding: 40px 20px; text-align: center; border-bottom: 5px solid #FF6600;">
    

    <h1 style="color: #ffffff; margin: 0; font-size: 36px; font-weight: 900; letter-spacing: -1px; line-height: 1; text-transform: uppercase; font-family: 'Arial Black', sans-serif;">
        LATIN COLOR <span style="color: #FF6600;">SPORTS</span>
    </h1>
    
    <p style="color: #FF6600; margin: 5px 0 0 0; font-size: 14px; font-weight: bold; letter-spacing: 3px; text-transform: uppercase;">
        Fotograf��a y Eventos
    </p>

</div>

    <div class="content">
        <h2>??Casi es tuyo!</h2>
        <p class="subtitle">Solo falta un paso para completar tu pedido.</p>

        <div class="ref-box">
            <p><strong>REFERENCIA DE PEDIDO:</strong> {{REFERENCIA}}</p>
            <p><strong>ESTADO:</strong> <span style="color: #FF6600; font-weight: bold;">ESPERANDO PAGO</span></p>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Descripci��n</th>
                    <th style="text-align: right;">Precio</th>
                </tr>
            </thead>
            <tbody>
                {{FILAS_FOTOS}}
                <tr class="total-row">
                    <td class="total-label">Total a pagar:</td>
                    <td class="total-amount">${{TOTAL}}</td>
                </tr>
            </tbody>
        </table>

        <div class="btn-container">
            <a href="{{LINK_PAGO}}" class="btn">FINALIZAR MI COMPRA AHORA</a>
        </div>
        
        <p style="font-size: 13px; color: #777; text-align: center;">
            * El link de pago expira pronto. Asegura tus fotos antes de que termine el evento.
        </p>
    </div>

    <div class="footer">
        <p><strong>LATIN COLOR SPORTS</strong><br>
        Capturando tus mejores momentos deportivos.</p>
        <p>Si tienes problemas con el pago, escr��benos a:<br>
        <a href="mailto:notificaciones@latincolorgroup.com">notificaciones@latincolorgroup.com</a></p>
        <p style="margin-top: 20px; font-size: 10px; opacity: 0.6;">
            ?? 2026 Latin Color Group. Todos los derechos reservados.
        </p>
    </div>
</div>

</body>
</html>