<?php
// mis_paquetes_api.php
header('Content-Type: application/json');
require_once 'dbfotografos.php';
$pdo = conectar();

// Leer POST JSON
$data = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $data['firebase_uid'] ?? '';

if (!$firebase_uid) {
    echo json_encode(['success' => false, 'message' => 'No se recibió el usuario.']);
    exit;
}

try {
    // Obtener compras de paquetes aceptadas
    $stmt = $pdo->prepare("
        SELECT id AS compra_id, fecha, total
        FROM compras_paquetes
        WHERE firebase_uid = ? AND estado = 'Pagado'
        ORDER BY fecha DESC
    ");
    $stmt->execute([$firebase_uid]);
    $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $result = [];

    foreach ($compras as $compra) {
        $compra_id = $compra['compra_id'];

        // Obtener eventos de esta compra
        $stmt = $pdo->prepare("
            SELECT e.id AS evento_id, e.titulo AS evento_titulo
            FROM detalle_compras_paquetes dcp
            INNER JOIN eventos e ON dcp.evento_id = e.id
            WHERE dcp.id_compra = ?
        ");
        $stmt->execute([$compra_id]);
        $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $eventos_array = [];

        foreach ($eventos as $ev) {
            $evento_id = $ev['evento_id'];

            // Obtener todas las fotos de ese evento
            $stmt = $pdo->prepare("
                SELECT f.id AS foto_id, f.url AS nombre_archivo
                FROM fotos f
                INNER JOIN postulaciones p ON f.postulacion_id = p.id
                WHERE p.evento_id = ?
            ");
            $stmt->execute([$evento_id]);
            $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $eventos_array[] = [
                'evento_id' => $evento_id,
                'evento_titulo' => $ev['evento_titulo'],
                'fotos' => $fotos
            ];
        }

        $result[] = [
            'compra_id' => $compra_id,
            'fecha_registro' => $compra['fecha'],
            'total' => $compra['total'],
            'eventos' => $eventos_array
        ];
    }

    echo json_encode(['success' => true, 'paquetes' => $result]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error al consultar la base de datos: ' . $e->getMessage()]);
}
