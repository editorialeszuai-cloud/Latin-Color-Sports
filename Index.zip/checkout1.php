<?php
// Sustituye las primeras líneas por esto:
ob_start();
ini_set('display_errors', 1); // <-- ACTIVADO
error_reporting(E_ALL);
require_once 'dbfotografos.php';
$pdo = conectar();
// ...

$firebase_uid = trim($_GET['firebase_uid'] ?? '');
$guest_uid    = trim($_GET['guest_uid']    ?? '');
$moneda       = trim($_GET['moneda']       ?? 'COP');
$compra_id    = trim($_GET['compra_id']    ?? '');

$public_key       = "pub_prod_qDvUDoTJtgy1bVkcuQJ7rcgkOM4oxbLw";
$secret_integrity = "prod_integrity_BWG58peE6yhM382mYETKtAjra3xNEARl";
$currency         = "COP";

// ─────────────────────────────────────────────────────────────────────────────
// MODO A: llega compra_id → mostrar resumen de compra ya creada (viene de redirect)
// ─────────────────────────────────────────────────────────────────────────────
if ($compra_id) {
    try {
        $stmt = $pdo->prepare("SELECT *, firebase_uid as uid_propietario FROM compras WHERE id = ?");
        $stmt->execute([$compra_id]);
        $compra = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$compra) die('Error: Orden no encontrada.');

        $stmt = $pdo->prepare("
            SELECT d.precio, d.id_foto, d.evento_id AS detalle_evento_id,
                   f.url AS foto_url, e.titulo AS evento_titulo, l.pais
            FROM detalle_compras d
            LEFT JOIN fotos f ON d.id_foto = f.id
            LEFT JOIN postulaciones p ON f.postulacion_id = p.id
            LEFT JOIN eventos e ON (d.evento_id = e.id OR p.evento_id = e.id)
            LEFT JOIN lugares l ON e.lugar_id = l.id
            WHERE d.id_compra = ?
        ");
        $stmt->execute([$compra_id]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $pais_evento = 'Desconocido';
        foreach ($items as $item) {
            if (!empty($item['detalle_evento_id'])) {
                $stmtLugar = $pdo->prepare("SELECT l.pais FROM eventos e JOIN lugares l ON e.lugar_id = l.id WHERE e.id = ?");
                $stmtLugar->execute([$item['detalle_evento_id']]);
                if ($res = $stmtLugar->fetch()) { $pais_evento = $res['pais']; break; }
            }
        }

        $es_colombia      = (strcasecmp(trim((string)$pais_evento), 'Colombia') === 0);
        $total_precio     = (float)$compra['total'];
        $transaccion_id   = $compra['referencia'];
        $amount_in_cents  = intval(round($total_precio * 100 * 3500));
        $amount_in_cents2 = intval(round($total_precio * 100 * 17.60));
        $firma            = hash("sha256", $transaccion_id . $amount_in_cents . $currency . $secret_integrity);
        $modo             = 'resumen_compra';

    } catch (PDOException $e) {
        die("Error de base de datos: " . $e->getMessage());
    }

// ─────────────────────────────────────────────────────────────────────────────
// MODO B: firebase_uid real → merge + crear compra → redirect a modo A
// ─────────────────────────────────────────────────────────────────────────────
} elseif ($firebase_uid && !str_starts_with($firebase_uid, 'guest_') && $firebase_uid !== 'undefined') {

    // Verificar que existe en BD
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$firebase_uid]);
    $usuario_existe = (bool)$stmt->fetch();

    if ($usuario_existe) {
        // Merge carrito guest → real
        if ($guest_uid && str_starts_with($guest_uid, 'guest_')) {
            $pdo->prepare("UPDATE carrito SET firebase_uid = ? WHERE firebase_uid = ?")
                ->execute([$firebase_uid, $guest_uid]);
        }

        $stmt = $pdo->prepare("SELECT foto_id, evento_id, precio FROM carrito WHERE firebase_uid = ?");
        $stmt->execute([$firebase_uid]);
        $items_carrito = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!$items_carrito) {
            $modo = 'carrito_vacio';
        } else {
            try {
                $total_raw  = array_sum(array_column($items_carrito, 'precio'));
                $referencia = "LCS-" . time() . "-" . strtoupper(substr(bin2hex(random_bytes(3)), 0, 4));

                $pdo->beginTransaction();

                $pdo->prepare(
                    "INSERT INTO compras (firebase_uid, referencia, total, estado, fecha_compra)
                     VALUES (?, ?, ?, 'Pendiente', NOW())"
                )->execute([$firebase_uid, $referencia, $total_raw]);
                $new_compra_id = $pdo->lastInsertId();

                $s_det = $pdo->prepare(
                    "INSERT INTO detalle_compras (id_compra, id_foto, evento_id, precio)
                     VALUES (:cid, :fid, :eid, :pre)"
                );
                $s_com = $pdo->prepare(
                    "INSERT INTO comisiones_usuario
                         (admin, fotografo, organizador, soporte, comercial, compra_id, foto_id, evento_id)
                     VALUES (:adm, :fot, :org, :sop, :com, :cid, :fid, :eid)"
                );

                foreach ($items_carrito as $item) {
                    $v = (float)$item['precio'];
                    $f = !empty($item['foto_id'])   ? $item['foto_id']   : null;
                    $e = !empty($item['evento_id']) ? $item['evento_id'] : null;
                    $s_det->execute([':cid'=>$new_compra_id,':fid'=>$f,':eid'=>$e,':pre'=>$v]);
                    $s_com->execute([
                        ':adm'=>round($v*0.35,2),':fot'=>round($v*0.50,2),
                        ':org'=>round($v*0.10,2),':sop'=>round($v*0.03,2),
                        ':com'=>round($v*0.02,2),
                        ':cid'=>$new_compra_id,':fid'=>$f,':eid'=>$e,
                    ]);
                }

                $pdo->prepare("DELETE FROM carrito WHERE firebase_uid = ?")->execute([$firebase_uid]);
                $pdo->commit();

                ob_end_clean();
                header("Location: checkout1.php?compra_id=" . $new_compra_id);
                exit;

            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log("[checkout1] Error UID=$firebase_uid | " . $e->getMessage());
                $modo          = 'error_compra';
                $error_mensaje = "Hubo un problema procesando tu compra. Intenta de nuevo.";
            }
        }
    } else {
        // UID desconocido → tratar como invitado
        $firebase_uid = $guest_uid ?: $firebase_uid;
        $modo = 'invitado';
    }

// ─────────────────────────────────────────────────────────────────────────────
// MODO C: invitado (guest_ o sin uid) → leer carrito en PHP + mostrar login modal
// ─────────────────────────────────────────────────────────────────────────────
} else {
    $modo = 'invitado';
}

// Para invitado: leer carrito directo de BD (sin fetch externo)
if ($modo === 'invitado') {
    $uid_carrito = $firebase_uid ?: $guest_uid;
    $items_guest = [];
    $total_guest = 0;

    if ($uid_carrito) {
        $stmt = $pdo->prepare("
            SELECT c.foto_id, c.evento_id, c.precio,
                   f.url AS foto_url,
                   e.titulo AS evento_titulo
            FROM carrito c
            LEFT JOIN fotos   f ON c.foto_id   = f.id
            LEFT JOIN eventos e ON c.evento_id  = e.id
            WHERE c.firebase_uid = ?
        ");
        $stmt->execute([$uid_carrito]);
        $items_guest = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $total_guest = array_sum(array_column($items_guest, 'precio'));
    }
}

ob_end_clean();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Checkout | Latin Color Sports</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
  
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --orange:      #f97316;
      --orange-dk:   #c2510e;
      --orange-glow: rgba(249,115,22,.18);
      --bg:          #080808;
      --surface:     #111111;
      --surface2:    #1a1a1a;
      --border:      rgba(255,255,255,.08);
      --border-h:    rgba(255,255,255,.15);
      --text:        #f0f0f0;
      --muted:       rgba(255,255,255,.35);
      --success:     #4ade80;
      --error:       #f87171;
      --radius:      14px;
      --radius-sm:   8px;
    }
    body {
      font-family: 'DM Sans', sans-serif;
      background: var(--bg); color: var(--text);
      min-height: 100vh;
      display: flex; align-items: center; justify-content: center;
      padding: 1.5rem 1rem; overflow-x: hidden;
    }
    body::before {
      content: ''; position: fixed; inset: 0; pointer-events: none; z-index: 0;
      background-image:
        linear-gradient(rgba(249,115,22,.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(249,115,22,.03) 1px, transparent 1px);
      background-size: 40px 40px;
    }
    body::after {
      content: ''; position: fixed; top: -200px; left: 50%;
      transform: translateX(-50%); width: 600px; height: 400px;
      background: radial-gradient(ellipse, rgba(249,115,22,.12) 0%, transparent 70%);
      pointer-events: none; z-index: 0;
    }

    /* ── LOADER ── */
    #loader {
      position: fixed; inset: 0; background: #080808; z-index: 9999;
      display: flex; align-items: center; justify-content: center; flex-direction: column; gap: 14px;
    }
    #loader .ring {
      width: 40px; height: 40px;
      border: 4px solid rgba(255,255,255,.15); border-top-color: #f97316;
      border-radius: 50%; animation: spin .8s linear infinite;
    }
    #loader p { font-size: .75rem; color: var(--muted); letter-spacing: .07em; text-transform: uppercase; }

    /* ── WRAP ── */
    .wrap {
      position: relative; z-index: 1; width: 100%; max-width: 460px;
      animation: rise .45s cubic-bezier(.22,.68,0,1.2);
    }
    @keyframes rise { from { opacity:0; transform:translateY(18px) scale(.97); } to { opacity:1; transform:none; } }
    @keyframes spin  { to { transform: rotate(360deg); } }
    @keyframes fadeUp { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:none; } }

    /* ── LOGO ── */
    .logo { text-align: center; margin-bottom: 1.6rem; }
    .logo img { width: 50px; height: 50px; border-radius: 12px; border: 1px solid var(--border-h); margin: 0 auto .6rem; display: block; }
    .logo h1 { font-family: 'Bebas Neue'; font-size: 1.7rem; letter-spacing: .12em; line-height: 1; }
    .logo p  { font-size: .72rem; color: var(--muted); margin-top: .3rem; letter-spacing: .04em; }

    /* ── CARD ── */
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; margin-bottom: 1rem; }
    .card-head { padding: 1rem 1.4rem; border-bottom: 1px solid var(--border); background: rgba(0,0,0,.35); display: flex; align-items: center; justify-content: space-between; }
    .card-head h2 { font-family: 'Bebas Neue'; font-size: 1.1rem; letter-spacing: .09em; color: var(--text); }
    .card-body { padding: 1.4rem; }
    .card-foot { padding: .85rem 1.4rem; background: rgba(0,0,0,.4); border-top: 1px solid var(--border); text-align: center; }

    /* ── BADGE USUARIO ── */
    .user-badge { font-size: .65rem; font-weight: 700; color: var(--muted); letter-spacing: .08em; text-transform: uppercase; }

    /* ── LISTA ÍTEMS ── */
    .item-list { max-height: 11rem; overflow-y: auto; padding-right: .2rem; margin-bottom: 1.2rem; }
    .item-list::-webkit-scrollbar { width: 3px; }
    .item-list::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 10px; }
    .item-row {
      display: flex; align-items: center; gap: .7rem;
      background: var(--surface2); border: 1px solid var(--border);
      border-radius: var(--radius-sm); padding: .55rem .7rem; margin-bottom: .45rem;
    }
    .item-row img { width: 36px; height: 36px; object-fit: cover; border-radius: 6px; flex-shrink: 0; }
    .item-row .info { flex: 1; min-width: 0; }
    .item-row .info span { display: block; font-size: .67rem; color: var(--muted); text-transform: uppercase; letter-spacing: .04em; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .item-row .info p { font-size: .8rem; }
    .item-row .price { font-size: .78rem; font-weight: 700; color: var(--orange); white-space: nowrap; }

    /* ── TOTALES ── */
    .sec-label { font-size: .63rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; color: var(--orange); margin-bottom: .65rem; }
    .totals { display: flex; flex-direction: column; gap: .45rem; margin-bottom: 1.2rem; }
    .total-row {
      display: flex; align-items: center; justify-content: space-between;
      background: rgba(255,255,255,.03); border: 1px solid var(--border);
      border-radius: var(--radius-sm); padding: .55rem .85rem;
      transition: border-color .2s;
    }
    .total-row:hover { border-color: var(--border-h); }
    .total-row .lbl { font-size: .67rem; color: var(--muted); text-transform: uppercase; letter-spacing: .07em; font-weight: 700; }
    .total-row .val { display: flex; align-items: baseline; gap: .3rem; }
    .total-row .num { font-size: 1.1rem; font-weight: 800; }
    .total-row .cur { font-size: .63rem; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; }
    .cur-cop { color: #818cf8; } .cur-usd { color: #34d399; } .cur-mxn { color: #fbbf24; }

    .fade1 { animation: fadeUp .4s ease forwards; }
    .fade2 { animation: fadeUp .4s ease .1s forwards; opacity:0; }
    .fade3 { animation: fadeUp .4s ease .2s forwards; opacity:0; }

    /* ── WOMPI ── */
    .wompi-wrap { display: flex; justify-content: center; padding: .4rem 0 .2rem; }

    /* ── FORMULARIO INVITADO ── */
    .field { margin-bottom: .75rem; }
    .field label { display: block; font-size: .68rem; font-weight: 700; color: var(--muted); letter-spacing: .05em; text-transform: uppercase; margin-bottom: .32rem; }
    .field input {
      width: 100%; padding: .7rem .95rem; background: var(--surface2);
      border: 1px solid var(--border); border-radius: var(--radius-sm);
      color: var(--text); font-family: 'DM Sans'; font-size: .88rem;
      transition: border-color .2s, box-shadow .2s;
    }
    .field input::placeholder { color: rgba(255,255,255,.18); }
    .field input:focus { outline: none; border-color: var(--orange); box-shadow: 0 0 0 3px var(--orange-glow); }

    /* ── BOTONES ── */
    .btn-main {
      width: 100%; padding: .78rem 1rem; background: var(--orange); color: #fff;
      border: none; border-radius: var(--radius-sm); font-family: 'DM Sans';
      font-size: .82rem; font-weight: 700; letter-spacing: .07em; text-transform: uppercase;
      cursor: pointer; transition: all .18s; box-shadow: 0 4px 18px var(--orange-glow);
    }
    .btn-main:hover:not(:disabled) { background: var(--orange-dk); transform: translateY(-1px); }
    .btn-main:active:not(:disabled) { transform: scale(.98); }
    .btn-main:disabled { opacity: .45; cursor: not-allowed; }
    .btn-ghost {
      width: 100%; padding: .78rem 1rem; background: var(--surface2); color: var(--text);
      border: 1px solid var(--border); border-radius: var(--radius-sm); font-family: 'DM Sans';
      font-size: .82rem; font-weight: 700; letter-spacing: .07em; text-transform: uppercase;
      cursor: pointer; transition: all .18s; margin-top: .5rem;
    }
    .btn-ghost:hover { border-color: var(--border-h); }
    .btn-back { background: none; border: none; color: var(--muted); font-size: .7rem; font-weight: 700; letter-spacing: .07em; text-transform: uppercase; cursor: pointer; transition: color .15s; }
    .btn-back:hover { color: var(--text); }

    /* ── TABS ── */
    .tabs { display: flex; gap: 5px; background: var(--surface2); padding: 4px; border-radius: 10px; margin-bottom: 1.3rem; }
    .tab { flex:1; padding:.5rem; border:none; border-radius:7px; font-family:'DM Sans'; font-size:.69rem; font-weight:700; letter-spacing:.06em; text-transform:uppercase; cursor:pointer; transition:all .2s; background:transparent; color:var(--muted); }
    .tab.active { background: var(--orange); color:#fff; box-shadow: 0 2px 12px var(--orange-glow); }

    /* ── MSGS ── */
    .msg { display:none; padding:.6rem .9rem; border-radius:var(--radius-sm); font-size:.76rem; font-weight:600; margin-bottom:1rem; line-height:1.4; }
    .msg.error   { display:block; background:rgba(248,113,113,.1); border:1px solid rgba(248,113,113,.25); color:var(--error); }
    .msg.success { display:block; background:rgba(74,222,128,.1);  border:1px solid rgba(74,222,128,.25);  color:var(--success); }

    /* ── SPINNER ── */
    .spinner { display:inline-block; width:13px; height:13px; border:2px solid rgba(255,255,255,.3); border-top-color:#fff; border-radius:50%; animation:spin .6s linear infinite; vertical-align:middle; margin-right:5px; }

    /* ── DIVIDER ── */
    .divider { display:flex; align-items:center; gap:.6rem; margin:1rem 0; }
    .divider::before, .divider::after { content:''; flex:1; height:1px; background:var(--border); }
    .divider span { font-size:.62rem; font-weight:700; letter-spacing:.1em; text-transform:uppercase; color:var(--muted); }

    /* ── MODAL ── */
    .modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.8); backdrop-filter:blur(8px); z-index:500; align-items:center; justify-content:center; padding:1rem; }
    .modal-overlay.open { display:flex; }
    .modal { background:var(--surface); border:1px solid var(--border-h); border-radius:var(--radius); width:100%; max-width:390px; animation:rise .3s cubic-bezier(.22,.68,0,1.2); position:relative; }
    .modal-head { padding:1.1rem 1.4rem; border-bottom:1px solid var(--border); display:flex; align-items:center; justify-content:space-between; }
    .modal-head h2 { font-family:'Bebas Neue'; font-size:1.2rem; letter-spacing:.08em; }
    .modal-close { background:none; border:none; color:var(--muted); font-size:1.2rem; cursor:pointer; line-height:1; transition:color .15s; }
    .modal-close:hover { color:var(--text); }
    .modal-body { padding:1.4rem; }

    /* ── SOCIAL HIDDEN ── */
    .hidden { display:none !important; }

    /* ── VACIO / ERROR ── */
    .state-box { text-align:center; padding:2.5rem 1.4rem; }
    .state-box .icon { margin:0 auto 1rem; opacity:.25; }
    .state-box h2 { font-family:'Bebas Neue'; font-size:1.5rem; letter-spacing:.1em; }
    .state-box p  { font-size:.82rem; color:var(--muted); margin:.4rem 0 1.4rem; }

    @keyframes fadeInUp { from{opacity:0;transform:translateY(6px);} to{opacity:1;transform:none;} }
    .animate-fade-in { animation: fadeInUp .4s cubic-bezier(.16,1,.3,1) forwards; }
    .dynamic-fade { animation: fadeInUp .3s ease forwards; }
    .dynamic-delay-1 { animation-delay:.1s; opacity:0; }
    .dynamic-delay-2 { animation-delay:.2s; opacity:0; }
	
	#guestWompiWrap {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100px;
    width: 100%;
}


  </style>
</head>
<body>

<!-- LOADER -->
<div id="loader">
  <div class="ring"></div>
  <p>Verificando sesión...</p>
</div>

<div class="wrap" id="mainWrap" style="display:none">

  <!-- LOGO -->
  <div class="logo">
    <img src="../uploads/LATIN-SPORTS.png" alt="Latin Color Sports" onerror="this.style.display='none'">
    <h1>Latin Color <span style="color:var(--orange)">Sports</span></h1>
    <p id="pageSubtitle">
      <?php if ($modo === 'resumen_compra'): ?>Resumen de tu pedido
      <?php elseif ($modo === 'invitado'): ?>Revisa tu pedido y completa el pago
      <?php else: ?>Procesando...<?php endif; ?>
    </p>
  </div>

<?php /* ════════════════════════════════════════════════════════
         MODO: CARRITO VACÍO
       ════════════════════════════════════════════════════════ */
if ($modo === 'carrito_vacio'): ?>
  <div class="card">
    <div class="state-box">
      <svg class="icon" width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 00-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 00-16.536-1.84M7.5 14.25L5.106 5.272M6 20.25a.75.75 0 11-1.5 0 .75.75 0 011.5 0zm12.75 0a.75.75 0 11-1.5 0 .75.75 0 011.5 0z"/></svg>
      <h2 style="color:var(--orange)">Carrito vacío</h2>
      <p>No tienes fotos seleccionadas.</p>
      <button class="btn-back" onclick="window.history.back()">← Volver a la galería</button>
    </div>
  </div>

<?php /* ════════════════════════════════════════════════════════
         MODO: ERROR AL CREAR COMPRA
       ════════════════════════════════════════════════════════ */
elseif ($modo === 'error_compra'): ?>
  <div class="card">
    <div class="state-box">
      <h2 style="color:var(--error)">Error en el pedido</h2>
      <p><?= htmlspecialchars($error_mensaje ?? 'Error inesperado.') ?></p>
      <button class="btn-back" onclick="window.history.back()">← Volver</button>
    </div>
  </div>

<?php /* ════════════════════════════════════════════════════════
         MODO: RESUMEN COMPRA (logueado, viene con compra_id)
       ════════════════════════════════════════════════════════ */
elseif ($modo === 'resumen_compra'): ?>
  <div class="card">
    <div class="card-head">
      <h2>Tu pedido</h2>
      <div class="user-badge" id="userBadge">cargando...</div>
    </div>
    <div class="card-body">

      <!-- Ítems -->
      <div class="item-list">
        <?php foreach($items as $item): ?>
        <div class="item-row">
          <img src="<?= htmlspecialchars($item['foto_url'] ?? '') ?>" alt="" onerror="this.src='/uploads/idevento.jpg'">
          <div class="info">
            <span><?= htmlspecialchars($item['evento_titulo'] ?? 'Evento') ?></span>
            <p><?= $item['id_foto'] ? "Foto #".$item['id_foto'] : "Pack Completo" ?></p>
          </div>
          <div class="price">$<?= number_format((float)$item['precio'], $es_colombia ? 0 : 2, ',', '.') ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Totales -->
      <div class="sec-label">Total a pagar</div>
      <div class="totals">
        <div class="total-row fade1">
          <span class="lbl">Monto base</span>
          <div class="val">
            <span class="num">$<?= number_format($total_precio, $es_colombia ? 0 : 2, ',', '.') ?></span>
            <span class="cur <?= $es_colombia ? 'cur-cop' : 'cur-usd' ?>"><?= $es_colombia ? 'COP' : 'USD' ?></span>
          </div>
        </div>
        <?php if ($amount_in_cents > 0): ?>
        <div class="total-row fade2">
          <span class="lbl">Pasarela (COP)</span>
          <div class="val">
            <span class="num">$<?= number_format($amount_in_cents / 100, 0, ',', '.') ?></span>
            <span class="cur cur-cop">COP</span>
          </div>
        </div>
        <?php endif; ?>
        <?php if ($amount_in_cents2 > 0): ?>
        <div class="total-row fade3">
          <span class="lbl">Equivalente MXN</span>
          <div class="val">
            <span class="num">$<?= number_format($amount_in_cents2 / 100, 2, ',', '.') ?></span>
            <span class="cur cur-mxn">MXN</span>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Wompi -->
      <?php if ($firma): ?>
      <div class="wompi-wrap" id="paymentMethodWrap">
    <?php if ($total_precio == 5): // Condición para mostrar PayPal ?>
        <div id="paypal-container-QMFNBRQZ72CEJ" style="width:100%; display:block !important; writing-mode:horizontal-tb !important; direction:ltr !important;"></div>
        <script src="https://www.paypal.com/sdk/js?client-id=BAAjUMSlbZei2VSaAaGbrHEkefSoUyJFr7t3bUld8RyYlS-vSGzC-Xt5TGJZhhRma8843NPH05l9maHHRY&components=hosted-buttons&disable-funding=venmo&currency=USD"></script>
        <script>
            paypal.HostedButtons({ hostedButtonId: "QMFNBRQZ72CEJ" }).render("#paypal-container-QMFNBRQZ72CEJ");
        </script>
    <?php else: ?>
        <form>
            <script
                src="https://checkout.wompi.co/widget.js"
                data-render="button"
                data-public-key="<?= $public_key ?>"
                data-currency="COP"
                data-amount-in-cents="<?= $amount_in_cents ?>"
                data-reference="<?= $transaccion_id ?>"
                data-redirect-url="https://latincolorsports.com/response.php"
                data-signature:integrity="<?= $firma ?>">
            </script>
        </form>
    <?php endif; ?>
</div>
      <?php endif; ?>

      <?php if (file_exists('medios.php')) require 'medios.php'; ?>
    </div>
    <div class="card-foot">
      <button class="btn-back" onclick="window.history.back()">← Cancelar y volver</button>
    </div>
  </div>

<?php /* ════════════════════════════════════════════════════════
         MODO: INVITADO — resumen carrito + datos + modal login
       ════════════════════════════════════════════════════════ */
elseif ($modo === 'invitado'): ?>

  <div class="card" id="guestCard">
    <div class="card-head">
      <h2>Tu pedido</h2>
      <span style="font-size:.65rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.07em">Invitado</span>
    </div>
    <div class="card-body">

      <div id="guestMsg" class="msg"></div>

      <!-- Ítems del carrito leídos en PHP -->
      <?php if (!empty($items_guest)): ?>
      <div class="item-list">
        <?php foreach($items_guest as $item): ?>
        <div class="item-row">
          <img src="<?= htmlspecialchars($item['foto_url'] ?? '') ?>" alt="" onerror="this.src='/uploads/idevento.jpg'">
          <div class="info">
            <span><?= htmlspecialchars($item['evento_titulo'] ?? 'Evento') ?></span>
            <p><?= $item['foto_id'] ? "Foto #".$item['foto_id'] : "Pack Completo" ?></p>
          </div>
          <div class="price">$<?= number_format((float)$item['precio'], 0, ',', '.') ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <div class="totals" style="margin-bottom:1.3rem">
        <div class="total-row">
          <span class="lbl">Total</span>
          <div class="val">
            <span class="num">$<?= number_format($total_guest, 0, ',', '.') ?></span>
            <span class="cur cur-cop">COP</span>
          </div>
        </div>
      </div>
      <?php else: ?>
      <div style="text-align:center;padding:1.2rem 0;color:var(--muted);font-size:.82rem">
        Sin ítems en el carrito.
      </div>
      <?php endif; ?>

      <!-- Datos del invitado -->
      <div class="sec-label">Tus datos</div>
      <div class="field">
        <label>Nombre completo</label>
        <input type="text" id="g-nombre" placeholder="Tu nombre" autocomplete="name">
      </div>
      <div class="field">
        <label>Email</label>
        <input type="email" id="g-email" placeholder="tu@correo.com" autocomplete="email">
      </div>
      <div class="field">
        <label>WhatsApp</label>
        <input type="tel" id="g-whatsapp" placeholder="+57 300 000 0000" autocomplete="tel">
      </div>

      <div class="divider"><span>o inicia sesión</span></div>

      <button class="btn-main" onclick="openModal()">Iniciar sesión / Crear cuenta</button>
      <?php if (!empty($items_guest)): ?>
      <button class="btn-ghost" id="btnGuestPay">Continuar como invitado →</button>
      <?php endif; ?>
    </div>
    <div class="card-foot">
      <button class="btn-back" onclick="window.history.back()">← Cancelar y volver</button>
    </div>
  </div>

  <!-- Wompi para invitado (aparece tras confirmar datos) -->
  <div id="guestWompiCard" class="card" style="display:none">
    <div class="card-head"><h2>Método de pago</h2></div>
    <div class="card-body">
      <div class="wompi-wrap" id="guestWompiWrap"></div>
      <?php if (file_exists('medios.php')) require 'medios.php'; ?>
    </div>
    <div class="card-foot">
      <button class="btn-back" onclick="document.getElementById('guestWompiCard').style.display='none';document.getElementById('guestCard').style.display=''">← Editar datos</button>
    </div>
  </div>

<?php endif; ?>

</div><!-- /wrap -->


<!-- ══════════ MODAL LOGIN / REGISTRO ══════════ -->
<div class="modal-overlay" id="modalOverlay" onclick="if(event.target===this)closeModal()">
  <div class="modal">
    <div class="modal-head">
      <h2>Acceso</h2>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">

      <div class="tabs">
        <button class="tab active" id="mTabLogin" onclick="switchTab('login')">Iniciar Sesión</button>
        <button class="tab"        id="mTabReg"   onclick="switchTab('reg')">Crear Cuenta</button>
      </div>

      <div class="msg" id="modalMsg"></div>

      <!-- Sociales ocultos (se pueden activar quitando .hidden) -->
      <div class="hidden">
        <button class="btn-main" id="btnGoogle" style="background:#fff;color:#333;box-shadow:none;margin-bottom:.5rem">Continuar con Google</button>
        <button class="btn-main" id="btnFacebook" style="background:#1877f2;box-shadow:none;margin-bottom:.5rem">Continuar con Facebook</button>
        <div class="divider"><span>o con email</span></div>
      </div>

      <!-- Login -->
      <div id="mFormLogin">
        <div class="field">
          <label>Email</label>
          <input type="email" id="m-l-email" placeholder="tu@correo.com" autocomplete="email">
        </div>
        <div class="field">
          <label>Contraseña</label>
          <input type="password" id="m-l-pass" placeholder="••••••••" autocomplete="current-password">
        </div>
        <button class="btn-main" id="mBtnLogin">Iniciar Sesión</button>
        <a href="forgot-password.html" style="display:block;text-align:center;font-size:.73rem;color:var(--muted);margin-top:.85rem;text-decoration:none;transition:color .15s" onmouseover="this.style.color='#f97316'" onmouseout="this.style.color=''">¿Olvidaste tu contraseña?</a>
      </div>

      <!-- Registro -->
      <div id="mFormReg" style="display:none">
        <div class="field">
          <label>Nombre completo</label>
          <input type="text" id="m-r-nombre" placeholder="Tu nombre" autocomplete="name">
        </div>
        <div class="field">
          <label>Email</label>
          <input type="email" id="m-r-email" placeholder="tu@correo.com" autocomplete="email">
        </div>
        <div class="field">
          <label>Contraseña</label>
          <input type="password" id="m-r-pass" placeholder="Mínimo 6 caracteres" autocomplete="new-password">
        </div>
        <button class="btn-main" id="mBtnReg">Crear Cuenta y Continuar</button>
      </div>

    </div>
  </div>
</div>


<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import {
  getAuth, onAuthStateChanged,
  signInWithEmailAndPassword, createUserWithEmailAndPassword,
  updateProfile, GoogleAuthProvider, FacebookAuthProvider,
  signInWithPopup, signInWithRedirect, getRedirectResult,
  setPersistence, browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const firebaseConfig = {
  apiKey:            "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain:        "latin-group-406b1.firebaseapp.com",
  projectId:         "latin-group-406b1",
  storageBucket:     "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId:             "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);

const URL_UID    = <?= json_encode($firebase_uid) ?>;
const MONEDA_URL = <?= json_encode($moneda) ?>;
const MODO       = <?= json_encode($modo) ?>;
const PROPIETARIO = <?= json_encode($compra['uid_propietario'] ?? '') ?>;

// ── Safari redirect result ──────────────────────────────────────────────────
(async () => {
  try {
    const rr = await getRedirectResult(auth);
    if (rr?.user) {
      const saved_guest  = sessionStorage.getItem('pending_guest_uid') || '';
      const saved_moneda = sessionStorage.getItem('pending_moneda')    || 'COP';
      sessionStorage.removeItem('pending_guest_uid');
      sessionStorage.removeItem('pending_moneda');
      await saveUser(rr.user);
      redirect(rr.user.uid, saved_guest, saved_moneda);
      return;
    }
  } catch(e) { console.error('Redirect result:', e); }
})();

// ── Auth state ──────────────────────────────────────────────────────────────
onAuthStateChanged(auth, async (user) => {
  const loader = document.getElementById('loader');
  const wrap   = document.getElementById('mainWrap');

  if (user && MODO === 'invitado') {
    // Ya está logueado → migrar y redirigir
    if (URL_UID && URL_UID.startsWith('guest_') && URL_UID !== user.uid) {
      try {
        const res  = await fetch('get_carrito.php', {
          method: 'POST', headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ guest_uid: URL_UID, real_uid: user.uid })
        });
        const data = await res.json();
        if (data.status === 'success') { redirect(user.uid, URL_UID, MONEDA_URL); return; }
      } catch(e) { console.error('Migrar carrito:', e); }
    } else {
      redirect(user.uid, '', MONEDA_URL);
      return;
    }
  }
  
  

  if (user && MODO === 'resumen_compra') {
    const badge = document.getElementById('userBadge');
    if (badge) badge.textContent = 'Cuenta: ' + user.email;
    if (PROPIETARIO && user.uid !== PROPIETARIO) {
      window.location.href = 'login_app.html'; return;
    }
  }

  loader.style.display = 'none';
  wrap.style.display   = '';
});

// ── Helpers ─────────────────────────────────────────────────────────────────
function redirect(uid, guestUid, moneda) {
  window.location.href =
    'checkout1.php?firebase_uid=' + encodeURIComponent(uid) +
    (guestUid ? '&guest_uid=' + encodeURIComponent(guestUid) : '') +
    '&moneda=' + encodeURIComponent(moneda);
}

async function saveUser(user) {
  const idToken = await user.getIdToken(true);
  const res  = await fetch('roles.php', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({
      idToken, firebase_uid: user.uid,
      email:       user.email       || '',
      nombre:      user.displayName || '',
      foto_perfil: user.photoURL    || '',
      rol: 'cliente'
    })
  });
  const data = await res.json();
  if (data.status !== 'success') throw new Error(data.message || 'Error del servidor.');
}

async function loginSuccess(user) {
  try {
    await saveUser(user);
    showModalMsg('Acceso concedido. Redirigiendo...', 'success');
    setTimeout(() => redirect(user.uid, URL_UID, MONEDA_URL), 800);
  } catch(e) {
    showModalMsg('Error: ' + e.message);
    ['mBtnLogin','mBtnReg'].forEach(id => {
      const b = document.getElementById(id);
      if(b) { b.disabled=false; b.textContent = id==='mBtnLogin' ? 'Iniciar Sesión' : 'Crear Cuenta y Continuar'; }
    });
  }
}

function setLoad(id, on, label='') {
  const b = document.getElementById(id); if(!b) return;
  b.disabled  = on;
  b.innerHTML = on ? '<span class="spinner"></span>' + label : label;
}
function showModalMsg(txt, type='error') {
  const el = document.getElementById('modalMsg');
  el.textContent = txt; el.className = 'msg ' + type;
}

// ── Modal ────────────────────────────────────────────────────────────────────
window.openModal  = () => document.getElementById('modalOverlay').classList.add('open');
window.closeModal = () => document.getElementById('modalOverlay').classList.remove('open');
window.switchTab  = (tab) => {
  document.getElementById('mFormLogin').style.display = tab==='login' ? '' : 'none';
  document.getElementById('mFormReg').style.display   = tab==='reg'   ? '' : 'none';
  document.getElementById('mTabLogin').className = 'tab' + (tab==='login'?' active':'');
  document.getElementById('mTabReg').className   = 'tab' + (tab==='reg'  ?' active':'');
  document.getElementById('modalMsg').className  = 'msg';
};

// ── Login ────────────────────────────────────────────────────────────────────
document.getElementById('mBtnLogin')?.addEventListener('click', async () => {
  const email = document.getElementById('m-l-email').value.trim();
  const pass  = document.getElementById('m-l-pass').value;
  if (!email || !pass) return showModalMsg('Ingresa tu email y contraseña.');
  setLoad('mBtnLogin', true, ' Verificando...');
  try {
    await setPersistence(auth, browserLocalPersistence);
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    await loginSuccess(cred.user);
  } catch(e) {
    setLoad('mBtnLogin', false, 'Iniciar Sesión');
    if (e.code === 'auth/invalid-login-credentials' || e.code === 'auth/user-not-found') {
      switchTab('reg');
      document.getElementById('m-r-email').value = email;
      showModalMsg('No encontramos esa cuenta. ¿Quieres crearla?');
    } else {
      const M = { 'auth/wrong-password':'Contraseña incorrecta.', 'auth/invalid-email':'Email inválido.', 'auth/too-many-requests':'Demasiados intentos. Espera.' };
      showModalMsg(M[e.code] || 'Error: ' + e.message);
    }
  }
});

// ── Registro ─────────────────────────────────────────────────────────────────
document.getElementById('mBtnReg')?.addEventListener('click', async () => {
  const nombre = document.getElementById('m-r-nombre').value.trim();
  const email  = document.getElementById('m-r-email').value.trim();
  const pass   = document.getElementById('m-r-pass').value;
  if (!nombre || !email || !pass) return showModalMsg('Completa todos los campos.');
  if (pass.length < 6) return showModalMsg('Mínimo 6 caracteres.');
  setLoad('mBtnReg', true, ' Creando cuenta...');
  try {
    await setPersistence(auth, browserLocalPersistence);
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    await updateProfile(cred.user, { displayName: nombre });
    await loginSuccess(cred.user);
  } catch(e) {
    setLoad('mBtnReg', false, 'Crear Cuenta y Continuar');
    const M = { 'auth/email-already-in-use':'Ya existe una cuenta con ese email.', 'auth/weak-password':'Contraseña muy débil.' };
    showModalMsg(M[e.code] || 'Error: ' + e.message);
  }
});

// ── Invitado: continuar sin cuenta ──────────────────────────────────────────
document.getElementById('btnGuestPay')?.addEventListener('click', async () => {
  const nombre    = document.getElementById('g-nombre').value.trim();
  const email     = document.getElementById('g-email').value.trim();
  const whatsapp  = document.getElementById('g-whatsapp').value.trim();
  
  // Identificamos si es el producto de 5 USD
  // Asegúrate de que TOTAL_CARRITO sea la variable que tiene el precio actual
  const esPayPal = (typeof TOTAL_CARRITO !== 'undefined' && TOTAL_CARRITO == 5);

  if (!nombre || !email) return showGuest('Ingresa tu nombre y email.', 'error');

  setLoad('btnGuestPay', true, ' Procesando...');
  try {
    const res = await fetch('crear_compra_guest.php', {
      method: 'POST', 
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ guest_uid: URL_UID, nombre, email, whatsapp })
    });
    const data = await res.json();
    if (data.status !== 'success') throw new Error(data.message || 'Error.');


const wrap = document.getElementById('guestWompiWrap');
wrap.innerHTML = ''; 
const botonesPayPal = {
    5:  "QMFNBRQZ72CEJ",
    10: "T57NN9LZVMHHC",
    15: "BPXLSZQFMXLHE",
    20: "C453T5SJFA5B6",
    25: "GYAR77HQG8YML"
};

if (data.metodo_pago === 'paypal') {

    const hostedButtonId = botonesPayPal[Number(data.total)];

    wrap.innerHTML =
        '<div id="paypal-container" style="width:100%;display:block!important;"></div>';

    const renderizar = () => {
        paypal.HostedButtons({
            hostedButtonId: hostedButtonId
        }).render("#paypal-container");
    };

    if (typeof paypal === "undefined") {

        const s = document.createElement("script");
        s.src = "https://www.paypal.com/sdk/js?client-id=BAAjUMSlbZei2VSaAaGbrHEkefSoUyJFr7t3bUld8RyYlS-vSGzC-Xt5TGJZhhRma8843NPH05l9maHHRY&components=hosted-buttons&disable-funding=venmo&currency=USD";
        s.onload = renderizar;
        document.body.appendChild(s);

    } else {

        renderizar();

    }

} else {
    // Wompi: el proceso original
    const s = document.createElement('script');
    s.src = 'https://checkout.wompi.co/widget.js';
    s.setAttribute('data-render', 'button');
    s.setAttribute('data-public-key', data.public_key);
    s.setAttribute('data-currency', 'COP');
    s.setAttribute('data-amount-in-cents', data.amount_in_cents);
    s.setAttribute('data-reference', data.referencia);
    s.setAttribute('data-signature:integrity', data.firma);
    const form = document.createElement('form');
    form.appendChild(s);
    wrap.appendChild(form);
}

    document.getElementById('guestCard').style.display = 'none';
    document.getElementById('guestWompiCard').style.display = '';

  } catch(e) {
    showGuest(e.message, 'error');
    setLoad('btnGuestPay', false, 'Continuar como invitado →');
  }
});

function showGuest(txt, type) {
  const el = document.getElementById('guestMsg');
  if(el) { el.textContent = txt; el.className = 'msg ' + type; }
}

// ── Social (preparado, activar quitando .hidden del bloque) ─────────────────
async function socialLogin(name) {
  const provider = name==='google' ? new GoogleAuthProvider() : new FacebookAuthProvider();
  const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
  try {
    await setPersistence(auth, browserLocalPersistence);
    if (isSafari) {
      sessionStorage.setItem('pending_guest_uid', URL_UID);
      sessionStorage.setItem('pending_moneda',    MONEDA_URL);
      await signInWithRedirect(auth, provider);
    } else {
      const result = await signInWithPopup(auth, provider);
      await loginSuccess(result.user);
    }
  } catch(e) { showModalMsg('No se pudo iniciar sesión con ' + name + '.'); }
}
document.getElementById('btnGoogle')?.addEventListener('click',   () => socialLogin('google'));
document.getElementById('btnFacebook')?.addEventListener('click', () => socialLogin('facebook'));
</script>
</body>
</html>