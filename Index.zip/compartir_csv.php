<?php
require_once "conexion.php";
$conn = conectar();

if (!isset($_POST['usuarios']) || count($_POST['usuarios']) === 0) {
    echo json_encode(["success" => false, "message" => "No se seleccionaron usuarios"]);
    exit;
}

$ids = array_map('intval', $_POST['usuarios']);
$in = str_repeat('?,', count($ids) - 1) . '?';
$stmt = $conn->prepare("SELECT id, nombre, email, rol, estado, fecha_registro, ultima_sesion FROM usuarios WHERE id IN ($in)");
$stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
$stmt->execute();
$result = $stmt->get_result();

// Crear carpeta temporal si no existe
$dir = __DIR__ . "/temp";
if (!file_exists($dir)) {
    mkdir($dir, 0777, true);
}

// Nombre único del archivo
$filename = "usuarios_" . uniqid() . ".csv";
$filepath = $dir . "/" . $filename;

// Escribir CSV
$file = fopen($filepath, 'w');
fputcsv($file, ['ID', 'Nombre', 'Email', 'Rol', 'Estado', 'Fecha Registro', 'Última Sesión']);
while ($row = $result->fetch_assoc()) {
    fputcsv($file, $row);
}
fclose($file);

// Generar URL pública
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$url = "$protocol://{$_SERVER['HTTP_HOST']}/LatinGroup/temp/$filename";

echo json_encode(["success" => true, "url" => $url]);
?>
