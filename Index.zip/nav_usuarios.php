<?php
require 'dbfotografos.php';
$pdo = conectar();
$eventos = [];
try {
    $stmt = $pdo->query("SELECT id, titulo, banner FROM eventos ORDER BY id DESC");
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Usuario - Latin Sports</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; margin: 0;margin-top:100px; }

    /* ESTILO LCS NAV PROFESIONAL */
    .header-lcs {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 40px;
      background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f8a700 40%, #f56c1e 60%, #e4312a 100%);
      border-top: 18px solid white;
      border-bottom: 18px solid white;
      height: 100px;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .nav-container { display: flex; align-items: center; flex-grow: 1; margin-left: 150px; }
    .nav-links { display: flex; align-items: center; gap: 30px;margin-left:100px; }

    .nav-links a, .nav-links button.nav-btn {
      text-decoration: none;
      color: white;
      font-weight: 900;
      text-transform: uppercase;
      font-size: 14px;
      letter-spacing: 0.5px;
      transition: 0.3s;
      display: flex;
      align-items: center;
      gap: 6px;
      background: none;
      border: none;
      cursor: pointer;
      white-space: nowrap;
    }

    .nav-links a:hover, .nav-links button.nav-btn:hover { color: #ffe29a; }

    /* Submenús Dropdown */
    .relative { position: relative; }
    .submenu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background-color: white;
      box-shadow: 0 10px 15px rgba(0,0,0,0.2);
      min-width: 180px;
      border-radius: 8px;
      padding: 10px 0;
      border-top: 4px solid #f46616;
      z-index: 1100;
    }
    .relative:hover .submenu { display: block; animation: fadeIn 0.2s ease-out; }
    .submenu a { color: #333 !important; padding: 10px 20px; display: block; font-size: 12px; font-weight: 600; }
    .submenu a:hover { background: #fff7ed; color: #f46616 !important; }

    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

    /* Tarjetas de Eventos */
    .card { background:#fff; border-radius:16px; overflow:hidden; border:1px solid #eee; transition:.3s; display:flex; flex-direction:column; height: 100%; }
    .img-container { aspect-ratio: 16/9; overflow:hidden; display:flex; align-items:center; justify-content:center; background:#f3f4f6; }
    .img-container img { width:100%; height:100%; object-fit: cover; }

    @media (max-width: 768px) {
      .header-lcs { padding: 0 15px; height: 80px; border-top: 10px solid white; border-bottom: 10px solid white; }
      .nav-container { display: none; }
    }
  </style>
</head>
<body class="flex flex-col min-h-screen">

  <header class="header-lcs">
    <div class="logo flex items-center">
        <a href="nav_usuarios.php" class="flex items-center">
            <img src="imagenes/LATINCOLOR.png" alt="Logo 1" style="height: 85px; width: auto;">
            <img src="uploads/LATIN-SPORTS.png" alt="Logo 2" style="height: 85px; width: auto; margin-left: 5px;">
        </a>
    </div>

    <div class="nav-container">
        <nav class="nav-links">
            <a href="nav_usuarios.php">Home</a>
            <a href="conjuntodeventospremium.php">Eventos</a>

            <div class="relative group">
                <button class="nav-btn">
                    Explorar 
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div class="submenu">
                    <a href="conjuntodeventospremium.php?search=&tipo_evento=Deportivo">DEPORTIVO</a>
                </div>
            </div>

            <div class="relative group">
                <button class="nav-btn">
                    Mis Compras
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div class="submenu">
                    <a href="migaleria.php">MIS COLECCIONES</a>
                    <a href="miscomprasfotos.php">MIS FOTOS</a>
                </div>
            </div>
        </nav>
    </div>

    <div class="flex items-center gap-4">
        <div class="hidden lg:flex flex-col text-right text-white mr-2">
            <span id="userName" class="font-black text-xs uppercase leading-none">Cargando...</span>
            <span id="userEmail" class="text-[9px] opacity-80 leading-none mt-1">Cargando...</span>
        </div>
        <button id="logoutButton" class="bg-white text-red-600 font-black text-[10px] px-4 py-2 rounded-full uppercase tracking-tighter hover:bg-black hover:text-white transition">
            Salir
        </button>
        <button id="mobile-menu-button" class="md:hidden text-white">
            <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>
        </button>
    </div>
  </header>

  <div id="mobile-menu" class="hidden bg-white border-b-4 border-orange-500 md:hidden">
      <div class="p-6 space-y-4">
          <a href="nav_usuarios.php" class="block font-black text-gray-800 uppercase">Home</a>
          <a href="conjuntodeventospremium.php" class="block font-black text-gray-800 uppercase">Eventos</a>
          <hr>
          <p class="text-[10px] font-bold text-gray-400 uppercase">Mis Compras</p>
          <a href="migaleria.php" class="block text-sm text-gray-600 pl-2">Mis Colecciones</a>
          <a href="miscomprasfotos.php" class="block text-sm text-gray-600 pl-2">Mis Fotos</a>
      </div>
  </div>

  <main class="flex-grow max-w-7xl mx-auto w-full p-4 md:p-8">
    <section id="home" class="py-6">
      <h1 class="text-3xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase italic">
        Bienvenido, <span class="text-orange-600" id="welcomeName">Usuario</span>
      </h1>
      <p class="text-gray-500 mt-1 text-sm md:text-lg font-medium">Encuentra tus mejores momentos deportivos aquí.</p>
      
      <div class="mt-12">
        <h2 class="text-xl font-black text-gray-800 mb-8 border-l-4 border-orange-500 pl-3 uppercase">Eventos Recientes</h2>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            <?php
            if(isset($error)){
                echo '<p class="text-red-600">Error: '.htmlspecialchars($error).'</p>';
            } elseif(!$eventos){
                echo '<p class="text-gray-500">No hay eventos disponibles.</p>';
            } else {
                foreach($eventos as $e){
                    $galeria_url = 'galeria.php?evento_id=' . $e['id'];
                    echo '<div class="card shadow-sm hover:shadow-2xl transition-all duration-300 group">';
                    echo '<div class="img-container">';
                    echo '<img src="'.htmlspecialchars($e['banner']).'" alt="'.htmlspecialchars($e['titulo']).'" class="group-hover:scale-110 transition-transform duration-700">';
                    echo '</div>';
                    echo '<div class="p-6 flex flex-col flex-grow">';
                    echo '<h2 class="text-lg font-black text-gray-800 line-clamp-2 mb-4 italic uppercase leading-tight">'.htmlspecialchars($e['titulo']).'</h2>';
                    echo '<a href="'.htmlspecialchars($galeria_url).'" class="mt-auto block w-full py-3 bg-orange-600 text-white text-center rounded-xl font-black uppercase text-[11px] tracking-widest hover:bg-black transition-colors">Ver Galería</a>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            ?>
        </div>
      </div>
    </section>
  </main>

  <script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
    import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

    const firebaseConfig = {
      apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
      authDomain: "latin-group-406b1.firebaseapp.com",
      projectId: "latin-group-406b1",
      storageBucket: "latin-group-406b1.appspot.com",
      messagingSenderId: "21494348297",
      appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
    };

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);

    // Toggle Móvil
    document.getElementById('mobile-menu-button')?.addEventListener('click', () => {
        document.getElementById('mobile-menu').classList.toggle('hidden');
    });

    onAuthStateChanged(auth, async (user) => {
        if (user) {
            document.getElementById('welcomeName').textContent = user.displayName || "Atleta";
            
            user.getIdToken().then(async token => {
                const res = await fetch('get_user_info.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ firebase_token: token, email: user.email })
                });
                const data = await res.json();
                if (data.status === 'success' && data.user) {
                    document.getElementById('userName').textContent = data.user.nombre;
                    document.getElementById('userEmail').textContent = data.user.email;
                }
            });
        } else {
            window.location.href = "login_app.html";
        }
    });

    const handleLogout = async () => {
      await signOut(auth);
      window.location.href = 'login_app.html';
    };

    document.getElementById('logoutButton')?.addEventListener('click', handleLogout);
  </script>
</body>
</html>