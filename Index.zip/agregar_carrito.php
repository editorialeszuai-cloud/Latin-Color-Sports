<?php
require 'dbfotografos.php';
header('Content-Type: application/json');

// --- Depuración completa ---
error_reporting(E_ALL);
ini_set('display_errors', 1);

$debug = [
    'GET' => $_GET,
    'POST' => $_POST
];

// 🧩 Recibir parámetros
$firebase_uid = $_GET['firebase_uid'] ?? '';
$foto_id = isset($_GET['foto_id']) ? (int)$_GET['foto_id'] : 0;
$precio = isset($_GET['precio']) ? (int)$_GET['precio'] : 15000;

// Añadir debug de variables
$debug['parsed'] = [
    'firebase_uid' => $firebase_uid,
    'foto_id' => $foto_id,
    'precio' => $precio
];

// 🧠 Validación básica
if (empty($firebase_uid) || $foto_id <= 0) {
    $debug['error'] = 'Datos incompletos';
    echo json_encode([
        'status' => 'error',
        'msg' => 'Datos incompletos',
        'debug' => $debug
    ]);
    exit;
}

// ✅ Verificar que la foto exista
try {
    $stmt = $pdo->prepare("SELECT id FROM fotos WHERE id = ? LIMIT 1");
    $stmt->execute([$foto_id]);
    if (!$stmt->fetch()) {
        $debug['error'] = 'Foto no encontrada';
        echo json_encode([
            'status' => 'error',
            'msg' => 'Foto no encontrada',
            'debug' => $debug
        ]);
        exit;
    }
} catch (PDOException $e) {
    $debug['exception'] = $e->getMessage();
    echo json_encode([
        'status' => 'error',
        'msg' => 'Error al verificar la foto',
        'debug' => $debug
    ]);
    exit;
}

// 🔍 Verificar si ya está en el carrito
try {
    $stmt = $pdo->prepare("SELECT id FROM carrito WHERE firebase_uid = ? AND foto_id = ?");
    $stmt->execute([$firebase_uid, $foto_id]);
    if ($stmt->fetch()) {
        echo json_encode([
            'status' => 'ok',
            'msg' => 'Ya está en el carrito',
            'debug' => $debug
        ]);
        exit;
    }
} catch (PDOException $e) {
    $debug['exception'] = $e->getMessage();
    echo json_encode([
        'status' => 'error',
        'msg' => 'Error al verificar carrito',
        'debug' => $debug
    ]);
    exit;
}

// 🛒 Insertar nueva foto al carrito
try {
    $stmt = $pdo->prepare("INSERT INTO carrito (firebase_uid, foto_id, precio, fecha_agregado) VALUES (?, ?, ?, NOW())");
    $success = $stmt->execute([$firebase_uid, $foto_id, $precio]);

    if ($success) {
        echo json_encode([
            'status' => 'ok',
            'msg' => '✅ Foto agregada al carrito',
            'debug' => $debug
        ]);
    } else {
        $debug['error_info'] = $stmt->errorInfo();
        echo json_encode([
            'status' => 'error',
            'msg' => 'No se pudo agregar al carrito',
            'debug' => $debug
        ]);
    }
} catch (PDOException $e) {
    $debug['exception'] = $e->getMessage();
    echo json_encode([
        'status' => 'error',
        'msg' => 'Error al insertar en carrito',
        'debug' => $debug
    ]);
}
?>
