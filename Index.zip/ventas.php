<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Compras Filtradas por Estado</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800 font-sans antialiased">

<div class="max-w-7xl mx-auto p-6 structural-container">
    <!-- Encabezado Principal -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-200 pb-5 mb-6">
        <h1 class="text-2xl font-bold tracking-tight text-gray-900 mb-4 md:mb-0">Compras Filtradas por Estado</h1>
        
        <!-- Filtro por estado estilizado -->
        <div class="flex items-center space-x-3 bg-white px-4 py-2 rounded-xl shadow-sm border border-gray-200">
            <label for="filtroEstado" class="text-sm font-semibold text-gray-600">Filtrar por estado:</label>
            <select id="filtroEstado" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-orange-500 focus:border-orange-500 block px-2.5 py-1.5 font-medium outline-none transition-all">
                <option value="">Todos</option>
                <option value="APPROVED">APPROVED</option>
                <option value="DECLINED">CANCELLED</option>
            </select>
        </div>
    </div>

    <!-- Contenedor de la Tabla Adaptativa -->
    <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200" id="tablaCompras">
                <thead class="bg-orange-600 text-white">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">ID Compra</th>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">Usuario</th>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">Estado</th>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">Total</th>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">ID Detalle</th>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">ID Foto</th>
                        <th class="px-5 py-3 text-left text-xs font-bold uppercase tracking-wider">Vista Previa</th>
                        <th class="px-5 py-3 text-center text-xs font-bold uppercase tracking-wider">Acción</th> <!-- CORRECCIÓN: Encabezado agregado -->
                    </tr>
                </thead>
                <tbody id="tbodyCompras" class="divide-y divide-gray-200 bg-white">
                    <tr><td colspan="8" class="text-center py-8 text-gray-500 font-medium">Cargando datos del servidor...</td></tr>
                </tbody>
                <tfoot id="tfootTotales" class="bg-gray-50 border-t-2 border-gray-200"></tfoot>
            </table>
        </div>
    </div>
</div>

<script>
async function cargarCompras(estadoFiltro = '') {
    const tbody = document.getElementById('tbodyCompras');
    const tfoot = document.getElementById('tfootTotales');
    tbody.innerHTML = '<tr><td colspan="8" class="text-center py-8 text-gray-500 font-medium">Cargando datos del servidor...</td></tr>';
    tfoot.innerHTML = '';

    try {
        const res = await fetch('get_compras.php');
        const data = await res.json();

        if(data.status === 'success' && data.compras.length > 0){
            tbody.innerHTML = '';
            let totalFiltrado = 0;

            data.compras.forEach(c => {
                if(estadoFiltro && c.estado !== estadoFiltro) return; 

                totalFiltrado += parseFloat(c.total);

                if(c.detalles && c.detalles.length > 0){
                    c.detalles.forEach((d, index) => {
                        // Estilo dinámico para los badges de estado
                        let estadoBadge = c.estado;
                        if(c.estado === 'APPROVED') {
                            estadoBadge = `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 border border-green-200">${c.estado}</span>`;
                        } else if(c.estado === 'DECLINED' || c.estado === 'CANCELLED') {
                            estadoBadge = `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 border border-red-200">${c.estado}</span>`;
                        }

                        tbody.innerHTML += `
                            <tr class="hover:bg-gray-50/70 transition-colors">
                                <td class="px-5 py-3 text-sm font-semibold text-gray-900">${index === 0 ? c.id : ''}</td>
                                <td class="px-5 py-3 text-sm text-gray-600">${index === 0 ? c.usuario_nombre : ''}</td>
                                <td class="px-5 py-3 text-sm">${index === 0 ? estadoBadge : ''}</td>
                                <td class="px-5 py-3 text-sm font-medium text-gray-900">${index === 0 ? `$${parseFloat(c.total).toFixed(2)}` : ''}</td>
                                <td class="px-5 py-3 text-sm text-gray-500">${d.id}</td>
                                <td class="px-5 py-3 text-sm text-gray-500">${d.id_foto}</td>
                                <td class="px-5 py-3 text-sm">
                                    ${d.nombre_archivo ? `<img src="${d.nombre_archivo}" class="w-12 h-12 object-cover rounded-lg border border-gray-200 shadow-sm" alt="Foto ${d.id_foto}">` : '<span class="text-gray-400">-</span>'}
                                </td>
                                <td class="px-5 py-3 text-sm text-center"> 
                                    ${d.nombre_archivo ? `
                                        <button onclick="descargarArchivoDirecto('${d.nombre_archivo}', 'foto_${d.id_foto}')" 
                                                class="inline-flex items-center justify-center px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-all border border-blue-200 shadow-sm hover:shadow active:scale-95 cursor-pointer">
                                           Descargar
                                        </button>` : '<span class="text-gray-400">-</span>'}
                                </td>
                            </tr>
                        `;
                    });
                } else {
                    // CORRECCIÓN: Se cambió colspan a 8 para coincidir con las columnas
                    tbody.innerHTML += `
                        <tr class="hover:bg-gray-50 transition-colors">
                            <td class="px-5 py-4 text-sm font-semibold text-gray-900">${c.id}</td>
                            <td class="px-5 py-4 text-sm text-gray-600">${c.usuario_nombre}</td>
                            <td class="px-5 py-4 text-sm"><span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 border border-gray-200">${c.estado}</span></td>
                            <td class="px-5 py-4 text-sm font-medium text-gray-900">$${parseFloat(c.total).toFixed(2)}</td>
                            <td colspan="4" class="px-5 py-4 text-sm text-center text-gray-400 italic bg-gray-50/50">Sin archivos o detalles registrados</td>
                        </tr>
                    `;
                }
            });

            // Footer de totales optimizado
            tfoot.innerHTML = `
                <tr class="font-bold text-gray-900">
                    <td colspan="3" class="px-5 py-4 text-right text-sm uppercase tracking-wider text-gray-500">Total ${estadoFiltro || 'General'}:</td>
                    <td class="px-5 py-4 text-base font-bold text-orange-600">$${totalFiltrado.toFixed(2)}</td>
                    <td colspan="4"></td>
                </tr>
            `;

        } else {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center py-12 text-sm text-gray-500 font-medium">No se encontraron compras en este estado actual.</td></tr>';
        }
    } catch(err){
        console.error('Error fetch:', err);
        tbody.innerHTML = '<tr><td colspan="8" class="text-center py-12 text-sm font-semibold text-red-600 bg-red-50/50">Ocurrió un error al procesar las compras del servidor.</td></tr>';
    }
}

document.getElementById('filtroEstado').addEventListener('change', (e) => {
    cargarCompras(e.target.value);
});

// Carga inicial al cargar la página
cargarCompras();

async function descargarArchivoDirecto(url, nombreSugerido) {
    try {
        const respuesta = await fetch(url);
        if (!respuesta.ok) throw new Error('Error de red al intentar obtener el archivo.');
        
        const blob = await respuesta.blob();
        const urlBlob = window.URL.createObjectURL(blob);
        const enlaceTemporal = document.createElement('a');
        enlaceTemporal.href = urlBlob;
        
        const extension = url.split('.').pop().split(/[?#]/)[0] || 'jpg';
        enlaceTemporal.download = `${nombreSugerido}.${extension}`;
        
        document.body.appendChild(enlaceTemporal);
        enlaceTemporal.click();
        
        document.body.removeChild(enlaceTemporal);
        window.URL.revokeObjectURL(urlBlob);
    } catch (error) {
        console.error('Fallo en la descarga forzada:', error);
        // Fallback inmediato si hay problemas de restricción CORS estricta en producción
        window.open(url, '_blank');
    }
}
</script>

</body>
</html>