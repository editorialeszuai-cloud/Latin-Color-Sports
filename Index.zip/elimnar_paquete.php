<?php
require 'dbfotografos.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$firebase_uid = $_GET['firebase_uid'] ?? '';

if(!$id || !$firebase_uid){
    echo json_encode(['status'=>'error','msg'=>'Datos inválidos']);
    exit;
}

$stmt = $pdo->prepare("DELETE FROM carrito_paquetes WHERE id=? AND firebase_uid=?");
$stmt->execute([$id,$firebase_uid]);

echo json_encode(['status'=>'ok']);
