<?php
function conectar() {
    $host = 'database-1.c8302k404lkf.us-east-1.rds.amazonaws.com';     // Cambiado a 127.0.0.1 para evitar problemas de sockets en XAMPP
    $db   = 'latincolors';    // ✅ CORREGIDO: Comilla de cierre añadida
    $user = 'admin';           // ✅ CORREGIDO: Enuelto entre comillas
    $pass = 'DannyCruxTecnoLoad!#';               // Vacío para tu XAMPP local
    $charset = 'utf8mb4';
    $port = 3306;             // Agregamos la variable por si acaso

    $dsn = "mysql:host=$host;dbname=$db;port=$port;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        // En lugar de un null silencioso, lanzamos una excepción para que el catch 
        // de 'get_user_info.php' te diga en la consola si la clave o la DB fallaron.
        throw new Exception("Error interno de MySQL: " . $e->getMessage());
    }
}

// Inicializamos la variable global que va a leer tu get_user_info.php
$pdo = conectar();