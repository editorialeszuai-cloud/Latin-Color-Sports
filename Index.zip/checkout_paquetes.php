<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);

require_once 'dbfotografos.php';
$pdo = conectar();

// Obtener firebase_uid desde GET
$firebase_uid = $_GET['firebase_uid'] ?? '';
if (!$firebase_uid) {
    die("<p style='color:red'>Usuario no identificado.</p>");
}

// Obtener items del carrito de paquetes
$stmt = $pdo->prepare("
    SELECT 
        cp.id AS carrito_id,
        cp.precio,
        cp.evento_id,
        e.titulo AS evento_titulo
    FROM carrito_paquetes cp
    INNER JOIN eventos e ON cp.evento_id = e.id
    WHERE cp.firebase_uid = ?
    ORDER BY cp.fecha DESC
");
$stmt->execute([$firebase_uid]);
$carrito = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$carrito) {
    die("<p style='color:red'>Tu carrito de paquetes está vacío.</p>");
}

// Calcular total
$total = 0;
foreach ($carrito as $item) {
    $total += $item['precio'];
}

// Generar referencia única
$ref_local = "EC-PAQ-" . time();

// Insertar compra pendiente de paquetes
$stmt = $pdo->prepare("INSERT INTO compras_paquetes (firebase_uid, referencia, total, estado) VALUES (?, ?, ?, 'Pendiente')");
$stmt->execute([$firebase_uid, $ref_local, $total]);
$id_compra = $pdo->lastInsertId();

// Insertar detalle_compras_paquetes
foreach ($carrito as $item) {
    $stmt = $pdo->prepare("INSERT INTO detalle_compras_paquetes (id_compra, evento_id, precio) VALUES (?, ?, ?)");
    $stmt->execute([$id_compra, $item['evento_id'], $item['precio']]);
}

// Opcional: registrar comisiones de cada paquete
foreach ($carrito as $item) {
    $precio = $item['precio'];
    $stmt = $pdo->prepare("
        INSERT INTO comisiones_paquetes (compra_id, admin, fotografo, organizador, soporte, comercial)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $id_compra,
        $precio * 0.40, // admin 65%
        $precio * 0.25, // fotografo 5%
        $precio * 0.10, // organizador 10%
        $precio * 0.03, // soporte 10%
        $precio * 0.10  // comercial 10%
    ]);
}

// Redirigir al checkout Wompi
header("Location: wompi_checkout_paquetes.php?compra_id=$id_compra");
exit;
