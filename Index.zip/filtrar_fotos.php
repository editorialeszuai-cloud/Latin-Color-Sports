<?php
require_once 'dbfotografos.php';
$evento_id = intval($_GET['evento_id']);
$sede_id = isset($_GET['sede_id']) ? intval($_GET['sede_id']) : 0;

$query = "SELECT f.id, f.url FROM fotos f 
          INNER JOIN postulaciones p ON f.postulacion_id = p.id 
          LEFT JOIN calendario_fotografos cf ON cf.postulacion_id = p.id 
          LEFT JOIN fotos_moderacion fm ON f.id = fm.foto_id 
          WHERE p.evento_id = ? AND fm.foto_id IS NULL";

$params = [$evento_id];

if ($sede_id > 0) {
    $query .= " AND cf.sede_id = ?";
    $params[] = $sede_id;
}

$query .= " GROUP BY f.id ORDER BY f.id DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));