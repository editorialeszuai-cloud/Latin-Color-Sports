<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Gestión de Lugares</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    h1 {
      text-align: center;
      color: #333;
    }
    form {
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      margin-bottom: 30px;
      max-width: 500px;
      margin-left: auto;
      margin-right: auto;
    }
    label {
      display: block;
      margin-top: 10px;
      color: #555;
    }
    input, textarea {
      width: 100%;
      padding: 8px;
      margin-top: 4px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    button {
      margin-top: 15px;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      background: orange;
      color: #fff;
    }
    button:hover {
      background: #0056b3;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
      background: #fff;
    }
    th, td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: left;
    }
    th {
      background: orange;
      color: white;
    }
    .acciones button {
      margin-right: 5px;
      padding: 5px 8px;
    }
    .editar {
      background: #ffc107;
      color: #000;
    }
    .eliminar {
      background: #dc3545;
      color: #fff;
    }
  </style>
</head>
<body>
    

<style>
/* ======== NAVBAR ESTILOS ======== */
#mainNav {
  width: 100%;
  background: linear-gradient(90deg, #4f46e5, #8b5cf6, #ec4899);
  color: white;
  padding: 0.75rem 0rem;
  box-shadow: 0 2px 6px rgba(0,0,0,0.15);
  position: relative;
  z-index: 1000;
  border-radius:20px;
}

#mainNav .nav-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
}

#mainNav .logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  font-size: 1.125rem;
}

#mainNav .logo img {
  width: 2rem;
  height: 2rem;
}

#mainNav .nav-links {
  display: flex;
  gap: 1rem;
  list-style: none;
}

#mainNav .nav-links li a {
  color: white;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.2s;
}

#mainNav .nav-links li a:hover {
  text-decoration: underline;
}

/* ======== BOTÓN HAMBURGUESA ======== */
.nav-toggle {
  display: none;
  flex-direction: column;
  justify-content: space-between;
  width: 5rem;
  height: 5rem;
  font-size:25px;
  background: none;
  border: none;
  cursor: pointer;
  padding-right:20px;
}

.nav-toggle span {
  display: block;
  height: 2px;
  width: 100%;
  background: white;
  border-radius: 2px;
}

/* ======== RESPONSIVE ======== */
@media (max-width: 768px) {
  #mainNav .nav-links {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: linear-gradient(90deg, #4f46e5, #8b5cf6, #ec4899);
    flex-direction: column;
    display: none;
    gap: 0;
    text-align: center;
    padding: 0.5rem 0;
  }

  #mainNav .nav-links.show {
    display: flex;
  }

  #mainNav .nav-links li {
    padding: 0.5rem 0;
  }

  .nav-toggle {
    display: flex;
  }
}
</style>

<script>
// ====== SCRIPT RESPONSIVE ======
const navToggle = document.getElementById('navToggle');
const navLinks = document.querySelector('#mainNav .nav-links');

navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('show');
});
</script>

  <h1>Gestión de Lugares</h1>

  <form id="formLugar">
    <input type="hidden" id="idLugar">
    <label>Nombre del Lugar</label>
    <input type="text" id="nombre_lugar" required>

    <label>Dirección</label>
    <input type="text" id="direccion">

    <label>Ciudad</label>
    <input type="text" id="ciudad">

    <label>País</label>
    <input type="text" id="pais">

    <label>Descripción</label>
    <textarea id="descripcion" rows="3"></textarea>

    <button type="submit">Guardar Lugar</button>
    <button type="button" id="btnCancelar" style="background:#6c757d;display:none;">Cancelar</button>
  </form>

  <table id="tablaLugares">
    <thead>
      <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Ciudad</th>
        <th>País</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody></tbody>
  </table>

  <script>
    const form = document.getElementById('formLugar');
    const btnCancelar = document.getElementById('btnCancelar');
    const tabla = document.querySelector('#tablaLugares tbody');

    const limpiarFormulario = () => {
      form.reset();
      document.getElementById('idLugar').value = '';
      btnCancelar.style.display = 'none';
      form.querySelector('button[type="submit"]').textContent = 'Guardar Lugar';
    };

    const cargarLugares = async () => {
      const res = await fetch('lugares.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accion: 'listar' })
      });
      const data = await res.json();
      tabla.innerHTML = '';
      if (data.status === 'success') {
        data.data.forEach(l => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${l.id}</td>
            <td>${l.nombre_lugar}</td>
            <td>${l.ciudad || ''}</td>
            <td>${l.pais || ''}</td>
            <td class="acciones">
              <button class="editar" onclick='editarLugar(${JSON.stringify(l)})'>Editar</button>
              <button class="eliminar" onclick="eliminarLugar(${l.id})">Eliminar</button>
            </td>
          `;
          tabla.appendChild(tr);
        });
      }
    };

    form.addEventListener('submit', async e => {
      e.preventDefault();
      const id = document.getElementById('idLugar').value;
      const datos = {
        accion: id ? 'editar' : 'crear',
        id: id,
        nombre_lugar: document.getElementById('nombre_lugar').value,
        direccion: document.getElementById('direccion').value,
        ciudad: document.getElementById('ciudad').value,
        pais: document.getElementById('pais').value,
        descripcion: document.getElementById('descripcion').value
      };

      const res = await fetch('lugares.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
      });
      const data = await res.json();
      alert(data.message);
      if (data.status === 'success') {
        limpiarFormulario();
        cargarLugares();
      }
    });

    const editarLugar = lugar => {
      document.getElementById('idLugar').value = lugar.id;
      document.getElementById('nombre_lugar').value = lugar.nombre_lugar;
      document.getElementById('direccion').value = lugar.direccion || '';
      document.getElementById('ciudad').value = lugar.ciudad || '';
      document.getElementById('pais').value = lugar.pais || '';
      document.getElementById('descripcion').value = lugar.descripcion || '';
      form.querySelector('button[type="submit"]').textContent = 'Actualizar Lugar';
      btnCancelar.style.display = 'inline-block';
    };

    const eliminarLugar = async id => {
      if (!confirm('¿Seguro que deseas eliminar este lugar?')) return;
      const res = await fetch('lugares.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accion: 'eliminar', id })
      });
      const data = await res.json();
      alert(data.message);
      if (data.status === 'success') cargarLugares();
    };

    btnCancelar.addEventListener('click', limpiarFormulario);

    // Al cargar la página
    cargarLugares();
  </script>
</body>
</html>
