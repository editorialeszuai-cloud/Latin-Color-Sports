<?php
require 'dbfotografos.php';
header('Content-Type: application/json');

// Obtener ID del paquete a eliminar
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if ($id <= 0) {
    echo json_encode([
        'status' => 'error',
        'msg' => 'ID de paquete inválido'
    ]);
    exit;
}

// Opcional: verificar que el paquete pertenece al usuario
$firebase_uid = $_GET['firebase_uid'] ?? null; // si quieres verificar seguridad extra

try {
    // Eliminar paquete
    $stmt = $pdo->prepare("DELETE FROM carrito_paquetes WHERE id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'status' => 'ok',
            'msg' => 'Paquete eliminado correctamente'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'msg' => 'No se encontró el paquete'
        ]);
    }

} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'msg' => 'Error al eliminar paquete',
        'error' => $e->getMessage()
    ]);
}
