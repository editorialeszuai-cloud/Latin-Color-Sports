<?php
// paquetes_fotos.php
header('Content-Type: application/json');
require_once "conexion.php"; // archivo con función conectar()
$conn = conectar(); // conexión MySQLi
$input = json_decode(file_get_contents('php://input'), true);

// Función de respuesta rápida
function resp($status, $msg = '', $data = null){
    echo json_encode(['status'=>$status, 'message'=>$msg, 'data'=>$data]);
    exit;
}

$accion = $input['accion'] ?? '';

try {

    if ($accion === 'crear') {
        $nombre = trim($input['nombre_paquete'] ?? '');
        $descripcion = trim($input['descripcion'] ?? '');
        $precio = floatval($input['precio_por_unidad'] ?? 0);
        $unidades = intval($input['unidades_incluidas'] ?? 0);

        if (!$nombre) resp('error','El nombre del paquete es obligatorio.');

        $stmt = $conn->prepare("INSERT INTO paquetes_fotos(nombre_paquete, descripcion, precio_por_unidad, unidades_incluidas) VALUES(?,?,?,?)");
        $stmt->bind_param("ssdi", $nombre, $descripcion, $precio, $unidades);
        if(!$stmt->execute()) resp('error','Error BD: '.$stmt->error);

        resp('success','Paquete creado.');

    } elseif ($accion === 'editar') {
        $id = intval($input['id'] ?? 0);
        $nombre = trim($input['nombre_paquete'] ?? '');
        $descripcion = trim($input['descripcion'] ?? '');
        $precio = floatval($input['precio_por_unidad'] ?? 0);
        $unidades = intval($input['unidades_incluidas'] ?? 0);

        if (!$id) resp('error','ID inválido.');
        if (!$nombre) resp('error','El nombre del paquete es obligatorio.');

        $stmt = $conn->prepare("UPDATE paquetes_fotos SET nombre_paquete=?, descripcion=?, precio_por_unidad=?, unidades_incluidas=? WHERE id=?");
        $stmt->bind_param("ssdii", $nombre, $descripcion, $precio, $unidades, $id);
        if(!$stmt->execute()) resp('error','Error BD: '.$stmt->error);

        resp('success','Paquete actualizado.');

    } elseif ($accion === 'eliminar') {
        $id = intval($input['id'] ?? 0);
        if(!$id) resp('error','ID inválido.');

        $stmt = $conn->prepare("DELETE FROM paquetes_fotos WHERE id=?");
        $stmt->bind_param("i",$id);
        if(!$stmt->execute()) resp('error','Error BD: '.$stmt->error);

        resp('success','Paquete eliminado.');

    } elseif ($accion === 'listar') {
        $result = $conn->query("SELECT * FROM paquetes_fotos ORDER BY id DESC");
        $data = [];
        while($row = $result->fetch_assoc()) $data[] = $row;

        resp('success','Paquetes obtenidos',$data);

    } else {
        resp('error','Acción desconocida.');
    }

} catch(Exception $e){
    resp('error',$e->getMessage());
}
?>
