<?php
require 'dbfotografos.php';
header('Content-Type: application/json');

// Obtener la acción (maneja tanto POST como GET para flexibilidad)
$action = $_POST['action'] ?? $_GET['action'] ?? '';

// --- ACCIÓN: ELIMINAR FOTO ---
if ($action === 'eliminar_foto') {
    $foto_id = $_POST['foto_id'] ?? null;
    if (!$foto_id) {
        echo json_encode(['success' => false, 'message' => 'ID no proporcionado']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT url FROM fotos WHERE id = ?");
        $stmt->execute([$foto_id]);
        $foto = $stmt->fetch();

        if ($foto) {
            $ruta_archivo = 'uploads/' . $foto['url'];
            $pdo->beginTransaction();
            $pdo->prepare("DELETE FROM faces WHERE foto_id = ?")->execute([$foto_id]);
            $pdo->prepare("DELETE FROM analisis_fotos WHERE foto_id = ?")->execute([$foto_id]);
            $pdo->prepare("DELETE FROM fotos WHERE id = ?")->execute([$foto_id]);
            $pdo->commit();

            if (file_exists($ruta_archivo)) unlink($ruta_archivo);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Foto no encontrada']);
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// --- ACCIÓN: GUARDAR ANÁLISIS (MobileNet / ml5) ---
if ($action === 'guardar_analisis') {
    $foto_id    = $_POST['foto_id'] ?? null;
    $label      = $_POST['label'] ?? '';
    $confidence = $_POST['confidence'] ?? 0;

    if (!$foto_id) exit(json_encode(['success' => false, 'message' => 'Falta ID']));

    try {
        $stmt = $pdo->prepare("INSERT INTO analisis_fotos (foto_id, etiqueta, confianza) VALUES (?, ?, ?)");
        $stmt->execute([$foto_id, $label, $confidence]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// --- ACCIÓN: GUARDAR ROSTRO (face-api.js) ---
if ($action === 'guardar_rostro') {
    $foto_id    = $_POST['foto_id'] ?? null;
    $descriptor = $_POST['descriptor'] ?? null; // Esto viene como JSON string

    if (!$foto_id || !$descriptor) exit(json_encode(['success' => false, 'message' => 'Faltan datos']));

    try {
        // Asegúrate de que la columna 'descriptor' sea tipo TEXT o JSON en tu DB
        $stmt = $pdo->prepare("INSERT INTO faces (foto_id, descriptor) VALUES (?, ?)");
        $stmt->execute([$foto_id, $descriptor]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// --- LÓGICA DE VISTA (HTML) ---
// Si no es una petición AJAX (POST), mostramos el panel
if ($_SERVER['REQUEST_METHOD'] !== 'POST'):
    
    $postulacion_id = $_GET['postulacion_id'] ?? null;
    if (!$postulacion_id) {
        $stmt_list = $pdo->query("SELECT DISTINCT postulacion_id FROM fotos ORDER BY id DESC LIMIT 10");
        $postulaciones_disponibles = $stmt_list->fetchAll(PDO::FETCH_COLUMN);
        if (!empty($postulaciones_disponibles)) { $postulacion_id = $postulaciones_disponibles[0]; }
    }
    
    if (!$postulacion_id) die("No hay fotos.");

    $sql = "SELECT f.id, f.url, (SELECT COUNT(*) FROM faces WHERE foto_id = f.id) as total_rostros FROM fotos f WHERE f.postulacion_id = ? ORDER BY f.id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$postulacion_id]);
    $fotos = $stmt->fetchAll();
?>
<?php endif; ?>