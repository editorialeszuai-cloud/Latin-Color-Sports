<?php
require_once 'dbfotografos.php';

// Habilitar errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Obtener ID del evento
$evento_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($evento_id <= 0) die('ID de evento inv��lido.');

// Obtener evento
$stmtEvento = $pdo->prepare("SELECT * FROM eventos WHERE id = ?");
$stmtEvento->execute([$evento_id]);
$evento = $stmtEvento->fetch(PDO::FETCH_ASSOC);
if (!$evento) die('Evento no encontrado.');

// Obtener filtros opcionales
$filtroDisciplina = $_GET['disciplina'] ?? '';
$filtroEscenario  = $_GET['escenario'] ?? '';
$filtroSede       = $_GET['sede'] ?? '';

// Traer fotos con info de filtros
$sql = "
SELECT 
    f.id AS foto_id,
    f.url,
    f.descripcion AS foto_descripcion,
    d.nombre_disciplina AS disciplina_nombre,
    es.nombre AS escenario_nombre,
    se.titulo AS sede_nombre
FROM fotos f
INNER JOIN postulaciones p ON f.postulacion_id = p.id
LEFT JOIN calendario_fotografos cf ON cf.postulacion_id = f.postulacion_id
LEFT JOIN disciplinas d ON d.id = cf.disciplina_id
LEFT JOIN escenarios es ON es.id = cf.escenario_id
LEFT JOIN sedes se ON se.id = cf.sede_id
WHERE p.evento_id = ?
";

$params = [$evento_id];

// Aplicar filtros
if($filtroDisciplina) { $sql .= " AND d.nombre_disciplina = ?"; $params[] = $filtroDisciplina; }
if($filtroEscenario)  { $sql .= " AND es.nombre = ?"; $params[] = $filtroEscenario; }
if($filtroSede)       { $sql .= " AND se.titulo = ?"; $params[] = $filtroSede; }

$sql .= " ORDER BY f.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Traer listas para filtros
$disciplinas = $pdo->query("SELECT nombre_disciplina FROM disciplinas")->fetchAll(PDO::FETCH_COLUMN);
$escenarios  = $pdo->query("SELECT nombre FROM escenarios")->fetchAll(PDO::FETCH_COLUMN);
$sedes       = $pdo->query("SELECT titulo FROM sedes")->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Galer��a - <?= htmlspecialchars($evento['titulo']) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.9.0"></script>
<script src="https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8/dist/teachablemachine-image.min.js"></script>
</head>
<body class="bg-gray-100">

<div class="flex">
    <!-- Filtros -->
    <aside class="w-64 bg-white p-4 shadow h-screen sticky top-0">
        <h2 class="text-xl font-bold mb-4">Filtros</h2>
        <form method="get" class="space-y-3">
            <input type="hidden" name="id" value="<?= $evento_id ?>">

            <select name="disciplina" class="border p-2 rounded w-full">
                <option value="">-- Disciplina --</option>
                <?php foreach($disciplinas as $d): ?>
                    <option value="<?= htmlspecialchars($d) ?>" <?= ($filtroDisciplina==$d)?'selected':'' ?>><?= htmlspecialchars($d) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="escenario" class="border p-2 rounded w-full">
                <option value="">-- Escenario --</option>
                <?php foreach($escenarios as $e): ?>
                    <option value="<?= htmlspecialchars($e) ?>" <?= ($filtroEscenario==$e)?'selected':'' ?>><?= htmlspecialchars($e) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="sede" class="border p-2 rounded w-full">
                <option value="">-- Sede --</option>
                <?php foreach($sedes as $s): ?>
                    <option value="<?= htmlspecialchars($s) ?>" <?= ($filtroSede==$s)?'selected':'' ?>><?= htmlspecialchars($s) ?></option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-2 px-4 rounded w-full mt-2">Filtrar</button>
        </form>
    </aside>

    <!-- Contenido principal -->
    <main class="flex-1 p-6">
        <!-- Subida de rostro -->
        <div class="mb-6 text-center">
            <h2 class="text-xl font-semibold mb-2">�9�3 Buscar fotos similares (IA)</h2>
            <input type="file" id="faceInput" accept="image/*" class="border p-2 rounded w-full max-w-sm mx-auto">
            <button id="btnFaceSearch" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded mt-2">Buscar similitudes</button>
            <p id="resultadoIA" class="mt-2 text-gray-600"></p>
        </div>

        <!-- Galer��a -->
        <div id="galeria" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <?php foreach($fotos as $f): 
                $fotoUrl = 'uploads/' . htmlspecialchars($f['url']);
                if(file_exists($fotoUrl)):
            ?>
            <div class="foto bg-white rounded-lg shadow overflow-hidden">
                <img src="<?= $fotoUrl ?>" alt="Foto" class="w-full h-64 object-cover foto-img">
            </div>
            <?php endif; endforeach; ?>
        </div>
    </main>
</div>

<script>
const MODEL_URL = "modelo/model.json";
let model;
let fotosPredicciones = [];

async function loadModel() {
    model = await tmImage.load(MODEL_URL, MODEL_URL.replace("model.json","metadata.json"));
    const fotos = Array.from(document.querySelectorAll(".foto-img"));

    for(const img of fotos){
        await new Promise(res => img.complete ? res() : img.onload = res);
        const pred = await model.predict(img);
        const probs = {};
        pred.forEach(p => probs[p.className] = p.probability);
        fotosPredicciones.push({ img, probs });
    }
    console.log("Predicciones cargadas");
}
loadModel();

function similarity(predA, predB){
    let score = 0;
    for(const key in predA){
        score += Math.abs((predA[key]||0) - (predB[key]||0));
    }
    return 1 - score/2;
}

document.getElementById("btnFaceSearch").addEventListener("click", async () => {
    const input = document.getElementById("faceInput");
    const resultado = document.getElementById("resultadoIA");
    if(!input.files[0]) return alert("Selecciona una foto");

    resultado.textContent = "Analizando foto subida...";
    const userImg = document.createElement("img");
    userImg.src = URL.createObjectURL(input.files[0]);
    await new Promise(res => userImg.onload = res);

    const userPredRaw = await model.predict(userImg);
    const userPred = {};
    userPredRaw.forEach(p => userPred[p.className] = p.probability);

    const similitudes = fotosPredicciones.map(f => ({ img: f.img, sim: similarity(userPred, f.probs) }));
    similitudes.sort((a,b) => b.sim - a.sim);

    document.querySelectorAll('.foto').forEach(div => div.style.display = 'none');

    const topSimilars = similitudes.filter(f => f.sim > 0.5).slice(0,3);
    topSimilars.forEach(f => f.img.closest('.foto').style.display = 'block');

    resultado.textContent = topSimilars.length === 0
        ? "�7�4 No se encontraron fotos suficientemente similares."
        : `�7�3 Mostrando ${topSimilars.length} foto(s) similar(es).`;
});
</script>

</body>
</html>
