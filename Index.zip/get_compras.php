<?php
require 'dbfotografos.php'; // tu conexión PDO

try {
    $pdo = conectar();

    // Obtener todas las compras con detalles
   $stmtCompras = $pdo->query("
    SELECT 
        c.id, 
        c.estado, 
        c.total, 
        COALESCE(u.nombre, ci.nombre, 'Invitado') AS usuario_nombre,
        COALESCE(u.id, ci.id) AS usuario_id
    FROM compras c
    /* Join para usuarios registrados basado en su UID */
    LEFT JOIN usuarios u ON c.firebase_uid = u.firebase_uid
    /* Join para invitados basado EXCLUSIVAMENTE en el ID de la compra */
    LEFT JOIN clientes_invitados ci ON c.id = ci.compra_id
    WHERE c.estado NOT IN ('Aceptada', 'Pendiente', 'ERROR')
    ORDER BY c.id ASC
");

    $compras = $stmtCompras->fetchAll(PDO::FETCH_ASSOC);

    foreach ($compras as &$c) {
        // Obtener detalles de cada compra
        $stmtDetalles = $pdo->prepare("
            SELECT dc.id, dc.id_compra, dc.id_foto, f.url AS nombre_archivo
            FROM detalle_compras dc
            LEFT JOIN fotos f ON dc.id_foto = f.id
            WHERE dc.id_compra = ?
        ");
        $stmtDetalles->execute([$c['id']]);
        $c['detalles'] = $stmtDetalles->fetchAll(PDO::FETCH_ASSOC);
    }

    echo json_encode(['status'=>'success','compras'=>$compras]);
} catch (Exception $e) {
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}

