<?php
define('ACCESO_PERMITIDO', true);
require_once 'dbfotografos.php';

$stmt = $pdo->prepare("
    SELECT f.id, f.url FROM fotos f 
    LEFT JOIN fotos_moderacion fm ON f.id = fm.foto_id 
    WHERE fm.foto_id IS NULL 
    ORDER BY f.id DESC LIMIT 30
");
$stmt->execute();
$fotos_iniciales = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Buscador - Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        :root { --primary: #f56c1e; --bg: #050505; }
        body { background: var(--bg); color: white; font-family: sans-serif; }
        .grid-fotos { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; }
        .foto-card { background: #111; padding: 12px; border-radius: 14px; border: 1px solid #222; transition: transform 0.2s; }
        .img-wrapper { aspect-ratio: 3/4; overflow: hidden; border-radius: 8px; background: #000; }
        .lazy-img { width: 100%; height: 100%; object-fit: cover; }
        .btn-action { font-size: 10px; padding: 6px; border-radius: 6px; border: none; cursor: pointer; width: 48%; }
    </style>
</head>
<body class="p-6">
 <button onclick="history.back()" class="inline-flex items-center gap-2 px-4 py-2 text-sm font-bold text-white bg-black border border-orange-500 rounded-xl transition-all hover:bg-orange-600 hover:text-white active:scale-95 shadow-lg shadow-orange-500/10">
        <span class="material-icons text-base">arrow_back</span>
        <span>Atras</span>
    </button>

<div class="max-w-5xl mx-auto">
    <div class="bg-[#111] p-8 rounded-2xl border border-[#222] mb-10 text-center">
        <h2 class="text-xl font-bold mb-4">Busca tu foto</h2>
        <form id="buscadorForm" class="flex flex-col gap-3">
    <div class="drop-zone border-2 border-dashed border-[#333] p-6 bg-[#0a0a0a] rounded-xl cursor-pointer text-center" 
         onclick="document.getElementById('fileInput').click()">
        <span id="txtFile" class="text-sm">Arrastra foto o haz clic para subir</span>
        <input type="file" id="fileInput" name="foto" accept="image/*" style="display:none;" 
               onchange="document.getElementById('txtFile').innerText = this.files[0].name">
    </div>

    <input type="number" name="id_foto" id="id_foto" placeholder="O busca por ID de foto..." 
           class="w-full p-3 bg-[#0a0a0a] border border-[#333] rounded-lg text-white">

    <button type="submit" class="w-full p-3 bg-[var(--primary)] text-white rounded-lg font-bold hover:opacity-90">
        Buscar
    </button>
</form>
    </div>

    <div class="grid-fotos" id="galeria">
        <?php foreach ($fotos_iniciales as $foto): ?>
            <div id="card-foto-<?= $foto['id'] ?>" class="foto-card">
                <div class="img-wrapper"><img src="minion.php?id=<?= $foto['id'] ?>&tipo=mini" class="lazy-img" loading="lazy"></div>
                <div class="mt-3 flex justify-between">
                    <span class="text-[10px] text-gray-500">ID: #<?= $foto['id'] ?></span>
                    <div class="flex gap-2 w-full justify-end">
                        <button onclick="moderarFoto('ocultar', <?= $foto['id'] ?>)" class="btn-action bg-gray-700">Ocultar</button>
                        <button onclick="moderarFoto('eliminar', <?= $foto['id'] ?>)" class="btn-action bg-red-900">Borrar</button>
						<button onclick="<?= $foto['id'] ?>)" class="btn-action bg-red-900">Borrar</button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
    let offset = 30;
    let cargando = false;
    let buscando = false;

    // L�gica Scroll Infinito
    window.addEventListener('scroll', async () => {
        if (buscando) return;
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 500) {
            if (cargando) return;
            cargando = true;
            const res = await fetch(`cargar_fotos.php?offset=${offset}`);
            const fotos = await res.json();
            if (fotos.length > 0) {
                fotos.forEach(f => renderFoto(f));
                offset += 30;
            }
            cargando = false;
        }
    });

    function renderFoto(foto) {
        const galeria = document.getElementById('galeria');
        const div = document.createElement('div');
        div.id = `card-foto-${foto.id}`;
        div.className = "foto-card";
        div.innerHTML = `
            <div class="img-wrapper"><img src="minion.php?id=${foto.id}&tipo=mini" class="lazy-img" loading="lazy"></div>
            <div class="mt-3 flex justify-between">
                <span class="text-[10px] text-gray-500">ID: #${foto.id}</span>
                <div class="flex gap-2 w-full justify-end">
                    <button onclick="moderarFoto('ocultar', ${foto.id})" class="btn-action bg-gray-700">Ocultar</button>
                    <button onclick="moderarFoto('eliminar', ${foto.id})" class="btn-action bg-red-900">Borrar</button>
                </div>
            </div>`;
        galeria.appendChild(div);
    }

    // Buscador
    document.getElementById('buscadorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const galeria = document.getElementById('galeria');
    const idInput = document.getElementById('id_foto').value;
    const fileInput = document.getElementById('fileInput').files[0];

    if (!idInput && !fileInput) {
        alert("Por favor, sube una foto o escribe un ID.");
        return;
    }

    buscando = true; // Desactiva el scroll infinito mientras vemos resultados
    galeria.innerHTML = '<p class="text-center p-10">Buscando...</p>';

    const formData = new FormData(e.target);
    
    // Si hay archivo, va a la IA. Si solo hay ID, va al buscador local.
    const url = fileInput ? 'https://api.latincolorsports.com/buscars' : 'buscar_id.php';

    try {
        const res = await fetch(url, { method: 'POST', body: formData });
        const data = await res.json();
        
        galeria.innerHTML = "";
        if (data.matches && data.matches.length > 0) {
            data.matches.forEach(f => renderFoto(f));
        } else {
            galeria.innerHTML = '<p class="text-center p-10">No se encontraron resultados.</p>';
        }
    } catch (err) {
        galeria.innerHTML = '<p class="text-center text-red-500">Error al buscar.</p>';
    }
});
    async function moderarFoto(accion, id) {
        if(!confirm('Confirmar ' + accion + '?')) return;
        const res = await fetch('gestionar_fotos_ia.php', { 
            method: 'POST', 
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ action: accion, foto_id: id }) 
        });
        const d = await res.json();
        if (d.success) document.getElementById(`card-foto-${id}`).remove();
    }
</script>
</body>
</html>