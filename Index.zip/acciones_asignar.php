<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'dbfotografos.php';

// Recibir datos
$evento_id = (int)($_POST['evento_id'] ?? 0);
$fotografo_id = (int)($_POST['fotografo_id'] ?? 0);
$capacidad_mb = (int)($_POST['capacidad_mb'] ?? 0);
$capacidad_fotos = (int)($_POST['capacidad_de_fotos'] ?? 0);
$eliminar = isset($_POST['eliminar']) ? true : false;

// Validar IDs
if (!$evento_id || !$fotografo_id) {
    echo json_encode(['status'=>'error','message'=>'Datos inválidos.']);
    exit;
}

if ($eliminar) {
    // Eliminar asignación
    $stmt = $pdo->prepare("DELETE FROM asignar_eventos WHERE evento_id = ? AND fotografo_id = ?");
    $stmt->execute([$evento_id, $fotografo_id]);
    echo json_encode(['status'=>'success','message'=>'Fotógrafo eliminado correctamente.']);
    exit;
}

// Validar capacidad
$evento = $pdo->prepare("SELECT capacidad_gb FROM eventos WHERE id = ?");
$evento->execute([$evento_id]);
$evento = $evento->fetch(PDO::FETCH_ASSOC);
if (!$evento) {
    echo json_encode(['status'=>'error','message'=>'Evento no encontrado.']);
    exit;
}

$capacidad_max_mb = $evento['capacidad_gb'] * 1024;

// Sumar capacidades ya asignadas
$capacidad_usada = $pdo->prepare("SELECT SUM(capacidad_mb) FROM asignar_eventos WHERE evento_id = ?");
$capacidad_usada->execute([$evento_id]);
$capacidad_usada = (int)$capacidad_usada->fetchColumn();

// Validar que no se supere la capacidad
if ($capacidad_usada + $capacidad_mb > $capacidad_max_mb) {
    echo json_encode([
        'status' => 'error',
        'message' => 'No hay suficiente capacidad en el evento para este fotógrafo.'
    ]);
    exit;
}

// Insertar asignación con capacidad de fotos
$stmt = $pdo->prepare("
    INSERT INTO asignar_eventos (evento_id, fotografo_id, capacidad_mb, capacidad_de_fotos) 
    VALUES (?, ?, ?, ?)
");
$stmt->execute([$evento_id, $fotografo_id, $capacidad_mb, $capacidad_fotos]);

echo json_encode(['status'=>'success','message'=>'Fotógrafo asignado correctamente.']);
