<?php
// conexion.php
// Archivo de conexi��n a la base de datos

function conectar() {
    // ???? Datos de conexi��n (ajusta solo si cambian en tu hosting)
    $servername = "database-1.c8302k404lkf.us-east-1.rds.amazonaws.com";
    $username   = "admin";
    $password   = "DannyCruxTecnoLoad!#";
    $dbname     = "latincolors";
    $port       = 3306;

    // Crear conexi��n
    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    // Verificar conexi��n
    if ($conn->connect_errno) {
        error_log("Error de conexi��n MySQL: " . $conn->connect_error);
        die("?? Error al conectar con la base de datos.");
    }

    // Establecer codificaci��n UTF-8
    if (!$conn->set_charset("utf8mb4")) {
        error_log("Error al establecer charset: " . $conn->error);
    }

    return $conn;
}
?>
