<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<title>Resumen de compra</title>
<style>
body { font-family: Arial; background:#f4f4f4; padding:20px; }
.box { background:#fff; padding:20px; max-width:600px; margin:auto; }
table { width:100%; border-collapse:collapse; margin-top:15px; }
th, td { padding:8px; border-bottom:1px solid #ddd; text-align:left; }
.total { text-align:right; font-size:18px; font-weight:bold; }
.btn { display:inline-block; background:#6c2bd9; color:#fff; padding:10px 15px; text-decoration:none; border-radius:4px; }
</style>
</head>
<body>

<div class="box">
<h2>📸 Gracias por tu compra</h2>

<p><strong>Referencia:</strong> {{REFERENCIA}}</p>
<p><strong>Estado:</strong> Pendiente de pago</p>

<table>
<tr>
<th>Foto</th>
<th>Evento</th>
<th>Precio</th>
</tr>
{{FILAS_FOTOS}}
</table>

<p class="total">Total: ${{TOTAL}}</p>

<p>
<a class="btn" href="{{LINK_PAGO}}">Pagar ahora</a>
</p>

<p style="font-size:12px;color:#777">
Este correo fue enviado automáticamente.
</p>
</div>

</body>
</html>
