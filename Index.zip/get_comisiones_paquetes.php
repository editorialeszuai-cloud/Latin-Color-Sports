<?php
session_start();
require 'dbfotografos.php';
$pdo = conectar();

// Evitar cualquier salida accidental
ob_start();

// Mostrar errores de PHP en desarrollo
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("
        SELECT cp.id AS comision_id,
               c.id AS compra_id,
               cp.fotografo AS comision_fotografo
        FROM comisiones_paquetes cp
        INNER JOIN compras_paquetes c ON cp.compra_id = c.id
        WHERE c.estado = 'Pagado'
        ORDER BY cp.id ASC
    ");
    $stmt->execute();
    $comisiones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status'=>'success','comisiones'=>$comisiones]);

} catch (Exception $e) {
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}

// Limpiar cualquier salida extra antes de cerrar
ob_end_flush();
