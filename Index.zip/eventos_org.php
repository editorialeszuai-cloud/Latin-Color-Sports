<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
require_once "conexion.php";

$conn = conectar();

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $accion = $input['accion'] ?? '';
    $firebase_uid = $input['firebase_uid'] ?? ''; // UID del usuario logueado en Firebase

    if ($accion === 'listar') {
        if (empty($firebase_uid)) {
            throw new Exception("No se proporcionó firebase_uid");
        }

        // --- Consultar eventos del usuario logueado ---
        // JOIN con usuarios para poder filtrar por firebase_uid
        $sql = "SELECT 
                    e.id,
                    e.titulo,
                    e.fecha,
                    e.tipo_evento,
                    e.banner,
                    e.lugar_id,
                    e.organizador_id,
                    e.comercial_id,
                    e.capacidad_gb,
                    e.max_fotografos,
                    e.paquetes_eventos,
                    e.disciplinas_evento,
                    u1.nombre AS organizador_nombre,
                    u2.nombre AS comercial_nombre,
                    l.nombre_lugar
                FROM eventos e
                LEFT JOIN usuarios u1 ON e.organizador_id = u1.id
                LEFT JOIN usuarios u2 ON e.comercial_id = u2.id
                LEFT JOIN lugares l ON e.lugar_id = l.id
                WHERE u1.firebase_uid = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $firebase_uid);
        $stmt->execute();
        $result = $stmt->get_result();

        $eventos = [];
        while ($row = $result->fetch_assoc()) {
            // Procesar banner
            $row['banner'] = !empty($row['banner']) ? 'uploads/' . basename($row['banner']) : null;

            // Decodificar JSON a arrays
            $paquetes_ids = !empty($row['paquetes_eventos']) ? json_decode($row['paquetes_eventos'], true) : [];
            $disciplinas_ids = !empty($row['disciplinas_evento']) ? json_decode($row['disciplinas_evento'], true) : [];

            // Obtener nombres de paquetes
            $row['paquetes_eventos'] = [];
            if (!empty($paquetes_ids)) {
                $ids = implode(',', array_map('intval', $paquetes_ids));
                $paq_res = $conn->query("SELECT nombre_paquete FROM paquetes_fotos WHERE id IN ($ids)");
                while ($paq = $paq_res->fetch_assoc()) {
                    $row['paquetes_eventos'][] = $paq['nombre_paquete'];
                }
            }

            // Obtener nombres de disciplinas
            $row['disciplinas_evento'] = [];
            if (!empty($disciplinas_ids)) {
                $ids = implode(',', array_map('intval', $disciplinas_ids));
                $disc_res = $conn->query("SELECT nombre_disciplina FROM disciplinas WHERE id IN ($ids)");
                while ($disc = $disc_res->fetch_assoc()) {
                    $row['disciplinas_evento'][] = $disc['nombre_disciplina'];
                }
            }

            // Valores por defecto
            $row['organizador_nombre'] = $row['organizador_nombre'] ?? '-';
            $row['comercial_nombre'] = $row['comercial_nombre'] ?? '-';
            $row['nombre_lugar'] = $row['nombre_lugar'] ?? '-';

            $eventos[] = $row;
        }

        echo json_encode(['success' => true, 'data' => $eventos]);
        exit;
    }

    echo json_encode(['success' => false, 'data' => [], 'message' => 'Acción no válida']);
    exit;

} catch(Exception $e) {
    echo json_encode(['success' => false, 'data' => [], 'message' => $e->getMessage()]);
    exit;
}
?>
