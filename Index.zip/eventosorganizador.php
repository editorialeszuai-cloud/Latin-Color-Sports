<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Eventos de Organizador</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
  body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
  .role-admin { background-color: #fee2e2; color: #7f1d1d; }
  .role-cliente { background-color: #dbeafe; color: #1e3a8a; }
  .fade-in { animation: fadeIn 0.4s ease-in-out; }
  @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
</style>
</head>
<body>

<div id="dashboardContainer" class="w-full bg-white p-0 rounded-2xl shadow-xl hidden fade-in">

  <!-- === NAV SUPERIOR === -->
<nav class="flex items-center justify-between bg-gradient-to-r from-orange-900 via-orange-800 to-black text-white px-6 py-4 rounded-t-2xl shadow-md">

    <div class="flex items-center space-x-3">
      <img src="uploads/LATIN-SPORTS.png" alt="Logo" width="80px">
      <h1 class="text-lg font-semibold tracking-wide">Crea tu Evento</h1>
    </div>

    <div class="flex items-center space-x-4">
<a href="nav_organizador.php">  <button id="homeButton" class="hover:underline hidden sm:inline">Inicio</button></a>
      <button id="helpButton" class="hover:underline hidden sm:inline">Ayuda</button>

      <!-- Botón Cerrar Sesión destacado -->
      <button id="logoutButton" class="flex items-center space-x-2 bg-red-600 hover:bg-red-700 active:scale-95 transition-all px-4 py-2 rounded-full text-white font-medium shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 002 2h3a2 2 0 002-2V5a2 2 0 00-2-2h-3a2 2 0 00-2 2v1" />
        </svg>
        <span>Cerrar Sesión</span>
      </button>
    </div>
  </nav>

  <!-- === CONTENIDO DEL DASHBOARD === -->
  <div class="p-8">
    <div class="bg-indigo-50 p-6 rounded-lg border border-indigo-200 shadow-inner hidden">
      <h2 class="text-xl font-semibold text-indigo-700 mb-4">Detalles del Usuario</h2>
      <div class="space-y-2 text-gray-700">
        <p><strong>UID:</strong> <span id="userId" class="font-mono text-sm block">Cargando...</span></p>
        <p><strong>Email:</strong> <span id="userEmail" class="font-medium">Cargando...</span></p>
        <p><strong>Nombre:</strong> <span id="userName" class="font-medium">Cargando...</span></p>
        <p><strong>Rol:</strong> <span id="userRole" class="inline-block px-3 py-1 text-xs font-semibold rounded-full">Cargando...</span></p>
      </div>
    </div>

    <div id="roleContent" class="mt-8 space-y-4"></div>
    <p id="loadingMessage" class="mt-8 text-center text-gray-500">Verificando sesión...</p>
    <p id="errorMessage" class="mt-4 text-center text-red-600 hidden"></p>
  </div>
</div>


<div id="modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-auto">
  <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-3xl relative" id="modalContent">
    
    <!-- Botón de cierre -->
    <button id="closeModal" class="absolute top-3 right-3 text-gray-500 hover:text-red-600 text-2xl font-bold">&times;</button>

    <h3 id="modalTitulo" class="text-xl font-semibold mb-4 text-gray-800">Crear/Editar Evento</h3>

    <form id="formEvento" class="space-y-4" enctype="multipart/form-data">
      <input type="hidden" name="accion" id="accion" value="">
      <input type="hidden" name="id_evento" id="id_evento">

      <!-- ===== PASO 1: Información General ===== -->
      <div class="step step-1">
        <h4 class="text-lg font-semibold mb-3 text-gray-700">Información General</h4>

        <div>
          <label class="block text-sm font-medium text-gray-700">Título</label>
          <input type="text" name="titulo" id="titulo" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" required>
        </div>

        <div class="mt-4">
          <label class="block text-sm font-medium text-gray-700">Descripción</label>
          <textarea name="descripcion" id="descripcion" rows="2" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500"></textarea>
        </div>

        <div class="mt-4">
          <label class="block text-sm font-medium text-gray-700">Organizador</label>
          <select name="organizador_id" id="organizador_id" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" required>
            <option value="">Seleccione un organizador</option>
          </select>
        </div>
        
        <div class="mt-4">
  <label class="block text-sm font-medium text-gray-700">Comercial</label>
  <select name="comercial_id" id="comercial_id" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
    <option value="">Seleccione un comercial</option>
  </select>
</div>


        <div class="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Fecha</label>
            <input type="date" name="fecha" id="fecha" class="mt-1 w-full border rounded-lg p-2" required>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">Fecha de Finalización</label>
            <input type="date" name="fechafin" id="fechafin" class="mt-1 w-full border rounded-lg p-2" required>
          </div>
          <div>
            
              
            <label class="block text-sm font-medium text-gray-700">Lugar</label>
            <select name="lugar_id" id="lugar_id" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" required>
              <option value="">Seleccione un lugar</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Ciudad</label>
            <input type="text" id="ciudad_lugar" class="mt-1 w-full border rounded-lg p-2 bg-gray-100" readonly>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">País</label>
            <input type="text" id="pais_lugar" class="mt-1 w-full border rounded-lg p-2 bg-gray-100" readonly>
          </div>
        </div>
      </div>

      <!-- ===== PASO 2: Multimedia y Logística ===== -->
      <div class="step step-2 hidden">
        <h4 class="text-lg font-semibold mb-3 text-gray-700">Multimedia y Logística</h4>

        <div class="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Tipo de Evento</label>
            <select name="tipo_evento" id="tipo_evento" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
              <option>Deportivo</option>
              <option>Corporativo</option>
              <option>Social</option>
              <option>Educativo</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">Método de Monetización</label>
            <select name="metodo_monetizacion" id="metodo_monetizacion" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500">
              <option value="Pago">Pago</option>
              <option value="No Pago">No Pago</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-2 gap-4 mt-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Capacidad (GB)</label>
            <input type="number" name="capacidad_gb" id="capacidad_gb" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" required>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">Máx. Fotógrafos</label>
            <input type="number" name="max_fotografos" id="max_fotografos" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500" required>
          </div>
        </div>

        <div class="grid grid-cols-3 gap-4 mt-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Logo</label>
            <input type="file" name="logo" id="logo" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">Banner</label>
            <input type="file" name="banner" id="banner" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700">Ícono / Foto</label>
            <input type="file" name="icono_foto" id="icono_foto" accept="image/*" class="mt-1 w-full border rounded-lg p-2">
          </div>
        </div>

        <div class="mt-4">
          <label class="block text-sm font-medium text-gray-700">Licencia de Fotos</label>
          <textarea name="photo_licensing" id="photo_licensing" rows="2" class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500"></textarea>
        </div>
      </div>

      <!-- ===== PASO 3: Paquetes y Disciplinas ===== -->
      <div class="step step-3 hidden">
        <h4 class="text-lg font-semibold mb-3 text-gray-700">Paquetes y Disciplinas</h4>

        <div class="mb-4">
          <label class="block text-sm font-medium text-gray-700">Paquetes de Fotos</label>
          <select name="paquetes_eventos[]" id="paquetes_eventos" multiple class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500"></select>
          <p class="text-xs text-gray-500 mt-1">Puedes seleccionar varios paquetes (Ctrl + clic)</p>
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-700">Disciplinas</label>
          <select name="disciplinas_evento[]" id="disciplinas_evento" multiple class="mt-1 w-full border rounded-lg p-2 focus:ring-2 focus:ring-indigo-500"></select>
          <p class="text-xs text-gray-500 mt-1">Puedes seleccionar varias disciplinas (Ctrl + clic)</p>
        </div>
      </div>

      <!-- ===== BOTONES ===== -->
      <div class="flex justify-between mt-6">
        <button type="button" id="prevBtn" class="bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500 hidden">Anterior</button>
        <button type="button" id="nextBtn" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700">Siguiente</button>
        <button type="submit" id="saveBtn" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 hidden">Guardar</button>
      </div>
    </form>
  </div>
</div>


<script>
document.addEventListener("DOMContentLoaded", () => {
  const modal = document.getElementById("modal");
  const closeModal = document.getElementById("closeModal");
  const formEvento = document.getElementById("formEvento");
  const nextBtn = document.getElementById("nextBtn");
  const prevBtn = document.getElementById("prevBtn");
  const saveBtn = document.getElementById("saveBtn");

  let currentStep = 1;
  const totalSteps = 3;

  // Función para mostrar el paso actual
  function showStep(step) {
    document.querySelectorAll(".step").forEach((el, index) => {
      el.classList.toggle("hidden", index !== step - 1);
    });
    prevBtn.classList.toggle("hidden", step === 1);
    nextBtn.classList.toggle("hidden", step === totalSteps);
    saveBtn.classList.toggle("hidden", step !== totalSteps);
  }

  // Navegación de pasos
  nextBtn.addEventListener("click", () => {
    if (currentStep < totalSteps) {
      currentStep++;
      showStep(currentStep);
    }
  });

  prevBtn.addEventListener("click", () => {
    if (currentStep > 1) {
      currentStep--;
      showStep(currentStep);
    }
  });

  showStep(currentStep);

  // Cerrar modal
  closeModal.addEventListener("click", () => {
    modal.classList.add("hidden");
  });

  // Submit del formulario
  formEvento.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = new FormData(formEvento);

    try {
      const res = await fetch("eventos_api.php", {
        method: "POST",
        body: formData,
      });
      const data = await res.json();

      if (data.success) {
        alert("✅ Evento guardado correctamente");
        modal.classList.add("hidden");
        formEvento.reset();
        currentStep = 1;
        showStep(currentStep);
      } else {
        alert("❌ Error: " + data.message);
      }
    } catch (err) {
      console.error(err);
      alert("❌ Error al enviar el formulario");
    }
  });
});
</script>

<script>
  const modal = document.getElementById('modal');
  const closeModal = document.getElementById('closeModal');
  const modalContent = document.getElementById('modalContent');

  // Cerrar al hacer clic en la "X"
  closeModal.addEventListener('click', () => {
    modal.classList.add('hidden');
  });

  // Cerrar al hacer clic fuera del contenido
  modal.addEventListener('click', (e) => {
    if (!modalContent.contains(e.target)) {
      modal.classList.add('hidden');
    }
  });

  // (Opcional) Función para abrir el modal
  function openModal() {
    modal.classList.remove('hidden');
  }

  // Ejemplo de uso: openModal() desde un botón
  // document.getElementById("btnAbrirModal").addEventListener("click", openModal);
</script>

<script>
let currentStep = 1;
const totalSteps = 3;

// === Mostrar el paso activo ===
function showStep(step) {
  // Oculta todos los pasos
  document.querySelectorAll('.step').forEach((el, i) => {
    el.classList.add('hidden');
    if (i === step - 1) el.classList.remove('hidden');
  });

  // Controlar visibilidad de botones
  document.getElementById('prevBtn').classList.toggle('hidden', step === 1);
  document.getElementById('nextBtn').classList.toggle('hidden', step === totalSteps);
  document.getElementById('saveBtn').classList.toggle('hidden', step !== totalSteps);
}

// === Botones siguiente / anterior ===
document.addEventListener('DOMContentLoaded', () => {
  // Asegurar que los elementos existen
  const nextBtn = document.getElementById('nextBtn');
  const prevBtn = document.getElementById('prevBtn');
  const saveBtn = document.getElementById('saveBtn');
  
  if (!nextBtn || !prevBtn) {
    console.error("Botones de navegación no encontrados");
    return;
  }

  // Mostrar el primer paso al inicio
  showStep(currentStep);

  nextBtn.addEventListener('click', () => {
    if (currentStep < totalSteps) currentStep++;
    showStep(currentStep);
  });

  prevBtn.addEventListener('click', () => {
    if (currentStep > 1) currentStep--;
    showStep(currentStep);
  });

  // Cerrar modal
  document.getElementById('closeModal').addEventListener('click', cerrarModal);
});

// === Función para abrir modal ===
function abrirModal() {
  currentStep = 1; // siempre empieza desde el paso 1
  document.getElementById('modal').classList.remove('hidden');
  showStep(currentStep);
}

// === Función para cerrar modal ===
function cerrarModal() {
  document.getElementById('modal').classList.add('hidden');
}
</script>

<script>
// Función para cargar lugares
async function cargarLugares() {
    const res = await fetch('lugares.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({accion:'listar'})
    });
    const data = await res.json();
    const lugarSelect = document.getElementById('lugar_id');
    lugarSelect.innerHTML = '<option value="">Seleccione un lugar</option>';
    if(data.status === 'success') {
        data.data.forEach(l => {
            const option = document.createElement('option');
            option.value = l.id;
            option.textContent = l.nombre_lugar; // campo de tabla lugares
            option.dataset.ciudad = l.ciudad;
            option.dataset.pais = l.pais;
            lugarSelect.appendChild(option);
        });
    }
}

// Mostrar ciudad y país al seleccionar lugar
document.getElementById('lugar_id').addEventListener('change', function(){
    const sel = this.selectedOptions[0];
    document.getElementById('ciudad_lugar').value = sel?.dataset.ciudad || '';
    document.getElementById('pais_lugar').value = sel?.dataset.pais || '';
});

// Función para cargar paquetes de fotos
async function cargarPaquetes() {
    const res = await fetch('paquetes.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({accion:'listar'})
    });
    const data = await res.json();
    const paquetesSelect = document.getElementById('paquetes_eventos');
    paquetesSelect.innerHTML = '';
    if(data.status === 'success') {
        data.data.forEach(p => {
            const option = document.createElement('option');
            option.value = p.id;
            option.textContent = `${p.nombre_paquete} - $${p.precio_por_unidad} -${p.unidades_incluidas} `;
            paquetesSelect.appendChild(option);
        });
    } else {
        console.error('Error al cargar paquetes:', data.message);
    }
}



async function cargarOrganizadores() {
  console.log("Llamando a cargarOrganizadores()...");
  try {
    const res = await fetch('usuariosor.php', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({accion:'listar_organizadores'})
    });
    console.log("Respuesta bruta:", res);
    const data = await res.json();
    console.log("JSON recibido:", data);
    const select = document.getElementById('organizador_id');
    select.innerHTML = '<option value="">Seleccione un organizador</option>';

    if (data.status === 'success') {
      data.data.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = u.nombre_usuario;
        select.appendChild(opt);
      });
    }
  } catch (err) {
    console.error('Error al cargar organizadores:', err);
  }
}

// Función para cargar comerciales
async function cargarComerciales() {
    console.log("Llamando a cargarComerciales()...");
    try {
        const res = await fetch('usuarioscom.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({accion:'listar_comerciales'})
        });
        console.log("Respuesta bruta:", res);
        const data = await res.json();
        console.log("JSON recibido:", data);
        
        const select = document.getElementById('comercial_id');
        if (!select) return; // evitar errores si no existe el select
        select.innerHTML = '<option value="">Seleccione un comercial</option>';

        if (data.status === 'success') {
            data.data.forEach(u => {
                const opt = document.createElement('option');
                opt.value = u.id;
                opt.textContent = u.nombre_comercial;
                select.appendChild(opt);
            });
        }
    } catch (err) {
        console.error('Error al cargar comerciales:', err);
    }
}


// Abre modal y carga todos los selects
function abrirModal() {
    document.getElementById('modal').classList.remove('hidden');
    showStep(currentStep);
    cargarLugares();
    cargarPaquetes();
    cargarDisciplinas();
    cargarOrganizadores();
}

// Botón cerrar
function cerrarModal() {
    document.getElementById('modal').classList.add('hidden');
}




// Función para cargar disciplinas
async function cargarDisciplinas() {
    const res = await fetch('disciplinas.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({accion:'listar'})
    });
    const data = await res.json();
    const disciplinasSelect = document.getElementById('disciplinas_evento');
    disciplinasSelect.innerHTML = '';
    if(data.status === 'success') {
        data.data.forEach(d => {
            const option = document.createElement('option');
            option.value = d.id;
            option.textContent = d.nombre_disciplina;
            disciplinasSelect.appendChild(option);
        });
    }
}

// Inicializar selects al cargar modal
document.addEventListener('DOMContentLoaded', () => {
  cargarLugares();
  cargarPaquetes();
  cargarDisciplinas();
  cargarOrganizadores(); 
  cargarComerciales();// 👈 importante
});

</script>




<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// =================== DOM ===================
const dashboardContainer = document.getElementById('dashboardContainer');
const userIdSpan = document.getElementById('userId');
const userEmailSpan = document.getElementById('userEmail');
const userNameSpan = document.getElementById('userName');
const userRoleSpan = document.getElementById('userRole');
const roleContentDiv = document.getElementById('roleContent');
const loadingMessage = document.getElementById('loadingMessage');
const errorMessage = document.getElementById('errorMessage');
const logoutButton = document.getElementById('logoutButton');
const modal = document.getElementById('modal');
const formEvento = document.getElementById('formEvento');

// Inputs de archivos
const logoInput = document.getElementById('logo');
const bannerInput = document.getElementById('banner');
const iconoInput = document.getElementById('icono_foto');

// =================== Utilidades ===================
function showError(message){
  errorMessage.textContent = message;
  errorMessage.classList.remove('hidden');
}

function updateUI(uid, email, nombre, rol){
  dashboardContainer.classList.remove('hidden');
  loadingMessage.classList.add('hidden');
  userIdSpan.textContent = uid;
  userEmailSpan.textContent = email;
  userNameSpan.textContent = nombre;
  userRoleSpan.textContent = rol;
  userRoleSpan.className = `inline-block px-3 py-1 text-xs font-semibold rounded-full role-${rol}`;
}

function renderRoleContent(rol){
  if(rol === 'organizador'){
    roleContentDiv.innerHTML = `
    <div class="bg-gray-50 p-6 rounded-lg border border-gray-200 shadow-inner mt-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-2xl font-semibold text-gray-800">Gestión de Eventos</h2>
        <button onclick="abrirModalCrear()" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700">+ Nuevo Evento</button>
      </div>
      <div id="eventosTableContainer"></div>
    </div>`;
    cargarEventos();
  } else {
    roleContentDiv.innerHTML = `
      <div class="bg-blue-100 border-l-4 border-blue-600 p-4 rounded">
        <p class="font-bold">Panel de Cliente</p>
        <p>Acceso básico a tu cuenta y perfil personal.</p>
      </div>`;
  }
}

// Convertir archivo a Base64
async function fileToBase64(file){
  if(!file) return null;
  return new Promise((resolve, reject)=>{
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = err => reject(err);
    reader.readAsDataURL(file);
  });
}

// =================== Eventos ===================

// Logout
logoutButton.addEventListener('click', async () => {
  try {
    await signOut(auth);
    window.location.href = 'login_app.html';
  } catch(err){
    console.error(err);
  }
});

// Estado de sesión
onAuthStateChanged(auth, async (user) => {
  if(user){
    try {
      const token = await user.getIdToken();
      const res = await fetch('get_user_info.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ firebase_token: token })
      });
      const data = await res.json();
      if(data.status === 'success' && data.user){
        updateUI(data.user.firebase_uid, data.user.email, data.user.nombre, data.user.rol);
        renderRoleContent(data.user.rol);
      } else throw new Error('No encontrado en DB');
    } catch(err){
      console.error(err);
      showError('Error al obtener datos. Muestra información parcial.');
      updateUI(user.uid, user.email, 'Desconocido', 'cliente');
      renderRoleContent('cliente');
    }
  } else window.location.href = 'login_app.html';
});

// =================== Eventos CRUD ===================

// Abrir modal Crear
window.abrirModalCrear = () => {
  document.getElementById('modalTitulo').textContent = 'Crear Nuevo Evento';
  document.getElementById('accion').value = 'crear';
  formEvento.reset();
  modal.classList.remove('hidden');
}

// Abrir modal Editar
window.editarEvento = (data) => {
  document.getElementById('modalTitulo').textContent = 'Editar Evento';
  document.getElementById('accion').value = 'editar';
  document.getElementById('id_evento').value = data.id;
  document.getElementById('titulo').value = data.titulo;
  document.getElementById('descripcion').value = data.descripcion;
  document.getElementById('fecha').value = data.fecha;
  document.getElementById('lugar_id').value = data.lugar_id;
  document.getElementById('tipo_evento').value = data.tipo_evento;
  document.getElementById('metodo_monetizacion').value = data.metodo_monetizacion;
  document.getElementById('capacidad_gb').value = data.capacidad_gb;
  document.getElementById('max_fotografos').value = data.max_fotografos;
  document.getElementById('photo_licensing').value = data.photo_licensing;
  modal.classList.remove('hidden');
}

// Cerrar modal
window.cerrarModal = () => modal.classList.add('hidden');


// Eliminar evento
window.eliminarEvento = async (id) => {
  if(!confirm('¿Eliminar este evento?')) return;
  try {
    const res = await fetch('eventos_elim.php', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({accion:'eliminar', id})
    });
    const result = await res.json();
    if(result.status === 'success') cargarEventos();
    else alert(result.message);
  } catch(err){
    console.error(err);
    alert('Error al eliminar el evento.');
  }
}

// Cargar eventos
async function cargarEventos() {
  try {
    // Obtenemos el UID del usuario logueado desde el dashboard
    const firebase_uid = userIdSpan.textContent; // ya contiene el UID

    const res = await fetch('eventos_org.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accion: 'listar', firebase_uid }) // <- enviamos UID
    });

    const data = await res.json();
    const container = document.getElementById('eventosTableContainer');

    if (!data.data || data.data.length === 0) {
      container.innerHTML = '<p class="text-gray-500 mt-2">No hay eventos registrados.</p>';
      return;
    }

    let html = `
<div class="overflow-x-auto border rounded-lg shadow-md">
  <table class="min-w-full text-sm divide-y divide-gray-200">
    <thead class="bg-gray-100 sticky top-0">
      <tr>
        <th class="px-3 py-2 text-left font-medium text-gray-700">ID</th>
        <th class="px-3 py-2 text-center font-medium text-gray-700">Banner</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Título</th>
        <th class="px-3 py-2 text-center font-medium text-gray-700">Fecha</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Lugar</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Tipo</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Organizador</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Comercial</th>
        <th class="px-3 py-2 text-center font-medium text-gray-700">Capacidad</th>
        <th class="px-3 py-2 text-center font-medium text-gray-700">Fotógrafos</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Paquetes</th>
        <th class="px-3 py-2 text-left font-medium text-gray-700">Disciplinas</th>
        <th class="px-3 py-2 text-center font-medium text-gray-700">Acciones</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-200 bg-white">`;

    data.data.forEach(e => {
      const paquetes = e.paquetes_eventos.length > 0 
          ? e.paquetes_eventos.join(', ') 
          : '-';
      const disciplinas = e.disciplinas_evento.length > 0 
          ? e.disciplinas_evento.join(', ') 
          : '-';

      html += `
  <tr class="hover:bg-gray-50 transition-colors">
    <td class="px-3 py-2 text-center">${e.id}</td>
    <td class="px-3 py-2 text-center">${e.banner ? `<img src="${e.banner}" class="h-12 w-20 object-cover mx-auto rounded">` : '-'}</td>
    <td class="px-3 py-2">${e.titulo}</td>
    <td class="px-3 py-2 text-center">${e.fecha}</td>
    <td class="px-3 py-2">${e.nombre_lugar || '-'}</td>
    <td class="px-3 py-2">${e.tipo_evento}</td>
    <td class="px-3 py-2">${e.organizador_nombre || '-'}</td>
    <td class="px-3 py-2">${e.comercial_nombre || '-'}</td>
    <td class="px-3 py-2 text-center">${e.capacidad_gb || '-'}</td>
    <td class="px-3 py-2 text-center">${e.max_fotografos || '-'}</td>
    <td class="px-3 py-2">${paquetes}</td>
    <td class="px-3 py-2">${disciplinas}</td>
    <td class="px-3 py-2 text-center space-x-1">
      <a href="editar.php?id=${e.id}" 
         class="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded-md text-xs transition inline-block">
         Editar
      </a>
      <button onclick="eliminarEvento(${e.id})" class="bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded-md text-xs transition">Eliminar</button>
    </td>
  </tr>`;
    });

    html += `</tbody></table></div>`;
    container.innerHTML = html;

  } catch (err) {
    console.error('Error al cargar eventos:', err);
    document.getElementById('eventosTableContainer').innerHTML = '<p class="text-red-500">Error al cargar eventos.</p>';
  }
}

</script>

</body>
</html>