<?php
// Reporte de errores desactivado para asegurar que no se rompa el JSON
error_reporting(0);
ob_start();

require 'dbfotografos.php';
require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => $_ENV['AWS_REGION'],
    'credentials' => ['key' => $_ENV['AWS_KEY'], 'secret' => $_ENV['AWS_SECRET']],
]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');

    $action = $_POST['action'] ?? null;
    $uid = $_POST['firebase_uid'] ?? null;
    $page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
    $limit = 50; // Fijado estrictamente en 10 en 10
    $offset = ($page - 1) * $limit;

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    try {
        if ($action === 'eliminar_foto') {
            // Tu lógica de eliminación aquí si la necesitas...
        }

        if (!$uid) {
            exit(json_encode(['success' => false, 'error' => 'UID no proporcionado']));
        }

        // Buscar al fotógrafo por su UID
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ?");
        $stmt->execute([$uid]);
        $user = $stmt->fetch();
        
        if (!$user) {
            exit(json_encode(['success' => true, 'fotos' => [], 'total_paginas' => 0, 'msg' => 'Usuario no registrado en DB']));
        }

        // 1. Obtener el total de fotos del usuario para la paginación
        $stmtTotal = $pdo->prepare("
            SELECT COUNT(f.id) as total 
            FROM fotos f
            INNER JOIN galerias g ON f.galeria_id = g.id
            INNER JOIN postulaciones p ON g.postulacion_id = p.id
            WHERE p.usuario_id = ?
        ");
        $stmtTotal->execute([$user['id']]);
        $totalFotos = (int)$stmtTotal->fetch()['total'];
        $totalPaginas = ceil($totalFotos / $limit);

        // 2. Traer las fotos de 10 en 10 con su Evento y Galería
        $stmtF = $pdo->prepare("
            SELECT f.*, g.titulo as galeria_titulo, e.titulo as evento_titulo 
            FROM fotos f
            INNER JOIN galerias g ON f.galeria_id = g.id
            INNER JOIN postulaciones p ON g.postulacion_id = p.id
            LEFT JOIN eventos e ON p.evento_id = e.id
            WHERE p.usuario_id = ?
            ORDER BY f.id DESC
            LIMIT $limit OFFSET $offset
        ");
        $stmtF->execute([$user['id']]);
        $fotos = $stmtF->fetchAll(PDO::FETCH_ASSOC);

        // Procesar urls para baja resolución si aplica (watermark o miniatura si tienes lógica)
        foreach ($fotos as &$foto) {
            // Si manejas versiones de baja res puedes mutar la URL aquí. Por ahora enviamos la disponible.
            $foto['url_baja'] = $foto['url']; 
        }

        exit(json_encode([
            'success' => true, 
            'fotos' => $fotos, 
            'pagina_actual' => $page,
            'total_paginas' => $totalPaginas,
            'total_fotos' => $totalFotos
        ]));

    } catch (Exception $e) {
        exit(json_encode(['success' => false, 'error' => $e->getMessage()]));
    }
}
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>📸 Mis Fotos</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
</head>
<body class="bg-[#050505] text-white min-h-screen">
    <?php require 'navfotografo.php'; ?>
    
    <div class="max-w-6xl mx-auto px-4 py-10">
        <div class="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
            <div>
                <h1 class="text-2xl font-black italic uppercase tracking-tighter text-orange-500">📸 Panel de Fotos</h1>
                <p class="text-xs text-gray-400" id="contador-total">Cargando estadísticas...</p>
            </div>
            
            <div class="flex items-center gap-2">
                <button id="btn-prev" onclick="cambiarPagina(-1)" class="bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-bold disabled:opacity-30" disabled>« Ant</button>
                <span id="info-pagina" class="text-xs font-mono bg-black/40 px-3 py-1.5 rounded-xl border border-white/5">Pág: 1 / 1</span>
                <button id="btn-next" onclick="cambiarPagina(1)" class="bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-bold disabled:opacity-30" disabled>Sig »</button>
            </div>
        </div>

        <div id="loader" class="text-center my-20 text-orange-500 font-black animate-pulse text-sm uppercase tracking-widest">
            Buscando carrete en el servidor...
        </div>

        <div id="contenedor-fotos" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4"></div>
        
        <div id="alerta-vacio" class="hidden text-center my-20 text-gray-500 text-sm">
            No se encontraron fotos subidas en tus postulaciones actuales.
        </div>
    </div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const app = initializeApp({
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
});

let paginaActual = 1;
let totalPaginas = 1;
let currentUid = localStorage.getItem('usuario_uid');

// Hacemos las funciones globales para que los botones onclick de HTML funcionen nativamente
window.cambiarPagina = async function(direccion) {
    const nuevaPagina = paginaActual + direccion;
    if (nuevaPagina >= 1 && nuevaPagina <= totalPaginas) {
        paginaActual = nuevaPagina;
        await solicitarFotos(currentUid);
    }
}

// ANTIBLOQUEO / ANTICIERRE DE SESIÓN INCORRECTO:
// Si hay sesión guardada localmente, asumimos que es válida y cargamos de inmediato. 
if(currentUid) {
    solicitarFotos(currentUid);
}

onAuthStateChanged(getAuth(app), (u) => {
    if(u) {
        localStorage.setItem('usuario_uid', u.uid);
        if (currentUid !== u.uid) { 
            currentUid = u.uid;
            solicitarFotos(u.uid);
        }
    } else {
        // BLINDAJE: Si Firebase tarda o parpadea, NO sacamos al usuario si el localStorage sigue vivo.
        if(!localStorage.getItem('usuario_uid')) {
            window.location.href = "login_app.html";
        }
    }
});

async function solicitarFotos(uid) {
    document.getElementById('loader').classList.remove('hidden');
    
    try {
        const fd = new FormData();
        fd.append('firebase_uid', uid);
        fd.append('page', paginaActual);

        const res = await fetch(window.location.href, { method: 'POST', body: fd });
        const data = await res.json();
        
        document.getElementById('loader').classList.add('hidden');
        
        if(!data.success) {
            console.error("Error devuelto por la API:", data.error);
            return;
        }

        totalPaginas = data.total_paginas;
        paginaActual = data.pagina_actual;

        // Actualizar marcadores de interfaz
        document.getElementById('contador-total').innerText = `Mostrando ${data.fotos.length} fotos de ${data.total_fotos} en total`;
        document.getElementById('info-pagina').innerText = `Pág: ${paginaActual} / ${totalPaginas || 1}`;
        
        // Habilitar/Deshabilitar botones de paginación
        document.getElementById('btn-prev').disabled = (paginaActual <= 1);
        document.getElementById('btn-next').disabled = (paginaActual >= totalPaginas);

        const cont = document.getElementById('contenedor-fotos');
        cont.innerHTML = '';

        if(data.fotos.length === 0) {
            document.getElementById('alerta-vacio').classList.remove('hidden');
            return;
        } else {
            document.getElementById('alerta-vacio').classList.add('hidden');
        }

        // Renderizar las fotos en baja resolución para visualización óptima
        data.fotos.forEach(f => {
            const card = document.createElement('div');
            card.className = 'bg-white/5 border border-white/5 rounded-2xl overflow-hidden flex flex-col group';
            
            card.innerHTML = `
                <div class="relative aspect-square w-full bg-black flex items-center justify-center overflow-hidden">
                    <img src="${f.url_baja}" alt="Foto #${f.id}" loading="lazy" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105">
                    <span class="absolute bottom-2 left-2 bg-black/60 text-[9px] px-2 py-0.5 rounded-md font-mono tracking-tighter">ID: ${f.id}</span>
                </div>
                <div class="p-3 flex-1 flex flex-col justify-between gap-1 bg-black/20">
                    <div class="min-w-0">
                        <p class="text-[9px] text-orange-500 font-bold truncate uppercase tracking-tight">${f.evento_titulo || 'Evento Desconocido'}</p>
                        <p class="text-[10px] text-gray-300 truncate font-medium">${f.galeria_titulo || 'Galería sin nombre'}</p>
                    </div>
                    <div class="pt-2 border-t border-white/5 flex gap-1">
                        <a href="foto_detalle.php?id=${f.id}" class="w-full text-center bg-white/10 hover:bg-orange-500 hover:text-black transition-colors text-[9px] font-black uppercase tracking-wider py-1 rounded-lg">Detalles</a>
                    </div>
                </div>
            `;
            cont.appendChild(card);
        });

    } catch (e) {
        document.getElementById('loader').classList.add('hidden');
        console.error("Fallo crítico al renderizar las imágenes:", e);
    }
}
</script>
</body>
</html>