const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const PAYPAL_BASE = "https://api-m.sandbox.paypal.com"; 
// 🔴 usa sandbox para pruebas (NO live)

async function getAccessToken() {
    const response = await axios.post(
        `${PAYPAL_BASE}/v1/oauth2/token`,
        "grant_type=client_credentials",
        {
            auth: {
                username: process.env.PAYPAL_CLIENT_ID,
                password: process.env.PAYPAL_CLIENT_SECRET
            },
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            }
        }
    );

    return response.data.access_token;
}

// 👉 Crear orden
app.post("/api/orders", async (req, res) => {
    try {
        const token = await getAccessToken();

        const response = await axios.post(
            `${PAYPAL_BASE}/v2/checkout/orders`,
            {
                intent: "CAPTURE",
                purchase_units: [
                    {
                        amount: {
                            currency_code: "USD",
                            value: "1.00"
                        }
                    }
                ]
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        res.json({ id: response.data.id });
    } catch (error) {
        console.log(error.response?.data || error.message);
        res.status(500).json({ error: "Error creando orden" });
    }
});

// 👉 Capturar pago
app.post("/api/orders/:id/capture", async (req, res) => {
    try {
        const token = await getAccessToken();

        const response = await axios.post(
            `${PAYPAL_BASE}/v2/checkout/orders/${req.params.id}/capture`,
            {},
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        res.json(response.data);
    } catch (error) {
        console.log(error.response?.data || error.message);
        res.status(500).json({ error: "Error capturando pago" });
    }
});

app.listen(3000, () => {
    console.log("Servidor corriendo en http://localhost:3000");
});