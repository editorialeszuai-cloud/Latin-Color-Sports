<?php
header('Content-Type: application/json');
require 'dbfotografos.php';

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
$firebase_uid = $data['firebase_uid'] ?? null;

if (!$firebase_uid) {
    echo json_encode(['status' => 'error', 'message' => 'firebase_uid no recibido']);
    exit;
}

try {
    $pdo = conectar();

    // Utilizamos LEFT JOIN en toda la cadena para nunca perder la comisión
    // y filtramos directamente por el firebase_uid del usuario al final.
    $stmt = $pdo->prepare("
        SELECT 
            cu.id AS comision_id,
            cu.organizador AS monto,
            cu.compra_id,
            f.url AS foto_url,
            rc.retirada
        FROM comisiones_usuario cu
        INNER JOIN compras c ON cu.compra_id = c.id
        LEFT JOIN fotos f ON cu.foto_id = f.id
        LEFT JOIN galerias gal ON f.galeria_id = gal.id
        LEFT JOIN postulaciones post ON gal.postulacion_id = post.id
        LEFT JOIN eventos e ON post.evento_id = e.id
        LEFT JOIN usuarios u ON e.organizador_id = u.id
        LEFT JOIN retiros_comisiones rc ON rc.comision_id = cu.id
        WHERE c.estado = 'APPROVED'
          AND (u.firebase_uid = ? OR cu.organizador_id = (SELECT id FROM usuarios WHERE firebase_uid = ?))
        GROUP BY cu.id
    ");

    $stmt->execute([$firebase_uid, $firebase_uid]);
    $comisiones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($comisiones)) {
        echo json_encode(['status' => 'error', 'message' => 'No tienes comisiones registradas aún.']);
        exit;
    }

    $res = array_map(function($c) {
        return [
            'comision_id'   => $c['comision_id'],
            'monto'         => $c['monto'],
            'compra_id'     => $c['compra_id'],
            'foto_url'      => $c['foto_url'] ?? null, // Si es null, el front lo maneja
            'estado_retiro' => ($c['retirada'] === null) ? 'Pendiente de retirar'
                             : ($c['retirada'] == 1      ? 'En proceso'
                                                         : 'Pagado')
        ];
    }, $comisiones);

    echo json_encode(['status' => 'success', 'comisiones' => $res]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}