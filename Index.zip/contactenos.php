<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contáctenos - LatinColorSports</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
  font-family: 'Montserrat', sans-serif;
  margin: 0;
  padding: 0;
  background-color: #fff;
  color: #222;
}

header {
  background: linear-gradient(90deg, #f9b233, #ed1c24);
  color: #fff;
  padding: 15px 40px;
  font-weight: 700;
  font-size: 1.4rem;
}

.container {
  display: flex;
  justify-content: space-around;
  align-items: flex-start;
  flex-wrap: wrap;
  padding: 40px 20px;
  gap: 30px;
}

.soluciones, .contacto {
  flex: 1 1 250px;
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 20px;
}

.soluciones h3, .contacto h3 {
  color: #ed1c24;
  font-weight: 700;
}

.soluciones ul, .contacto ul {
  list-style: none;
  padding: 0;
}

.soluciones li {
  padding: 6px 0;
  font-weight: 500;
}

form {
  flex: 2 1 400px;
  display: flex;
  flex-direction: column;
  gap: 15px;
}

/* INPUTS Y SELECT */
input, select, textarea {
  border: 2px solid #f7941d;
  border-radius: 4px;
  padding: 10px;
  font-size: 1rem;
  font-family: 'Montserrat', sans-serif;
  width: 100%;
  box-sizing: border-box;
}

/* SELECT estilo */
select {
  background-color: #fff;
  cursor: pointer;
}

/* TEXTAREA */
textarea {
  resize: none;
  height: 120px;
}

/* BOTÓN */
button {
  background-color: #f7941d;
  border: none;
  color: white;
  padding: 12px 20px;
  font-weight: 600;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  transition: 0.3s;
}

button:hover {
  background-color: #ed1c24;
}

/* CONTACTO */
.contacto p, .contacto a {
  font-size: 0.95rem;
  line-height: 1.6;
}

.contacto a {
  color: #ed1c24;
  text-decoration: none;
}

.contacto i {
  margin-right: 8px;
  color: #f7941d;
}

/* FOOTER */
footer {
  background-color: #f7941d;
  color: #fff;
  text-align: center;
  padding: 20px 10px;
  font-size: 0.9rem;
  font-weight: 500;
  position: relative;
}

.footer-menu {
  background: #222;
  color: #fff;
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 20px;
  padding: 15px;
}

.footer-menu a {
  color: #fff;
  text-decoration: none;
  font-weight: 600;
}

/* RESPONSIVE */
@media(max-width:768px){
  .container {
    flex-direction: column;
    align-items: center;
  }

  form {
    width: 100%;
  }
}
</style>
</head>
<body>
<header>CONTÁCTENOS</header>
<section class="container">
  <div class="soluciones">
    <h3><i class="fa-solid fa-circle-dot"></i> Soluciones</h3>
    <ul>
      <a href="https://latincolorgroup.com/latincolor-images/" target="_blank" style="color:black;"><li>Latincolor Image</li></a>
     <a href="https://latincolorgroup.com/latincolor-desing/" target="_blank" style="color:black;"> <li>Latincolor Design</li></a>
     <a href="https://latincolorgroup.com/latincolor-studio/" target="_blank" style="color:black;"> <li>Latincolor Studio</li></a>
    <a href="https://latincolorgroup.com/latincolor-e-commerce/" target="_blank" style="color:black;"><li>Latincolor E-Commerce</li></a></a>
      <a href="https://latincolorcollege.com" target="_blank" style="color:black;"> <li>Latincolor College</li></a>
     <a href="https://latincolorgroup.com/latincolor-tech/" target="_blank" style="color:black;"><li>Latincolor Tech</li></a>
    </ul>
  </div>

  <form>
    <input type="text" placeholder="Nombre" required>
    <input type="email" placeholder="Email" required>
<input type="tel" name="celular" placeholder="Celular" required>
    <input type="text" placeholder="Asunto" required>
<select name="pais" required>
  <option value="">Selecciona tu país</option>
  <option value="colombia">Colombia</option>
  <option value="mexico">México</option>
  <option value="peru">Perú</option>
  <option value="argentina">Argentina</option>
  <option value="chile">Chile</option>
  <option value="ecuador">Ecuador</option>
  <option value="espana">España</option>
  <option value="otro">Otro</option>
</select>
<select name="ciudad" required>
  <option value="">Selecciona tu ciudad</option>
  <option value="bogota">Bogotá</option>
  <option value="medellin">Medellín</option>
  <option value="cali">Cali</option>
  <option value="barranquilla">Barranquilla</option>
  <option value="cartagena">Cartagena</option>
  <option value="otra">Otra ciudad</option>
</select>
    <textarea placeholder="Mensaje" required></textarea>
    <button type="submit">Enviar</button>
  </form>

  <div class="contacto">
    <h3><i class="fa-solid fa-circle-dot"></i> Contacto</h3>
    <a href="https://wa.me/573142958463" target="_blank" rel="noopener noreferrer">
  <p>
    <i class="fa-solid fa-phone"></i> LLAMA<br>
    (+57) 3142958463
  </p>
</a>
    <p><i class="fa-solid fa-location-dot"></i> ESTAMOS EN<br>Calle 32 bis a Nº 13-32<br>Torre 3 Studio 317 Bogotá, Colombia.</p>
    <h4>SÍGUENOS</h4>
    <p>
     <a href="https://www.instagram.com/latincolorsports/" target="_blank">  <i class="fa-brands fa-instagram"></i>@latincolorsports</a><br>
     <a href="https://www.instagram.com/latincolorgroup" target="_blank">    <i class="fa-brands fa-instagram"></i>@latincolorgroup</a><br>
     <a href="https://www.instagram.com/latincolorcollege" target="_blank">   <i class="fa-brands fa-instagram"></i>@latincolorcollege</a><br>
     <a href"https://www.facebook.com/share/18Lrg2Csuh/?mibextid=wwXIfr" target="_blank"> <i class="fa-brands fa-facebook"></i>/latincolorsports</a></p>
  </div>
</section>
<footer>
<svg viewBox="0 0 1600 180" width="100%" xmlns="http://www.w3.org/2000/svg">

  <!-- FRANJA INFERIOR -->
  <rect x="0" y="70" width="1600" height="100" fill="#F2994A"/>

  <!-- BLOQUE IZQUIERDO NARANJA -->
  <rect x="0" y="0" width="340" height="70" fill="#E6B93C"/>
  <polygon points="0,0 50,35 0,70" fill="#F7D86A"/>

  <!-- TEXTO IZQUIERDO -->
  <text x="70" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#5E5E5E">
    Quién es Latin Color Sports
  </text>

  <!-- BLOQUE GRIS CENTRAL -->
  <rect x="340" y="0" width="620" height="70" fill="#A9A9A9"/>
  <polygon points="339,0 380,35 339,70" fill="#E6B93C"/>

  <!-- TEXTO MENÚ (BLANCO) -->
  <g font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF">

<a xlink:href="https://latincolorcollege.com" target="_blank">
  <text x="410" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF" >
    Escuela
  </text>
</a>

<a xlink:href="https://latincolorcollege.com/marca-personal/" target="_blank">
  <text x="550" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF">
    Marca Personal
  </text>
</a>

<a xlink:href="https://latincolorgroup.com/latincolor-studio/" target="_blank">
  <text x="770" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF">
    Studio Fotográfico
  </text>
</a>

  </g>

  <!-- BLOQUE MENSAJE AMARILLO -->
  <rect x="960" y="0" width="560" height="70" fill="#F2C94C"/>
  <polygon points="959,0 1000,35 959,70" fill="#A9A9A9"/>
  <text x="1010" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#5E5E5E">
    ¿Quieres participar en nuestros eventos?
  </text>

  <!-- BLOQUE ICONO AMARILLO CLARO -->
   <a href="contactenos.php"><rect x="1460" y="0" width="140" height="70" fill="#F7D86A"/>
  <rect x="1495" y="18" width="50" height="36" rx="6" fill="#F2994A"/>
  <path d="M1508 30h20v12h-10l-6 6v-6h-4z" fill="#FFFFFF"/></a>

  <!-- TEXTO INFERIOR -->
<g font-family="Arial, Helvetica, sans-serif" font-size="20" fill="#FFFFFF">
  <text x="40" y="110">Condiciones de uso del sitio web</text>
  <text x="420" y="110">
    No divulgar, ni transferir ni vender información personal / Contáctenos
  </text>
  <text x="420" y="130" font-size="16">
    Derechos Reservados Latin Color Group SAS, Bogotá, Colombia. 2025
  </text>
</g>


  <!-- BLOQUE GRIS PARA ICONOS DE REDES -->
  <rect x="1200" y="80" width="100" height="50" fill="#A9A9A9" rx="5"/>


<a xlink:href="https://www.facebook.com/latincolorsportscol?mibextid=wwXIfr&rdid=WyRug4sHgkPcvIFI&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2F18Lrg2Csuh%2F%3Fmibextid%3DwwXIfr#" target="_blank">
  <circle cx="1235" cy="105" r="15" fill="#F2994A"/>
  <text x="1235" y="111" font-family="Arial, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF" text-anchor="middle">f</text>
</a>

<!-- ICONO INSTAGRAM -->
<a xlink:href="https://www.instagram.com/latincolorsports/" target="_blank">
  <circle cx="1275" cy="105" r="15" fill="#F2994A"/>
  <text x="1275" y="111" font-family="Arial, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF" text-anchor="middle">i</text>
</a>



</svg>
</footer>
</body>
</html>