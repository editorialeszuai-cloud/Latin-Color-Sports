<?php
session_start();
require 'dbfotografos.php';
$pdo = conectar();

header('Content-Type: application/json');

// Recibir firebase_uid desde el frontend
$input = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $input['firebase_uid'] ?? '';
if (!$firebase_uid) {
    echo json_encode(['status'=>'error','message'=>'Usuario no autenticado']);
    exit;
}

// Obtener usuario_id desde firebase_uid
$stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ?");
$stmt->execute([$firebase_uid]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$usuario) {
    echo json_encode(['status'=>'error','message'=>'Usuario no encontrado']);
    exit;
}
$usuario_id = $usuario['id'];

// --- Paso 1: obtener todas las descargas de fotos de la compra ---
$stmt = $pdo->prepare("
    SELECT d.compra_id, d.foto_id, COUNT(*) AS veces, p.usuario_id AS dueño_foto
    FROM descargas d
    INNER JOIN fotos f ON d.foto_id = f.id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    INNER JOIN compras_paquetes c ON d.compra_id = c.id
    WHERE c.estado = 'Pagado'
    GROUP BY d.compra_id, d.foto_id, p.usuario_id
    ORDER BY d.compra_id ASC
");
$stmt->execute();
$descargas = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$descargas) {
    echo json_encode(['status'=>'error','message'=>'No hay descargas disponibles']);
    exit;
}

// --- Paso 2: agrupar descargas por compra y fotógrafo ---
$compras = [];
foreach ($descargas as $d) {
    $compra_id = $d['compra_id'];
    $dueño_id = $d['dueño_foto'];
    $foto_id = $d['foto_id'];
    $veces = $d['veces'];

    if (!isset($compras[$compra_id])) {
        $compras[$compra_id] = ['total_descargas'=>0, 'fotografos'=>[]];
    }
    $compras[$compra_id]['total_descargas'] += $veces;

    if (!isset($compras[$compra_id]['fotografos'][$dueño_id])) {
        $compras[$compra_id]['fotografos'][$dueño_id] = ['total_fotografo'=>0, 'fotos'=>[]];
    }
    $compras[$compra_id]['fotografos'][$dueño_id]['total_fotografo'] += $veces;
    $compras[$compra_id]['fotografos'][$dueño_id]['fotos'][$foto_id] = $veces;
}

// --- Paso 3: obtener comisiones totales de cada compra ---
$compra_ids = array_keys($compras);
if (count($compra_ids) > 0) {
    $stmt = $pdo->prepare("
        SELECT id AS compra_id, cp.fotografo AS comision_total, cp.id AS comision_id
        FROM comisiones_paquetes cp
        WHERE cp.compra_id IN (" . implode(',', $compra_ids) . ")
    ");
    $stmt->execute();
    $comisiones = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $comisiones = [];
}

if (!$comisiones) {
    echo json_encode(['status'=>'error','message'=>'No hay comisiones para estas compras']);
    exit;
}

// --- Paso 4: calcular comisión proporcional por foto solo para el dueño ---
$resultado = [];
foreach ($comisiones as $c) {
    $compra_id = $c['compra_id'];
    $comision_total = $c['comision_total'];
    $total_descargas_compra = $compras[$compra_id]['total_descargas'];

    if (!isset($compras[$compra_id]['fotografos'][$usuario_id])) continue;

    $data_foto = $compras[$compra_id]['fotografos'][$usuario_id];

    foreach ($data_foto['fotos'] as $foto_id => $veces) {
        $comision = ($comision_total / $total_descargas_compra) * $veces;

        $resultado[] = [
            'comision_id' => $c['comision_id'],
            'compra_id' => $compra_id,
            'foto_id' => $foto_id,
            'dueño_foto_id' => $usuario_id,
            'veces_descargada' => $veces,
            'comision' => $comision
        ];
    }
}

echo json_encode(['status'=>'success','detalle_comisiones'=>$resultado]);
?>
