<?php
// 1. Forzar visualización de errores técnicos
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Content-Type: application/json");

$diagnostico = [
    "paso_1_php_version" => PHP_VERSION,
    "paso_2_db_conexion" => "Pendiente",
    "paso_3_vendor_existe" => "Pendiente",
    "paso_4_firebase_libreria" => "Pendiente",
    "errores" => []
];

// --- PASO 2: Probar Base de Datos ---
try {
    require_once "db.php";
    if (isset($pdo) && $pdo instanceof PDO) {
        $diagnostico["paso_2_db_conexion"] = "✅ OK (PDO detectado)";
        
        // Probar una consulta simple
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
        $res = $stmt->fetch();
        $diagnostico["db_tabla_usuarios"] = "✅ Existe (Total: " . $res['total'] . ")";
    } else {
        throw new Exception("La variable \$pdo no está definida o no es PDO.");
    }
} catch (Throwable $e) {
    $diagnostico["paso_2_db_conexion"] = "❌ FALLÓ";
    $diagnostico["errores"][] = "DB: " . $e->getMessage();
}

// --- PASO 3: Probar Carpeta Vendor ---
$path_vendor = __DIR__ . '/vendor/autoload.php';
if (file_exists($path_vendor)) {
    $diagnostico["paso_3_vendor_existe"] = "✅ OK";
    require_once $path_vendor;
} else {
    $diagnostico["paso_3_vendor_existe"] = "❌ FALLÓ (No existe el archivo en $path_vendor)";
}

// --- PASO 4: Probar Firebase SDK ---
if ($diagnostico["paso_3_vendor_existe"] === "✅ OK") {
    try {
        if (class_exists('Firebase\Auth\Token\Verifier')) {
            $diagnostico["paso_4_firebase_libreria"] = "✅ OK (Clase Verifier cargada)";
            
            // Probar instanciación (sin verificar token aún)
            $verifier = new \Firebase\Auth\Token\Verifier('latin-group-406b1');
            $diagnostico["paso_4_instancia"] = "✅ OK";
        } else {
            throw new Exception("La clase Verifier no existe. Carpeta vendor incompleta.");
        }
    } catch (Throwable $e) {
        $diagnostico["paso_4_firebase_libreria"] = "❌ FALLÓ";
        $diagnostico["errores"][] = "Firebase: " . $e->getMessage();
    }
}

echo json_encode($diagnostico, JSON_PRETTY_PRINT);