<?php
$urlOriginal = $_GET['img'] ?? '';
$width = isset($_GET['w']) ? intval($_GET['w']) : 800;

if (empty($urlOriginal)) {
    http_response_code(400);
    exit;
}

$urlFinal = urldecode($urlOriginal);

$urlCloudFront = str_replace(
    "fotos-latincolor-2026.s3-accelerate.amazonaws.com",
    "d3fnhkeilwwjkl.cloudfront.net",
    $urlFinal
);

// Headers CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

// Descargar la imagen desde CloudFront y servirla directamente
$contexto = stream_context_create([
    'http' => [
        'method' => 'GET',
        'timeout' => 10,
        'header' => 'User-Agent: Mozilla/5.0'
    ]
]);

$imagen = @file_get_contents($urlCloudFront, false, $contexto);

if ($imagen === false) {
    http_response_code(404);
    exit;
}

// Detectar tipo de imagen
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->buffer($imagen);

header("Content-Type: " . $mime);
header("Cache-Control: public, max-age=86400");
echo $imagen;
exit;
?>