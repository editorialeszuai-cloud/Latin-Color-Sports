<?php
session_start();
$data = json_decode(file_get_contents('php://input'), true);
if (isset($data['uid'])) {
    $_SESSION['firebase_uid'] = $data['uid'];
    echo json_encode(['status'=>'ok']);
} else {
    echo json_encode(['status'=>'error']);
}
?>
