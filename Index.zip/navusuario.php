<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latin Color Sports | Eventos Deportivos</title>
    <script src="https://cdn.tailwindcss.com"></script>
		<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body { font-family: 'Roboto', sans-serif; background-color: #020617; margin: 0; }

        /* --- HEADER BASE --- */
        .header-lcs {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f8a700 40%, #f56c1e 60%, #e4312a 100%);
            border-bottom: 8px solid white;
            height: 70px;
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        /* --- NAVEGACI�N PC (Desktop Only) --- */
        .nav-desktop { display: none; } 

        @media (min-width: 1024px) {
            .header-lcs { height: 100px; padding: 0 40px; border-top: 18px solid white; border-bottom: 18px solid white; }
            
            /* Contenedor que empuja el men� a la derecha */
            .logo-container { flex-grow: 1; display: flex; align-items: center; }
            
            .nav-desktop { 
                display: flex; 
                align-items: center; 
                gap: 35px; 
                margin-right: 40px; /* Espacio antes de los idiomas */
            }
            
            .nav-desktop a, .nav-desktop button {
                color: white; font-weight: 900; text-transform: uppercase; font-size: 14px;
                text-decoration: none; transition: 0.3s; cursor: pointer; background: none; border: none;
                white-space: nowrap;
            }
            .nav-desktop a:hover, .nav-desktop button:hover { color: #ffe29a; }
            .btn-mobile-toggle { display: none !important; }
        }

        /* --- SIDEBAR M�VIL --- */
        #sidebarMobile {
            position: fixed; top: 0; left: 0; height: 100%; width: 300px;
            background: #0f172a; z-index: 2000; transform: translateX(-100%);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 20px 0 50px rgba(0,0,0,0.8); border-right: 1px solid rgba(255,255,255,0.1);
        }
        #sidebarMobile.open { transform: translateX(0); }
        .overlay { position: fixed; inset: 0; background: rgba(2, 6, 23, 0.8); backdrop-filter: blur(4px); z-index: 1900; display: none; }
        .overlay.visible { display: block; }

        /* Submen�s PC */
        .relative { position: relative; }
        .relative:hover .submenu { display: block; animation: fadeIn 0.2s ease; }
        .submenu {
            display: none; position: absolute; top: 100%; right: 0; /* Alineado a la derecha del bot�n */
            background: white; min-width: 180px; border-radius: 8px;
            box-shadow: 0 10px 15px rgba(0,0,0,0.2); border-top: 4px solid #f46616; padding: 10px 0;
        }
        .submenu a { color: #333 !important; padding: 10px 20px; font-size: 12px; display: block; text-align: left; }
        
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

<div id="overlay" class="overlay" onclick="toggleNav()"></div>

<aside id="sidebarMobile">
    <div class="p-6 flex justify-between items-center border-b border-white/10 bg-slate-900">
        <img src="../uploads/LATIN-SPORTS.png" class="h-10">
        <button onclick="toggleNav()" class="text-white text-3xl">&times;</button>
    </div>
    <nav class="p-6 flex flex-col gap-2">
        <p class="text-[10px] font-black text-slate-500 tracking-[3px] mb-2 uppercase">Men� Principal</p>
        <a href="nav_usuarios.php" class="flex items-center gap-4 text-white font-bold p-3 rounded-xl hover:bg-white/5 transition">
            <i class="fas fa-home text-orange-500 w-5"></i> HOME
        </a>
        <a href="conjuntodeventos.php" class="flex items-center gap-4 text-white font-bold p-3 rounded-xl hover:bg-white/5 transition">
            <i class="fas fa-calendar-alt text-orange-500 w-5"></i> EVENTOS
        </a>
        <div class="my-4 border-t border-white/5"></div>
        <p class="text-[10px] font-black text-orange-500 tracking-[3px] mb-2 uppercase">Mi Cuenta</p>
        <a href="migaleria.php" class="flex items-center gap-4 text-white font-bold p-3 rounded-xl hover:bg-white/5 transition">
            <i class="fas fa-images text-orange-400 w-5"></i> MIS COLECCIONES
        </a>
    </nav>
</aside>

<header class="header-lcs">
    <button onclick="toggleNav()" class="btn-mobile-toggle p-2 bg-slate-900 rounded-xl text-white shadow-lg active:scale-95 transition">
        <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
    </button>

    <div class="logo-container">
        <a href="index.php" class="flex items-center">
            <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;">
            <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="width:85px;">
        </a>
    </div>

    <nav class="nav-desktop">
        <a href="nav_usuarios.php">Home</a>
        <div class="relative group">
            <button class="flex items-center gap-1 uppercase">Eventos <i class="fas fa-chevron-down text-[10px]"></i></button>
            <div class="submenu">
                <a href="conjuntodeventos.php">VER TODOS</a>
                <a href="conjuntodeventos.php?search=&tipo_evento=Deportivo">DEPORTIVO</a>
            </div>
        </div>
        <div class="relative group">
            <button class="flex items-center gap-1 uppercase">Mi Cuenta <i class="fas fa-chevron-down text-[10px]"></i></button>
            <div class="submenu">
                <a href="migaleria.php">MIS COLECCIONES</a>
                <a href="miscomprasfotos.php">MIS FOTOS</a>
            </div>
        </div>
    </nav>

    <div class="flex items-center gap-2">
        <div class="flex -space-x-1">
            <img src="imagenes/idioma-01.webp" class="w-6 lg:w-8 h-6 lg:h-8 rounded-full border-2 border-white shadow-sm" alt="EN">
            <img src="imagenes/idioma-02.webp" class="w-6 lg:w-8 h-6 lg:h-8 rounded-full border-2 border-white shadow-sm" alt="ES">
        </div>
    </div>
</header>


<script>
    function toggleNav() {
        const sidebar = document.getElementById('sidebarMobile');
        const overlay = document.getElementById('overlay');
        sidebar.classList.toggle('open');
        overlay.classList.toggle('visible');
        document.body.style.overflow = sidebar.classList.contains('open') ? 'hidden' : 'auto';
    }
</script>

</body>
</html>