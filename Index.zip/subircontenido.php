<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

require 'vendor/autoload.php';
require 'dbfotografos.php';

use Aws\S3\S3Client;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

define('MAX_FILE_SIZE', 20 * 1024 * 1024);
define('MAX_FOTOS', 200);

session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$s3 = new S3Client([
    'version'     => 'latest',
    'region'      => $_ENV['AWS_REGION'] ?? 'us-east-1',
    'use_accelerate_endpoint' => true,
    'credentials' => ['key' => $_ENV['AWS_KEY'], 'secret' => $_ENV['AWS_SECRET']],
]);
$bucket = $_ENV['AWS_BUCKET'];

function jsonOut(array $data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        jsonOut(['success' => false, 'error' => 'Token inválido.'], 403);
    }

    $postulacion_id = filter_input(INPUT_POST, 'postulacion_id', FILTER_VALIDATE_INT);

    if ($_POST['action'] === 'crear_galeria') {
        $titulo = trim($_POST['titulo'] ?? '');
        if (!$titulo) jsonOut(['success' => false, 'error' => 'Título vacío.'], 400);
        if (!$postulacion_id) jsonOut(['success' => false, 'error' => 'postulacion_id inválido.'], 400);
        $stmt = $pdo->prepare("INSERT INTO galerias (postulacion_id, titulo) VALUES (?, ?)");
        $stmt->execute([$postulacion_id, $titulo]);
        jsonOut(['success' => true, 'galeria_id' => (int)$pdo->lastInsertId()]);
    }

    if ($_POST['action'] === 'batch_presign') {
        $galeria_id = filter_input(INPUT_POST, 'galeria_id', FILTER_VALIDATE_INT);
        if (!$galeria_id || !$postulacion_id) jsonOut(['success' => false, 'error' => 'IDs inválidos.'], 400);
        $files = json_decode($_POST['files'] ?? '[]', true);
        if (!is_array($files) || count($files) === 0) jsonOut(['success' => false, 'error' => 'Sin archivos.'], 400);
        if (count($files) > 200) jsonOut(['success' => false, 'error' => 'Máximo 200.'], 400);
        $urls = [];
        $prefix = date('Ymd');
        foreach ($files as $f) {
            $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $f['name'] ?? 'foto.jpg');
            $mime     = in_array($f['type'] ?? '', ['image/jpeg','image/png','image/webp','image/gif']) ? $f['type'] : 'image/jpeg';
            $key      = "fotos/{$postulacion_id}/{$galeria_id}/{$prefix}_" . bin2hex(random_bytes(8)) . '_' . $filename;
            $cmd      = $s3->getCommand('PutObject', ['Bucket' => $bucket, 'Key' => $key, 'ContentType' => $mime, 'ACL' => 'public-read']);
            $request  = $s3->createPresignedRequest($cmd, '+30 minutes');
            $urls[]   = ['upload_url' => (string)$request->getUri(), 's3_key' => $key, 'public_url' => "https://{$bucket}.s3-accelerate.amazonaws.com/{$key}"];
        }
        jsonOut(['success' => true, 'urls' => $urls]);
    }

    if ($_POST['action'] === 'get_upload_url') {
        $filename   = preg_replace('/[^a-zA-Z0-9._-]/', '', $_POST['filename'] ?? 'foto.jpg');
        $galeria_id = filter_input(INPUT_POST, 'galeria_id', FILTER_VALIDATE_INT);
        if (!$galeria_id || !$postulacion_id) jsonOut(['success' => false, 'error' => 'IDs inválidos.'], 400);
        $key = "fotos/{$postulacion_id}/{$galeria_id}/" . date('Ymd') . '_' . bin2hex(random_bytes(8)) . '_' . $filename;
        $cmd = $s3->getCommand('PutObject', ['Bucket' => $bucket, 'Key' => $key, 'ContentType' => $_POST['mime_type'] ?? 'image/jpeg', 'ACL' => 'public-read']);
        $request = $s3->createPresignedRequest($cmd, '+20 minutes');
        jsonOut(['success' => true, 'upload_url' => (string)$request->getUri(), 's3_key' => $key, 'public_url' => "https://{$bucket}.s3-accelerate.amazonaws.com/{$key}"]);
    }

    if ($_POST['action'] === 'confirmar_subida') {
        try {
            $galeria_id     = filter_input(INPUT_POST, 'galeria_id',     FILTER_VALIDATE_INT);
            $postulacion_id = filter_input(INPUT_POST, 'postulacion_id', FILTER_VALIDATE_INT);
            $s3_key         = $_POST['s3_key'] ?? '';
            $tamanio        = (int)($_POST['tamanio'] ?? 0);
            if (!$galeria_id || !$postulacion_id || !$s3_key) jsonOut(['success' => false, 'error' => 'Parámetros incompletos.'], 400);
            $urlS3 = "https://{$bucket}.s3-accelerate.amazonaws.com/{$s3_key}";
            $stmt  = $pdo->prepare("INSERT INTO fotos (galeria_id, postulacion_id, url, tamano_kb, fecha_creacion) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$galeria_id, $postulacion_id, $urlS3, $tamanio]);
            jsonOut(['success' => true, 'url' => $urlS3]);
        } catch (Exception $e) {
            jsonOut(['success' => false, 'error' => $e->getMessage()], 500);
        }
    }
}

$post_id = filter_input(INPUT_GET, 'postulacion_id', FILTER_VALIDATE_INT) ?: 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Contenido — Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
	    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800&family=Barlow:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root { --naranja: #f97316; --naranja-dark: #c2410c; --slate: #0f172a; --success: #16a34a; --danger: #dc2626; }
        body { font-family: 'Barlow', sans-serif; background: #f8fafc; }
        h1,h2,.condensed { font-family: 'Barlow Condensed', sans-serif; }

        .btn-primary {
            background: var(--naranja); color: #fff; border: none;
            padding: .65rem 2rem; border-radius: .5rem;
            font-family: 'Barlow Condensed', sans-serif; font-weight: 800;
            font-size: .9rem; letter-spacing: .08em; text-transform: uppercase;
            cursor: pointer; transition: background .15s, transform .1s;
        }
        .btn-primary:hover:not(:disabled) { background: var(--naranja-dark); }
        .btn-primary:disabled { opacity: .4; cursor: not-allowed; }
        .btn-primary.ok { background: var(--success); }

        .btn-ghost {
            background: none; border: 2px solid #e2e8f0; color: #475569;
            padding: .5rem 1.4rem; border-radius: .5rem;
            font-family: 'Barlow Condensed', sans-serif; font-weight: 700;
            font-size: .85rem; letter-spacing: .07em; text-transform: uppercase;
            cursor: pointer; transition: border-color .15s, color .15s;
        }
        .btn-ghost:hover:not(:disabled) { border-color: var(--naranja); color: var(--naranja); }
        .btn-ghost.activo { background: var(--naranja); color: #fff; border-color: var(--naranja-dark); }
        .btn-ghost:disabled { opacity: .4; cursor: not-allowed; }

        #dropZone {
            border: 2px dashed #cbd5e1; border-radius: .75rem;
            padding: 3rem 1rem; text-align: center; cursor: pointer;
            transition: border-color .2s, background .2s;
        }
        #dropZone:hover, #dropZone.drag { border-color: var(--naranja); background: #fff7ed; }

        #barra {
            height: 10px; border-radius: 9999px; width: 0%;
            background: linear-gradient(90deg, var(--naranja-dark), var(--naranja), #fbbf24, var(--naranja));
            background-size: 300% 100%;
            animation: sh 2s infinite linear;
            transition: width .3s ease;
        }
        #barra.done { animation: none; background: var(--success); }
        #barra.err  { animation: none; background: var(--danger); }
        @keyframes sh { 0%{background-position:100% 0} 100%{background-position:-100% 0} }

        .card { background:#fff; border:1px solid #e2e8f0; border-radius:1rem; padding:1.75rem; margin-bottom:1.5rem; }

        #toast {
            position:fixed; bottom:1.5rem; right:1.5rem;
            padding:.7rem 1.3rem; border-radius:.5rem; color:#fff;
            font-family:'Barlow Condensed',sans-serif; font-weight:700; font-size:.9rem;
            transform:translateY(200%); transition:transform .3s cubic-bezier(.34,1.56,.64,1);
            z-index:1000; box-shadow:0 6px 20px rgba(0,0,0,.2);
        }
        #toast.show { transform:translateY(0); }
        #toast.e { background:var(--danger); }
        #toast.s { background:var(--success); }
        #toast.i { background:#1e293b; }
    </style>
</head>
<?php require 'navfotografo.php'; ?>
<body>

<div id="toast"></div>

<div class="max-w-2xl mx-auto px-4 py-8">

    <!-- PASO 1: Tipo -->
    <div class="card" id="paso1">
        <p class="condensed text-xs font-bold tracking-widest text-slate-400 uppercase mb-1">Paso 1 — Tipo de galería</p>
        <h1 class="text-2xl font-bold text-slate-900 mb-4">¿Qué tipo de galería es?</h1>
        <div class="flex flex-wrap gap-3" role="group">
            <?php foreach(['Color','Sociales'] as $t): ?>
                <button type="button" class="btn-ghost galeria-btn"
                        onclick="selGaleria(this,'<?= $t ?>')"
                        aria-pressed="false"><?= $t ?></button>
            <?php endforeach; ?>
        </div>
        <div class="mt-5">
            <button id="crearBtn" class="btn-primary" disabled>Crear galería →</button>
        </div>
    </div>

    <!-- PASO 2: Subida -->
    <div class="card hidden" id="paso2">
        <p class="condensed text-xs font-bold tracking-widest text-slate-400 uppercase mb-1">Paso 2 — Subir fotos</p>
        <h2 class="text-2xl font-bold text-slate-900 mb-1">
            Galería: <span id="tituloGal" class="text-orange-500"></span>
        </h2>
        <p class="text-sm text-slate-400 mb-5">JPG · PNG · WEBP · máx. 20 MB · hasta <?= MAX_FOTOS ?> fotos · se suben al instante</p>

        <div id="dropZone" tabindex="0" role="button"
             onclick="fileInput.click()"
             onkeydown="if(event.key==='Enter'||event.key===' ')fileInput.click()">
            <svg class="mx-auto mb-2 w-9 h-9 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                      d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z"/>
            </svg>
            <p class="condensed font-bold text-slate-500 text-sm uppercase tracking-wide">Haz clic o arrastra fotos aquí</p>
        </div>
        <input type="file" id="fileInput" multiple accept="image/*" class="sr-only">

        <!-- Contadores -->
        <div id="contadores" class="hidden mt-5 grid grid-cols-3 gap-3 text-center">
            <div class="bg-slate-50 rounded-lg py-3">
                <div id="cTotal" class="condensed text-3xl font-bold text-slate-700">0</div>
                <div class="condensed text-xs font-bold uppercase tracking-wider text-slate-400 mt-0.5">Seleccionadas</div>
            </div>
            <div class="bg-green-50 rounded-lg py-3">
                <div id="cOk" class="condensed text-3xl font-bold text-green-600">0</div>
                <div class="condensed text-xs font-bold uppercase tracking-wider text-green-400 mt-0.5">Subidas OK</div>
            </div>
            <div class="bg-red-50 rounded-lg py-3">
                <div id="cErr" class="condensed text-3xl font-bold text-red-500">0</div>
                <div class="condensed text-xs font-bold uppercase tracking-wider text-red-300 mt-0.5">Errores</div>
            </div>
        </div>

        <!-- Barra de progreso -->
        <div id="bloqueProgreso" class="hidden mt-5">
            <div class="flex justify-between items-center mb-2">
                <span id="progrLabel" class="condensed text-sm font-bold uppercase tracking-wide text-orange-500">Preparando…</span>
                <span id="progrPct" class="condensed font-bold text-slate-600 text-sm">0 %</span>
            </div>
            <div class="bg-slate-100 rounded-full overflow-hidden">
                <div id="barra"></div>
            </div>
        </div>

        <!-- Acciones post-subida -->
        <div id="acciones" class="hidden mt-5 flex gap-3 flex-wrap items-center">
            <button id="reintentarBtn" class="btn-primary hidden">Reintentar errores</button>
            <p id="mensajeFinal" class="condensed text-sm font-bold text-green-600"></p>
        </div>
    </div>

</div>

<script>
(function(){
'use strict';

const CONCURRENCIA   = 6;
const MAX_REINTENTOS = 2;
const RETRASO_BASE   = 800;
const POST_ID        = <?= (int)$post_id ?>;
const MAX_FOTOS      = <?= MAX_FOTOS ?>;
const MAX_MB         = 20;
const CSRF           = '<?= htmlspecialchars($csrf, ENT_QUOTES) ?>';

let galeriaId   = null;
let tituloSel   = '';
let archivos    = [];    // todas las entradas
let colaNueva   = [];    // llegan mientras ya hay subida activa
let subiendo    = false;
let cntOk       = 0;
let cntErr      = 0;

const $ = id => document.getElementById(id);
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* Toast */
let toastT;
function toast(msg, t='i', ms=3200){
    const el=$('toast'); clearTimeout(toastT);
    el.className=`show ${t}`; el.textContent=msg;
    toastT=setTimeout(()=>el.classList.remove('show'),ms);
}

/* Selector galería */
window.selGaleria = function(btn, val){
    document.querySelectorAll('.galeria-btn').forEach(b=>{ b.classList.remove('activo'); b.setAttribute('aria-pressed','false'); });
    btn.classList.add('activo'); btn.setAttribute('aria-pressed','true');
    tituloSel = val;
    $('crearBtn').disabled = false;
};

$('crearBtn').onclick = async () => {
    if(!tituloSel) return;
    const btn = $('crearBtn');
    btn.disabled = true; btn.textContent = 'Creando…';
    try {
        const fd = new FormData();
        fd.append('action','crear_galeria'); fd.append('titulo',tituloSel);
        fd.append('postulacion_id',POST_ID); fd.append('csrf_token',CSRF);
        const r = await fetch('',{method:'POST',body:fd});
        if(!r.ok) throw new Error(`HTTP ${r.status}`);
        const d = await r.json();
        if(!d.success) throw new Error(d.error||'Error');
        galeriaId = d.galeria_id;
        $('tituloGal').textContent = tituloSel;
        $('paso2').classList.remove('hidden');
        $('paso2').scrollIntoView({behavior:'smooth',block:'start'});
        document.querySelectorAll('.galeria-btn').forEach(b=>b.disabled=true);
        btn.textContent = '✓ Galería creada'; btn.classList.add('ok');
        toast(`Galería "${tituloSel}" creada`,'s');
    } catch(e){
        btn.disabled=false; btn.textContent='Crear galería →';
        toast('Error: '+e.message,'e',5000);
    }
};

/* Drop zone */
const dz = $('dropZone');
dz.addEventListener('dragover',  e=>{e.preventDefault();dz.classList.add('drag');});
dz.addEventListener('dragleave', ()=>dz.classList.remove('drag'));
dz.addEventListener('drop', e=>{e.preventDefault();dz.classList.remove('drag');procesar(e.dataTransfer.files);});
$('fileInput').addEventListener('change', e=>{procesar(e.target.files); e.target.value='';});

/* Procesar */
function procesar(lista){
    if(!galeriaId) return;
    const nuevos  = Array.from(lista).filter(f=>f.type.startsWith('image/'));
    if(!nuevos.length){ toast('No se detectaron imágenes','e'); return; }

    const existSet = new Set(archivos.map(a=>a.file.name+'_'+a.file.size));
    const unicos   = nuevos.filter(f=>!existSet.has(f.name+'_'+f.size));

    const grandes = unicos.filter(f=>f.size > MAX_MB*1024*1024);
    if(grandes.length) toast(`${grandes.length} foto(s) superan ${MAX_MB} MB, omitidas`,'e',4000);

    const validos  = unicos.filter(f=>f.size<=MAX_MB*1024*1024);
    if(!validos.length) return;

    const espacio  = MAX_FOTOS - archivos.length;
    const lote     = validos.slice(0, espacio);
    if(validos.length > espacio) toast(`Límite ${MAX_FOTOS} fotos. Se omitieron ${validos.length-espacio}.`,'i',4000);
    if(!lote.length) return;

    const entradas = lote.map(f=>{
        const id = archivos.length;
        const e  = {file:f, id, status:'pending', intentos:0};
        archivos.push(e);
        return e;
    });

    actualizarContadores();
    $('contadores').classList.remove('hidden');

    if(subiendo){
        colaNueva.push(...entradas);
        toast(`${entradas.length} foto(s) añadidas a la cola`,'i',2000);
    } else {
        iniciar(entradas);
    }
}

/* Contadores */
function actualizarContadores(){
    $('cTotal').textContent = archivos.length;
    $('cOk').textContent    = cntOk;
    $('cErr').textContent   = cntErr;
}

/* Iniciar subida */
async function iniciar(lista){
    const porSubir = lista.filter(a=>a.status==='pending');
    if(!porSubir.length) return;

    subiendo = true;
    colaNueva = [];
    $('bloqueProgreso').classList.remove('hidden');
    $('acciones').classList.add('hidden');
    $('reintentarBtn').classList.add('hidden');
    $('mensajeFinal').textContent = '';
    const barra = $('barra');
    barra.className=''; barra.style.width='0%';
    $('progrPct').textContent='0 %';
    $('progrLabel').textContent='Obteniendo URLs…';

    /* Batch presign */
    let urlMap = {};
    try {
        const fd = new FormData();
        fd.append('action','batch_presign');
        fd.append('galeria_id',galeriaId);
        fd.append('postulacion_id',POST_ID);
        fd.append('csrf_token',CSRF);
        fd.append('files',JSON.stringify(porSubir.map(e=>({name:e.file.name,type:e.file.type||'image/jpeg'}))));
        const r = await fetch('',{method:'POST',body:fd});
        if(!r.ok) throw new Error(`HTTP ${r.status}`);
        const d = await r.json();
        if(!d.success) throw new Error(d.error);
        porSubir.forEach((e,i)=>{ urlMap[e.id]=d.urls[i]; });
    } catch(err){
        console.warn('batch_presign falló, modo individual:', err.message);
    }

    $('progrLabel').textContent = 'Subiendo…';

    let completados = 0;
    let erroresSesion = 0;

    function onDone(tipo){
        completados++;
        if(tipo==='ok')  cntOk++;
        if(tipo==='err') { cntErr++; erroresSesion++; }
        actualizarContadores();

        const totalDin = porSubir.length + colaNueva.length;
        const pct = Math.round((completados / Math.max(totalDin, completados)) * 100);
        $('barra').style.width = pct+'%';
        $('progrPct').textContent = pct+' %';
        $('progrLabel').textContent = `${completados} de ${totalDin}`;

        if(completados >= totalDin) finalizar(erroresSesion);
    }

    const cola = [...porSubir];
    await Promise.all(
        Array.from({length: Math.min(CONCURRENCIA, porSubir.length)},
            ()=> worker(cola, onDone, urlMap))
    );
}

async function worker(cola, cb, urlMap){
    while(true){
        let e = cola.shift() || colaNueva.shift();
        if(!e) break;
        await subir(e, cb, urlMap);
    }
}

async function subir(entry, cb, urlMap){
    if(entry.status==='ok'){ cb('ok'); return; }
    entry.status = 'uploading';

    while(entry.intentos < MAX_REINTENTOS){
        try {
            if(entry.intentos>0) await sleep(RETRASO_BASE * Math.pow(2, entry.intentos-1));
            await subirFoto(entry, urlMap[entry.id]);
            entry.status = 'ok';
            cb('ok');
            return;
        } catch(e){
            entry.intentos++;
            console.warn(`[${entry.id}] intento ${entry.intentos} falló:`, e.message);
        }
    }
    entry.status = 'error';
    cb('err');
}

async function subirFoto(entry, presigned){
    let upload_url, s3_key, public_url;

    if(presigned){
        ({upload_url, s3_key, public_url} = presigned);
    } else {
        const fd = new FormData();
        fd.append('action','get_upload_url');
        fd.append('filename',entry.file.name);
        fd.append('mime_type',entry.file.type||'image/jpeg');
        fd.append('galeria_id',galeriaId);
        fd.append('postulacion_id',POST_ID);
        fd.append('csrf_token',CSRF);
        const r = await fetch('',{method:'POST',body:fd});
        if(!r.ok) throw new Error(`Presign HTTP ${r.status}`);
        const d = await r.json();
        if(!d.success) throw new Error(d.error);
        ({upload_url, s3_key, public_url} = d);
    }

    /* PUT a S3 — solo confirmar si 200 */
    await new Promise((resolve, reject)=>{
        const xhr = new XMLHttpRequest();
        xhr.open('PUT', upload_url);
        xhr.setRequestHeader('Content-Type', entry.file.type||'image/jpeg');
        xhr.timeout = 120000;
        xhr.onload    = ()=> xhr.status===200 ? resolve() : reject(new Error(`S3 HTTP ${xhr.status}`));
        xhr.onerror   = ()=> reject(new Error('Error de red'));
        xhr.ontimeout = ()=> reject(new Error('Timeout'));
        xhr.send(entry.file);
    });

    /* Confirmar en DB — solo llega aquí si S3 respondió 200 */
    const fd2 = new FormData();
    fd2.append('action','confirmar_subida');
    fd2.append('galeria_id',galeriaId);
    fd2.append('postulacion_id',POST_ID);
    fd2.append('s3_key',s3_key);
    fd2.append('tamanio',entry.file.size);
    fd2.append('csrf_token',CSRF);
    const r2 = await fetch('',{method:'POST',body:fd2});
    if(!r2.ok) throw new Error(`Confirm HTTP ${r2.status}`);
    const d2 = await r2.json();
    if(!d2.success) throw new Error(d2.error);
    return {url: public_url||d2.url};
}

function finalizar(errores){
    subiendo = false;
    $('barra').style.width = '100%';
    $('progrPct').textContent = '100 %';
    $('acciones').classList.remove('hidden');

    if(errores>0){
        $('barra').className = 'err';
        $('progrLabel').textContent = `Listo — ${errores} error(es)`;
        $('reintentarBtn').classList.remove('hidden');
        toast(`${errores} foto(s) fallaron`,'e',6000);
    } else {
        $('barra').className = 'done';
        $('progrLabel').textContent = '¡Todas subidas!';
        $('mensajeFinal').textContent = '✓ Subida completa';
        toast('¡Fotos subidas correctamente!','s');
        setTimeout(()=>{ window.location.href='https://www.latincolorsports.com/misfotografias.php'; }, 1200);
    }
}

$('reintentarBtn').onclick = ()=>{
    if(subiendo) return;
    const fallidos = archivos.filter(a=>a.status==='error');
    if(!fallidos.length) return;
    cntErr = 0;
    fallidos.forEach(a=>{ a.status='pending'; a.intentos=0; });
    actualizarContadores();
    iniciar(fallidos);
};

window.addEventListener('beforeunload', e=>{
    if(subiendo){ e.preventDefault(); e.returnValue='Hay fotos subiendo. ¿Seguro que quieres salir?'; }
});

})();
</script>
</body>
</html>