<?php require 'navfotografo.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mis Asignaciones de Fotograf�a</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <h1 class="text-3xl font-bold text-center mb-6 mt-6 text-orange-500">Mis Asignaciones Fotogr&aacute;ficas</h1>

    <div class="max-w-7xl mx-auto p-4">
        <div id="calendarioContainer" class="p-4 bg-white shadow rounded-xl overflow-x-auto">
            <p class="text-center text-gray-500">Cargando asignaciones...</p>
        </div>
    </div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.appspot.com",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const cont = document.getElementById('calendarioContainer');

onAuthStateChanged(auth, user => {
    if(user) cargarUsuarioYAsignaciones(user.uid);
    else cont.innerHTML = '<p class="text-center text-red-500">Debes iniciar sesi�n.</p>';
});

async function cargarUsuarioYAsignaciones(firebase_uid){
    try{
        const resUser = await fetch('usuarios_api2.php',{
            method:'POST',
            body: new URLSearchParams({accion:'buscar_por_uid', firebase_uid})
        });
        const dataUser = await resUser.json();
        if(!dataUser.success) throw new Error(dataUser.message);

        const usuario_id = dataUser.data.id;
        const resAsign = await fetch('calendaris_apisf.php',{
            method:'POST',
            body: new URLSearchParams({accion:'ver_asignaciones_fotografo', usuario_id})
        });
        const dataAsign = await resAsign.json();

        if(!dataAsign.success || !dataAsign.data || dataAsign.data.length === 0){
            cont.innerHTML = `<p class="text-center text-gray-500">No tienes asignaciones registradas.</p>`;
            return;
        }

        // 1. Iniciar estructura de la tabla
        let html = `<table class="min-w-full border divide-y divide-gray-200 bg-white">
            <thead class="bg-gray-50">
                <tr>
				 <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">ID</th>
                    <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Evento</th>
                    <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Sede / Escenario</th>
                    <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Disciplina</th>
                    <th class="px-4 py-3 text-left text-xs font-bold text-orange-600 uppercase">Encuentro</th>
                    <th class="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Fecha</th>
                    <th class="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase">Acci&oacute;n</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100">`;

        // 2. Llenar filas
        dataAsign.data.forEach(a => {
            const partido = (a.equipo_a && a.equipo_b) ? `${a.equipo_a} vs ${a.equipo_b}` : '---';
            const cat = a.categoria === 'M' ? 'Masculino' : (a.categoria === 'F' ? 'Femenino' : (a.categoria || '---'));
            
            const params = new URLSearchParams({
				id: a.idf || '',
                postulacion_id: a.asignacion_id || '',
                evento_id: a.evento_id || '',
                evento: a.evento || '',
                disciplina: a.disciplina || '',
                categoria: a.categoria || 'M',
                fecha: a.fecha || '',
                hora: a.hora || '',
                escenario: a.escenario || '',
                sede: a.sede || ''
            });

            html += `
            <tr class="hover:bg-gray-50 transition-colors border-b border-gray-100">
			        <td class="px-4 py-4 text-sm font-mono font-bold text-gray-400">${a.idf ?? '-'}</td>
                <td class="px-3 py-4 text-sm font-bold text-gray-700">${a.evento ?? '-'}</td>
                <td class="px-3 py-4 text-xs text-gray-500">${a.sede ?? '-'} <br> <span class="text-gray-400">${a.escenario ?? ''}</span></td>
                <td class="px-3 py-4 text-xs text-gray-500">${a.disciplina ?? '-'} <br> <span class="text-blue-600 font-bold text-[10px]">${cat}</span></td>
                <td class="px-3 py-4 text-sm font-black text-orange-600">${partido}</td>
                <td class="px-3 py-4 text-xs font-mono text-gray-600">${a.fecha} <br> <span class="text-orange-400 font-bold">${a.hora ?? ''}</span></td>
                <td class="px-3 py-4 text-center">
                    <button onclick="window.location.href='subircontenido.php?${params.toString()}'"
                        class="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg text-xs font-bold transition-transform active:scale-95 shadow-md shadow-orange-200">
                        SUBIR
                    </button>
                </td>
            </tr>`;
        });

        html += `</tbody></table>`;
        cont.innerHTML = html;
    } catch(e){
        console.error("Error:", e);
        cont.innerHTML = `<p class="text-center text-red-500">Error cargando tus asignaciones.</p>`;
    }
}
</script>
</body>
</html>