<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Postulaciones</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<!-- HEADER -->
<header class="bg-orange-500 text-white p-4 shadow-md">
  <div class="container mx-auto flex justify-between items-center">
    <h1 class="text-2xl font-bold">Mis Postulaciones</h1>
    <button id="logoutButton" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded">Cerrar Sesión</button>
  </div>
</header>

<!-- CONTENIDO -->
<main class="container mx-auto p-6">
  <h2 class="text-xl font-semibold mb-4">Calendario de Eventos Asignados</h2>
  <div id="userInfo" class="bg-white p-4 rounded-lg shadow mb-6">
    <p><strong>UID Firebase:</strong> <span id="uidText">Cargando...</span></p>
    <p><strong>Usuario:</strong> <span id="nombreText">Cargando...</span></p>
    <p><strong>Email:</strong> <span id="emailText">Cargando...</span></p>
  </div>

  <div id="calendarioUsuario" class="bg-white p-4 rounded-lg shadow">
    <p class="text-gray-500">Cargando información de tus postulaciones...</p>
  </div>
</main>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// 1. Detectar sesión de Firebase
onAuthStateChanged(auth, async (user) => {
    if (user) {
        // Mostrar datos básicos
        document.getElementById('uidText').textContent = user.uid;
        document.getElementById('emailText').textContent = user.email;
        
        try {
            const token = await user.getIdToken();

            // Obtener información de usuario
            const res = await fetch('get_user_info.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firebase_token: token })
            });

            // Leer respuesta y verificar si es JSON
            const text = await res.text();
            let data;
            try {
                data = JSON.parse(text);
            } catch (e) {
                console.error("Respuesta del servidor no es JSON:", text);
                throw new Error("El servidor no respondió correctamente.");
            }

            if (data.status === 'success') {
                document.getElementById('nombreText').textContent = data.user.nombre;
                await cargarCalendarioUsuario(token);
            } else {
                document.getElementById('nombreText').textContent = 'No encontrado';
                document.getElementById('calendarioUsuario').innerHTML = `<p class="text-red-600">Error: ${data.message}</p>`;
            }
        } catch (error) {
            console.error("Error crítico en la carga:", error);
            document.getElementById('calendarioUsuario').innerHTML = `<p class="text-red-600">Error de conexión: ${error.message}</p>`;
        }
    } else {
        window.location.href = 'login_app.html';
    }
});

// 2. Cerrar sesión
document.getElementById('logoutButton').addEventListener('click', async () => {
    try {
        await signOut(auth);
        window.location.href = 'login_app.html';
    } catch (e) { console.error("Error al cerrar sesión", e); }
});

// 3. Cargar las postulaciones
async function cargarCalendarioUsuario(token) {
    const cont = document.getElementById('calendarioUsuario');
    cont.innerHTML = '<p class="text-gray-500">Cargando tus postulaciones...</p>';

    try {
        const res = await fetch('postulaciones_usuario_calendario2.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ firebase_token: token })
        });
        
        const data = await res.json();

        if (!data.success) {
            cont.innerHTML = `<p class="text-red-600">Error: ${data.message}</p>`;
            return;
        }

        if (data.data.length === 0) {
            cont.innerHTML = `<p class="text-gray-500">No tienes postulaciones aún.</p>`;
            return;
        }

        // Construir tabla
        let html = `
            <table class="min-w-full bg-white border rounded shadow text-sm">
                <thead class="bg-gray-100 text-gray-700 uppercase text-xs">
                    <tr>
                        <th class="px-3 py-2 text-left">Evento</th>
                        <th class="px-3 py-2 text-left">Fecha</th>
                        <th class="px-3 py-2 text-left">Estado</th>
                    </tr>
                </thead>
                <tbody>`;

        data.data.forEach(p => {
            const colorEstado = p.estado === 'aceptado' ? 'text-green-600 font-semibold' : 
                                p.estado === 'rechazado' ? 'text-red-600 font-semibold' : 'text-gray-600';
            html += `
                <tr class="border-b hover:bg-gray-50">
                    <td class="px-3 py-2">${p.evento_nombre || '-'}</td>
                    <td class="px-3 py-2">${p.fecha_evento || '-'}</td>
                    <td class="px-3 py-2 ${colorEstado}">${p.estado}</td>
                </tr>`;
        });

        html += '</tbody></table>';
        cont.innerHTML = html;
    } catch (e) {
        console.error('Error cargando calendario:', e);
        cont.innerHTML = '<p class="text-red-600">Error al cargar la tabla de postulaciones.</p>';
    }
}
</script>
</body>
</html>
