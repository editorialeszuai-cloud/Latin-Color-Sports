<?php
// 1. Configuración de errores y limpieza de salida
ini_set('display_errors', 0);
error_reporting(E_ALL);
ob_start(); 

// 2. Encabezado de respuesta con charset definido
header("Content-Type: application/json; charset=utf-8");

require_once "db.php"; 

$rawInput = file_get_contents("php://input");
$data = json_decode($rawInput, true) ?? [];

$accion         = $data['accion'] ?? '';
$id_postulacion = intval($data['id'] ?? 0);
$estado         = $data['estado'] ?? null;
$calendario_id  = intval($data['calendario_id'] ?? 0);
$capacidad_mb   = intval($data['capacidad_mb'] ?? 0);
$unidad_fotos   = $data['unidad_fotos'] ?? 'N/A';

/**
 * Función de respuesta mejorada para manejar caracteres especiales
 */
function resp($status, $msg = '', $payload = null) {
    if (ob_get_length()) ob_end_clean(); 
    echo json_encode([
        'success' => $status === 'success',
        'message' => $msg,
        'data'    => $payload
    ], JSON_UNESCAPED_UNICODE); // Evita que las tildes se conviertan en códigos hexadecimales
    exit;
}

try {
    if (!isset($pdo)) { $pdo = conectar(); }
    
    // 3. Forzar a la base de datos a comunicarse en UTF-8
    $pdo->exec("SET NAMES utf8");

    if ($accion === 'listar') {
        $sql = "SELECT p.id, p.usuario_id, u.nombre AS usuario_nombre, 
                       p.evento_id, e.titulo AS evento_nombre, 
                       p.estado, p.calendario_id, p.capacidad_mb, p.unidad_fotos
                FROM postulaciones p
                LEFT JOIN usuarios u ON u.id = p.usuario_id
                LEFT JOIN eventos e ON e.id = p.evento_id
                ORDER BY p.id DESC";
        $stmt = $pdo->query($sql);
        resp('success', 'Lista cargada', $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    elseif ($accion === 'editar') {
        if (!$id_postulacion) resp('error', 'ID de postulación faltante.');
        
        $sql = "UPDATE postulaciones 
                SET estado = ?, calendario_id = ?, capacidad_mb = ?, unidad_fotos = ? 
                WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $ok = $stmt->execute([$estado, $calendario_id, $capacidad_mb, $unidad_fotos, $id_postulacion]);
        
        $ok ? resp('success', 'Actualizado correctamente') : resp('error', 'No se pudo actualizar');
    }

    elseif ($accion === 'crear') {
        $u_id = intval($data['usuario_id'] ?? 0);
        $e_id = intval($data['evento_id'] ?? 0);
        
        if (!$u_id || !$e_id) resp('error', 'Datos insuficientes');

        $check = $pdo->prepare("SELECT id FROM postulaciones WHERE usuario_id = ? AND evento_id = ?");
        $check->execute([$u_id, $e_id]);
        if ($check->fetch()) resp('error', 'Ya existe una postulación activa');

        $sql = "INSERT INTO postulaciones (usuario_id, evento_id, estado, calendario_id, capacidad_mb, unidad_fotos, creado_en)
                VALUES (?, ?, 'pendiente', 0, ?, ?, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$u_id, $e_id, $capacidad_mb, $unidad_fotos]);
        resp('success', 'Postulación creada');
    }

    elseif ($accion === 'eliminar') {
        $stmt = $pdo->prepare("DELETE FROM postulaciones WHERE id = ?");
        $stmt->execute([$id_postulacion]);
        resp('success', 'Eliminado');
    }

    else {
        resp('error', 'Acción no reconocida: ' . $accion);
    }

} catch (PDOException $e) {
    resp('error', 'Error de BD: ' . $e->getMessage());
} catch (Exception $e) {
    resp('error', 'Error general: ' . $e->getMessage());
}