<?php
require 'dbfotografos.php';
$pdo = conectar();
header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $input['firebase_uid'] ?? null;

if (!$firebase_uid) {
    echo json_encode(['status' => 'error', 'message' => 'UID no proporcionado']);
    exit;
}

try {
    // 1. Obtener el ID del usuario (comercial) por su firebase_uid
    $stmtUser = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmtUser->execute([$firebase_uid]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    $id_comercial = $user['id'];

    // 2. Consulta siguiendo la jerarquía: 
    // eventos (comercial_id) -> postulaciones (evento_id) -> fotos (postulacion_id) -> comisiones
    $sql = "SELECT DISTINCT 
                cu.id AS comision_id,
                cu.comercial AS monto, 
                dc.id_compra,
                f.url AS foto_url,
                rc.retirada
            FROM eventos e
            INNER JOIN postulaciones p ON p.evento_id = e.id
            INNER JOIN fotos f ON f.postulacion_id = p.id
            INNER JOIN comisiones_usuario cu ON cu.foto_id = f.id
            INNER JOIN detalle_compras dc ON cu.compra_id = dc.id_compra
            INNER JOIN compras c ON dc.id_compra = c.id
            LEFT JOIN retiros_comisiones rc 
                ON rc.comision_id = cu.id AND rc.tipo = 'comercial'
            WHERE e.comercial_id = :id_comercial 
              AND c.estado = 'APPROVED'
            ORDER BY cu.id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id_comercial' => $id_comercial]);
    $comisiones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $resultado = [];
    foreach ($comisiones as $c) {
        if (is_null($c['retirada'])) {
            $estado = 'Pendiente de retirar'; 
        } elseif ($c['retirada'] == 1) {
            $estado = 'En Proceso';
        } else {
            $estado = 'Pagado';
        }

        $resultado[] = [
            'comision_id' => $c['comision_id'],
            'monto' => (float)$c['monto'], 
            'compra_id' => $c['id_compra'],
            'foto_url' => $c['foto_url'],
            'estado_retiro' => $estado
        ];
    }

    echo json_encode(['status' => 'success', 'comisiones' => $resultado]);

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
}