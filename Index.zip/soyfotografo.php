<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fotógrafo Deportivo - LatinColorSports</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root {
      --red-latin: #ed1c24;
      --orange-latin: #f7941d;
      --yellow-latin: #ffc72c;
      --blue-latin: #2b6fb5;
      --dark-blue: #2b2b9b;
    }

    body {
      font-family: 'Montserrat', sans-serif;
      margin: 0;
      padding: 0;
      color: #222;
      background-image: url('../imagenes/deportista-foto-fondo.jpg');
      background-size: cover;
      background-position: center;
      background-attachment: fixed;
      overflow-x: hidden;
    }

    /* --- WHATSAPP --- */
    .whatsapp-float {
      position: fixed;
      width: 60px;
      height: 60px;
      bottom: 30px;
      right: 30px;
      background-color: #25d366;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
      z-index: 9999;
      animation: pulse-whatsapp 2s infinite;
    }
    .whatsapp-float img { width: 35px; height: 35px; }
    
    @keyframes pulse-whatsapp {
      0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); }
      70% { box-shadow: 0 0 0 15px rgba(37, 211, 102, 0); }
      100% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
    }

    /* --- OVERLAY --- */
    .menu-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(4px);
      visibility: hidden;
      opacity: 0;
      transition: 0.4s;
      z-index: 4000;
    }
    .menu-overlay.active { visibility: visible; opacity: 1; }

    /* --- HEADER UNIFICADO --- */
    .header-lcs {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 15px;
      background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f56c1e 60%, #e4312a 100%);
      border-top: 6px solid white;
      border-bottom: 6px solid white;
      height: 75px;
      position: sticky;
      top: 0;
      z-index: 5000;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    .logo-lcs a { display: flex; align-items: center; text-decoration: none; }
    .logo-lcs img { height: 35px; width: auto; }

    .right-side { display: flex; align-items: center; gap: 15px; }

    .nav-links { display: flex; align-items: center; gap: 15px; }
    .nav-links a {
      text-decoration: none;
      color: white;
      font-weight: 800;
      font-size: 11px;
      text-transform: uppercase;
    }

    .btn-login-lcs {
      background-color: var(--yellow-latin) !important;
      color: #000 !important;
      padding: 8px 12px !important;
      border-radius: 4px;
      transform: skewX(-12deg);
      display: inline-block;
    }
    .btn-login-lcs span { display: inline-block; transform: skewX(12deg); font-weight: 900; }

    .hamburger {
      display: none;
      cursor: pointer;
      flex-direction: column;
      gap: 5px;
      width: 30px;
      z-index: 5100;
    }
    .hamburger span {
      display: block;
      width: 100%;
      height: 3px;
      background-color: white;
      border-radius: 2px;
      transition: 0.4s;
    }

    @media (max-width: 1100px) {
      .nav-links {
        position: fixed;
        top: 0;
        left: -100%;
        width: 280px;
        height: 100vh;
        background: var(--red-latin);
        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
        padding: 100px 0 0 40px;
        gap: 25px;
        transition: 0.5s cubic-bezier(0.7, 0, 0.3, 1);
        z-index: 4500;
      }
      .nav-links.active { left: 0; }
      .nav-links a { font-size: 1.2rem; }
      .hamburger { display: flex; }
      
      .hamburger.open span:nth-child(1) { transform: translateY(8px) rotate(45deg); }
      .hamburger.open span:nth-child(2) { opacity: 0; }
      .hamburger.open span:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }
    }

    /* --- SECCIONES DE CONTENIDO --- */
    .hero {
      text-align: center;
      padding: 40px 20px;
      position: relative;
      color: #000;
    }
    .hero h1 {
      color: var(--dark-blue);
      font-weight: 900;
      display: inline-block;
      background-color: #fff;
      padding: 10px 30px;
      border-radius: 5px;
      font-size: 2.2rem;
      text-transform: uppercase;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .hero p {
      font-size: 1.2rem;
      max-width: 800px;
      margin: 20px auto;
      font-weight: 600;
      line-height: 1.4;
    }
    .highlight-blue {
      background: var(--blue-latin);
      color: #fff;
      font-weight: 700;
      padding: 15px 30px;
      border-radius: 12px;
      display: inline-block;
      margin-top: 20px;
      font-size: 1.1rem;
      box-shadow: 0 4px 15px rgba(43, 111, 181, 0.3);
    }

    .why-section { text-align: center; padding: 40px 20px; }
    .why-section h2 { font-weight: 800; font-size: 2rem; margin-bottom: 40px; color: #fff; text-shadow: 1px 1px 5px rgba(0,0,0,0.5); }

    .cards { display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; max-width: 1200px; margin: 0 auto; }
    .card {
      background: #fff;
      border: 4px solid var(--yellow-latin);
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      padding: 30px;
      flex: 1 1 300px;
      max-width: 350px;
      text-align: center;
      font-weight: 700;
      transition: 0.3s;
    }
    .card:hover { transform: translateY(-5px); }

    .ai-section {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      margin: 60px 0;
      gap: 30px;
      padding: 0 20px;
    }
    .ai-box {
      background: #cbe6fa;
      border-radius: 15px;
      padding: 25px;
      max-width: 350px;
      font-weight: 700;
      color: #001a33;
      border-left: 8px solid var(--blue-latin);
    }
    .ai-face {
      background: #fff url('../imagenes/imagen foto_Mesa de trabajo 12.webp') center/cover;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
      padding: 40px 20px;
      width: 250px;
      text-align: center;
    }
    .ai-face .icon { font-size: 70px; color: var(--blue-latin); margin-bottom: 15px; }
    .ai-face button {
      background-color: var(--orange-latin);
      border: none;
      color: #fff;
      padding: 12px 30px;
      border-radius: 25px;
      font-weight: 800;
      text-transform: uppercase;
      cursor: pointer;
      transition: 0.3s;
    }
    .ai-face button:hover { background-color: #e67e00; }

    .ai-info {
      background: #fff;
      border: 3px solid var(--blue-latin);
      border-radius: 15px;
      padding: 25px;
      max-width: 350px;
      color: #001a33;
    }
    .ai-info ul { padding-left: 20px; margin: 0; font-weight: 700; }
    .ai-info li { margin-bottom: 12px; }

    .cta-section { text-align: center; padding: 60px 20px; background: rgba(255,255,255,0.9); margin-top: 40px; }
    .cta-section h3 { color: var(--red-latin); font-weight: 800; font-size: 1.8rem; font-style: italic; }
    .cta-section button {
      background-color: var(--orange-latin);
      color: #fff;
      border: none;
      padding: 15px 40px;
      font-size: 1.1rem;
      font-weight: 800;
      border-radius: 30px;
      cursor: pointer;
      margin: 10px;
      transition: 0.3s;
    }
    .secondary-btn { background-color: var(--blue-latin) !important; }

    footer { background-color: #222; color: #fff; text-align: center; padding: 30px; font-weight: 600; }

    @media (max-width: 768px) {
      .hero h1 { font-size: 1.6rem; width: 90%; }
      .ai-section { flex-direction: column; }
    }
  </style>
</head>
<body>

  <div class="menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>
  <a href="https://wa.me/573142958463" class="whatsapp-float" target="_blank">
    <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp" />
  </a>

  <header class="header-lcs">
    <div class="logo-lcs">
      <a href="index.php">
        <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;height:auto;">
        <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="margin-left: 5px;width:85px;height:auto;">
      </a>
    </div>

    <div class="right-side">
      <nav class="nav-links" id="navLinks">
        <a href="conjuntodeventos.php">EVENTOS</a>
        <a href="soyorganizador.php">ORGANIZADOR</a>
        <a href="soyfotografo.php">FOTÓGRAFO</a>
        <a href="soydeportista.php">DEPORTISTA</a>
        <a href="soypatrocinador.php">PATROCINADORES</a>
        <a href="marcas.php">ESCUELA</a>
        <a href="login_app.html" class="btn-login-lcs"><span>INICIAR SESIÓN</span></a>
      </nav>

      <div class="idiomas">
        <img src="imagenes/idioma-02.webp" width="22px" alt="ES" style="cursor:pointer;">
      </div>

      <div class="hamburger" id="hamburger" onclick="toggleMenu()">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </header>

  <section class="hero">
    <h1>Fotógrafo deportivo</h1>
    <p>Plataforma especializada en la comercialización de fotografías y videos de eventos deportivos del ciclo olímpico y paralímpico.</p>
    <div class="highlight-blue">
      Gana dinero con cada disparo<br>
      <strong>Direccionamos tus fotos a los deportistas</strong>
    </div>
  </section>

  <section class="why-section">
    <h2>¿POR QUÉ SER ALIADOS?</h2>
    <div class="cards">
      <div class="card">Sube, clasifica y vende tus fotos fácilmente con nuestra tecnología.</div>
      <div class="card">Recibe comisiones automáticas, seguras y 100% transparentes.</div>
      <div class="card">Sé parte de una red élite acreditada en eventos multideportivos.</div>
    </div>
  </section>

  <section class="ai-section">
    <div class="ai-box">
      Captura el momento, nosotros lo llevamos al mundo con <strong>LatinColorSports</strong>. Cada disparo cuenta para la historia.<br><br>
      Haz parte de la red oficial de fotógrafos más grande del deporte.
    </div>

    <div class="ai-face">
      <div class="icon"><i class="fa-solid fa-camera-retro"></i></div>
      <a href="registro.html"><button>Empezar ahora</button></a>
    </div>

    <div class="ai-info">
      <ul>
        <li>Gestión total de pagos y entregas digitales.</li>
        <li>Dashboard exclusivo de seguimiento de ventas en tiempo real.</li>
        <li>Soporte técnico y legal para tus obras.</li>
      </ul>
    </div>
  </section>

  <section class="cta-section">
    <h3>“Vende tus fotos sin preocuparte por nada”</h3>
    <a href="registro.html"><button>Regístrate Aquí</button></a>
    <a href="https://latincolorcollege.com/fotografia-deportiva/" target="_blank"><button class="secondary-btn">Especialízate</button></a>
    <p style="margin-top:20px; font-weight:800; color:var(--dark-blue);">¡Convierte tu pasión en tu profesión con Latin Color Sports!</p>
  </section>

  <footer>
    © 2026 LatinColorSports. Todos los derechos reservados.
  </footer>

  <script>
    function toggleMenu() {
      const nav = document.getElementById('navLinks');
      const burger = document.getElementById('hamburger');
      const overlay = document.getElementById('menuOverlay');
      
      const isOpen = nav.classList.toggle('active');
      burger.classList.toggle('open');
      overlay.classList.toggle('active');
      
      document.body.style.overflow = isOpen ? 'hidden' : 'auto';
    }
  </script>
</body>
</html>