<?php
require_once 'dbfotografos.php';

// Consulta solo el registro con ID 1119
$stmt = $pdo->prepare("SELECT url FROM fotos WHERE id = 1119");
$stmt->execute();
$foto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$foto) {
    die("La foto con ID 1119 no existe en la base de datos.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Prueba ID 1119</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-black p-10 text-white">
    <h1 class="mb-4">Probando foto ID 1119</h1>
    <div class="max-w-md">
        <p>URL encontrada: <?= htmlspecialchars($foto['url']) ?></p>
        <img src="<?= htmlspecialchars($foto['url']) ?>" 
             alt="Foto 1119" 
             class="w-full h-auto border-2 border-orange-500 mt-4"
             onerror="console.error('La imagen falló al cargar. Revisa la consola de red.'); this.style.border='2px solid red';">
    </div>
</body>
</html>