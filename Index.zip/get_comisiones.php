<?php
require 'dbfotografos.php';
header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $input['firebase_uid'] ?? null;

if (!$firebase_uid) {
    echo json_encode(['status' => 'error', 'message' => 'UID no recibido']);
    exit;
}

try {
    $stmtUser = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmtUser->execute([$firebase_uid]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['status' => 'error', 'message' => 'Usuario no encontrado']);
        exit;
    }

    $id_autenticado = $user['id'];

    $sql = "SELECT DISTINCT 
                cu.id AS comision_id,
                cu.fotografo AS monto,
                dc.id_compra,
                f.url AS foto_url,
                rc.retirada
            FROM comisiones_usuario cu
            INNER JOIN fotos f ON cu.foto_id = f.id
            INNER JOIN postulaciones p ON f.postulacion_id = p.id 
            INNER JOIN detalle_compras dc ON cu.compra_id = dc.id_compra
            INNER JOIN compras c ON dc.id_compra = c.id
            LEFT JOIN retiros_comisiones rc 
                ON rc.comision_id = cu.id AND rc.tipo = 'fotografo'
            WHERE p.usuario_id = :id_usuario 
              AND c.estado = 'APPROVED'
              AND p.estado = 'aceptado'
            ORDER BY cu.id DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id_usuario' => $id_autenticado]);
    $comisiones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $resultado = [];
    foreach ($comisiones as $c) {
        // LÓGICA DE ESTADO SEGÚN EXISTENCIA EN retiros_comisiones
        if (is_null($c['retirada'])) {
            $estado = 'Pendiente de retirar'; 
        } elseif ($c['retirada'] == 1) {
            $estado = 'En Proceso';
        } elseif ($c['retirada'] == 0) {
            $estado = 'Pagado';
        } else {
            $estado = 'Pendiente de retirar';
        }

        $resultado[] = [
            'comision_id' => $c['comision_id'],
            'monto' => (float)$c['monto'],
            'compra_id' => $c['id_compra'],
            'foto_url' => $c['foto_url'],
            'estado_retiro' => $estado
        ];
    }

    echo json_encode(['status' => 'success', 'comisiones' => $resultado]);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
}