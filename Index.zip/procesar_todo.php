<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once 'dbfotografos.php'; 

try {
    // 1. Obtener todas las fotos
    $stmt = $pdo->query("SELECT id, url FROM fotos");
    $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Obtener un array con los IDs que YA están en la tabla 'miniaturas' (Validación masiva)
    $stmtCheck = $pdo->query("SELECT foto_id FROM miniaturas");
    $procesadas = $stmtCheck->fetchAll(PDO::FETCH_COLUMN); // Lista simple de IDs [1, 5, 8...]

    $directorio = __DIR__ . '/miniatura/';
    if (!is_dir($directorio)) mkdir($directorio, 0755, true);

    echo "<h1>Procesamiento Optimizado</h1><table border='1'><tr><th>ID</th><th>Acción</th></tr>";

    foreach ($fotos as $f) {
        $foto_id = $f['id'];
        
        // 3. Validar si ya está procesada usando el array de memoria (mucho más rápido que un SELECT por cada vuelta)
        if (in_array($foto_id, $procesadas)) {
            echo "<tr><td>{$foto_id}</td><td style='color:blue;'>⏭ Ya existe en BD</td></tr>";
            continue; // Saltamos a la siguiente foto
        }

        // Si no está en BD, procedemos a crear
        $nombreHash = md5($f['url']) . '.avif';
        $rutaFinal = $directorio . $nombreHash;
        $urlDB = 'miniatura/' . $nombreHash;

        echo "<tr><td>{$foto_id}</td>";

        // Procesamiento de imagen
        $opts = ["http" => ["header" => "User-Agent: Mozilla/5.0..."]];
        $contenido = @file_get_contents($f['url'], false, stream_context_create($opts));
        
        if ($contenido) {
            $img = @imagecreatefromstring($contenido);
            if ($img) {
                $min = imagescale($img, 600);
                imageavif($min, $rutaFinal, 85);
                imagedestroy($img); imagedestroy($min);
                
                // Registrar en base de datos
                $ins = $pdo->prepare("INSERT INTO miniaturas (foto_id, url_miniatura) VALUES (?, ?)");
                $ins->execute([$foto_id, $urlDB]);
                
                echo "<td style='color:green;'>✅ Creado y registrado</td></tr>";
            } else {
                echo "<td style='color:red;'>❌ Error imagen</td></tr>";
            }
        } else {
            echo "<td style='color:red;'>❌ No se pudo descargar</td></tr>";
        }
        
        flush(); 
    }
    echo "</table>¡Proceso finalizado!";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>