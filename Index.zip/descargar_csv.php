<?php
require_once "conexion.php";
$conn = conectar();

// Validar que haya usuarios seleccionados
if (!isset($_POST['usuarios']) || !is_array($_POST['usuarios']) || count($_POST['usuarios']) === 0) {
    die("No seleccionaste ningún usuario para descargar.");
}

$ids = array_map('intval', $_POST['usuarios']);
$in = str_repeat('?,', count($ids) - 1) . '?';
$stmt = $conn->prepare("SELECT id, nombre, email, rol, estado, fecha_registro, ultima_sesion FROM usuarios WHERE id IN ($in)");
$stmt->bind_param(str_repeat('i', count($ids)), ...$ids);
$stmt->execute();
$result = $stmt->get_result();

// Configurar cabeceras para descarga CSV
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=usuarios_seleccionados.csv');

$output = fopen('php://output', 'w');

// Encabezados
fputcsv($output, ['ID', 'Nombre', 'Email', 'Rol', 'Estado', 'Fecha Registro', 'Última Sesión']);

// Filas
while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
exit;
?>
