<?php
// ===========================
// exportar_usuarios_csv.php
// ===========================

// ⚙️ Modo debug (puedes quitarlo luego)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// 📦 Incluir conexión
if (!file_exists("dbexport.php")) {
    die("❌ Error: No se encontró el archivo 'dbexport.php'.");
}

include("dbexport.php");

if (!isset($conexion) || !($conexion instanceof mysqli)) {
    die("❌ Error: La variable \$conexion no está definida correctamente en 'dbexport.php'.");
}

if ($conexion->connect_error) {
    die("❌ Error de conexión a la base de datos: " . $conexion->connect_error);
}

// 🧾 Consulta de usuarios
$query = "SELECT id, nombre, email, rol, estado, foto_perfil FROM usuarios ORDER BY id ASC";
$result = $conexion->query($query);

if (!$result) {
    die("❌ Error en la consulta SQL: " . $conexion->error);
}

if ($result->num_rows === 0) {
    die("⚠️ No hay usuarios para exportar.");
}

// 📥 Preparar encabezados de descarga
$filename = "usuarios_" . date("Y-m-d_H-i-s") . ".csv";
header("Content-Type: text/csv; charset=utf-8");
header("Content-Disposition: attachment; filename=$filename");

// ⚙️ UTF-8 BOM para Excel
echo "\xEF\xBB\xBF";

// 📄 Crear CSV
$output = fopen("php://output", "w");
fputcsv($output, ['ID', 'Nombre', 'Email', 'Rol', 'Estado', 'Foto Perfil']);

while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['id'],
        $row['nombre'],
        $row['email'],
        $row['rol'],
        $row['estado'],
        $row['foto_perfil']
    ]);
}

fclose($output);
exit;
?>
