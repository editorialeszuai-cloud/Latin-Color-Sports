<?php
// response.php

ini_set('display_errors', 1);
error_reporting(E_ALL);

include("dbfotografos.php");
$pdo = conectar();

// Clave secreta para consultar la API de ePayco
$p_secret_key = "6f4f055542257a5c97242a3ac28d996d";

// Obtener referencia interna de la compra
$ref_local = $_GET['ref_local'] ?? '';
$compra = null;

if ($ref_local) {
    // 1. Buscar la compra en la base de datos
    $stmt = $pdo->prepare("
        SELECT referencia, estado, total, metodo_pago, x_transaction_id
        FROM compras 
        WHERE referencia = ?
    ");
    $stmt->execute([$ref_local]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. Si la compra existe y tiene ID de transacción, consultar API ePayco
    if ($compra && !empty($compra['x_transaction_id'])) {
        $id_transaccion = $compra['x_transaction_id']; 
        $url = "https://secure.epayco.co/validation/v1/reference/" . urlencode($id_transaccion);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $p_secret_key
        ]);
        
        $response = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response && $http_status === 200) {
            $data = json_decode($response, true);
            
            if (isset($data['data']['x_response'])) {
                // Normalizar el estado
                $estado = strtolower($data['data']['x_response']);
                if ($estado === 'aceptada') $estado = 'Aprobada';
                if ($estado === 'rechazada') $estado = 'Rechazada';
                if ($estado === 'pendiente') $estado = 'Pendiente';
                if ($estado === 'fallida') $estado = 'Fallida';

                $compra['estado'] = $estado;
                $compra['metodo_pago'] = $data['data']['x_bank_name'] ?? $data['data']['x_payment_method_name'] ?? $compra['metodo_pago'];

                // Actualizar la base de datos si cambió
                $pdo->prepare("
                    UPDATE compras 
                    SET estado = ?, metodo_pago = ?, fecha_compra = NOW()
                    WHERE referencia = ?
                ")->execute([$estado, $compra['metodo_pago'], $ref_local]);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Resultado del pago</title>
<style>
body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
h2 { color: #333; }
.success { color: green; font-weight: bold; }
.error { color: red; font-weight: bold; }
.warning { color: orange; font-weight: bold; }
.card { background-color: #fff; padding: 20px; border-radius: 10px; max-width: 700px; margin: auto; box-shadow:0 2px 8px rgba(0,0,0,0.1);}
</style>
</head>
<body>
<div class="card">
<h2>Resultado del pago</h2>
<?php if ($compra): 
    $estado_lower = strtolower($compra['estado']); ?>
    <p>Referencia de Compra: <strong><?= htmlspecialchars($ref_local) ?></strong></p>
    <p>Estado: 
        <?php if ($estado_lower === 'aprobada'): ?>
            <span class="success"><?= htmlspecialchars($compra['estado']) ?></span>
        <?php elseif ($estado_lower === 'pendiente'): ?>
             <span class="warning"><?= htmlspecialchars($compra['estado']) ?></span>
        <?php else: ?>
            <span class="error"><?= htmlspecialchars($compra['estado']) ?></span>
        <?php endif; ?>
    </p>
    <p>Total: <strong>$<?= number_format($compra['total'], 0, '.', ',') ?> COP</strong></p>
    <p>Método de pago: <strong><?= htmlspecialchars($compra['metodo_pago'] ?? 'No disponible') ?></strong></p>
    
    <?php if ($estado_lower === 'pendiente'): ?>
        <p style="color: orange;">Tu pago está en proceso de verificación. El estado final se confirmará en el callback.</p>
    <?php endif; ?>
<?php else: ?>
    <p>No se encontró información de la compra. Por favor, contacta soporte e indica la referencia: <strong><?= htmlspecialchars($ref_local) ?></strong>.</p>
<?php endif; ?>
</div>
</body>
</html>
