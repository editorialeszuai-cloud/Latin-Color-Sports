<?php
require_once 'navusuario.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Fotograf�as | Latin Colors</title>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

    <style>
        body { background-color: #f9fafb; font-family: 'Inter', sans-serif; }
        
        /* Tarjetas estilizadas */
        .card { 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        .card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1); }
        
        /* Imagen con ratio fijo para que todas se vean iguales */
        .img-container {
            width: 100%;
            aspect-ratio: 1/1;
            overflow: hidden;
            position: relative;
        }
        .card img { 
            width: 100%; height: 100%; object-fit: cover;
            transition: transform 0.5s ease;
        }
        .card:hover img { transform: scale(1.1); }

        /* Checkbox est�tico */
        .foto-checkbox {
            position: absolute;
            top: 12px; left: 12px;
            width: 24px; height: 24px;
            accent-color: #f97316;
            z-index: 10;
            cursor: pointer;
        }

        /* Bot�n de descarga flotante din�mico */
        #descargarSeleccionadas {
            display: none;
            position: fixed;
            bottom: 25px;
            right: 50%;
            transform: translateX(50%);
            background: #f97316;
            color: white;
            font-weight: 800;
            padding: 14px 28px;
            border-radius: 50px;
            z-index: 1000;
            box-shadow: 0 10px 20px rgba(249, 115, 22, 0.3);
            white-space: nowrap;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.05em;
        }
        @media (min-width: 768px) {
            #descargarSeleccionadas {
                bottom: 40px;
                right: 40px;
                transform: none;
            }
        }

        /* Scrollbar suave */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 10px; }
    </style>
</head>
<body class="p-4 md:p-8">

    <div class="max-w-7xl mx-auto">
        <header class="flex flex-col md:flex-row justify-between items-center mb-10 gap-4">
            <div>
                <h1 class="text-3xl md:text-4xl font-black text-gray-900 tracking-tight text-center md:text-left">Mis Fotograf&iacute;as</h1>
                <p class="text-gray-500 text-sm text-center md:text-left mt-1 font-medium italic">Tus mejores momentos, capturados para siempre.</p>
            </div>
            <button id="descargarSeleccionadas">Descargar Seleccionadas</button>
        </header>

        <div id="fotosContainer" class="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6 mt-6">
            <div class="col-span-full py-20 text-center">
                <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
                <p class="mt-4 text-gray-500 font-bold uppercase text-xs tracking-widest">Cargando Galer�a...</p>
            </div>
        </div>
    </div>

<script>
const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
    measurementId: "G-NXZW7KNWW1"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

let fotosSeleccionadas = [];

async function cargarFotos(uid) {
    const container = document.getElementById('fotosContainer');
    
    try {
        const [resIndiv, resPack] = await Promise.all([
            fetch('mis_fotos_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firebase_uid: uid })
            }),
            fetch('mis_fotos_pack.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firebase_uid: uid })
            })
        ]);

        const dataIndiv = await resIndiv.json();
        const dataPack = await resPack.json();

        // Combinamos los resultados
        const todasLasFotos = [
            ...(dataIndiv.fotos || []),
            ...(dataPack.fotos || [])
        ];

        container.innerHTML = '';

        if (todasLasFotos.length === 0) {
            container.innerHTML = `
                <div class="col-span-full py-20 text-center bg-white rounded-3xl border-2 border-dashed border-gray-200">
                    <p class="text-gray-400 font-bold uppercase text-xs tracking-widest">No se encontraron compras a&uacute;n.</p>
                </div>`;
            return;
        }

        todasLasFotos.forEach(f => {
            const div = document.createElement('div');
            div.className = 'card';
            
            const esPack = f.tipo === 'pack';
            const ruta = esPack ? `${f.foto_preview}` : `${f.nombre_archivo}`;
            
            // IMPORTANTE: Aqu� sacamos el hash que YA VIENE del PHP
            const hash = f.hash || ''; 
            
            // Construcci�n limpia de la URL
            const urlFinal = esPack 
                ? `ver_pack.php?evento_id=${f.evento_id}&h=${hash}`
                : `fotos.php?id=${f.foto_id}&h=${hash}`;
            
            div.innerHTML = `
                <div class="img-container ${esPack ? 'border-4 border-orange-500' : ''}">
                    ${!esPack ? `<input type='checkbox' class='foto-checkbox' data-src='${ruta}' onchange='toggleSeleccion(this)'>` : ''}
                    <img src='${ruta}' alt='${f.evento_titulo}' loading="lazy" class="${esPack ? 'brightness-50' : ''}">
                    ${esPack ? `
                        <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                            <span class="bg-orange-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter shadow-lg">Pack Completo</span>
                        </div>
                    ` : ''}
                </div>
                <div class="p-4 flex flex-col flex-1">
                    <h2 class='text-sm font-black text-gray-800 uppercase truncate mb-1'>${f.evento_titulo}</h2>
                    <p class='text-[10px] text-gray-400 font-bold mb-4 uppercase'>${esPack ? 'Acceso Total' : 'Foto Individual'}</p>
                    <div class="mt-auto flex flex-col gap-2">
                        <a href='${urlFinal}' class='${esPack ? 'bg-orange-600 text-white' : 'bg-gray-100 hover:bg-gray-900 hover:text-white text-gray-800'} text-[10px] font-black py-2 rounded-lg text-center transition-all uppercase shadow-lg'>
                            ${esPack ? 'Explorar Pack' : 'Ver Full HD'}
                        </a>
                    </div>
                </div>
            `;
            container.appendChild(div);
        });

    } catch (e) {
        console.error("Error cargando galer�a:", e);
        container.innerHTML = '<p class="text-center text-red-600 col-span-full">Error de conexi�n.</p>';
    }
}

function toggleSeleccion(checkbox) {
    const src = checkbox.dataset.src;
    const btn = document.getElementById('descargarSeleccionadas');
    
    if (checkbox.checked) {
        fotosSeleccionadas.push(src);
    } else {
        fotosSeleccionadas = fotosSeleccionadas.filter(f => f !== src);
    }
    
    btn.style.display = fotosSeleccionadas.length > 0 ? 'block' : 'none';
    btn.innerHTML = `Descargar ${fotosSeleccionadas.length} ${fotosSeleccionadas.length === 1 ? 'Foto' : 'Fotos'}`;
}

document.getElementById('descargarSeleccionadas').addEventListener('click', async () => {
    if (fotosSeleccionadas.length === 0) return;
    const btn = document.getElementById('descargarSeleccionadas');
    const originalText = btn.innerHTML;
    
    btn.innerHTML = "Generando ZIP...";
    btn.disabled = true;

    try {
        const zip = new JSZip();
        const folder = zip.folder('latin_colors_fotos');
        for (const url of fotosSeleccionadas) {
            const res = await fetch(url);
            const blob = await res.blob();
            const nombre = url.split('/').pop();
            folder.file(nombre, blob);
        }
        const content = await zip.generateAsync({ type: 'blob' });
        saveAs(content, 'mis_fotografias_latin_colors.zip');
    } catch (e) {
        alert("Error al descargar. Intenta de nuevo.");
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
});

// Variable para evitar redirecciones falsas durante la carga
let firebaseLoaded = false;

auth.onAuthStateChanged(user => {
    firebaseLoaded = true; // Firebase ya respondi�
    const container = document.getElementById('fotosContainer');
    
    if (user) {
        cargarFotos(user.uid);
    } else {
        // Redirigir solo si NO hay usuario
        window.location.href = 'login_app.html';
    }
});

// A�ADE ESTO: Un "salvavidas" que espera 1 segundo antes de decidir que no hay usuario
setTimeout(() => {
    if (!firebaseLoaded) {
        console.log("Firebase tardando en responder, esperando...");
    }
}, 1000);
</script>

</body>
</html>