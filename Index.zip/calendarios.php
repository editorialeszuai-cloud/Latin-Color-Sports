<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Calendarios</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">

<div class="container mx-auto">
  <h1 class="text-2xl font-bold mb-4">Gestión de Calendarios</h1>
  <button onclick="abrirModalCrear()" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 mb-4">+ Nuevo Calendario</button>
  <div id="calendariosTableContainer"></div>
</div>

<!-- Modal -->
<div id="modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
  <div class="bg-white p-6 rounded-lg w-full max-w-md relative">
    <button onclick="cerrarModal()" class="absolute top-2 right-2 text-xl font-bold">&times;</button>
    <h2 id="modalTitulo" class="text-xl font-semibold mb-4">Crear Calendario</h2>
    
    <form id="formCalendario" class="space-y-4">
      <input type="hidden" id="accion" name="accion">
      <input type="hidden" id="id_calendario" name="id">

      <div>
        <label class="block font-medium">Evento</label>
        <select id="evento_id" name="evento_id" class="w-full border p-2 rounded" required></select>
      </div>

      <div>
        <label class="block font-medium">Sede</label>
        <select id="sede_id" name="sede_id" class="w-full border p-2 rounded" required></select>
      </div>

      <div>
        <label class="block font-medium">Escenario</label>
        <select id="escenario_id" name="escenario_id" class="w-full border p-2 rounded" required></select>
      </div>

      <div>
        <label class="block font-medium">Disciplina</label>
        <select id="disciplina_id" name="disciplina_id" class="w-full border p-2 rounded" required></select>
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block font-medium">Fecha</label>
          <input type="date" id="fecha" name="fecha" class="w-full border p-2 rounded" required>
        </div>
        <div>
          <label class="block font-medium">Hora</label>
          <input type="time" id="hora" name="hora" class="w-full border p-2 rounded" required>
        </div>
      </div>

      <div class="flex justify-end space-x-2">
        <button type="button" onclick="cerrarModal()" class="px-4 py-2 bg-gray-400 rounded hover:bg-gray-500">Cancelar</button>
        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
// Modal y formulario
const modal = document.getElementById('modal');
const form = document.getElementById('formCalendario');
const modalTitulo = document.getElementById('modalTitulo');

function abrirModalCrear(){
    form.reset();
    document.getElementById('accion').value = 'crear';
    document.getElementById('id_calendario').value = '';
    modalTitulo.textContent = 'Crear Calendario';
    modal.classList.remove('hidden');
    cargarSelects();
}

function abrirModalEditar(data){
    document.getElementById('accion').value = 'editar';
    document.getElementById('id_calendario').value = data.id; // ✅ corregido
    document.getElementById('evento_id').value = data.evento_id;
    document.getElementById('sede_id').value = data.sede_id;
    document.getElementById('escenario_id').value = data.escenario_id;
    document.getElementById('disciplina_id').value = data.disciplina_id;
    document.getElementById('fecha').value = data.fecha;
    document.getElementById('hora').value = data.hora;

    modalTitulo.textContent = 'Editar Calendario';
    modal.classList.remove('hidden');
    cargarSelects();
}

function cerrarModal(){
    modal.classList.add('hidden');
}

// Guardar formulario
form.addEventListener('submit', async e=>{
    e.preventDefault();
    const formData = new FormData(form);
    const res = await fetch('calendarios_api.php', {method:'POST', body: formData});
    const data = await res.json();
    if(data.success){
        alert('✅ Operación exitosa');
        cerrarModal();
        listarCalendarios();
    } else {
        alert('❌ ' + data.message);
    }
});

// Listar calendarios
async function listarCalendarios(){
    const res = await fetch('calendarios_api.php', {
        method:'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({accion:'listar'})
    });
    const data = await res.json();
    const container = document.getElementById('calendariosTableContainer');
    if(!data.success) { 
        container.innerHTML = 'Error al cargar: ' + (data.message || 'Desconocido'); 
        return; 
    }
    
    let html = `<table class="min-w-full border divide-y divide-gray-200 bg-white rounded shadow">
        <thead class="bg-gray-100">
            <tr>
                <th class="px-2 py-1">ID</th>
                <th class="px-2 py-1">Evento</th>
                <th class="px-2 py-1">Sede</th>
                <th class="px-2 py-1">Escenario</th>
                <th class="px-2 py-1">Disciplina</th>
                <th class="px-2 py-1">Fecha</th>
                <th class="px-2 py-1">Hora</th>
                <th class="px-2 py-1">Acciones</th>
            </tr>
        </thead>
        <tbody>`;
    
    data.data.forEach(c=>{
        html += `<tr class="hover:bg-gray-50">
            <td class="px-2 py-1">${c.id}</td>
            <td class="px-2 py-1">${c.evento}</td>
            <td class="px-2 py-1">${c.sede}</td>
            <td class="px-2 py-1">${c.escenario}</td>
            <td class="px-2 py-1">${c.disciplina}</td>
            <td class="px-2 py-1">${c.fecha}</td>
            <td class="px-2 py-1">${c.hora}</td>
            <td class="px-2 py-1 space-x-1">
                <button onclick='abrirModalEditar(${JSON.stringify(c)})' class="px-2 py-1 bg-yellow-500 text-white rounded">Editar</button>
                <button onclick='eliminar(${c.id})' class="px-2 py-1 bg-red-600 text-white rounded">Eliminar</button>
            </td>
        </tr>`;
    });

    html += '</tbody></table>';
    container.innerHTML = html;
}


// Eliminar
async function eliminar(id){
    if(!confirm('¿Eliminar este calendario?')) return;
    const res = await fetch('calendarios_api.php', {method:'POST', body: new URLSearchParams({accion:'eliminar', id})});
    const data = await res.json();
    if(data.success) listarCalendarios();
    else alert('Error: ' + data.message);
}

// Cargar selects
async function cargarSelects(){
    const selects = [
        {id:'evento_id', url:'eventos_carg.php'},
        {id:'sede_id', url:'sedes_carg.php'},
        {id:'escenario_id', url:'escenarios_carg.php'},
        {id:'disciplina_id', url:'disciplinas_carg.php'}
    ];

    for(const s of selects){
        const res = await fetch(s.url, {method:'POST', body: new URLSearchParams({accion:'listar'})});
        const data = await res.json();
        const selectEl = document.getElementById(s.id);
        selectEl.innerHTML = '<option value="">Seleccione</option>';
        if(data.success){
            data.data.forEach(item=>{
                const opt = document.createElement('option');
                opt.value = item.id;
                opt.textContent = item.nombre || item.titulo;
                selectEl.appendChild(opt);
            });
        }
    }
}

// Inicial
listarCalendarios();
</script>

</body>
</html>
