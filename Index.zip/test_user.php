<?php
header("Content-Type: application/json");
require_once "db.php";

$res = ["php_version" => PHP_VERSION, "vendor_exists" => false, "db_connection" => "failed"];

// Verificar Vendor
if (file_exists(__DIR__ . "/vendor/autoload.php")) {
    $res["vendor_exists"] = true;
}

// Verificar DB
try {
    $pdo = conectar();
    $res["db_connection"] = "success";
} catch (Exception $e) {
    $res["db_error"] = $e->getMessage();
}

// Verificar Archivo JSON
$json_path = __DIR__ . "/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json";
$res["json_file"] = file_exists($json_path) ? "exists" : "missing";

echo json_encode($res);