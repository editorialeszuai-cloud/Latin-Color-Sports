import os
import json
import numpy as np
import face_recognition
from PIL import Image
import sys

# Archivos y rutas
EMBEDDINGS_FILE = "embeddings.json"   # Generado con generar_embeddings.py
UPLOADS_DIR = "uploads"               # Carpeta donde están las fotos

# Parámetro: ruta de la foto que se sube para buscar
if len(sys.argv) < 2:
    print("Uso: python buscar_rostro.py <ruta_foto>")
    sys.exit(1)

query_image_path = sys.argv[1]

# Cargar embeddings existentes
if not os.path.exists(EMBEDDINGS_FILE):
    print(f"No se encontró {EMBEDDINGS_FILE}, primero ejecuta generar_embeddings.py")
    sys.exit(1)

with open(EMBEDDINGS_FILE, "r") as f:
    embeddings_data = json.load(f)

# Procesar la foto de búsqueda
query_image = face_recognition.load_image_file(query_image_path)
query_faces = face_recognition.face_locations(query_image)
query_encodings = face_recognition.face_encodings(query_image, query_faces)

if not query_encodings:
    print("No se detectó ningún rostro en la imagen proporcionada.")
    sys.exit(1)

query_embedding = query_encodings[0]

# Comparar con todos los embeddings existentes
matches = []

for filename, embedding_list in embeddings_data.items():
    db_embedding = np.array(embedding_list)
    distance = np.linalg.norm(query_embedding - db_embedding)  # Distancia euclidiana
    matches.append((filename, distance))

# Ordenar por distancia más cercana
matches.sort(key=lambda x: x[1])

# Mostrar los top 5 resultados
TOP_N = 5
print(f"Top {TOP_N} coincidencias:")
for filename, distance in matches[:TOP_N]:
    print(f"{filename} - distancia: {distance:.4f}")
