<?php
// Reporte de errores desactivado para evitar fugas de texto en peticiones
error_reporting(0);
ob_start();

require 'dbfotografos.php';
require 'vendor/autoload.php';

// LAS DECLARACIONES USE SIEMPRE DEBEN IR EN LA PARTE SUPERIOR FUERA DE CONDICIONALES
use Aws\S3\S3Client;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => $_ENV['AWS_REGION'],
    'credentials' => ['key' => $_ENV['AWS_KEY'], 'secret' => $_ENV['AWS_SECRET']],
]);

$foto_id = $_GET['id'] ?? null;

if (!$foto_id) {
    die('<p style="color:red; text-align:center; padding:20px; background:#050505; min-h-screen">Error: ID de foto no especificado.</p>');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 1. MODO PUENTE: Si se solicita la visualización segura, procesamos y salimos
if (isset($_GET['stream']) && $_GET['stream'] == '1') {
    ob_end_clean();
    try {
        $stmtF = $pdo->prepare("SELECT url FROM fotos WHERE id = ?");
        $stmtF->execute([$foto_id]);
        $foto = $stmtF->fetch(PDO::FETCH_ASSOC);

        if ($foto) {
            $url_parts = parse_url($foto['url']);
            $s3_key = ltrim($url_parts['path'], '/');

            // Descarga interna desde AWS S3 (El cliente nunca ve la URL real)
            $result = $s3->getObject([
                'Bucket' => $_ENV['AWS_BUCKET'] ?? 'latincolorsports-bucket',
                'Key'    => $s3_key,
            ]);

            header("Content-Type: image/jpeg");
            header("Cache-Control: private, max-age=86400");
            echo $result['Body'];
            exit;
        }
    } catch (Exception $e) {
        header("HTTP/1.1 500 Internal Server Error");
        exit;
    }
}

// 2. LÓGICA DE ELIMINACIÓN ASÍNCRONA (AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'eliminar') {
    ob_end_clean();
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $stmtF = $pdo->prepare("SELECT url FROM fotos WHERE id = ?");
        $stmtF->execute([$foto_id]);
        $foto = $stmtF->fetch(PDO::FETCH_ASSOC);

        if (!$foto) {
            exit(json_encode(['success' => false, 'error' => 'La foto no existe.']));
        }

        $url_parts = parse_url($foto['url']);
        $s3_key = ltrim($url_parts['path'], '/');

        $s3->deleteObject([
            'Bucket' => $_ENV['AWS_BUCKET'] ?? 'latincolorsports-bucket',
            'Key'    => $s3_key,
        ]);

        $stmtDel = $pdo->prepare("DELETE FROM fotos WHERE id = ?");
        $stmtDel->execute([$foto_id]);

        exit(json_encode(['success' => true]));

    } catch (Exception $e) {
        exit(json_encode(['success' => false, 'error' => $e->getMessage()]));
    }
}

// 3. CARGA INICIAL: Consultar los detalles completos de la foto para el HTML
try {
    $stmt = $pdo->prepare("
        SELECT f.*, g.titulo as galeria_titulo, e.titulo as evento_titulo, p.usuario_id
        FROM fotos f
        INNER JOIN galerias g ON f.galeria_id = g.id
        INNER JOIN postulaciones p ON g.postulacion_id = p.id
        LEFT JOIN eventos e ON p.evento_id = e.id
        WHERE f.id = ?
    ");
    $stmt->execute([$foto_id]);
    $detalles = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$detalles) {
        die('<p style="color:red; text-align:center; padding:20px; background:#050505; min-h-screen">Error: Foto no encontrada en el sistema.</p>');
    }

} catch (PDOException $e) {
    die("Error en el servidor: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Detalle de Foto #<?= htmlspecialchars($foto_id) ?> | Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
		<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <style>
        /* Desactivar selección de texto global y toques prolongados en pantallas móviles */
        * {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-touch-callout: none;
        }
    </style>
</head>
<body class="bg-[#050505] text-white font-sans min-h-screen flex flex-col">

    <?php require 'navfotografo.php'; ?>

    <div class="flex-1 flex items-center justify-center p-4">
        <div class="w-full max-w-lg bg-[#0f0f0f] border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
            
            <div class="p-4 border-b border-white/5 bg-black/40 flex justify-between items-center">
                <a href="javascript:history.back()" class="text-xs text-gray-400 hover:text-orange-500 font-bold flex items-center gap-1">
                    « Volver
                </a>
                <h1 class="text-xs font-mono tracking-widest uppercase text-gray-400">Detalle Foto <span class="text-orange-500">#<?= htmlspecialchars($foto_id) ?></span></h1>
                <div class="w-10"></div> </div>

            <div class="relative w-full bg-black aspect-square flex items-center justify-center overflow-hidden border-b border-white/5">
                
                <div class="absolute inset-0 z-50 bg-transparent" oncontextmenu="return false;"></div>

                <img id="img-target" 
                     src="foto_detalle.php?id=<?= $foto_id ?>&stream=1" 
                     alt="Latin Color Sports Protegida" 
                     class="w-full h-full object-contain pointer-events-none select-none">
                
                <span class="absolute top-3 right-3 z-50 bg-black/70 border border-white/10 text-[10px] font-mono px-3 py-1 rounded-full text-orange-500 font-bold">
                   <?= htmlspecialchars($detalles['evento_titulo'] ?? 'Sin evento asociado') ?>
                </span>
            </div>

            <div class="p-6 space-y-4">
                <div class="bg-white/5 p-4 rounded-2xl border border-white/5 space-y-3">
                    <div>
                        <p class="text-[9px] text-orange-500 font-black uppercase tracking-wider">Evento deportivo</p>
                        <p class="text-sm font-bold text-white truncate"><?= htmlspecialchars($detalles['evento_titulo'] ?? 'Sin evento asociado') ?></p>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-2 pt-2 border-t border-white/5">
                        <div>
                            <p class="text-[9px] text-gray-500 font-black uppercase tracking-wider">Galería / Carrete</p>
                            <p class="text-xs font-medium text-gray-300 truncate"><?= htmlspecialchars($detalles['galeria_titulo'] ?? 'General') ?></p>
                        </div>
                        <div>
                            <p class="text-[9px] text-gray-500 font-black uppercase tracking-wider">Nombre del Archivo</p>
                            <p class="text-xs font-mono text-gray-300 truncate"><?= htmlspecialchars($detalles['nombre'] ?? 'S/N') ?></p>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1">
                    <button onclick="confirmarEliminacion()" class="w-full bg-red-500/10 hover:bg-red-600 hover:text-white border border-red-500/20 text-red-500 transition-colors text-xs font-bold uppercase py-3 rounded-xl">
                        🗑️ Eliminar permanentemente
                    </button>
                </div>
            </div>

        </div>
    </div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const app = initializeApp({
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
});

onAuthStateChanged(getAuth(app), (u) => {
    if(!u && !localStorage.getItem('usuario_uid')) {
        window.location.href = "login_app.html";
    }
});

// Bloqueo total de eventos de mouse y teclado (Anti-Inspección Básica)
document.addEventListener('contextmenu', e => e.preventDefault());
document.addEventListener('keydown', e => {
    if (e.key === 'F12' || 
        (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J')) || 
        (e.ctrlKey && e.key === 'U')) {
        e.preventDefault();
    }
});

window.confirmarEliminacion = async function() {
    if (confirm("⚠️ ¿Estás absolutamente seguro de que deseas eliminar esta foto de forma permanente? Esta acción la borrará de AWS S3 y no se podrá deshacer.")) {
        
        const btnEliminar = document.activeElement;
        if(btnEliminar) {
            btnEliminar.disabled = true;
            btnEliminar.innerText = "Borrando...";
        }

        try {
            const fd = new FormData();
            fd.append('action', 'eliminar');

            const response = await fetch(window.location.href, { method: 'POST', body: fd });
            const data = await response.json();

            if (data.success) {
                alert("✅ Foto eliminada correctamente.");
                window.location.href = "mis_galerias.php";
            } else {
                alert("❌ Error: " + (data.error || "No se pudo eliminar la foto."));
                if(btnEliminar) {
                    btnEliminar.disabled = false;
                    btnEliminar.innerText = "🗑️ Eliminar";
                }
            }
        } catch (error) {
            alert("❌ Ocurrió un problema de conexión con el servidor.");
            if(btnEliminar) {
                btnEliminar.disabled = false;
                btnEliminar.innerText = "🗑️ Eliminar";
            }
        }
    }
}
</script>
</body>
</html>