<?php
require 'dbfotografos.php'; // conexión PDO

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json; charset=utf-8');

    // Traducciones etiquetas -> español
    $traducciones = [
        "runner" => "Corredor",
        "podium" => "Podio",
        "medal" => "Medalla",
        "team" => "Equipo",
        "start_line" => "Línea de salida",
        "finish_line" => "Línea de llegada",
        "coach" => "Entrenador",
    ];

    // Buscar usuario por Firebase UID
    if (isset($_POST['firebase_uid'])) {
        $firebase_uid = $_POST['firebase_uid'];
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid=?");
        $stmt->execute([$firebase_uid]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) { echo json_encode(['success'=>false,'message'=>'Usuario no encontrado']); exit; }

        $usuario_id = $user['id'];
        $stmt = $pdo->prepare("
            SELECT p.id, e.titulo AS evento_nombre, p.estado, p.capacidad_mb, p.unidad_fotos
            FROM postulaciones p
            JOIN eventos e ON e.id=p.evento_id
            WHERE p.usuario_id=? AND p.estado='aceptado'
        ");
        $stmt->execute([$usuario_id]);
        echo json_encode(['success'=>true,'postulaciones'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    }

    // Crear galería
    if (isset($_POST['action']) && $_POST['action']==='crear_galeria') {
        $postulacion_id = $_POST['postulacion_id'] ?? '';
        $titulo = $_POST['titulo'] ?? '';
        if (!$postulacion_id || !$titulo) { echo json_encode(['success'=>false,'message'=>'Datos incompletos']); exit; }
        $stmt = $pdo->prepare("INSERT INTO galerias (postulacion_id, titulo) VALUES (?,?)");
        if ($stmt->execute([$postulacion_id, $titulo])) {
            echo json_encode(['success'=>true,'galeria_id'=>$pdo->lastInsertId(),'message'=>'Galería creada correctamente']);
        } else echo json_encode(['success'=>false,'message'=>'Error creando galería']);
        exit;
    }

    // Subir fotos
    if (isset($_POST['action']) && $_POST['action']==='subir_fotos') {
        $galeria_id = $_POST['galeria_id'] ?? '';
        $postulacion_id = $_POST['postulacion_id'] ?? '';
        if (!$galeria_id || !$postulacion_id || !isset($_FILES['fotos'])) {
            echo json_encode(['success'=>false,'message'=>'Datos incompletos']); exit;
        }

        $stmt = $pdo->prepare("SELECT capacidad_mb, unidad_fotos FROM postulaciones WHERE id=?");
        $stmt->execute([$postulacion_id]);
        $p = $stmt->fetch(PDO::FETCH_ASSOC);
        $capacidad_kb = ($p['capacidad_mb'] ?? 0) * 1024;
        $unidad_fotos = intval($p['unidad_fotos'] ?? 0);

        $stmt = $pdo->prepare("SELECT SUM(tamano_kb) AS usado_kb, COUNT(*) AS fotos_subidas FROM fotos WHERE postulacion_id=?");
        $stmt->execute([$postulacion_id]);
        $res = $stmt->fetch(PDO::FETCH_ASSOC);
        $usado_kb = intval($res['usado_kb'] ?? 0);
        $fotos_subidas = intval($res['fotos_subidas'] ?? 0);

        $fotos = $_FILES['fotos'];
        $temas = $_POST['temas'] ?? [];
        $descripciones = $_POST['descripcion'] ?? [];
        $total_nuevo_kb = 0;
        foreach ($fotos['size'] as $s) { $total_nuevo_kb += round($s/1024); }

        if ($usado_kb + $total_nuevo_kb > $capacidad_kb)
            exit(json_encode(['success'=>false,'message'=>'Excede la capacidad máxima permitida']));
        if ($unidad_fotos > 0 && $fotos_subidas + count($fotos['name']) > $unidad_fotos)
            exit(json_encode(['success'=>false,'message'=>'Excede el número máximo de fotos']));

        $carpeta = 'uploads/';
        if (!is_dir($carpeta)) mkdir($carpeta,0777,true);

        $analisis_result = [];
        foreach ($fotos['name'] as $i => $nombreOriginal) {
            $tmp = $fotos['tmp_name'][$i];
            $nombre = time().'_'.$nombreOriginal;
            if (move_uploaded_file($tmp, $carpeta.$nombre)) {
                $tamano_kb = round($fotos['size'][$i]/1024);
                $tipo = $fotos['type'][$i];
                $descripcion = is_array($descripciones)?($descripciones[$i] ?? ''):'';
                $tema = is_array($temas)?($temas[$i] ?? ''):'';
                $temaTrad = $traducciones[$tema] ?? $tema;

                $stmt = $pdo->prepare("INSERT INTO fotos (galeria_id, postulacion_id, url, descripcion, tamano_kb, tipo)
                                       VALUES (?,?,?,?,?,?)");
                $stmt->execute([$galeria_id,$postulacion_id,$nombre,$descripcion,$tamano_kb,$tipo]);
                $foto_id = $pdo->lastInsertId();

                list($ancho,$alto)=getimagesize($carpeta.$nombre);
                $img=imagecreatefromstring(file_get_contents($carpeta.$nombre));
                $total_r=$total_g=$total_b=$total_px=0;
                for($x=0;$x<$ancho;$x+=10){for($y=0;$y<$alto;$y+=10){
                    $rgb=imagecolorat($img,$x,$y);
                    $r=($rgb>>16)&0xFF; $g=($rgb>>8)&0xFF; $b=$rgb&0xFF;
                    $total_r+=$r; $total_g+=$g; $total_b+=$b; $total_px++;
                }}
                imagedestroy($img);
                $color_dominante="rgb(".round($total_r/$total_px).",".round($total_g/$total_px).",".round($total_b/$total_px).")";

                $stmt2=$pdo->prepare("INSERT INTO foto_analisis (galeria_id,foto_id,ancho,alto,tamano_kb,color_dominante,objetos_detectados)
                                      VALUES (?,?,?,?,?,?,?)");
                $stmt2->execute([$galeria_id,$foto_id,$ancho,$alto,$tamano_kb,$color_dominante,$temaTrad]);

                $analisis_result[]=['url'=>$nombre,'ancho'=>$ancho,'alto'=>$alto,'tamano_kb'=>$tamano_kb,'color'=>$color_dominante,'objetos'=>$temaTrad];
            }
        }

        echo json_encode(['success'=>true,'message'=>'Fotos subidas correctamente','analisis'=>$analisis_result]);
        exit;
    }

    echo json_encode(['success'=>false,'message'=>'Acción no válida']); exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Postulaciones y Galerías</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/ml5@latest/dist/ml5.min.js"></script>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
</head>
<body class="bg-gray-100 p-6">
<h1 class="text-3xl font-bold mb-8 text-center">Mis Postulaciones y Galerías</h1>
<div id="postulacionesContainer" class="space-y-6"></div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.firebasestorage.app",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
  measurementId: "G-NXZW7KNWW1"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

let classifier;
async function initTMModel() {
    classifier = await ml5.imageClassifier('./my_model/model.json');
}

onAuthStateChanged(auth, async user => {
    if(!user) return alert("Usuario no autenticado");
    await initTMModel();
    await cargarPostulaciones(user.uid);
});

async function cargarPostulaciones(uid){
    const fd = new FormData();
    fd.append('firebase_uid', uid);
    const res = await fetch('', {method:'POST', body:fd});
    const data = await res.json();
    if(!data.success) return alert(data.message);

    const container = document.getElementById('postulacionesContainer');
    container.innerHTML = '';

    data.postulaciones.forEach(p => {
        const div = document.createElement('div');
        div.className = "p-6 bg-white rounded-lg shadow-md border border-gray-200";

        const titulo = document.createElement('h2');
        titulo.className = "text-xl font-bold mb-3";
        titulo.textContent = `${p.evento_nombre} [${p.estado}] - Capacidad: ${p.capacidad_mb} MB, Fotos: ${p.unidad_fotos}`;
        div.appendChild(titulo);

        const inputNombre = document.createElement('input');
        inputNombre.placeholder="Nombre de la galería";
        inputNombre.className="border rounded px-3 py-2 w-full mb-3";
        div.appendChild(inputNombre);

        const opciones = ["Galería Oficial","Competencia","Podio","Entrenamiento","Detrás de escena"];
        const optDiv = document.createElement('div');
        optDiv.className="flex flex-wrap gap-2 mb-3";
        opciones.forEach(o=>{
            const b=document.createElement('button');
            b.textContent=o; b.type="button";
            b.className="bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded-full text-sm";
            b.onclick=()=>{inputNombre.value=o;};
            optDiv.appendChild(b);
        });
        div.insertBefore(optDiv,inputNombre);

        const btnCrear=document.createElement('button');
        btnCrear.className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded w-full mb-3";
        btnCrear.textContent="Crear Galería";
        div.appendChild(btnCrear);

        const subirDiv=document.createElement('div');
        subirDiv.className="hidden mt-4 space-y-2";

        const inputFiles=document.createElement('input');
        inputFiles.type="file"; inputFiles.multiple=true; inputFiles.className="border rounded px-3 py-2 w-full";

        const inputDesc=document.createElement('input');
        inputDesc.placeholder="Descripción (nombre competidor, dorsal)";
        inputDesc.className="border rounded px-3 py-2 w-full";

        const progreso=document.createElement('p');
        progreso.className="text-sm text-gray-500";

        const btnSubir=document.createElement('button');
        btnSubir.className="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded w-full";
        btnSubir.textContent="Subir Fotos";

        subirDiv.append(inputFiles,inputDesc,progreso,btnSubir);
        div.appendChild(subirDiv);
        container.appendChild(div);

        let galeria=null;
        btnCrear.onclick=async()=>{
            if(!inputNombre.value.trim()) return alert("Ingresa un nombre");
            const fd2=new FormData();
            fd2.append('action','crear_galeria');
            fd2.append('postulacion_id',p.id);
            fd2.append('titulo',inputNombre.value.trim());
            const r=await fetch('',{method:'POST',body:fd2});
            const d=await r.json();
            alert(d.message);
            if(d.success){galeria=d.galeria_id; subirDiv.classList.remove('hidden');}
        };

  btnSubir.onclick = async () => {
    if (!galeria) return alert("Primero crea la galería");
    const archivos = inputFiles.files;
    if (archivos.length === 0) return alert("Selecciona fotos");

    const fd3 = new FormData();
    fd3.append('action', 'subir_fotos');
    fd3.append('galeria_id', galeria);
    fd3.append('postulacion_id', p.id);

    let fotosValidas = 0;

    for (let i = 0; i < archivos.length; i++) {
        progreso.textContent = `Analizando foto ${i + 1} de ${archivos.length}...`;
        const file = archivos[i];
        const esBorroso = await detectarDesenfoque(file);

       if (esBorroso) {
    alert(`❌ La foto "${file.name}" no cumple con los parámetros de calidad establecidos y no será aceptada.`);
    continue;
}


        const pred = await classifyFile(file); // Teachable Machine para tema
        fd3.append(`fotos[${fotosValidas}]`, file);
        fd3.append(`temas[${fotosValidas}]`, pred);
        fd3.append(`descripcion[${fotosValidas}]`, inputDesc.value.trim());
        fotosValidas++;
    }

    if (fotosValidas === 0) {
        progreso.textContent = "";
        alert("No se subieron fotos válidas.");
        return;
    }

    progreso.textContent = "Subiendo fotos válidas...";
    const r2 = await fetch('', { method: 'POST', body: fd3 });
    const d2 = await r2.json();
    progreso.textContent = "";
    alert(d2.success ? d2.message + "\n" + d2.analisis.map(a => a.objetos).join("\n") : d2.message);
};


    });
}

async function detectarDesenfoque(file) {
    return new Promise(resolve => {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = new Image();
            img.src = e.target.result;
            img.onload = function() {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                canvas.width = img.width;
                canvas.height = img.height;
                ctx.drawImage(img, 0, 0, img.width, img.height);

                // Convertir a escala de grises
                const imageData = ctx.getImageData(0, 0, img.width, img.height);
                const gray = [];
                let totalBrightness = 0;
                let minVal = 255, maxVal = 0;

                for (let i = 0; i < imageData.data.length; i += 4) {
                    const avg = (imageData.data[i] + imageData.data[i+1] + imageData.data[i+2]) / 3;
                    gray.push(avg);
                    totalBrightness += avg;
                    if (avg < minVal) minVal = avg;
                    if (avg > maxVal) maxVal = avg;
                }

                // Calcular varianza de bordes (simplificación del Laplaciano)
                let sum = 0, sumSq = 0;
                for (let y = 1; y < img.height - 1; y++) {
                    for (let x = 1; x < img.width - 1; x++) {
                        const i = y * img.width + x;
                        const lap = -4 * gray[i] + gray[i - 1] + gray[i + 1] + gray[i - img.width] + gray[i + img.width];
                        sum += lap;
                        sumSq += lap * lap;
                    }
                }
                const n = (img.width - 2) * (img.height - 2);
                const variance = (sumSq / n) - Math.pow(sum / n, 2);

                // 🔍 Ajusta el umbral según tus fotos (80-150 aprox)
                const threshold = 100;
                const desenfocada = variance < threshold;

                // 📸 Evaluación adicional profesional
                const brilloPromedio = totalBrightness / gray.length;
                const contraste = maxVal - minVal;
                const iluminacionMala = (brilloPromedio < 50 || brilloPromedio > 200);
                const bajoContraste = (contraste < 40);

                // 🔊 Detección de ruido (granulado)
                // Calculamos la varianza de diferencias entre píxeles vecinos
                let diffSum = 0, diffCount = 0;
                for (let y = 1; y < img.height - 1; y += 2) {
                    for (let x = 1; x < img.width - 1; x += 2) {
                        const i = y * img.width + x;
                        const d1 = Math.abs(gray[i] - gray[i - 1]);
                        const d2 = Math.abs(gray[i] - gray[i + 1]);
                        const d3 = Math.abs(gray[i] - gray[i - img.width]);
                        const d4 = Math.abs(gray[i] - gray[i + img.width]);
                        diffSum += d1 + d2 + d3 + d4;
                        diffCount += 4;
                    }
                }
                const ruidoPromedio = diffSum / diffCount;
                const ruidoAlto = ruidoPromedio > 12; // >25 suele indicar ruido visible

                // 🚫 Rechazar si es borrosa, oscura, sobreexpuesta, con poco contraste o ruidosa
                const fotoMala = desenfocada || iluminacionMala || bajoContraste || ruidoAlto;

                console.log(`Análisis de calidad:
                    Varianza: ${variance.toFixed(1)},
                    Brillo: ${brilloPromedio.toFixed(1)},
                    Contraste: ${contraste.toFixed(1)},
                    Desenfocada: ${desenfocada},
                    Iluminación mala: ${iluminacionMala},
                    Bajo contraste: ${bajoContraste},
                    Ruido promedio: ${ruidoPromedio.toFixed(1)},
                    Ruido alto: ${ruidoAlto}
                `);

                resolve(fotoMala); // true si está borrosa, mal iluminada, o con ruido
            };
        };
        reader.readAsDataURL(file);
    });
}



async function classifyFile(file){
    return new Promise(resolve=>{
        const reader=new FileReader();
        reader.onload=async e=>{
            const img=document.createElement('img');
            img.src=e.target.result; img.width=224; img.height=224;
            img.onload=async()=>{
                const res=await classifier.classify(img);
                resolve(res[0].label);
            };
        };
        reader.readAsDataURL(file);
    });
}
</script>
</body>
</html>
