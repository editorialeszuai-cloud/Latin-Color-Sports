<?php
// conjuntodeventos.php

// 1. Inclusión de archivos obligatorios
require_once 'dbfotografos.php'; 

// Forzar codificación
header('Content-Type: text/html; charset=utf-8');

// 2. Bloque de Auditoría de Navegación
try {
    if (isset($pdo)) {
        $ip = $_SERVER['REMOTE_ADDR'];
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]; 
        }
        $ua = $_SERVER['HTTP_USER_AGENT'];

        $sql_audit = "INSERT INTO auditoria_navegacion 
                      (usuario_id, nombre_usuario, rol, pagina_visitada, ip_acceso, user_agent) 
                      VALUES (:uid, :nom, :rol, :pag, :ip, :ua)";
        
        $stmt_audit = $pdo->prepare($sql_audit);
        $stmt_audit->execute([
            ':uid' => 'Anonimo', 
            ':nom' => 'Visita Catalogo', 
            ':rol' => 'Public',
            ':pag' => 'CONJUNTO_EVENTOS', 
            ':ip'  => $ip, 
            ':ua'  => $ua
        ]);
    }
} catch (Exception $e) {
    error_log("Error de auditoría: " . $e->getMessage());
}

// 3. Captura de variables de búsqueda
$search = $_GET['search'] ?? '';
$tipo = $_GET['tipo_evento'] ?? '';

// 4. Consulta Principal de Eventos
$sql = "
    SELECT 
        e.*, 
        l.ciudad, 
        l.pais,
        COUNT(f.id) AS total_fotos,
        GROUP_CONCAT(DISTINCT u.nombre SEPARATOR ', ') AS fotografos
    FROM eventos e
    LEFT JOIN lugares l ON e.lugar_id = l.id
    LEFT JOIN postulaciones p ON p.evento_id = e.id
    LEFT JOIN fotos f ON f.postulacion_id = p.id
    LEFT JOIN usuarios u ON p.usuario_id = u.id
    WHERE 1=1
";

$params = [];
if (!empty($search)) { $sql .= " AND e.titulo LIKE ? "; $params[] = "%$search%"; }
if (!empty($tipo)) { $sql .= " AND e.tipo_evento = ? "; $params[] = $tipo; }

$sql .= " GROUP BY e.id ORDER BY e.created_at DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $tiposStmt = $pdo->query("SELECT DISTINCT tipo_evento FROM eventos WHERE tipo_evento IS NOT NULL AND tipo_evento <> '' ORDER BY tipo_evento ASC");
    $tipos = $tiposStmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Usuario - Latin Sports</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; margin: 0;margin-top:100px; }

    /* ESTILO LCS NAV PROFESIONAL */
    .header-lcs {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 40px;
      background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f8a700 40%, #f56c1e 60%, #e4312a 100%);
      border-top: 18px solid white;
      border-bottom: 18px solid white;
      height: 100px;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .nav-container { display: flex; align-items: center; flex-grow: 1; margin-left: 150px; }
    .nav-links { display: flex; align-items: center; gap: 30px;margin-left:100px; }

    .nav-links a, .nav-links button.nav-btn {
      text-decoration: none;
      color: white;
      font-weight: 900;
      text-transform: uppercase;
      font-size: 14px;
      letter-spacing: 0.5px;
      transition: 0.3s;
      display: flex;
      align-items: center;
      gap: 6px;
      background: none;
      border: none;
      cursor: pointer;
      white-space: nowrap;
    }

    .nav-links a:hover, .nav-links button.nav-btn:hover { color: #ffe29a; }

    /* Submenús Dropdown */
    .relative { position: relative; }
    .submenu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background-color: white;
      box-shadow: 0 10px 15px rgba(0,0,0,0.2);
      min-width: 180px;
      border-radius: 8px;
      padding: 10px 0;
      border-top: 4px solid #f46616;
      z-index: 1100;
    }
    .relative:hover .submenu { display: block; animation: fadeIn 0.2s ease-out; }
    .submenu a { color: #333 !important; padding: 10px 20px; display: block; font-size: 12px; font-weight: 600; }
    .submenu a:hover { background: #fff7ed; color: #f46616 !important; }

    @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

    /* Tarjetas de Eventos */
    .card { background:#fff; border-radius:16px; overflow:hidden; border:1px solid #eee; transition:.3s; display:flex; flex-direction:column; height: 100%; }
    .img-container { aspect-ratio: 16/9; overflow:hidden; display:flex; align-items:center; justify-content:center; background:#f3f4f6; }
    .img-container img { width:100%; height:100%; object-fit: cover; }

    @media (max-width: 768px) {
      .header-lcs { padding: 0 15px; height: 80px; border-top: 10px solid white; border-bottom: 10px solid white; }
      .nav-container { display: none; }
    }
  </style>
</head>
<body class="flex flex-col min-h-screen">

 <!-- Header actualizado con rutas correctas -->
<header class="header-lcs">
    <div class="logo flex items-center">
        <a href="nav_usuarios.php" class="flex items-center">
            <img src="imagenes/LATINCOLOR.png" alt="Logo 1" style="height: 85px; width: auto;">
            <img src="uploads/LATIN-SPORTS.png" alt="Logo 2" style="height: 85px; width: auto; margin-left: 5px;">
        </a>
    </div>

    <div class="nav-container">
        <nav class="nav-links">
            <a href="nav_usuarios.php">Home</a>
            <a href="conjuntodeventos.php">Eventos</a> <!-- Ruta corregida -->

            <div class="relative group">
                <button class="nav-btn">
                    Explorar 
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div class="submenu">
                    <!-- Generado dinámicamente -->
                    <?php foreach ($tipos as $t): ?>
                        <a href="conjuntodeventos.php?tipo_evento=<?= urlencode($t) ?>"><?= strtoupper($t) ?></a>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="relative group">
                <button class="nav-btn">
                    Mis Compras
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div class="submenu">
                    <a href="migaleria.php">MIS COLECCIONES</a>
                    <a href="miscomprasfotos.php">MIS FOTOS</a>
                </div>
            </div>
        </nav>
    </div>

    <div class="flex items-center gap-4">
        <div class="hidden lg:flex flex-col text-right text-white mr-2">
            <!-- IDs para el Script de Firebase -->
            <span id="userName" class="font-black text-xs uppercase leading-none">Invitado</span>
            <span id="userEmail" class="text-[9px] opacity-80 leading-none mt-1"></span>
        </div>
        <button id="logoutButton" class="bg-white text-red-600 font-black text-[10px] px-4 py-2 rounded-full uppercase tracking-tighter hover:bg-black hover:text-white transition">
            Salir
        </button>
        <button id="mobile-menu-button" class="md:hidden text-white">
            <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>
        </button>
    </div>
</header>

<!-- Agregamos el saludo de bienvenida que faltaba en el segundo diseño -->
<div class="max-w-7xl mx-auto px-4 pt-8">
    <h1 class="text-3xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase italic">
        Hola, <span class="text-orange-600" id="welcomeName">Atleta</span>
    </h1>
    <p class="text-gray-500 mt-1 text-sm font-medium">Explora la lista completa de eventos disponibles.</p>
</div>

  <div id="mobile-menu" class="hidden bg-white border-b-4 border-orange-500 md:hidden">
      <div class="p-6 space-y-4">
          <a href="nav_usuarios.php" class="block font-black text-gray-800 uppercase">Home</a>
          <a href="conjuntodeventospremium.php" class="block font-black text-gray-800 uppercase">Eventos</a>
          <hr>
          <p class="text-[10px] font-bold text-gray-400 uppercase">Mis Compras</p>
          <a href="migaleria.php" class="block text-sm text-gray-600 pl-2">Mis Colecciones</a>
          <a href="miscomprasfotos.php" class="block text-sm text-gray-600 pl-2">Mis Fotos</a>
      </div>
  </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        <h1 class="text-2xl md:text-4xl font-black mb-8 text-center text-gray-900 uppercase tracking-tighter italic">
            Eventos <span class="text-orange-600">Disponibles</span>
        </h1>

        <form method="GET" class="mb-10 bg-white p-4 rounded-2xl shadow-sm border border-gray-100 max-w-4xl mx-auto">
            <div class="flex flex-col md:flex-row gap-3">
                <div class="relative flex-1">
                    <input 
                        type="text" 
                        name="search" 
                        value="<?= htmlspecialchars($search) ?>" 
                        placeholder="Nombre del evento..." 
                        class="w-full pl-4 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-sm"
                    >
                </div>

                <select 
                    name="tipo_evento" 
                    class="w-full md:w-48 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-sm"
                >
                    <option value="">Todos los tipos</option>
                    <?php foreach ($tipos as $t): ?>
                        <option value="<?= htmlspecialchars($t) ?>" <?= ($t === $tipo) ? 'selected' : '' ?>>
                            <?= htmlspecialchars(ucfirst($t)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="w-full md:w-auto bg-orange-600 hover:bg-orange-700 text-white font-bold px-8 py-3 rounded-xl transition-all shadow-lg text-sm">
                    BUSCAR
                </button>
            </div>

            <?php if ($search || $tipo): ?>
                <div class="text-center mt-3">
                    <a href="conjuntodeventos.php" class="text-xs text-gray-400 hover:text-orange-600 font-bold uppercase tracking-widest">Limpiar filtros</a>
                </div>
            <?php endif; ?>
        </form>

        <?php if(empty($eventos)): ?>
            <div class="bg-white rounded-3xl p-12 text-center shadow-sm border border-gray-100">
                <p class="text-gray-400 font-bold italic">No se encontraron eventos.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                <?php foreach ($eventos as $e): 
                    $banner = $e['banner'] ?? '';
                    $icono = $e['icono_foto'] ?? '';
                ?>
                <div class="group bg-white rounded-2xl shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 overflow-hidden flex flex-col">
                    <div class="relative h-52 overflow-hidden">
                        <?php if($banner): ?>
                            <img src="<?= htmlspecialchars($banner) ?>" alt="<?= htmlspecialchars($e['titulo']) ?>" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                        <?php else: ?>
                            <div class="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400 text-[10px] font-bold uppercase tracking-widest">Sin Imagen</div>
                        <?php endif; ?>
                        
                        <?php if(!empty($e['tipo_evento'])): ?>
                            <div class="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-lg uppercase tracking-wider">
                                <?= htmlspecialchars($e['tipo_evento']) ?>
                            </div>
                        <?php endif; ?>

                        <?php if($icono): ?>
                            <img src="<?= htmlspecialchars($icono) ?>" class="absolute -bottom-4 right-4 w-12 h-12 rounded-2xl border-4 border-white shadow-lg z-10 bg-white">
                        <?php endif; ?>
                    </div>

                    <div class="p-6 flex-1 flex flex-col">
                        <div class="mb-4">
                            <h2 class="text-xl font-extrabold text-gray-900 group-hover:text-orange-600 transition-colors leading-tight mb-2 uppercase italic">
                                <?= htmlspecialchars($e['titulo']) ?>
                            </h2>
                            <div class="flex items-center gap-4 text-gray-400 text-[11px] font-bold uppercase tracking-widest">
                                <span class="flex items-center gap-1">
                                    <i class="fa-solid fa-calendar-days text-orange-500"></i>
                                    <?= date('d M, Y', strtotime($e['fecha'])) ?>
                                </span>
                                <span class="flex items-center gap-1">
                                    <i class="fa-solid fa-location-dot text-orange-500"></i>
                                    <?= htmlspecialchars($e['ciudad']) ?>
                                </span>
                            </div>
                        </div>

                        <p class="text-gray-500 text-sm mb-6 line-clamp-2 leading-relaxed font-medium">
                            <?= htmlspecialchars($e['descripcion'] ?? 'Sin descripción disponible.') ?>
                        </p>

                        <div class="mt-auto pt-4 border-t border-gray-50 flex items-center justify-between">
                            <div class="text-[10px] text-gray-400 uppercase font-black tracking-tighter">
                                <span class="text-orange-600 block text-lg leading-none"><?= (int)$e['total_fotos'] ?></span>
                                FOTOS
                            </div>
                            <a href="galeria.php?evento_id=<?= (int)$e['id'] ?>" class="bg-gray-900 hover:bg-orange-600 text-white text-[10px] font-black px-5 py-3 rounded-xl transition-all uppercase tracking-widest shadow-lg active:scale-95">
                                Ver Galería
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function toggleMenu() {
            const nav = document.getElementById('navLinks');
            const burger = document.getElementById('hamburger');
            const overlay = document.getElementById('menuOverlay');
            const isOpen = nav.classList.toggle('active');
            burger.classList.toggle('open');
            overlay.classList.toggle('active');
            document.body.style.overflow = isOpen ? 'hidden' : 'auto';
        }
    </script>
    
      <script type="module">
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
    import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

    const firebaseConfig = {
      apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
      authDomain: "latin-group-406b1.firebaseapp.com",
      projectId: "latin-group-406b1",
      storageBucket: "latin-group-406b1.appspot.com",
      messagingSenderId: "21494348297",
      appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
    };

    const app = initializeApp(firebaseConfig);
    const auth = getAuth(app);

    // Toggle Móvil
    document.getElementById('mobile-menu-button')?.addEventListener('click', () => {
        document.getElementById('mobile-menu').classList.toggle('hidden');
    });

    onAuthStateChanged(auth, async (user) => {
        if (user) {
            document.getElementById('welcomeName').textContent = user.displayName || "Atleta";
            
            user.getIdToken().then(async token => {
                const res = await fetch('get_user_info.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ firebase_token: token, email: user.email })
                });
                const data = await res.json();
                if (data.status === 'success' && data.user) {
                    document.getElementById('userName').textContent = data.user.nombre;
                    document.getElementById('userEmail').textContent = data.user.email;
                }
            });
        } else {
            window.location.href = "login_app.html";
        }
    });

    const handleLogout = async () => {
      await signOut(auth);
      window.location.href = 'login_app.html';
    };

    document.getElementById('logoutButton')?.addEventListener('click', handleLogout);
  </script>
</body>
</html>