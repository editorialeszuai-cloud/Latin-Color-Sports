<head><script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          primary: '#6366F1',
          secondary: '#10B981',
          accent: '#F59E0B',
        },
        fontFamily: {
          sans: ['Inter', 'sans-serif'],
        },
      },
    },
    plugins: [],
  }
</script>
</head>

<footer class="bg-gray-900 text-gray-300 pt-12">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-10">

      <!-- Columna 1: Logo y descripción -->
      <div class="space-y-4">
        <img src="logo.png" alt="Logo" class="h-12">
        <p class="text-gray-400 text-sm">
          Nuestra plataforma permite a los usuarios explorar eventos, subir selfies y gestionar su galería personal de manera sencilla y segura.
        </p>
        <div class="flex space-x-4 mt-2">
          <a href="#" class="hover:text-indigo-400 transition"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="hover:text-indigo-400 transition"><i class="fab fa-twitter"></i></a>
          <a href="#" class="hover:text-indigo-400 transition"><i class="fab fa-instagram"></i></a>
          <a href="#" class="hover:text-indigo-400 transition"><i class="fab fa-linkedin-in"></i></a>
        </div>
      </div>

      <!-- Columna 2: Acerca de -->
      <div>
        <h3 class="text-white font-semibold mb-4">Acerca de</h3>
        <ul class="space-y-2">
          <li><a href="#como" class="hover:text-indigo-400 transition">Cómo funciona</a></li>
          <li><a href="#explorar" class="hover:text-indigo-400 transition">Explorar Eventos</a></li>
          <li><a href="#galeria" class="hover:text-indigo-400 transition">Nuestra Galería</a></li>
        </ul>
      </div>

      <!-- Columna 3: Apoyo -->
      <div>
        <h3 class="text-white font-semibold mb-4">Apoyo</h3>
        <ul class="space-y-2">
          <li><a href="#privacidad" class="hover:text-indigo-400 transition">Política de Privacidad</a></li>
          <li><a href="#condiciones" class="hover:text-indigo-400 transition">Condiciones de Uso</a></li>
          <li><a href="#contacto" class="hover:text-indigo-400 transition">Contacto</a></li>
        </ul>
      </div>

      <!-- Columna 4: Información / Newsletter -->
      <div>
        <h3 class="text-white font-semibold mb-4">Información</h3>
        <p class="text-gray-400 text-sm mb-4">Suscríbete a nuestro newsletter para recibir las últimas novedades.</p>
        <form class="flex flex-col sm:flex-row gap-2">
          <input type="email" placeholder="Tu correo electrónico" class="px-3 py-2 rounded-lg w-full sm:flex-1 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-gray-900" required>
          <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition">Suscribirse</button>
        </form>
      </div>

    </div>

    <!-- Copyrigth -->
    <div class="border-t border-gray-700 mt-10 pt-6 text-center text-gray-500 text-sm">
      &copy; 2025 LatinGroup. Todos los derechos reservados.
    </div>
  </div>
</footer>

<!-- FontAwesome para íconos sociales -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
