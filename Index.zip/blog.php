<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel de Blogs</title>
<script type="module" src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js"></script>
<script type="module" src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js"></script>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<style>
body { font-family: Arial, sans-serif; margin: 20px; background-color: #f9f9f9; }
h1,h2 { color:#333; }
#blogsContainer { display: grid; gap: 20px; margin-top: 20px; }
.blog { padding: 15px; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
.blog h3 { margin-top: 0; color: #333; }
.blog p { color: #555; }
#logoutButton { margin-top: 10px; padding: 8px 12px; background-color: #e74c3c; color: #fff; border: none; border-radius: 5px; cursor: pointer; }
form { margin-top: 20px; background:#fff; padding:15px; border-radius:8px; box-shadow:0 2px 5px rgba(0,0,0,0.1); }
form input, form textarea, form select { width: 100%; padding: 8px; margin-bottom:10px; border-radius:5px; border:1px solid #ccc; }
form button { padding:10px 15px; background:#3498db; color:#fff; border:none; border-radius:5px; cursor:pointer; }
#blogMessage { margin-top:10px; }
</style>
</head>
<body>

<h1 id="welcomeMessage">Bienvenido!</h1>
<button id="logoutButton">Cerrar sesión</button>

<h2>Crear nuevo blog</h2>
<form id="blogForm">
<label for="titulo">Título:</label>
<input type="text" id="titulo" name="titulo" required>

<label for="resumen">Resumen:</label>
<textarea id="resumen" name="resumen" rows="3"></textarea>

<label for="contenido">Contenido:</label>
<textarea id="contenido" name="contenido" rows="6" required></textarea>

<label for="categoria">Categoría:</label>
<input type="text" id="categoria" name="categoria">

<label for="estado">Estado:</label>
<select id="estado" name="estado">
<option value="borrador">Borrador</option>
<option value="publicado">Publicado</option>
</select>

<button type="submit">Guardar Blog</button>
</form>
<div id="blogMessage"></div>

<h2>Mis Blogs</h2>
<div id="blogsContainer"></div>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// --- Configuración Firebase ---
const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
    measurementId: "G-NXZW7KNWW1"
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// --- Función para cargar blogs ---
async function loadBlogs(uid){
    if(!uid) return;
    const form = new FormData();
    form.append('uid', uid);
    try{
        const res = await fetch('load_blogs.php',{method:'POST', body:form});
        const html = await res.text();
        document.getElementById('blogsContainer').innerHTML = html;
    } catch(e){
        document.getElementById('blogsContainer').innerHTML = `<p style="color:red;">Error cargando blogs.</p>`;
        console.error(e);
    }
}

// --- Detectar usuario logueado ---
onAuthStateChanged(auth, async (user)=>{
    if(user){
        const token = await user.getIdToken();
        try {
            const res = await fetch('get_user_info.php',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify({firebase_token: token})
            });
            const data = await res.json();
            if(data.status==='success'){
                document.getElementById('welcomeMessage').textContent = `Bienvenido, ${data.user.nombre}!`;
                loadBlogs(data.user.firebase_uid);
            } else {
                alert('⚠️ '+data.message);
            }
        } catch(err){
            console.error(err);
            alert('Error al obtener info del usuario.');
        }
    } else {
        window.location.href = 'login_app.html';
    }
});

// --- Cerrar sesión ---
document.getElementById('logoutButton').addEventListener('click', async ()=>{
    await signOut(auth);
    window.location.href = 'login_app.html';
});

// --- Crear blog ---
const blogForm = document.getElementById('blogForm');
const blogMessage = document.getElementById('blogMessage');

blogForm.addEventListener('submit', async e=>{
    e.preventDefault();
    const user = auth.currentUser;
    if(!user) return alert("Usuario no logueado");
    const token = await user.getIdToken();

    const formData = new FormData(blogForm);
    formData.append('firebase_token', token);

    try{
        const res = await fetch('insert_blog.php',{method:'POST', body:formData});
        const data = await res.json();
        if(data.status==='success'){
            blogMessage.innerHTML='<p style="color:green;">Blog creado con éxito!</p>';
            blogForm.reset();
            loadBlogs(user.uid);
        } else {
            blogMessage.innerHTML=`<p style="color:red;">Error: ${data.message}</p>`;
        }
    } catch(err){
        console.error(err);
        blogMessage.innerHTML='<p style="color:red;">Error de conexión</p>';
    }
});
</script>

</body>
</html>
