<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

try {
    require 'dbfotografos.php';

    // 1. Validar entrada
    $firebase_uid = $_POST['firebase_uid'] ?? null;
    $evento_id    = $_POST['evento_id']    ?? null;

    if (!$firebase_uid || !$evento_id) {
        throw new Exception("Faltan parámetros: UID o Evento ID");
    }

    // 2. Obtener el descriptor del perfil del usuario
    $stmtUser = $pdo->prepare("SELECT descriptor FROM perfiles_biometricos WHERE firebase_uid = ? LIMIT 1");
    $stmtUser->execute([$firebase_uid]);
    $userRow = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if (!$userRow) {
        echo json_encode(['success' => false, 'message' => 'No tienes perfil biométrico registrado']);
        exit;
    }

    $user_descriptor = json_decode($userRow['descriptor'], true);

    // 3. Obtener todas las caras del evento (con miniatura)
    $stmtFaces = $pdo->prepare("
        SELECT f.id AS foto_id, f.url, m.url_miniatura, fs.descriptor 
        FROM faces fs
        INNER JOIN fotos f ON fs.foto_id = f.id
        INNER JOIN postulaciones p ON f.postulacion_id = p.id
        LEFT JOIN miniaturas m ON f.id = m.foto_id
        WHERE p.evento_id = ?
    ");
    $stmtFaces->execute([$evento_id]);
    $fotos_evento = $stmtFaces->fetchAll(PDO::FETCH_ASSOC);

    $matches   = [];
    $threshold = 0.55;

    // 4. Comparación Matemática (Distancia Euclidiana)
    foreach ($fotos_evento as $f) {
        $db_descriptor = json_decode($f['descriptor'], true);
        if (!$db_descriptor || count($db_descriptor) !== 128) continue;

        $sum = 0;
        for ($i = 0; $i < 128; $i++) {
            $sum += pow($db_descriptor[$i] - $user_descriptor[$i], 2);
        }
        $distance = sqrt($sum);

        if ($distance < $threshold) {
            $matches[] = [
                'id'            => $f['foto_id'],
                'url'           => $f['url'],
                'url_miniatura' => $f['url_miniatura'],
                'distance'      => round($distance, 4)
            ];
        }
    }

    // 5. Ordenar por la más parecida
    usort($matches, function($a, $b) {
        return $a['distance'] <=> $b['distance'];
    });

    // 6. Respuesta
    echo json_encode([
        'success' => true,
        'fotos'   => $matches,
        'total'   => count($matches)
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}