<?php
require_once 'dbfotografos.php';
$pdo = conectar();

// Obtener referencia local enviada por Wompi
$ref_local = $_GET['reference'] ?? '';

$estado = 'Pendiente';
if ($ref_local) {
    $stmt = $pdo->prepare("SELECT estado FROM compras_paquetes WHERE referencia = ?");
    $stmt->execute([$ref_local]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($compra) $estado = $compra['estado'];
}

// Redirigir automáticamente a la página de paquetes comprados
header("Location: https://latincolorsports.com/miscompraspaquetes.php");
exit;
?>
