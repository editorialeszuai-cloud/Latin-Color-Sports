<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Datos Bancarios | Latin Color Sports</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<style>
    /* Estilos personalizados para inputs de tipo file y scrollbars */
    input[type="file"]::file-selector-button {
        background-color: rgba(255, 255, 255, 0.1);
        color: #ffffff;
        border: 0;
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 11px;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
        transition: background-color 0.2s;
    }
    input[type="file"]::file-selector-button:hover {
        background-color: rgba(255, 255, 255, 0.2);
    }
    /* Estilo para barra de desplazamiento en tablas responsivas */
    .custom-scrollbar::-webkit-scrollbar {
        height: 6px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
        background: #0f0f0f;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
        background: #ea580c;
        border-radius: 3px;
    }
</style>
<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// ---------------------------
// Configuración Firebase
// ---------------------------
const firebaseConfig = {
  apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
  authDomain: "latin-group-406b1.firebaseapp.com",
  projectId: "latin-group-406b1",
  storageBucket: "latin-group-406b1.appspot.com",
  messagingSenderId: "21494348297",
  appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

let currentUID = null;
let editarID = null;

// ---------------------------
// Logout
// ---------------------------
function setupLogout(){
    document.getElementById('logoutButton').addEventListener('click', async () => {
        await signOut(auth);
        window.location.href = 'login_app.html';
    });
}

// ---------------------------
// Cargar registros
// ---------------------------
async function cargarRegistros(){
    if(!currentUID) return;
    try {
        const res = await fetch(`datos_banca.php?firebase_uid=${currentUID}`);
        if(!res.ok) throw new Error("Error al cargar registros");
        const data = await res.json();
        const tbody = document.getElementById('registrosBody');
        tbody.innerHTML = '';
        if(!data || !data.length){
            tbody.innerHTML = `<tr><td colspan="8" class="text-center p-8 text-gray-500 text-sm">No hay cuentas bancarias registradas en el sistema.</td></tr>`;
            return;
        }
        data.forEach(r => {
            const tr = document.createElement('tr');
            tr.className = "border-b border-white/5 bg-[#0f0f0f]/40 hover:bg-white/5 transition-colors text-sm";
            tr.innerHTML = `
            <td class="px-4 py-3 font-mono text-gray-400">${r.id}</td>
            <td class="px-4 py-3 font-bold text-white">${r.banco}</td>
            <td class="px-4 py-3 text-gray-300"><span class="px-2 py-0.5 rounded text-xs ${r.tipo_cuenta === 'Ahorros' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'}">${r.tipo_cuenta}</span></td>
            <td class="px-4 py-3">
                <div class="flex items-center justify-between min-w-[140px] bg-black/40 px-2 py-1 rounded-lg border border-white/5">
                    <span class="font-mono text-orange-400 font-bold">${r.numero_cuenta}</span>
                    <button onclick="copiarCuenta('${r.numero_cuenta}')" class="ml-2 text-[10px] uppercase font-black tracking-wider bg-white/10 hover:bg-orange-600 px-2 py-0.5 rounded text-white transition-colors">Copiar</button>
                </div>
            </td>
            <td class="px-4 py-3 text-gray-300 font-medium">${r.titular}</td>
            <td class="px-4 py-3 font-mono text-gray-400">${r.cedula}</td>
            <td class="px-4 py-3 font-mono text-gray-400">${r.celular || '—'}</td>
            <td class="px-4 py-3">
                <div class="flex flex-wrap items-center gap-2">
                    ${r.rut_pdf ? `<a href="${r.rut_pdf}" target="_blank" class="px-2 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded text-xs font-bold text-gray-300 transition-colors">📄 RUT</a>` : ''}
                    ${r.certificacion_pdf ? `<a href="${r.certificacion_pdf}" target="_blank" class="px-2 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded text-xs font-bold text-gray-300 transition-colors">🏦 Cert.</a>` : ''}
                    <button class="bg-amber-500/10 hover:bg-amber-500 hover:text-black border border-amber-500/20 text-amber-400 px-2 py-1 rounded text-xs font-bold transition-colors"
                        data-id="${r.id}"
                        data-banco="${r.banco}"
                        data-tipo="${r.tipo_cuenta}"
                        data-numero="${r.numero_cuenta}"
                        data-titular="${r.titular}"
                        data-cedula="${r.cedula}"
                        data-celular="${r.celular || ''}"
                        onclick="editarRegistro(this)">Editar</button>
                     </div>
            </td>`;
            tbody.appendChild(tr);
        });
    } catch (err) {
        alert("Error: " + err.message);
    }
}

// ---------------------------
// Copiar al portapapeles
// ---------------------------
window.copiarCuenta = (numero) => {
    navigator.clipboard.writeText(numero).then(() => alert('📋 Número de cuenta copiado al portapapeles.'));
}

// ---------------------------
// Editar
// ---------------------------
window.editarRegistro = (btn) => {
    editarID = btn.dataset.id;
    const bancoValor = btn.dataset.banco;
    const selectBanco = document.getElementById('banco_select');
    const inputManual = document.getElementById('banco_manual');
    const contenedorOtro = document.getElementById('contenedor-otro-banco');

    // Cambiar texto del botón principal a modo edición
    document.getElementById('btnSubmit').innerText = "Actualizar Cuenta Bancaria";

    // Validar si el banco existe en las opciones predefinidas
    let existeOpcion = false;
    for (let i = 0; i < selectBanco.options.length; i++) {
        if (selectBanco.options[i].value === bancoValor) {
            existeOpcion = true;
            break;
        }
    }

    if (existeOpcion) {
        selectBanco.value = bancoValor;
        contenedorOtro.classList.add('hidden');
        inputManual.removeAttribute('required');
        inputManual.value = '';
    } else {
        selectBanco.value = 'Otro';
        contenedorOtro.classList.remove('hidden');
        inputManual.setAttribute('required', 'true');
        inputManual.value = bancoValor;
    }

    document.getElementById('banco_final').value = bancoValor;
    document.getElementById('tipo_cuenta').value = btn.dataset.tipo;
    document.getElementById('numero_cuenta').value = btn.dataset.numero;
    document.getElementById('titular').value = btn.dataset.titular;
    document.getElementById('cedula').value = btn.dataset.cedula;
    document.getElementById('celular').value = btn.dataset.celular;
    
    // Enfocar y hacer scroll al formulario
    document.getElementById('formBancario').scrollIntoView({ behavior: 'smooth' });
}

// ---------------------------
// Eliminar
// ---------------------------
async function eliminarRegistro(id){
    if(!confirm('⚠️ ¿Estás seguro de que deseas eliminar de forma permanente este registro bancario?')) return;
    try {
        const form = new FormData();
        form.append('firebase_uid', currentUID);
        form.append('accion', 'eliminar');
        form.append('id', id);
        const res = await fetch('datos_banca.php', { method: 'POST', body: form });
        const data = await res.json();
        alert(data.message);
        cargarRegistros();
    } catch(err){
        alert("Error: " + err.message);
    }
}

// ---------------------------
// Inicializar eventos dinámicos del formulario (Manejador del campo "Otro")
// ---------------------------
document.addEventListener('DOMContentLoaded', () => {
    const selectBanco = document.getElementById('banco_select');
    const contenedorOtro = document.getElementById('contenedor-otro-banco');
    const inputManual = document.getElementById('banco_manual');
    const inputFinal = document.getElementById('banco_final');

    selectBanco.addEventListener('change', function() {
        if (this.value === 'Otro') {
            contenedorOtro.classList.remove('hidden');
            inputManual.setAttribute('required', 'true');
            inputManual.focus();
            inputFinal.value = inputManual.value;
        } else {
            contenedorOtro.classList.add('hidden');
            inputManual.removeAttribute('required');
            inputManual.value = '';
            inputFinal.value = this.value;
        }
    });

    inputManual.addEventListener('input', function() {
        if (selectBanco.value === 'Otro') {
            inputFinal.value = this.value;
        }
    });

    // Envío del Formulario integrado
    document.getElementById('formBancario').addEventListener('submit', async (e) => {
        e.preventDefault();
        if(!currentUID) return alert('Sesión inválida o expirada.');

        const form = new FormData();
        form.append('firebase_uid', currentUID);
        form.append('accion', editarID ? 'editar' : 'crear');
        if(editarID) form.append('id', editarID);
        
        form.append('banco', inputFinal.value);
        form.append('tipo_cuenta', document.getElementById('tipo_cuenta').value);
        form.append('numero_cuenta', document.getElementById('numero_cuenta').value);
        form.append('titular', document.getElementById('titular').value);
        form.append('cedula', document.getElementById('cedula').value);
        form.append('celular', document.getElementById('celular').value);

        const rut = document.getElementById('rut_pdf').files[0];
        const cert = document.getElementById('cert_bancaria').files[0];
        if(rut) form.append('rut_pdf', rut);
        if(cert) form.append('certificacion_pdf', cert);

        try {
            const res = await fetch('datos_banca.php', { method: 'POST', body: form });
            const data = await res.json();
            alert(data.message);
            document.getElementById('formBancario').reset();
            contenedorOtro.classList.add('hidden');
            inputManual.removeAttribute('required');
            document.getElementById('btnSubmit').innerText = "Guardar Datos Bancarios";
            editarID = null;
            cargarRegistros();
        } catch(err){
            alert("Error al guardar: " + err.message);
        }
    });
});

// ---------------------------
// Firebase Auth
// ---------------------------
onAuthStateChanged(auth, user => {
    if(user){
        currentUID = user.uid;
        document.getElementById('userName').textContent = user.displayName || 'Fotógrafo Profesional';
        document.getElementById('userEmail').textContent = user.email || 'Sin email configurado';
        setupLogout();
        cargarRegistros();
    } else {
        window.location.href = 'login_app.html';
    }
});
</script>
</head>

<body class="bg-[#050505] text-white font-sans min-h-screen antialiased selection:bg-orange-500 selection:text-white">
    
<nav class="bg-[#0f0f0f] border-b border-white/5 sticky top-0 z-50 backdrop-blur-md bg-opacity-90">
  <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">

      <div class="flex-shrink-0 flex items-center gap-2">
        <div class="w-9 h-9 rounded-xl bg-orange-600/10 border border-orange-500/30 flex items-center justify-center">
            <img class="h-6 w-auto" src="uploads/LATIN-SPORTS.png" alt="Logo">
        </div>
        <span class="font-black text-sm tracking-wider uppercase text-white">Latin Color <span class="text-orange-500">Sports</span></span>
      </div>

      <div class="flex items-center gap-2 sm:gap-4">
	       <a href="login_app.html" class="px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition">Home</a>
        <a href="editar_perfil.php" class="px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition">Perfil</a>
        <button id="logoutButton" class="px-3 py-2 text-xs font-bold uppercase tracking-wider bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl hover:bg-red-600 hover:text-white transition-colors">Salir</button>
      </div>

    </div>
  </div>
</nav>

<div class="max-w-6xl mx-auto px-4 py-8 space-y-6">

    <div class="flex flex-col md:flex-row md:items-center justify-between p-6 bg-[#0f0f0f] border border-white/10 rounded-3xl gap-4 shadow-2xl relative overflow-hidden">
        <div class="absolute -right-16 -top-16 w-36 h-36 bg-orange-600/10 blur-3xl rounded-full"></div>
        <div>
            <p class="text-[10px] uppercase font-black tracking-widest text-orange-500 mb-1">Panel de Fotógrafo</p>
            <h1 id="userName" class="text-xl font-bold text-white">Cargando...</h1>
            <p id="userEmail" class="text-xs text-gray-400 font-mono">Cargando...</p>
        </div>
        <div class="flex items-center gap-2 bg-black/40 px-4 py-2 border border-white/5 rounded-2xl w-fit">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span class="text-xs font-mono text-gray-300">Conexión Segura AWS / Firebase</span>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        <div class="bg-[#0f0f0f] border border-white/10 p-6 rounded-3xl shadow-xl h-fit space-y-4">
            <div>
                <h2 class="text-base font-bold text-white flex items-center gap-2">
                    <span class="text-orange-500">💳</span> Configurar Cuenta
                </h2>
                <p class="text-[11px] text-gray-400">Ingresa o modifica tus credenciales para recibir tus liquidaciones.</p>
            </div>

            <form id="formBancario" class="space-y-4" enctype="multipart/form-data">
                <input type="hidden" id="banco_final" name="banco" required>

                <div>
                    <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Entidad Bancaria</label>
                    <select id="banco_select" required class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 transition-colors text-sm">
                        <option value="">Seleccione banco</option>
                        <option value="Bancolombia">Bancolombia</option>
                        <option value="Banco de Bogotá">Banco de Bogotá</option>
                        <option value="Davivienda">Davivienda</option>
                        <option value="BBVA Colombia">BBVA Colombia</option>
                        <option value="BBVA Mexico">BBVA México</option>
                        <option value="Santander">Santander</option>
                        <option value="Banco Popular">Banco Popular</option>
                        <option value="Banco de Occidente">Banco de Occidente</option>
                        <option value="Scotiabank Colpatria">Scotiabank Colpatria</option>
                        <option value="Banco AV Villas">Banco AV Villas</option>
                        <option value="Banco Caja Social">Banco Caja Social</option>
                        <option value="Bancoomeva">Bancoomeva</option>
                        <option value="Banco Agrario">Banco Agrario</option>
                        <option value="Coopcentral">Coopcentral</option>
                        <option value="GNB Sudameris">GNB Sudameris</option>
                        <option value="Otro" class="text-orange-500 font-bold">Otro (Especificar)</option>
                    </select>
                </div>

                <div id="contenedor-otro-banco" class="hidden">
                    <label for="banco_manual" class="text-[10px] uppercase tracking-wider font-bold text-orange-400 block mb-1">Escribe tu Banco / Billetera Digital</label>
                    <input type="text" id="banco_manual" placeholder="Ej: Nequi, Daviplata, Lulo Bank..." class="w-full bg-black/40 border border-orange-500/30 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 text-sm transition-colors">
                </div>

                <div>
                    <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Tipo de Cuenta</label>
                    <select id="tipo_cuenta" required class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 transition-colors text-sm">
                        <option value="">Seleccione tipo</option>
                        <option value="Ahorros">Ahorros</option>
                        <option value="Corriente">Corriente</option>
                    </select>
                </div>

                <div>
                    <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Número de Cuenta</label>
                    <input id="numero_cuenta" type="text" placeholder="000-000000-00" class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 text-sm font-mono" required>
                </div>

                <div>
                    <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Nombre Completo del Titular</label>
                    <input id="titular" type="text" placeholder="Titular de la cuenta" class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 text-sm" required>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Cédula / Documento</label>
                        <input id="cedula" type="text" placeholder="Cédula" class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 text-sm font-mono" required>
                    </div>
                    <div>
                        <label class="text-[10px] uppercase tracking-wider font-bold text-gray-400 block mb-1">Celular de Contacto</label>
                        <input id="celular" type="text" placeholder="Celular" class="w-full bg-black/40 border border-white/10 text-white p-3 rounded-xl focus:outline-none focus:border-orange-500 text-sm font-mono" required>
                    </div>
                </div>

                <div class="space-y-2 pt-2 border-t border-white/5">
                    <label class="block text-[11px] font-bold text-gray-400">
                        Documento RUT <span class="text-gray-600 font-normal">(PDF, Opcional)</span>
                        <input id="rut_pdf" type="file" accept="application/pdf" class="w-full mt-1 bg-black/30 border border-white/5 p-2 rounded-xl text-xs text-gray-400 focus:outline-none">
                    </label>

                    <label class="block text-[11px] font-bold text-gray-400">
                        Certificación Bancaria <span class="text-gray-600 font-normal">(PDF, Opcional)</span>
                        <input id="cert_bancaria" type="file" accept="application/pdf" class="w-full mt-1 bg-black/30 border border-white/5 p-2 rounded-xl text-xs text-gray-400 focus:outline-none">
                    </label>
                </div>

                <button type="submit" id="btnSubmit" class="w-full bg-orange-600 hover:bg-orange-500 text-white text-xs uppercase font-black tracking-widest py-3.5 px-4 rounded-xl shadow-lg shadow-orange-600/10 transition-all active:scale-[0.98] mt-2">
                    Guardar Datos Bancarios
                </button>
            </form>
        </div>

        <div class="bg-[#0f0f0f] border border-white/10 p-6 rounded-3xl shadow-xl lg:col-span-2 space-y-4">
            <div>
                <h2 class="text-base font-bold text-white flex items-center gap-2">
                    <span class="text-orange-500">🏢</span> Cuentas Registradas
                </h2>
                <p class="text-[11px] text-gray-400">Lista interna de canales de cobro activos para tus eventos deportivos.</p>
            </div>

            <div class="overflow-x-auto border border-white/5 rounded-2xl custom-scrollbar">
                <table class="w-full border-collapse text-left whitespace-nowrap">
                    <thead class="bg-black/50 text-[10px] uppercase font-black tracking-wider text-gray-400 border-b border-white/5">
                        <tr>
                            <th class="px-4 py-3.5">ID</th>
                            <th class="px-4 py-3.5">Banco</th>
                            <th class="px-4 py-3.5">Tipo</th>
                            <th class="px-4 py-3.5">Número de Cuenta</th>
                            <th class="px-4 py-3.5">Titular</th>
                            <th class="px-4 py-3.5">Cédula</th>
                            <th class="px-4 py-3.5">Celular</th>
                            <th class="px-4 py-3.5">Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="registrosBody">
                        <tr>
                            <td colspan="8" class="text-center p-8 text-gray-500 text-sm">
                                <div class="flex items-center justify-center gap-2">
                                    <span class="w-4 h-4 rounded-full border-2 border-t-transparent border-orange-500 animate-spin"></span>
                                    Sincronizando cuentas...
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

</body>
</html>