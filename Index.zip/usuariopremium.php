<style>
    /* Submenu Navbar Desktop (Solo se activa en pantallas grandes) */
    @media (min-width: 768px) {
        .submenu { 
            display: none; 
            position: absolute; 
            background-color: #111; /* Fondo oscuro para que combine con el nav */
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.5); 
            min-width: 14rem; 
            border-radius: 0.5rem; 
            z-index: 50; 
            border: 1px solid #333;
        }
        .group:hover .submenu { display: block; animation: fadeIn 0.2s ease-out; }
    }

    /* Ajustes para Mobile */
    .mobile-submenu { display: none; background-color: #0a0a0a; }
    .mobile-submenu.show { display: block; }
    
    .rotate-icon { transition: transform 0.3s ease; }
    .rotate-180 { transform: rotate(180deg); }

    /* Animación */
    @keyframes fadeIn { 
        from { opacity: 0; transform: translateY(5px); } 
        to { opacity: 1; transform: translateY(0); } 
    }
</style>

<nav class="bg-black shadow-xl sticky top-0 z-50 border-b border-white/10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">

            <div class="flex-shrink-0 flex items-center">
                <img class="h-10 w-auto" src="uploads/LATIN-SPORTS.png" alt="Logo">
                <span class="ml-2 font-black text-xl text-white tracking-tighter italic uppercase">LATIN <span class="text-orange-600">COLOR SPORTS</span></span>
            </div>

            <div class="hidden md:flex md:items-center md:space-x-8">
                <a href="nav_usuarios.php" class="text-gray-300 hover:text-orange-500 font-bold text-sm transition uppercase">Home</a>
                <a href="conjuntodeventospremium.php" class="text-gray-300 hover:text-orange-500 font-bold text-sm transition uppercase">Eventos</a>

                <div class="relative group">
                    <button class="text-gray-300 group-hover:text-orange-500 font-bold text-sm transition flex items-center gap-1 uppercase">
                        Explorar
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div class="submenu mt-2 py-2">
                        <a href="conjuntodeventospremium.php?tipo_evento=Deportivo" class="block px-4 py-2 text-sm text-gray-300 hover:bg-orange-600 hover:text-white transition">Deportivo</a>
                    </div>
                </div>

                <div class="relative group">
                    <button class="text-gray-300 group-hover:text-orange-500 font-bold text-sm transition flex items-center gap-1 uppercase">
                        Mis Compras
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                    </button>
                    <div class="submenu mt-2 py-2">
                        <a href="migaleria.php" class="block px-4 py-2 text-sm text-gray-300 hover:bg-orange-600 hover:text-white transition">Mis Colecciones</a>
                        <a href="miscomprasfotos.php" class="block px-4 py-2 text-sm text-gray-300 hover:bg-orange-600 hover:text-white transition">Mis Fotos</a>
                        <a href="miscomprasvideos.php" class="block px-4 py-2 text-sm text-gray-300 hover:bg-orange-600 hover:text-white transition">Mis Videos</a>
                        <a href="miscompraspaquetes.php" class="block px-4 py-2 text-sm text-gray-300 hover:bg-orange-600 hover:text-white transition">Mis Paquetes</a>
                    </div>
                </div>
            </div>

            <div class="md:hidden flex items-center">
                <button id="mobile-menu-button" class="text-white p-2 focus:outline-none bg-zinc-900 rounded-lg">
                    <svg id="menu-icon" class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path id="path-open" class="block" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                        <path id="path-close" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>

        </div>
    </div>

    <div id="mobile-menu" class="hidden md:hidden bg-black border-t border-white/10 overflow-y-auto max-h-screen">
        <div class="px-4 py-4 space-y-1">
            <a href="nav_usuarios.php" class="block px-4 py-3 text-base font-bold text-white border-b border-white/5 uppercase">Home</a>
            <a href="conjuntodeventospremium.php" class="block px-4 py-3 text-base font-bold text-white border-b border-white/5 uppercase">Eventos</a>
            
            <div>
                <button onclick="toggleAccordion('mobile-sub-explorar', 'icon-explorar')" class="w-full flex justify-between items-center px-4 py-3 text-base font-bold text-white border-b border-white/5 uppercase">
                    Explorar
                    <svg id="icon-explorar" class="w-5 h-5 rotate-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div id="mobile-sub-explorar" class="mobile-submenu">
                    <a href="conjuntodeventospremium.php?tipo_evento=Deportivo" class="block px-8 py-3 text-sm font-medium text-gray-400">Deportivo</a>
                </div>
            </div>

            <div>
                <button onclick="toggleAccordion('mobile-sub-compras', 'icon-compras')" class="w-full flex justify-between items-center px-4 py-3 text-base font-bold text-white border-b border-white/5 uppercase">
                    Mis Compras
                    <svg id="icon-compras" class="w-5 h-5 rotate-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div id="mobile-sub-compras" class="mobile-submenu">
                    <a href="migaleria.php" class="block px-8 py-3 text-sm font-medium text-gray-400">Mis Colecciones</a>
                    <a href="miscomprasfotos.php" class="block px-8 py-3 text-sm font-medium text-gray-400">Mis Fotos</a>
                    <a href="miscomprasvideos.php" class="block px-8 py-3 text-sm font-medium text-gray-400">Mis Videos</a>
                    <a href="miscompraspaquetes.php" class="block px-8 py-3 text-sm font-medium text-gray-400">Mis Paquetes</a>
                </div>
            </div>
        </div>
    </div>
</nav>

<script>
    // Lógica para abrir/cerrar menú principal en móvil
    const btn = document.getElementById('mobile-menu-button');
    const menu = document.getElementById('mobile-menu');
    const pathOpen = document.getElementById('path-open');
    const pathClose = document.getElementById('path-close');

    btn.addEventListener('click', () => {
        const isHidden = menu.classList.contains('hidden');
        menu.classList.toggle('hidden');
        pathOpen.classList.toggle('hidden');
        pathClose.classList.toggle('hidden');
    });

    // Lógica para los acordeones móviles
    function toggleAccordion(id, iconId) {
        const submenu = document.getElementById(id);
        const icon = document.getElementById(iconId);
        
        // Cerrar otros si estuvieran abiertos (opcional)
        submenu.classList.toggle('show');
        icon.classList.toggle('rotate-180');
    }
</script>