<?php
require_once 'dbfotografos.php';
$stmt = $pdo->query("SELECT id, titulo FROM eventos ORDER BY fecha DESC");
$eventos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latin Colors Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <style>
        .lcs-nav { font-family: 'Roboto', sans-serif; }

        /* Header con bordes blancos y gradiente */
        .header-lcs {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f8a700 40%, #f56c1e 60%, #e4312a 100%);
            border-top: 18px solid white;
            border-bottom: 18px solid white;
            height: 100px;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container { display: flex; align-items: center; flex-grow: 1; margin-left: 60px; }
        .nav-links { display: flex; align-items: center; gap: 30px; margin-left:100px; }

        .nav-links a, .nav-links button.nav-btn {
            text-decoration: none;
            color: white;
            font-weight: 900;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
            transition: 0.3s;
            display: flex;
            align-items: center;
            gap: 6px;
            background: none;
            border: none;
            cursor: pointer;
            white-space: nowrap;
        }

        .nav-links a:hover, .nav-links button.nav-btn:hover { color: #ffe29a; }

        /* Sidebar Móvil */
        #sidebarMobile {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 280px;
            background: #0f1724;
            z-index: 2000;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
            box-shadow: 10px 0 30px rgba(0,0,0,0.5);
        }
        #sidebarMobile.open { transform: translateX(0); }
        
        .overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 1900;
            display: none;
        }
        .overlay.visible { display: block; }

        /* Submenús Dropdown (Desktop) */
        .relative { position: relative; }
        .submenu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: white;
            box-shadow: 0 10px 15px rgba(0,0,0,0.2);
            min-width: 180px;
            border-radius: 8px;
            padding: 10px 0;
            border-top: 4px solid #f46616;
            z-index: 1100;
        }
        .relative:hover .submenu { display: block; animation: fadeIn 0.2s ease-out; }
        .submenu a { color: #333 !important; padding: 10px 20px; display: block; font-size: 12px; }
        .submenu a:hover { background: #fff7ed; color: #f46616 !important; }

        /* Barra de búsqueda */
        .search-bar-container { background: #111; padding: 15px; border-bottom: 2px solid #f8a700; }

        #resultados img:hover { transform: scale(1.05); transition: 0.3s; }
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #f97316; border-radius: 10px; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        @media (max-width: 768px) {
            .header-lcs { padding: 0 15px; height: 80px; border-top: 10px solid white; border-bottom: 10px solid white; }
            .nav-container, .idiomas { display: none; }
            #resultadosPanel { left: 5%; right: 5%; width: 90%; position: fixed; top: 25%; }
        }
    </style>
</head>
<body>

<div id="overlay" class="overlay"></div>
<aside id="sidebarMobile">
    <div style="padding: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; justify-content: space-between; align-items: center;">
        <img src="uploads/LATIN-SPORTS.png" style="height: 40px;">
        <button id="closeBtn" style="color: white; font-size: 30px; background: none; border: none; cursor: pointer;">&times;</button>
    </div>
    <nav style="padding: 20px; display: flex; flex-direction: column; gap: 15px;">
        <a href="nav_usuarios.php" style="color: white; text-decoration: none; font-weight: 700; font-size: 16px;">HOME</a>
        <a href="conjuntodeventos.php" style="color: white; text-decoration: none; font-weight: 700; font-size: 16px;">EVENTOS</a>
        <hr style="border: 0; border-top: 1px solid rgba(255,255,255,0.1);">
        <p style="color: #777; font-size: 12px; margin: 0;">MIS COMPRAS</p>
        <a href="migaleria.php" style="color: #f97316; text-decoration: none; font-weight: 600;">MIS COLECCIONES</a>
        <a href="miscomprasfotos.php" style="color: #f97316; text-decoration: none; font-weight: 600;">MIS FOTOS</a>
    </nav>
</aside>

<header class="header-lcs lcs-nav">
    <div class="logo flex items-center">
        <a href="index.php" class="flex items-center">
            <img src="imagenes/LATINCOLOR.png" alt="Logo 1" style="height: 45px; width: auto;">
            <img src="uploads/LATIN-SPORTS.png" alt="Logo 2" style="height: 45px; width: auto; margin-left: 5px;">
        </a>
    </div>

    <div class="nav-container">
        <nav class="nav-links">
            <a href="nav_usuarios.php">Home</a>
            <a href="conjuntodeventos.php">Eventos</a>

            <div class="relative group">
                <button class="nav-btn">
                    Explorar 
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div class="submenu">
                    <a href="conjuntodeventos.php?tipo_evento=Deportivo">DEPORTIVO</a>
                </div>
            </div>

            <div class="relative group">
                <button class="nav-btn">
                    Mis Compras
                    <svg style="width:14px; height:14px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div class="submenu">
                    <a href="migaleria.php">MIS COLECCIONES</a>
                    <a href="miscomprasfotos.php">MIS FOTOS</a>
                </div>
            </div>
        </nav>
    </div>

    <div class="flex items-center gap-4">
        <div class="idiomas hidden md:flex gap-2">
            <img src="imagenes/idioma-01.webp" width="25px" alt="EN">
            <img src="imagenes/idioma-02.webp" width="25px" alt="ES">
        </div>
        <button id="btnMobileMenu" class="md:hidden text-white" style="background: #0f1724; padding: 8px; border-radius: 8px;">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>
        </button>
    </div>
</header>

<div class="search-bar-container">
    <div class="max-w-7xl mx-auto px-4">
        <div id="searchPanel" class="flex flex-col md:flex-row items-center gap-4 justify-center relative">
            
            <div class="w-full md:w-64 flex items-center gap-2">
                <select id="eventoSelect" class="w-full text-sm bg-gray-800 text-white border border-gray-700 rounded-lg p-2.5 focus:ring-2 focus:ring-orange-500 outline-none">
                    <option value="">Seleccione evento</option>
                    <?php foreach($eventos as $e): ?>
                        <option value="<?= htmlspecialchars($e['id']) ?>"><?= htmlspecialchars($e['titulo']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="w-full md:w-auto flex gap-2">
                <label class="flex-1 flex items-center justify-center gap-2 bg-gray-700 hover:bg-gray-600 cursor-pointer text-white rounded-lg px-4 py-2 text-sm transition border border-gray-600">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-orange-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    <span id="fileName">Subir Foto</span>
                    <input type="file" id="faceInput" accept="image/*" class="hidden">
                </label>
                <button id="btnFaceSearch" class="bg-orange-600 hover:bg-orange-700 text-white font-black px-8 py-2 rounded-lg transition shadow-lg uppercase text-sm tracking-widest">
                    BUSCAR ROSTRO
                </button>
            </div>
            
            <div id="resultadosPanel" class="hidden absolute left-1/2 md:left-auto md:right-0 -translate-x-1/2 md:translate-x-0 top-full mt-4 bg-white shadow-2xl rounded-2xl p-4 w-[90%] md:w-[320px] z-[2000] border border-gray-200 text-gray-800">
                <div class="flex justify-between items-center mb-2">
                    <p id="resultadoIA" class="text-orange-600 font-bold text-sm italic"></p>
                    <button onclick="document.getElementById('resultadosPanel').classList.add('hidden')" class="text-gray-400 hover:text-black text-xl">&times;</button>
                </div>
                <div id="resultados" class="grid grid-cols-2 gap-2 max-h-[300px] overflow-y-auto custom-scrollbar p-1"></div>
                <div id="verMasBtn" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<script>
// Lógica de UI - Sidebar Móvil
const sidebar = document.getElementById('sidebarMobile');
const overlay = document.getElementById('overlay');
const btnOpen = document.getElementById('btnMobileMenu');
const btnClose = document.getElementById('closeBtn');

function toggleSidebar() {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('visible');
}

btnOpen.addEventListener('click', toggleSidebar);
btnClose.addEventListener('click', toggleSidebar);
overlay.addEventListener('click', toggleSidebar);

// Mostrar nombre de archivo al subir
document.getElementById('faceInput').addEventListener('change', function(e) {
    const name = e.target.files[0]?.name || "Subir Foto";
    document.getElementById('fileName').textContent = name.length > 15 ? name.substring(0,12) + "..." : name;
});

// IA y Fetch
window.addEventListener('load', async () => {
    const MODEL_URL = '../face-demo/models/';
    try {
        await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL);
        await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
        await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
        console.log("IA Lista");
    } catch(e) { console.error("Error modelos", e); }
});

document.getElementById('btnFaceSearch').addEventListener('click', async () => {
    const input = document.getElementById('faceInput');
    const evento = document.getElementById('eventoSelect').value;
    const panel = document.getElementById('resultadosPanel');
    const cont = document.getElementById('resultados');
    const label = document.getElementById('resultadoIA');

    if (!input.files[0] || !evento) return alert('Seleccione evento y foto');

    panel.classList.remove('hidden');
    label.textContent = "Procesando...";
    cont.innerHTML = `<div class="col-span-2 text-center py-4 text-gray-400 text-xs italic">Analizando facciones...</div>`;

    const img = await faceapi.bufferToImage(input.files[0]);
    const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();
    
    if (!detection) {
        label.textContent = "Rostro no detectado";
        cont.innerHTML = "";
        return;
    }

    const fd = new FormData();
    fd.append('evento_id', evento);
    fd.append('foto', input.files[0]);
    fd.append('descriptors', JSON.stringify(Array.from(detection.descriptor)));

    try {
        const res = await fetch('buscar_rosto.php', { method:'POST', body:fd });
        const data = await res.json();
        cont.innerHTML = "";
        if (!data.fotos?.length) {
            label.textContent = "Sin coincidencias";
            return;
        }
        label.textContent = `Encontradas: ${data.total}`;
        data.fotos.forEach(f => {
            const a = document.createElement('a');
            a.href = `ver_foto.php?id=${f.id}`;
            a.innerHTML = `<img src="miniatura.php?img=${encodeURIComponent(f.url)}&w=150" class="w-full aspect-square object-cover rounded-lg border border-gray-200">`;
            cont.appendChild(a);
        });
        if (data.total > 4) {
            document.getElementById('verMasBtn').innerHTML = `
                <a href="resultados_totales.php?id=${evento}" class="block text-center bg-orange-600 text-white py-2 rounded-xl text-xs font-bold">
                    VER TODO (${data.total})
                </a>`;
        }
    } catch(e) { label.textContent = "Error en servidor"; }
});
</script>
</body>
</html>