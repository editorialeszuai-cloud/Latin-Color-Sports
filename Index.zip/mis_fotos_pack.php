<?php
require 'dbfotografos.php';
header('Content-Type: application/json');

$pdo = conectar();

$data = json_decode(file_get_contents('php://input'), true);
$uid = $data['firebase_uid'] ?? null;

if (!$uid) {
    echo json_encode(['success' => false, 'fotos' => []]);
    exit;
}

// Tu clave secreta para el hash SHA-256
$secret_key = "LAtinSportSCoLOrs2026";

try {
    $sql = "
        SELECT 
            c.id AS compra_id,
            dc.evento_id,
            e.titulo AS evento_titulo,
            'pack' as tipo,
            (SELECT url FROM fotos WHERE evento_id = dc.evento_id LIMIT 1) as foto_preview
        FROM compras c
        INNER JOIN detalle_compras dc ON c.id = dc.id_compra
        INNER JOIN eventos e ON e.id = dc.evento_id
        WHERE c.firebase_uid = :uid
          AND c.estado = 'APPROVED'
          AND dc.id_foto IS NULL
        ORDER BY c.id DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['uid' => $uid]);
    
    // Obtenemos los resultados de PDO
    $packs_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $packs_finales = [];

    // Procesamos cada fila para agregar el HASH
    foreach ($packs_raw as $fila) {
        // Generamos el hash HMAC SHA-256
        // Usamos evento_id porque es el identificador del pack
        $fila['hash'] = hash_hmac('sha256', $fila['evento_id'], $secret_key);
        
        $packs_finales[] = $fila;
    }

    // Enviamos UNA SOLA respuesta JSON
    echo json_encode([
        'success' => true, 
        'fotos' => $packs_finales
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>