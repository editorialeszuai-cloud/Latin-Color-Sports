<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Comercial | Latin Color Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f3f4f6; }
        .glass-nav { background: rgba(11, 18, 32, 0.95); backdrop-filter: blur(10px); }
    </style>
</head>
<body class="bg-gray-100">

<nav class="glass-nav shadow-xl sticky top-0 z-50 border-b border-white/10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-20 items-center">

            <div class="flex-shrink-0 flex items-center gap-3">
                <img class="h-12 w-auto" src="uploads/LATIN-SPORTS.png" alt="Logo">
            </div>

            <div class="hidden md:flex md:items-center md:space-x-8">
                <a href="nav_comercial.php" class="text-white hover:text-orange-400 font-semibold transition">Home</a>
                <a href="ver_eventoscomercial.php" class="text-gray-300 hover:text-orange-400 font-medium transition">Mis Eventos</a>
                <a href="comisioncom.php" class="text-gray-300 hover:text-orange-400 font-medium transition">Comisión</a>
                <a href="datos_bancarios.php" class="text-gray-300 hover:text-orange-400 font-medium transition">Datos Bancarios</a>
                
                <div class="flex items-center gap-4 pl-6 border-l border-white/10">
                    <div class="text-right">
                        <div class="flex items-center justify-end gap-2">
                            <span id="userRole" class="text-[9px] font-black px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-500 uppercase">Cargando...</span>
                            <span id="userName" class="font-bold text-white text-sm">Cargando...</span>
                        </div>
                        <button id="toggleInfo" class="text-[10px] text-gray-400 hover:text-white transition uppercase tracking-widest font-bold">
                            Cuenta <span id="arrow">▼</span>
                        </button>
                    </div>
                    
                    <div class="relative group">
                        <img id="userFotoPerfil" 
                             src="uploads/perfil.jpg" 
                             onerror="this.src='uploads/perfil.jpg'"
                             class="w-12 h-12 rounded-2xl object-cover border-2 border-orange-500/50 shadow-lg cursor-pointer">
                        
                        <div id="moreInfo" class="absolute right-0 mt-3 w-64 hidden bg-[#0b1220] border border-white/10 p-4 rounded-2xl shadow-2xl text-xs z-50">
                            <p class="text-gray-400 uppercase font-black text-[9px] mb-1">ID Usuario</p>
                            <p id="userId" class="text-white font-mono mb-3 break-all">...</p>
                            <p class="text-gray-400 uppercase font-black text-[9px] mb-1">Email</p>
                            <p id="userEmail" class="text-white font-medium">...</p>
                            <hr class="my-3 border-white/10">
                            <a href="editar_perfil.php" class="block w-full text-center py-2 bg-orange-500 text-white rounded-lg font-bold hover:bg-orange-600 transition">Editar Perfil</a>
                        </div>
                    </div>

                    <button id="logoutButton" class="p-2 bg-red-600/20 hover:bg-red-600 rounded-xl text-red-500 hover:text-white transition">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                        </svg>
                    </button>
                </div>
            </div>

            <div class="md:hidden flex items-center">
                <button id="mobile-menu-button" class="text-white p-2">
                    <svg class="h-8 w-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <div id="mobile-menu" class="md:hidden hidden bg-[#0b1220] border-t border-white/5 p-4 space-y-4">
        <a href="#" class="block px-4 py-3 text-white font-bold bg-white/5 rounded-xl">Home</a>
        <a href="ver_eventoscomercial.php" class="block px-4 py-3 text-gray-400">Mis Eventos</a>
        <a href="comisioncom.php" class="block px-4 py-3 text-gray-400">Comisión</a>
        <a href="datos_bancarios.php" class="block px-4 py-3 text-gray-400">Datos Bancarios</a>
        <a href="editar_perfil.php" class="block px-4 py-3 text-orange-500 font-bold italic">Editar Perfil</a>
        <button id="logoutButtonMobile" class="w-full py-4 bg-red-600 text-white rounded-2xl font-bold uppercase tracking-widest text-xs">Cerrar Sesión</button>
    </div>
</nav>

<main class="max-w-7xl mx-auto p-6 mt-4">
    <section class="relative overflow-hidden bg-white rounded-[3rem] shadow-2xl border border-gray-100">
        <div class="relative z-10 px-8 py-20 flex flex-col items-center text-center">
            <h1 class="text-4xl md:text-6xl font-black text-gray-900 leading-tight uppercase">
                ¡HOLA, <span id="welcomeName" class="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-orange-600">ORGANIZADOR</span>!
            </h1>
            <p class="mt-6 text-lg text-gray-500 max-w-xl">Bienvenido a Latin Color Sports.</p>
        </div>
    </section>
    <div id="roleContent" class="mt-10"></div>
</main>

<script>
    // Toggle menu
    const mobileBtn = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    mobileBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));

    const toggleBtn = document.getElementById('toggleInfo');
    const moreInfo = document.getElementById('moreInfo');
    toggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        moreInfo.classList.toggle('hidden');
    });
    document.addEventListener('click', () => moreInfo.classList.add('hidden'));
</script>

<script type="module">
    import { auth } from './firebase-config.js';
    import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

    const roleContentDiv = document.getElementById('roleContent');
    const userFotoImg = document.getElementById('userFotoPerfil');
    const userRoleSpan = document.getElementById('userRole');
    const userNameSpan = document.getElementById('userName');
    const welcomeName = document.getElementById('welcomeName');
    const userIdSpan = document.getElementById('userId');
    const userEmailSpan = document.getElementById('userEmail');

  function updateUI(userData) {
    const { firebase_uid, email, nombre, rol, foto_perfil } = userData;

    userIdSpan.textContent = firebase_uid || 'N/A';
    // Cambiado: si no hay email, mostrará un guion o vacío en lugar de "Sin correo"
    userEmailSpan.textContent = email || '-'; 
    userNameSpan.textContent = nombre || 'Usuario';
    welcomeName.textContent = nombre ? nombre.split(' ')[0] : 'ORGANIZADOR';
    userRoleSpan.textContent = rol || 'Invitado';

    // ... resto de tu lógica de inyección de panel

        // --- SOLUCIÓN DEFINITIVA PARA LA FOTO ---
        if (foto_perfil && foto_perfil.trim() !== '') {
            // Quitamos 'uploads/' si ya lo trae para que no se repita
            const fileName = foto_perfil.replace('uploads/', '');
            // Añadimos un timestamp (?t=...) para que el navegador no use la imagen vieja guardada en memoria
            userFotoImg.src = `uploads/${fileName}?t=${new Date().getTime()}`;
        } else {
            userFotoImg.src = 'uploads/perfil.jpg';
        }

        if(rol === 'comercial' || rol === 'admin'){
            roleContentDiv.innerHTML = `
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-orange-500 text-white p-8 rounded-[2.5rem] shadow-xl">
                        <h3 class="text-2xl font-black italic uppercase italic">Eventos Activos</h3>
                        <a href="ver_eventoscomercial.php" class="mt-6 inline-block bg-white text-orange-500 px-6 py-2 rounded-xl font-bold uppercase text-xs">Ir a Eventos</a>
                    </div>
                </div>`;
        }
    }

    onAuthStateChanged(auth, async (user) => {
        if (user) {
            try {
                const token = await user.getIdToken();
                const res = await fetch('get_user_info.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ firebase_token: token })
                });
                const data = await res.json();
                if (data.status === 'success' && data.user) {
                    updateUI(data.user);
                }
            } catch (err) {
                console.error(err);
            }
        } else {
            window.location.href = 'login_app.html';
        }
    });

    document.getElementById('logoutButton').addEventListener('click', () => signOut(auth).then(() => window.location.href = 'login_app.html'));
    document.getElementById('logoutButtonMobile').addEventListener('click', () => signOut(auth).then(() => window.location.href = 'login_app.html'));
</script>
</body>
</html>