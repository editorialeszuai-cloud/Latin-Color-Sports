<?php
// Evitar cualquier salida de texto antes del JSON
ob_start();

// Cabecera JSON obligatoria
header("Content-Type: application/json; charset=utf-8");

// Cargar librerías de Composer
require_once __DIR__ . '/vendor/autoload.php';

// Cargar conexión a BD
require_once "db.php";

use Kreait\Firebase\Factory;

try {
    // Obtener datos del cuerpo de la petición
    $json = file_get_contents("php://input");
    $data = json_decode($json, true);
    $token = $data['firebase_token'] ?? null;

    if (!$token) {
        throw new Exception("Token no recibido");
    }

    // Inicializar Firebase
    $jsonPath = __DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json';
    
    if (!file_exists($jsonPath)) {
        throw new Exception("Archivo JSON de Firebase no encontrado en la ruta configurada");
    }

    $factory = (new Factory())->withServiceAccount($jsonPath);
    $auth = $factory->createAuth();

    // Validar Token
    $verifiedIdToken = $auth->verifyIdToken($token);
    $uid = $verifiedIdToken->claims()->get('sub');

    // Consultar MySQL
    // SI EN TU db.php TU VARIABLE ES $conn, CAMBIA $pdo POR $conn ABAJO
    if (!isset($pdo)) {
        throw new Exception("Variable de conexión \$pdo no encontrada");
    }

    $stmt = $pdo->prepare("SELECT id, firebase_uid, nombre, rol, foto_perfil FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Limpiar el buffer de salida para asegurar que solo se envíe el JSON
    ob_end_clean();

    if ($user) {
        echo json_encode(["status" => "success", "user" => $user]);
    } else {
        echo json_encode(["status" => "error", "message" => "Usuario no existe en BD"]);
    }

} catch (Exception $e) {
    ob_end_clean();
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>