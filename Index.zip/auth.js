// auth.js
import { auth } from './firebase-config.js';
import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  FacebookAuthProvider,
  signInWithPopup,
  updateProfile
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// 2. REFERENCIAS AL DOM
const nombreInput = document.getElementById('nombre');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const userRoleSelect = document.getElementById('userRole');
const registerEmailButton = document.getElementById('registerEmail');
const googleRegisterButton = document.getElementById('googleRegister');
const facebookRegisterButton = document.getElementById('facebookRegister');
const messageDiv = document.getElementById('message');

// 3. FUNCIÓN PARA MOSTRAR MENSAJES
function showMessage(text, type = 'info') {
  if (!messageDiv) return console.warn('messageDiv no encontrado en el DOM.');
  messageDiv.textContent = text;
  messageDiv.className = `message ${type}`;
  messageDiv.style.display = 'block';
  console.log(`[${type.toUpperCase()}] ${text}`);
}

// 4. FUNCIÓN PARA OBTENER EL ROL DESDE EL BACKEND
async function verificarRolDesdeServidor(firebaseUid) {
  try {
    const res = await fetch(`get_rol.php?firebase_uid=${encodeURIComponent(firebaseUid)}`);
    if (!res.ok) throw new Error('Error al consultar el rol del servidor.');
    const data = await res.json();
    if (data.status !== 'success') throw new Error(data.message || 'Error al obtener rol.');
    return data.rol;
  } catch (error) {
    console.error("❌ Error en verificarRolDesdeServidor:", error);
    return 'cliente';
  }
}

// 5. FUNCIÓN PARA ENVIAR DATOS AL BACKEND (Recibe el user como parámetro)
function sendUserToPHP(user, extraData = {}) {
  if (!user) {
    showMessage('Error: No se pudo obtener la sesión de usuario.', 'error');
    return;
  }

  user.getIdToken(true)
    .then(idToken => {
      const dataToSend = {
        idToken,
        firebase_uid: user.uid,
        email: user.email || emailInput.value.trim(),
        nombre: user.displayName || nombreInput.value.trim(),
        foto_perfil: user.photoURL || '',
        ...extraData
      };

      return fetch('roles.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSend)
      });
    })
    .then(res => res.json())
    .then(async data => {
      if (data.status !== 'success') throw new Error(data.message || 'Error del servidor.');
      showMessage('¡Operación exitosa!', 'success');
      
      const rolVerificado = await verificarRolDesdeServidor(user.uid);
      const rutasPorRol = {
        fotografo: 'menu_fotografo.php',
        cliente: 'nav_usuarios.php',
        organizador: 'nav_organizador.php',
        comercial: 'nav_comercial.php'
      };

      const redirectUrl = rutasPorRol[rolVerificado] || 'login.php';
      setTimeout(() => { window.location.href = redirectUrl; }, 1500);
    })
    .catch(error => {
      console.error('❌ Error en sendUserToPHP:', error);
      showMessage('Error al conectar con el servidor: ' + error.message, 'error');
    });
}

// 6. VALIDAR ROL
function getSelectedRole() {
  const rol = userRoleSelect?.value || '';
  if (!rol) {
    showMessage('⚠️ Debes seleccionar un rol antes de registrarte.', 'error');
    throw new Error('Rol no seleccionado');
  }
  return rol;
}

// 7. REGISTRO CON EMAIL
registerEmailButton?.addEventListener('click', async () => {
  try {
    const nombre = nombreInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();
    const rol = getSelectedRole();

    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    await updateProfile(user, { displayName: nombre });
    
    sendUserToPHP(user, { nombre, rol });
  } catch (error) {
    if (error.code === 'auth/email-already-in-use') {
      showMessage('Este correo ya está registrado.', 'error');
    } else {
      showMessage('Error: ' + error.message, 'error');
    }
  }
});

// 8. GOOGLE
googleRegisterButton?.addEventListener('click', async () => {
  try {
    const rol = getSelectedRole();
    const result = await signInWithPopup(auth, new GoogleAuthProvider());
    sendUserToPHP(result.user, { rol });
  } catch (error) {
    showMessage('Error con Google: ' + error.message, 'error');
  }
});

// 9. FACEBOOK
facebookRegisterButton?.addEventListener('click', async () => {
  try {
    const rol = getSelectedRole();
    const result = await signInWithPopup(auth, new FacebookAuthProvider());
    sendUserToPHP(result.user, { rol });
  } catch (error) {
    showMessage('Error con Facebook: ' + error.message, 'error');
  }
});