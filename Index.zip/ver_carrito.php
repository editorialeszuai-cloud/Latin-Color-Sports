<?php
// Reporte de errores para desarrollo
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'dbfotografos.php';

$firebase_uid = $_GET['firebase_uid'] ?? '';
if (!$firebase_uid) {
    die('<div class="p-10 text-center text-gray-500 text-[10px] font-black uppercase">Inicia sesión para ver tu carrito</div>');
}

try {
    // 1. CONSULTA DE PACKS
    $stmtPacks = $pdo->prepare("
        SELECT c.id AS carrito_id, e.id AS evento_id, e.titulo AS evento_titulo, l.pais AS pais_lugar
        FROM carrito c
        LEFT JOIN eventos e ON c.evento_id = e.id
        LEFT JOIN lugares l ON e.lugar_id = l.id
        WHERE c.firebase_uid = ? AND c.foto_id IS NULL
    ");
    $stmtPacks->execute([$firebase_uid]);
    $packs_items = $stmtPacks->fetchAll(PDO::FETCH_ASSOC);

    // 2. CONSULTA DE FOTOS CORREGIDA CON JERARQUÍA (Fotos -> Galerias -> Postulaciones -> Eventos)
    $stmtFotos = $pdo->prepare("
        SELECT 
            c.id AS carrito_id, 
            f.url AS nombre_archivo, 
            f.id AS foto_id, 
            e.id AS evento_id, 
            e.titulo AS evento_titulo, 
            e.paquetes_eventos,
            l.pais AS pais_lugar
        FROM carrito c
        LEFT JOIN fotos f ON c.foto_id = f.id
        LEFT JOIN galerias g ON f.galeria_id = g.id
        LEFT JOIN postulaciones p ON g.postulacion_id = p.id
        LEFT JOIN eventos e ON p.evento_id = e.id
        LEFT JOIN lugares l ON e.lugar_id = l.id
        WHERE c.firebase_uid = ? AND c.foto_id IS NOT NULL
    ");
    $stmtFotos->execute([$firebase_uid]);
    $raw_fotos = $stmtFotos->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die('<div class="p-4 bg-red-900 text-white">Error SQL: ' . $e->getMessage() . '</div>');
}

$fotos_procesadas = [];
$total_carrito = 0;
$grupos = [];
$es_colombia = true;

// Procesar fotos y detectar moneda
foreach ($raw_fotos as $item) {
    if (isset($item['pais_lugar']) && trim(strtolower($item['pais_lugar'])) !== 'colombia') {
        $es_colombia = false;
    }
    $eid = $item['evento_id'] ?? 'sin_evento';
    $grupos[$eid][] = $item;
}

// Calcular precios de fotos por volumen (PRECIO DINÁMICO)
foreach ($grupos as $evento_id => $fotos) {
    $precio_unidad = 0; // Iniciamos en 0 para que tome el valor de la base de datos
    
    if ($evento_id !== 'sin_evento' && !empty($fotos[0]['paquetes_eventos'])) {
        $paquetes_ids = json_decode($fotos[0]['paquetes_eventos'], true);
        if (is_array($paquetes_ids) && !empty($paquetes_ids)) {
            $in = str_repeat('?,', count($paquetes_ids) - 1) . '?';
            $stmtP = $pdo->prepare("SELECT precio_por_unidad, unidades_incluidas FROM paquetes_fotos WHERE id IN ($in) ORDER BY unidades_incluidas DESC");
            $stmtP->execute($paquetes_ids);
            $paquetes_info = $stmtP->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($paquetes_info as $pkg) {
                if (count($fotos) >= (int)$pkg['unidades_incluidas']) {
                    $precio_unidad = (float)$pkg['precio_por_unidad'];
                    break;
                }
            }
        }
    }
    
    foreach ($fotos as $f) {
        $f['precio_final'] = $precio_unidad;
        $fotos_procesadas[] = $f;
        $total_carrito += $precio_unidad;
    }
}

// 3. PROCESAR PRECIO DE LOS PACKS
foreach ($packs_items as &$pack) {
    $es_colombia_pack = (isset($pack['pais_lugar']) && trim(strtolower($pack['pais_lugar'])) === 'colombia');
    $nombre_paquete = $es_colombia_pack ? 'Todas Las Fotos' : 'Todas Las Fotos Internacional';

    $stmtP = $pdo->prepare("SELECT precio_por_unidad FROM paquetes_fotos WHERE nombre_paquete = ? LIMIT 1");
    $stmtP->execute([$nombre_paquete]);
    $res = $stmtP->fetch(PDO::FETCH_ASSOC);
    
    $precio_pack = $res ? (float)$res['precio_por_unidad'] : 0;
    $pack['precio_final'] = $precio_pack;
    $total_carrito += $precio_pack; 
}
unset($pack);

$cantidad_total = count($fotos_procesadas) + count($packs_items);
$moneda = $es_colombia ? 'COP' : 'USD';
?>
<div class="flex flex-col h-full bg-gray-950 text-white">
    
    <div class="px-6 py-4 bg-gradient-to-r from-orange-600/10 to-transparent border-b border-orange-500/20">
        <div class="flex items-start gap-3">
            <div class="bg-orange-500/20 p-2 rounded-lg">
                <svg class="w-5 h-5 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5A5 5 0 017 10H5a7 7 0 007 7h4a7 7 0 007-7h-2a5 5 0 01-5-5z"></path>
                </svg>
            </div>
            <div>
                <h3 class="text-[11px] font-bold text-orange-500 uppercase tracking-widest">¡Oferta Especial!</h3>
                <p class="text-[10px] text-gray-400 leading-tight mt-0.5">
                    Compra más fotos y recibe un <span class="text-white font-bold">15% de descuento</span> adicional. 
                    <?php 
                    $id_evento = (!empty($fotos_procesadas)) ? $fotos_procesadas[0]['evento_id'] : 
                                 (!empty($packs_items) ? $packs_items[0]['evento_id'] : 0);
                    
                    if ($id_evento > 0): ?>
                        <a href="combos_fotos.php?evento_id=<?= (int)$id_evento ?>" 
                           class="text-white underline hover:text-orange-400 transition-colors ml-1">
                            Revisa nuestros combos
                        </a>
                    <?php else: ?>
                        <span class="text-gray-500 italic ml-1">Selecciona fotos para ver combos</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>

    <div class="flex-1 overflow-y-auto p-4 custom-scroll pb-10">
        <?php if ($cantidad_total == 0): ?>
            <div class="flex flex-col items-center justify-center py-20 opacity-30">
                <span class="material-icons text-5xl mb-3">local_mall</span>
                <p class="text-[10px] font-black uppercase tracking-widest text-center">No hay fotos seleccionadas</p>
            </div>
        <?php else: ?>
            
            <?php foreach ($packs_items as $pack): 
                $es_colombia_pack = (isset($pack['pais_lugar']) && trim(strtolower($pack['pais_lugar'])) === 'colombia');
            ?>
                <div class="mb-4 p-4 bg-gradient-to-r from-orange-600/20 to-gray-800/40 border border-orange-500/30 rounded-2xl flex justify-between items-start shadow-lg">
                    <div class="flex flex-col gap-1">
                        <div>
                            <p class="text-[9px] font-black text-orange-400 uppercase tracking-tighter">Pack Full Access</p>
                            <p class="text-xs font-bold truncate max-w-[180px]"><?= htmlspecialchars($pack['evento_titulo']) ?></p>
                        </div>
                        <p class="font-black text-xl text-white mt-1">
                            <?php if ($es_colombia_pack): ?>
                                $<?= number_format($pack['precio_final'], 0, ',', '.') ?>
                            <?php else: ?>
                                $<?= number_format($pack['precio_final'], 2, '.', ',') ?> <span class="text-sm font-normal">USD</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <button class="js-btn-eliminar-evento p-2 text-gray-500 hover:text-red-500 transition-colors" data-evento-id="<?= $pack['evento_id'] ?>">
                        <span class="material-icons text-sm">close</span>
                    </button>
                </div>
            <?php endforeach; ?>

            <div class="space-y-2">
                <?php foreach ($fotos_procesadas as $f): ?>
                    <div class="p-2 bg-white/5 rounded-xl flex items-center gap-3 border border-white/5">
                        <img src="minion.php?id=<?= urlencode($f['foto_id']) ?>&tipo=mini" 
                             class="w-12 h-12 object-cover rounded-lg shadow-sm" 
                             alt="Miniatura ##<?= $f['foto_id'] ?>">
                        
                        <div class="flex-1">
                            <p class="text-[10px] font-bold">Foto #<?= $f['foto_id'] ?></p>
                            <p class="text-orange-500 text-[11px] font-black italic">
                                $<?= $es_colombia ? number_format($f['precio_final'], 0, ',', '.') : number_format($f['precio_final'], 2, '.', ',') ?>
                                <?= !$es_colombia ? ' USD' : '' ?>
                            </p>
                        </div>
                       <button class="js-btn-eliminar group flex items-center justify-center p-3 rounded-full bg-slate-800/50 hover:bg-red-600 border border-white/5 transition-all duration-300 active:scale-90" 
        data-id="<?= $f['carrito_id'] ?>">
    <span class="material-icons text-lg text-slate-400 group-hover:text-white transition-colors">delete_forever</span>
</button>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($cantidad_total > 0): ?>
        <div class="p-6 bg-gray-900 border-t border-white/10 shadow-[0_-20px_40px_rgba(0,0,0,0.8)]">
            <div class="flex justify-between items-end mb-4 px-2">
                <div class="flex flex-col">
                    <span class="text-orange-500 text-[10px] font-black uppercase tracking-[2px] mb-1">Total a pagar</span>
                </div>
                <p class="text-4xl font-black text-white">
                    <?= $es_colombia ? '$'.number_format($total_carrito, 0, ',', '.') : '$'.number_format($total_carrito, 2, '.', ',').' USD' ?>
                </p>
            </div>
            
            <a id="btnConfirmar" 
               href="pre_checkout.php?firebase_uid=<?= urlencode($firebase_uid) ?>&moneda=<?= urlencode($moneda) ?>"
               class="group block w-full bg-orange-600 hover:bg-orange-500 text-white font-black py-5 rounded-2xl text-center uppercase text-[11px] tracking-[2px] transition-colors shadow-lg shadow-orange-600/20">
                Confirmar Pedido
            </a>

            <p class="text-center text-[8px] text-gray-600 uppercase mt-3 tracking-widest font-bold">
                Pago 100% Seguro vía <?= $es_colombia ? 'Wompi (Bancolombia, Nequi / PSE)' : 'PayPal' ?>
            </p>
        </div>
    <?php endif; ?>
</div>

<style>
.custom-scroll::-webkit-scrollbar { width: 4px; }
.custom-scroll::-webkit-scrollbar-track { background: transparent; }
.custom-scroll::-webkit-scrollbar-thumb { background: #444; border-radius: 10px; }
.custom-scroll::-webkit-scrollbar-thumb:hover { background: #f97316; }
</style>