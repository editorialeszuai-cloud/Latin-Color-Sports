<?php
header('Content-Type: application/json; charset=utf-8');
include 'dbfotografos.php';

$accion = $_POST['accion'] ?? '';

switch ($accion) {

  case 'listar_fotografos':
    try {
      $stmt = $pdo->prepare("SELECT id, nombre, rol FROM usuarios WHERE rol = 'fotografo' ORDER BY nombre");
      $stmt->execute();
      echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    } catch (Exception $e) {
      echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    break;

  default:
    echo json_encode(['success' => false, 'message' => 'Acción no válida']);
}
?>
