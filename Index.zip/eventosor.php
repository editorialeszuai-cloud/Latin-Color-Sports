<?php
// conjuntodeventos.php

// 1. Inclusi¨®n de archivos obligatorios
require_once 'dbfotografos.php'; 

// Forzar codificaci¨®n
header('Content-Type: text/html; charset=utf-8');

// 2. Bloque de Auditor¨ªa de Navegaci¨®n
try {
    if (isset($pdo)) {
        $ip = $_SERVER['REMOTE_ADDR'];
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]; 
        }
        $ua = $_SERVER['HTTP_USER_AGENT'];

        $sql_audit = "INSERT INTO auditoria_navegacion 
                      (usuario_id, nombre_usuario, rol, pagina_visitada, ip_acceso, user_agent) 
                      VALUES (:uid, :nom, :rol, :pag, :ip, :ua)";
        
        $stmt_audit = $pdo->prepare($sql_audit);
        $stmt_audit->execute([
            ':uid' => 'Anonimo', 
            ':nom' => 'Visita Catalogo', 
            ':rol' => 'Public',
            ':pag' => 'CONJUNTO_EVENTOS', 
            ':ip'  => $ip, 
            ':ua'  => $ua
        ]);
    }
} catch (Exception $e) {
    error_log("Error de auditor¨ªa: " . $e->getMessage());
}

// 3. Captura de variables de b¨²squeda
$search = $_GET['search'] ?? '';
$tipo = $_GET['tipo_evento'] ?? '';

// 4. Consulta Principal de Eventos
$sql = "
    SELECT 
        e.*, 
        l.ciudad, 
        l.pais,
        COUNT(f.id) AS total_fotos,
        GROUP_CONCAT(DISTINCT u.nombre SEPARATOR ', ') AS fotografos
    FROM eventos e
    LEFT JOIN lugares l ON e.lugar_id = l.id
    LEFT JOIN postulaciones p ON p.evento_id = e.id
    LEFT JOIN fotos f ON f.postulacion_id = p.id
    LEFT JOIN usuarios u ON p.usuario_id = u.id
    WHERE 1=1
";

$params = [];
if (!empty($search)) { $sql .= " AND e.titulo LIKE ? "; $params[] = "%$search%"; }
if (!empty($tipo)) { $sql .= " AND e.tipo_evento = ? "; $params[] = $tipo; }

$sql .= " GROUP BY e.id ORDER BY e.created_at DESC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $tiposStmt = $pdo->query("SELECT DISTINCT tipo_evento FROM eventos WHERE tipo_evento IS NOT NULL AND tipo_evento <> '' ORDER BY tipo_evento ASC");
    $tipos = $tiposStmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    die("Error en la consulta: " . $e->getMessage());
}
?>
<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos | Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
		<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --red-latin: #ed1c24;
            --orange-latin: #f7941d;
            --yellow-latin: #ffc72c;
        }

        body { font-family: 'Montserrat', sans-serif; background-color: #f3f4f6; }

        /* --- WHATSAPP --- */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 30px;
            right: 30px;
            background-color: #25d366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            z-index: 9999;
            animation: pulse-whatsapp 2s infinite;
        }
        .whatsapp-float img { width: 35px; height: 35px; }
        @keyframes pulse-whatsapp {
            0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(37, 211, 102, 0); }
            100% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
        }

        /* --- OVERLAY --- */
        .menu-overlay {
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(4px);
            visibility: hidden; opacity: 0;
            transition: 0.4s; z-index: 4000;
        }
        .menu-overlay.active { visibility: visible; opacity: 1; }

        /* --- HEADER UNIFICADO --- */
        .header-lcs {
            display: flex; justify-content: space-between; align-items: center;
            padding: 0 15px;
            background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f56c1e 60%, #e4312a 100%);
            border-top: 6px solid white; border-bottom: 6px solid white;
            height: 75px; position: sticky; top: 0; z-index: 5000;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .logo-lcs a { display: flex; align-items: center; text-decoration: none; }
        .logo-lcs img { height: 35px; width: auto; }

        .right-side { display: flex; align-items: center; gap: 15px; }
        .nav-links { display: flex; align-items: center; gap: 15px; }
        .nav-links a {
            text-decoration: none; color: white; font-weight: 800; font-size: 11px; text-transform: uppercase;
        }

        .btn-login-lcs {
            background-color: var(--yellow-latin) !important; color: #000 !important;
            padding: 8px 12px !important; border-radius: 4px;
            transform: skewX(-12deg); display: inline-block;
        }
        .btn-login-lcs span { display: inline-block; transform: skewX(12deg); font-weight: 900; }

        .hamburger {
            display: none; cursor: pointer; flex-direction: column; gap: 5px; width: 30px; z-index: 5100;
        }
        .hamburger span { display: block; width: 100%; height: 3px; background-color: white; border-radius: 2px; }

        @media (max-width: 1100px) {
            .nav-links {
                position: fixed; top: 0; left: -100%; width: 280px; height: 100vh;
                background: var(--red-latin); flex-direction: column;
                justify-content: flex-start; align-items: flex-start;
                padding: 100px 0 0 40px; gap: 25px; transition: 0.5s; z-index: 4500;
            }
            .nav-links.active { left: 0; }
            .hamburger { display: flex; }
            .hamburger.open span:nth-child(1) { transform: translateY(8px) rotate(45deg); }
            .hamburger.open span:nth-child(2) { opacity: 0; }
            .hamburger.open span:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }
        }

        .line-clamp-2 { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
		/* Contenedor de las banderas */
.idiomas {
  display: flex;
  gap: 8px; /* espacio entre las banderas */
  align-items: center;
}

/* Opcional: mejora visual de las banderas */
.idiomas img {
  cursor: pointer;
  transition: transform 0.2s ease;
}

.idiomas img:hover {
  transform: scale(1.1); /* efecto al pasar el ratón */
}

    </style>
</head>
<body class="pb-10">

    <div class="menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>
    <a href="https://wa.me/573142958463" class="whatsapp-float" target="_blank">
        <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp">
    </a>

    <header class="header-lcs">
        <div class="logo-lcs">
            <a href="index.php">
                <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;height:auto;">
                <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="margin-left: 5px;width:85px;height:auto;">
            </a>
        </div>

        <div class="right-side">
            <nav class="nav-links" id="navLinks">
			 <a href="index.php">INICIO</a>
                <a href="eventosadmin.php">EVENTOS</a>
                <a href="comisionor.php">VENTAS</a>
                <a href="logout.php" class="btn-login-lcs"><span>CERRAR SESIÓN<span></a>
				
				 <div class="idiomas">
    <img src="imagenes/idioma-01.webp" width="22px" alt="EN" onclick="applyLanguage('en')">
    <img src="imagenes/idioma-02.webp" width="22px" alt="ES" onclick="applyLanguage('es')">
</div>
            </nav>
			
			
            <div class="hamburger" id="hamburger" onclick="toggleMenu()">
                <span></span><span></span><span></span>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        <h1 class="text-2xl md:text-4xl font-black mb-8 text-center text-gray-900 uppercase tracking-tighter italic">
            Eventos <span class="text-orange-600">Disponibles</span>
        </h1>

        <form method="GET" class="mb-10 bg-white p-4 rounded-2xl shadow-sm border border-gray-100 max-w-4xl mx-auto">
            <div class="flex flex-col md:flex-row gap-3">
                <div class="relative flex-1">
                    <input 
                        type="text" 
                        name="search" 
                        value="<?= htmlspecialchars($search) ?>" 
                        placeholder="Nombre del evento..." 
                        class="w-full pl-4 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-sm"
                    >
                </div>

                <select 
                    name="tipo_evento" 
                    class="w-full md:w-48 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 outline-none transition-all text-sm"
                >
                    <option value="">Todos los tipos</option>
                    <?php foreach ($tipos as $t): ?>
                        <option value="<?= htmlspecialchars($t) ?>" <?= ($t === $tipo) ? 'selected' : '' ?>>
                            <?= htmlspecialchars(ucfirst($t)) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" class="w-full md:w-auto bg-orange-600 hover:bg-orange-700 text-white font-bold px-8 py-3 rounded-xl transition-all shadow-lg text-sm">
                    BUSCAR
                </button>
            </div>

            <?php if ($search || $tipo): ?>
                <div class="text-center mt-3">
                    <a href="eventosadmin.php" class="text-xs text-gray-400 hover:text-orange-600 font-bold uppercase tracking-widest">Limpiar filtros</a>
                </div>
            <?php endif; ?>
        </form>

        <?php if(empty($eventos)): ?>
            <div class="bg-white rounded-3xl p-12 text-center shadow-sm border border-gray-100">
                <p class="text-gray-400 font-bold italic">No se encontraron eventos.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                <?php foreach ($eventos as $e): 
                    $banner = $e['banner'] ?? '';
                    $icono = $e['icono_foto'] ?? '';
                ?>
                <div class="group bg-white rounded-2xl shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 overflow-hidden flex flex-col">
                    <div class="relative h-52 overflow-hidden">
                        <?php if($banner): ?>
                            <img src="<?= htmlspecialchars($banner) ?>" alt="<?= htmlspecialchars($e['titulo']) ?>" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110">
                        <?php else: ?>
                            <div class="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400 text-[10px] font-bold uppercase tracking-widest">Sin Imagen</div>
                        <?php endif; ?>
                        
                        <?php if(!empty($e['tipo_evento'])): ?>
                            <div class="absolute top-4 left-4 bg-black/60 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-lg uppercase tracking-wider">
                                <?= htmlspecialchars($e['tipo_evento']) ?>
                            </div>
                        <?php endif; ?>

                        <?php if($icono): ?>
                            <img src="<?= htmlspecialchars($icono) ?>" class="absolute -bottom-4 right-4 w-12 h-12 rounded-2xl border-4 border-white shadow-lg z-10 bg-white">
                        <?php endif; ?>
                    </div>

                    <div class="p-6 flex-1 flex flex-col">
                        <div class="mb-4">
                            <h2 class="text-xl font-extrabold text-gray-900 group-hover:text-orange-600 transition-colors leading-tight mb-2 uppercase italic">
                                <?= htmlspecialchars($e['titulo']) ?>
                            </h2>
                            <div class="flex items-center gap-4 text-gray-400 text-[11px] font-bold uppercase tracking-widest">
                                <span class="flex items-center gap-1">
                                    <i class="fa-solid fa-calendar-days text-orange-500"></i>
                                    <?= date('d M, Y', strtotime($e['fecha'])) ?>
                                </span>
                                <span class="flex items-center gap-1">
                                    <i class="fa-solid fa-location-dot text-orange-500"></i>
                                <?= htmlspecialchars($e['ciudad'] ?? 'Ciudad no especificada') ?>
                                </span>
                            </div>
                        </div>

                        <p class="text-gray-500 text-sm mb-6 line-clamp-2 leading-relaxed font-medium">
                            <?= htmlspecialchars($e['descripcion'] ?? 'Sin descripci¨®n disponible.') ?>
                        </p>

                        <div class="mt-auto pt-4 border-t border-gray-50 flex items-center justify-between">
                            <div class="text-[10px] text-gray-400 uppercase font-black tracking-tighter">
                                <span class="text-orange-600 block text-lg leading-none"><?= (int)$e['total_fotos'] ?></span>
                                FOTOS
                            </div>
                            <a href="galeriaadmin.php?evento_id=<?= (int)$e['id'] ?>" class="bg-gray-900 hover:bg-orange-600 text-white text-[10px] font-black px-5 py-3 rounded-xl transition-all uppercase tracking-widest shadow-lg active:scale-95">
                                Ver Fotos
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function toggleMenu() {
            const nav = document.getElementById('navLinks');
            const burger = document.getElementById('hamburger');
            const overlay = document.getElementById('menuOverlay');
            const isOpen = nav.classList.toggle('active');
            burger.classList.toggle('open');
            overlay.classList.toggle('active');
            document.body.style.overflow = isOpen ? 'hidden' : 'auto';
        }
    </script>
</body>
</html>
