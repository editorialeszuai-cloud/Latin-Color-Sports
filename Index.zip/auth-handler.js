// auth-handler.js - Manejador de Autenticación de Firebase para Latin Color Sports
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

document.addEventListener('DOMContentLoaded', () => {
    const auth = getAuth();

    // Escuchar el estado de la sesión de Firebase en tiempo real
    onAuthStateChanged(auth, async (user) => {
        const loginModal = document.getElementById('loginModal');
        
        if (user) {
            console.log("✅ Usuario autenticado en Firebase:", user.uid);
            window.firebase_uid = user.uid;
            
            // Sincronizar la sesión con PHP mediante un fetch rápido por si acaso
            try {
                await fetch('crear_sesion_php.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `firebase_uid=${encodeURIComponent(user.uid)}&email=${encodeURIComponent(user.email)}`
                });
            } catch (e) {
                console.error("Error sincronizando sesión con PHP:", e);
            }

            // Ocultar modal de login si está abierto
            if (loginModal) loginModal.classList.add('hidden');

            // Disparar las funciones globales de la galería que dependen del usuario
            if (typeof window.loadCarrito === 'function') window.loadCarrito();
            if (typeof window.verificarYMostrarModal === 'function') window.verificarYMostrarModal(user.uid);
            
        } else {
            console.warn("⚠️ No hay usuario activo. Bloqueando galería pública.");
            window.firebase_uid = null;
            
            // Si tu lógica requiere login obligatorio para ver las fotos, abrimos el modal
            if (typeof window.openLoginModal === 'function') {
                window.openLoginModal();
            } else if (loginModal) {
                loginModal.classList.remove('hidden');
            }
        }
    });

    // Control del formulario de login nativo dentro del modal (Email/Password)
    const loginForm = document.getElementById('modalLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('modalEmail').value;
            const pass = document.getElementById('modalPass').value;
            
            // Aquí puedes importar signInWithEmailAndPassword dinámicamente o delegarlo a los botones de Firebase
            console.log("Intentando login manual para:", email);
            // Nota: Si usas botones personalizados, la lógica se ejecuta a través del sdk expuesto.
        });
    }
});