<?php
header('Content-Type: application/json');
require 'dbfotografos.php'; // Asegúrate que devuelve $db

$usuario_id = $_POST['usuario_id'] ?? null;

if(!$usuario_id){
    echo json_encode(['success'=>false,'message'=>'Faltan parámetros.', 'post_data'=>$_POST]);
    exit;
}

try{
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $db->prepare("SELECT postulacion_id, subido FROM confirmaciones WHERE usuario_id=?");
    $stmt->execute([$usuario_id]);
    $confirmaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $resultado = [];
    foreach($confirmaciones as $c){
        $resultado[$c['postulacion_id']] = $c['subido'];
    }

    echo json_encode(['success'=>true,'data'=>$resultado]);

} catch(PDOException $e){
    // Devuelve el mensaje exacto de error
    echo json_encode(['success'=>false,'message'=>'Error BD: '.$e->getMessage()]);
}
