<?php
header('Content-Type: application/json; charset=utf-8');
include 'dbfotografos.php';
$pdo = conectar();
$accion = $_POST['accion'] ?? '';

switch($accion) {
    case 'listar_eventos':
        $stmt = $pdo->query("SELECT id, titulo FROM eventos ORDER BY titulo");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;

    case 'listar':
        try {
            $evento_id = $_POST['evento_id'] ?? null;
            $sql = "SELECT 
                        cb.id AS bloque_id, 
                        ce.id AS calendario_id, 
                        ce.nombre AS calendario,
                        ev.id AS evento_id, 
                        s.id AS sede_id, 
                        s.titulo AS sede, 
                        esc.id AS escenario_id, 
                        esc.nombre AS escenario, 
                        d.id AS disciplina_id, 
                        d.nombre_disciplina AS disciplina, 
                        cbd.id AS bloque_dis_id, 
                        cbd.categoria,
                        p.id AS partido_id, 
                        p.equipo_a, 
                        p.equipo_b,
                        cb.fecha, 
                        cb.hora
                    FROM calendario_bloque cb
                    JOIN calendario_evento ce ON cb.calendario_id = ce.id
                    JOIN eventos ev ON ce.evento_id = ev.id
                    JOIN calendario_bloque_sede cbs ON cbs.bloque_id = cb.id
                    JOIN sedes s ON s.id = cbs.sede_id
                    JOIN calendario_bloque_escenario cbe ON cbe.bloque_sede_id = cbs.id
                    JOIN escenarios esc ON esc.id = cbe.escenario_id
                    JOIN calendario_bloque_disciplina cbd ON cbd.escenario_id = cbe.id
                    JOIN disciplinas d ON cbd.disciplina_id = d.id
                    LEFT JOIN partidos p ON p.bloque_disciplina_id = cbd.id
                    WHERE ce.evento_id = ?
                    ORDER BY cb.fecha, cb.hora";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([$evento_id]);
            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode(['success' => true, 'data' => $data]);
        } catch(Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;
		
    case 'listar_fotografos':
        $stmt = $pdo->query("SELECT DISTINCT u.id, u.nombre FROM usuarios u 
                             JOIN postulaciones p ON p.usuario_id = u.id 
                             WHERE u.rol='fotografo' AND p.estado='Aceptado' ORDER BY u.nombre");
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        break;

    case 'asignar_fotografo':
        try {
            $sql = "INSERT INTO calendario_fotografos 
                    (evento_id, calendario_id, bloque_id, sede_id, escenario_id, disciplina_id, bloque_dis_id, partido_id, postulacion_id, fotografo_id, fecha, hora) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, (SELECT id FROM postulaciones WHERE usuario_id = ? AND estado = 'Aceptado' LIMIT 1), ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $_POST['evento_id'], $_POST['calendario_id'], $_POST['bloque_id'], $_POST['sede_id'], 
                $_POST['escenario_id'], $_POST['disciplina_id'], $_POST['bloque_dis_id'], $_POST['partido_id'], 
                $_POST['fotografo_id'], $_POST['fotografo_id'], $_POST['fecha'], $_POST['hora']
            ]);
            echo json_encode(['success' => true, 'message' => '✅ Fotógrafo asignado.']);
        } catch(Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        break;
}
?>