<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP; // Añadido para debugging

require_once __DIR__ . '/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer-master/src/SMTP.php';

$mail = new PHPMailer(true);

try {
    // --- CONFIGURACIÓN DE DEPURACIÓN ---
    $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Muestra toda la interacción con el servidor
    $mail->Debugoutput = 'html';           // Formatea el error para que sea legible en el navegador
    
    $mail->isSMTP();
    $mail->Host       = 'kirby.nocdirect.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'notificaciones@latincolorgroup.com';
    $mail->Password   = '3Eoi@u=_b4LdCMwj';
    
    // Configuración para Servidores Jaguar/NocDirect (Usualmente puerto 465 es más estable)
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 
    $mail->Port       = 465; 

    // IMPORTANTE: El setFrom DEBE ser el mismo correo que el Username en la mayoría de hostings
    $mail->setFrom('notificaciones@latincolorgroup.com', 'Latin Color Group');
    
    $mail->addAddress('notificaciones@latincolorgroup.com');
    // Si quieres probar la copia oculta (BCC) actívala aquí:
    // $mail->addBCC('lolaela1960@hotmail.com');

    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Subject = "Prueba de Conexión Jaguar";
    $mail->Body    = "DEPURACIÓN: " . date('Y-m-d H:i:s');

    $mail->send();
    echo "<h3>¡El mensaje salió del servidor con éxito!</h3>";

} catch (Exception $e) {
    echo "<h3>Error de PHPMailer:</h3> " . $mail->ErrorInfo;
}