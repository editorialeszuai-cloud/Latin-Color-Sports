<?php
require 'db.php'; // Conexión a la base de datos

// =======================
// Procesar creación de galería
// =======================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['evento_id'], $_POST['fotografo_id'], $_POST['titulo'])) {
    $evento_id = $_POST['evento_id'];
    $fotografo_id = $_POST['fotografo_id'];
    $titulo = $_POST['titulo'];

    $stmt = $pdo->prepare("INSERT INTO galerias (evento_id, fotografo_id, titulo) VALUES (?, ?, ?)");
    $stmt->execute([$evento_id, $fotografo_id, $titulo]);

    $mensaje = "Galería creada con éxito.";
}

// =======================
// Obtener asignaciones de eventos y fotógrafos
// =======================
$asignaciones = $pdo->query("
    SELECT ae.evento_id, ae.fotografo_id, e.titulo AS evento, u.nombre AS fotografo
    FROM asignar_eventos ae
    JOIN eventos e ON ae.evento_id = e.id
    JOIN usuarios u ON ae.fotografo_id = u.id
    ORDER BY e.fecha ASC
")->fetchAll();

// =======================
// Obtener galerías existentes
// =======================
$galerias = $pdo->query("SELECT * FROM galerias ORDER BY fecha_creacion DESC")->fetchAll();
$galerias_map = [];
foreach ($galerias as $g) {
    $galerias_map[$g['evento_id']][$g['fotografo_id']][] = $g;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administración de Galerías</title>
    <script src="https://cdn.tailwindcss.com"></script>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
</head>
<body class="p-6 bg-gray-100">

<h1 class="text-3xl font-bold mb-6">Administración de Galerías por Evento</h1>

<?php if(isset($mensaje)): ?>
    <p class="mb-4 p-2 bg-green-200 text-green-800 rounded"><?= htmlspecialchars($mensaje) ?></p>
<?php endif; ?>

<div class="bg-white p-6 rounded shadow">
    <table class="min-w-full border border-gray-300">
        <thead class="bg-gray-200">
            <tr>
                <th class="border px-4 py-2 text-left">Evento</th>
                <th class="border px-4 py-2 text-left">Fotógrafo</th>
                <th class="border px-4 py-2 text-left">Galerías existentes</th>
                <th class="border px-4 py-2 text-left">Agregar nueva galería</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($asignaciones as $a): ?>
                <tr class="even:bg-gray-50">
                    <td class="border px-4 py-2"><?= htmlspecialchars($a['evento']) ?></td>
                    <td class="border px-4 py-2"><?= htmlspecialchars($a['fotografo']) ?></td>
                    <td class="border px-4 py-2">
                        <?php
                        if(isset($galerias_map[$a['evento_id']][$a['fotografo_id']])) {
                            echo '<ul class="list-disc ml-5">';
                            foreach($galerias_map[$a['evento_id']][$a['fotografo_id']] as $g) {
                                echo '<li>'.htmlspecialchars($g['titulo']).' ('.htmlspecialchars($g['fecha_creacion']).')</li>';
                            }
                            echo '</ul>';
                        } else {
                            echo '<span class="text-gray-500">No hay galerías</span>';
                        }
                        ?>
                    </td>
                    <td class="border px-4 py-2">
                        <form method="POST" class="flex gap-2">
                            <input type="hidden" name="evento_id" value="<?= $a['evento_id'] ?>">
                            <input type="hidden" name="fotografo_id" value="<?= $a['fotografo_id'] ?>">
                            <input type="text" name="titulo" placeholder="Título de la galería" class="border rounded p-1 flex-1" required>
                            <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition text-sm">
                                Crear
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
