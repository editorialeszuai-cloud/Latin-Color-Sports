<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require 'dbfotografos.php';

// Obtenemos el evento_id de la URL
$evento_id = isset($_GET['evento_id']) ? (int)$_GET['evento_id'] : 0;
if ($evento_id <= 0) die('Evento no especificado.');

// 1. CONSULTA DEL EVENTO Y SU PAÍS PARA LA MONEDA
$stmt = $pdo->prepare("
    SELECT e.titulo, e.paquetes_eventos, l.pais 
    FROM eventos e 
    LEFT JOIN lugares l ON e.lugar_id = l.id 
    WHERE e.id = ? LIMIT 1
");
$stmt->execute([$evento_id]);
$evento = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$evento) die('Evento no encontrado.');

// Lógica de Moneda
$es_colombia = (isset($evento['pais']) && trim(strtolower($evento['pais'])) === 'colombia');

// 2. CONSULTA DE PAQUETES
$paquetes = [];
$ids_limpios = preg_replace('/[^0-9,]/', '', $evento['paquetes_eventos'] ?? '');
if (!empty($ids_limpios)) {
    $ids_array = array_filter(explode(',', $ids_limpios), 'strlen');
    $placeholders = implode(',', array_fill(0, count($ids_array), '?'));
    $stmt_p = $pdo->prepare("SELECT * FROM paquetes_fotos WHERE id IN ($placeholders) ORDER BY precio_por_unidad ASC");
    $stmt_p->execute(array_values($ids_array));
    $paquetes = $stmt_p->fetchAll(PDO::FETCH_ASSOC);
}

function formatPrecio($precio, $es_colombia) {
    return $es_colombia 
        ? '$' . number_format($precio, 0, ',', '.') 
        : '$' . number_format($precio, 2, '.', ',') . ' USD';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Paquetes del Evento | <?= htmlspecialchars($evento['titulo']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>body { background: #0a0a0a; color: #eee; font-family: 'Inter', sans-serif; }</style>
</head>
<body class="p-4">

<nav class="flex items-center justify-between p-4 bg-black border-b border-white/5 sticky top-0 z-40">
    <a href="galeria.php?evento_id=<?= $evento_id ?>" class="p-2 bg-white/5 rounded-xl text-[10px] font-black uppercase tracking-widest">← Volver</a>
</nav>

<div class="max-w-3xl mx-auto mt-10">
    <div class="mb-10 text-center">
        <h1 class="text-3xl font-black uppercase tracking-widest text-white"><?= htmlspecialchars($evento['titulo']) ?></h1>
        <p class="text-orange-500 font-bold text-xs uppercase tracking-[0.2em] mt-2">Selecciona un paquete para continuar</p>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php if (!empty($paquetes)): ?>
            <?php foreach ($paquetes as $p): ?>
                <div class="bg-[#111] border border-white/10 p-6 rounded-3xl hover:border-orange-500/50 transition-all">
                    <h3 class="text-white font-black text-sm uppercase tracking-widest mb-1"><?= htmlspecialchars($p['nombre_paquete']) ?></h3>
                    <div class="text-2xl font-black text-orange-500 my-4"><?= formatPrecio($p['precio_por_unidad'], $es_colombia) ?></div>
                    <ul class="text-[10px] text-gray-400 uppercase font-bold space-y-2 mb-6">
                        <li>Incluye: <?= htmlspecialchars($p['unidades_incluidas']) ?> fotos</li>
                    </ul>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-span-full text-center py-20 border border-dashed border-white/10 rounded-3xl text-gray-600 uppercase text-[10px] tracking-widest">
                No hay paquetes configurados para este evento.
            </div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>