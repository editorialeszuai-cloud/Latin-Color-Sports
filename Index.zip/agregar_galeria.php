<?php
session_start();
require 'dbfotografos.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $data['firebase_uid'] ?? null;
$foto_id = $data['foto_id'] ?? 0;

if(!$firebase_uid || $foto_id <= 0){
    echo json_encode(['status'=>'error','msg'=>'Datos inválidos']); exit;
}

// Evitar duplicados
$stmt = $pdo->prepare("SELECT id FROM mi_galeria WHERE firebase_uid=? AND foto_id=?");
$stmt->execute([$firebase_uid,$foto_id]);
if($stmt->fetch()){
    echo json_encode(['status'=>'error','msg'=>'Foto ya existe en tu galería']); exit;
}

// Insertar en mi_galeria
$stmt = $pdo->prepare("INSERT INTO mi_galeria (firebase_uid,foto_id) VALUES (?,?)");
if($stmt->execute([$firebase_uid,$foto_id])){
    echo json_encode(['status'=>'ok']);
}else{
    echo json_encode(['status'=>'error','msg'=>'No se pudo agregar']);
}
?>
