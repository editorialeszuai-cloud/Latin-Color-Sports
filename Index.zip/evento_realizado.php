<?php
require 'db.php';

// =======================
// Obtener asignaciones actuales
// =======================
$asignaciones = $pdo->query("SELECT ae.evento_id, ae.fotografo_id, e.titulo AS evento, u.nombre AS fotografo
    FROM asignar_eventos ae
    JOIN eventos e ON ae.evento_id = e.id
    JOIN usuarios u ON ae.fotografo_id = u.id
    ORDER BY e.fecha ASC")->fetchAll();

// =======================
// Obtener galerías
// =======================
$galerias = $pdo->query("SELECT * FROM galerias")->fetchAll();
$galerias_map = [];
foreach($galerias as $g) {
    $galerias_map[$g['evento_id']][$g['fotografo_id']][] = $g;
}
?>

<div class="bg-white p-6 rounded shadow mt-6">
    <h2 class="text-2xl font-bold mb-4">Administración de Galerías por Evento</h2>
    <table class="min-w-full border border-gray-300">
        <thead class="bg-gray-200">
            <tr>
                <th class="border px-4 py-2">Evento</th>
                <th class="border px-4 py-2">Fotógrafo</th>
                <th class="border px-4 py-2">Galerías existentes</th>
                <th class="border px-4 py-2">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($asignaciones as $a): ?>
                <tr class="even:bg-gray-50">
                    <td class="border px-4 py-2"><?= htmlspecialchars($a['evento']) ?></td>
                    <td class="border px-4 py-2"><?= htmlspecialchars($a['fotografo']) ?></td>
                    <td class="border px-4 py-2">
                        <?php 
                        if(isset($galerias_map[$a['evento_id']][$a['fotografo_id']])) {
                            echo '<ul class="list-disc ml-5">';
                            foreach($galerias_map[$a['evento_id']][$a['fotografo_id']] as $g) {
                                echo '<li>'.htmlspecialchars($g['titulo']).'</li>';
                            }
                            echo '</ul>';
                        } else {
                            echo '<span class="text-gray-500">No hay galerías</span>';
                        }
                        ?>
                    </td>
                    <td class="border px-4 py-2">
                        <form method="POST" action="agregar_galeria.php">
                            <input type="hidden" name="evento_id" value="<?= $a['evento_id'] ?>">
                            <input type="hidden" name="fotografo_id" value="<?= $a['fotografo_id'] ?>">
                            <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition text-sm">
                                Agregar Galería
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
