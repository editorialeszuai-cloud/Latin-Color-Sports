<?php
require_once 'dbfotografos.php';
$evento_id = intval($_GET['evento_id']);

$stmt = $pdo->prepare("SELECT id, CONCAT(equipo_a, ' vs ', equipo_b) as nombre FROM partidos WHERE bloque_disciplina_id IN (SELECT id FROM calendario_bloque_disciplina WHERE evento_id = ?)");
$stmt->execute([$evento_id]);
$partidos = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

echo json_encode([
    'partidos' => $partidos
]);