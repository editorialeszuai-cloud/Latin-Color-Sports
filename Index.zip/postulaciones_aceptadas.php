<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mis Postulaciones</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">

<header class="bg-orange-600 text-white p-4 shadow-md">
  <div class="container mx-auto flex justify-between items-center">
    <h1 class="text-2xl font-bold">Mis Postulaciones</h1>
    <div class="flex items-center gap-3">
      <a href="ver_calendario_fotografo.php" class="bg-gray-500 hover:bg-gray-600 px-3 py-1 rounded text-white transition">Calendario</a>
      <button onclick="window.location.href='menu_fotografo.php'" class="bg-white text-orange-600 px-3 py-1 rounded font-bold hover:bg-gray-100">Men&uacute;</button>
      <button id="logoutButton" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded">Salir</button>
    </div>
  </div>
</header>

<main class="container mx-auto p-6">
  <div id="userInfo" class="bg-white p-4 rounded-lg shadow mb-6 border-l-4 border-orange-500">
    <p class="text-sm text-gray-500 uppercase font-bold">Perfil Fot&oacute;grafo</p>
    <p><strong class="text-gray-700">Usuario:</strong> <span id="nombreText" class="text-orange-600">Cargando...</span></p>
    <p><strong class="text-gray-700">Email:</strong> <span id="emailText">Cargando...</span></p>
  </div>

  <div class="bg-white p-4 rounded-lg shadow">
    <h2 class="text-xl font-semibold mb-4 text-gray-800">Historial de Postulaciones</h2>
    <div id="calendarioUsuario" class="overflow-x-auto">
        <p class="text-gray-500 animate-pulse">Sincronizando con el servidor...</p>
    </div>
  </div>
</main>

<script type="module">
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

// Tu config de Firebase (Mantenla id��ntica a tus otros archivos)
const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.appspot.com",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

onAuthStateChanged(auth, async (user) => {
  if (user) {
    document.getElementById('emailText').textContent = user.email;
    try {
        const token = await user.getIdToken(true);
        
        // 1. Obtener nombre del usuario
        const resUser = await fetch('get_user_info.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ firebase_token: token })
        });
        const userData = await resUser.json();

        if (userData.status === 'success') {
          document.getElementById('nombreText').textContent = userData.user.nombre;
          cargarPostulaciones(token);
        } else {
          document.getElementById('nombreText').textContent = 'No registrado';
        }
    } catch (e) {
        console.error("Error de conexi��n:", e);
    }
  } else {
    window.location.href = 'login_app.html';
  }
});

async function cargarPostulaciones(token) {
  const cont = document.getElementById('calendarioUsuario');

  try {
    const res = await fetch('postulaciones_usuario_calendario.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ firebase_token: token })
    });
    const data = await res.json();

    if (!data.success) {
      cont.innerHTML = `<p class="text-red-600">Error: ${data.message}</p>`;
      return;
    }

    if (data.data.length === 0) {
      cont.innerHTML = `<p class="text-gray-500 py-4 text-center">A&uacute;n no te has postulado a ning&uacute;n evento.</p>`;
      return;
    }

    let html = `<table class="w-full text-sm text-left border-collapse">
      <thead class="bg-gray-100 text-gray-700 uppercase text-[10px] tracking-wider">
        <tr>
          <th class="px-4 py-3 border">Evento</th>
          <th class="px-4 py-3 border">Fecha</th>
          <th class="px-4 py-3 border text-center">Estado</th>
        </tr>
      </thead><tbody class="divide-y">`;

    data.data.forEach(p => {
      const colorEstado = 
        p.estado === 'aceptado' ? 'bg-green-100 text-green-700' : 
        p.estado === 'rechazado' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600';

      html += `<tr class="hover:bg-gray-50">
        <td class="px-4 py-3 font-medium text-gray-900">${p.evento_nombre}</td>
        <td class="px-4 py-3">${p.fecha_evento}</td>
        <td class="px-4 py-3 text-center">
            <span class="px-2 py-1 rounded-full text-[10px] font-bold uppercase ${colorEstado}">${p.estado}</span>
        </td>
      </tr>`;
    });

    html += '</tbody></table>';
    cont.innerHTML = html;
  } catch (e) {
    cont.innerHTML = '<p class="text-red-600">Error de conexi��n al cargar postulaciones.</p>';
  }
}

document.getElementById('logoutButton').addEventListener('click', () => signOut(auth));
</script>
</body>
</html>