<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');
include 'dbfotografos.php'; 
$pdo = conectar();

$accion = $_POST['accion'] ?? '';

try {
    if($accion === 'crear'){
        $evento_id = $_POST['evento_id'] ?? null;
        $nombre_calendario = $_POST['nombre_calendario'] ?? '';

        if(!$evento_id || !$nombre_calendario) throw new Exception('Faltan datos básicos');

        // 1. Crear calendario principal
        $stmt = $pdo->prepare("INSERT INTO calendario_evento (evento_id, nombre) VALUES (?, ?)");
        $stmt->execute([$evento_id, $nombre_calendario]);
        $calendario_id = $pdo->lastInsertId();

        // 2. Guardar bloques (Fechas)
        foreach($_POST['fecha'] as $i => $fecha){
            $stmtB = $pdo->prepare("INSERT INTO calendario_bloque (calendario_id, fecha, hora) VALUES (?, ?, ?)");
            $stmtB->execute([$calendario_id, $fecha, $_POST['hora'][$i]]);
            $bloque_id = $pdo->lastInsertId();

            // 3. Sedes
            foreach($_POST["sede_ids_$i"] as $j => $sede_id){
                $stmtS = $pdo->prepare("INSERT INTO calendario_bloque_sede (bloque_id, sede_id) VALUES (?, ?)");
                $stmtS->execute([$bloque_id, $sede_id]);
                $bloque_sede_id = $pdo->lastInsertId();

                // 4. Escenarios
                foreach($_POST["escenario_ids_{$i}_{$j}"] as $k => $escenario_id){
                    $stmtE = $pdo->prepare("INSERT INTO calendario_bloque_escenario (bloque_sede_id, escenario_id) VALUES (?, ?)");
                    $stmtE->execute([$bloque_sede_id, $escenario_id]);
                    $bloque_escenario_id = $pdo->lastInsertId();

                    // 5. Disciplinas
                    foreach($_POST["disciplina_ids_{$i}_{$j}_{$k}"] as $l => $disciplina_id){
                        $stmtD = $pdo->prepare("INSERT INTO calendario_bloque_disciplina (escenario_id, disciplina_id, categoria) VALUES (?, ?, ?)");
                        $stmtD->execute([$bloque_escenario_id, $disciplina_id, $_POST["categoria_{$i}_{$j}_{$k}"][$l]]);
                        $bd_id = $pdo->lastInsertId(); // ID de la disciplina en el bloque

                        // --- NUEVO: GUARDAR PARTIDO ---
                        $equipo_a = $_POST["partido_a_{$i}_{$j}_{$k}"][$l] ?? '';
                        $equipo_b = $_POST["partido_b_{$i}_{$j}_{$k}"][$l] ?? '';
                        
                        if(!empty($equipo_a) && !empty($equipo_b)){
                            $stmtP = $pdo->prepare("INSERT INTO partidos (bloque_disciplina_id, equipo_a, equipo_b) VALUES (?, ?, ?)");
                            $stmtP->execute([$bd_id, $equipo_a, $equipo_b]);
                        }
                    }
                }
            }
        }
        echo json_encode(['success'=>true, 'message'=>'Calendario y partidos creados con éxito']);

    } elseif($accion === 'listar'){
        // Consulta unida con LEFT JOIN para traer los partidos
        $sql = "SELECT 
                    cb.id AS competencia_id,
                    ce.nombre AS calendario,
                    cb.fecha,
                    cb.hora,
                    s.titulo AS sede,
                    e.nombre AS escenario,
                    d.nombre_disciplina AS disciplina,
                    cbd.categoria,
                    p.equipo_a,
                    p.equipo_b
                FROM calendario_bloque cb
                JOIN calendario_evento ce ON cb.calendario_id = ce.id
                JOIN calendario_bloque_sede cbs ON cbs.bloque_id = cb.id
                JOIN sedes s ON s.id = cbs.sede_id
                JOIN calendario_bloque_escenario cbe ON cbe.bloque_sede_id = cbs.id
                JOIN escenarios e ON e.id = cbe.escenario_id
                JOIN calendario_bloque_disciplina cbd ON cbd.escenario_id = cbe.id
                JOIN disciplinas d ON d.id = cbd.disciplina_id
                LEFT JOIN partidos p ON p.bloque_disciplina_id = cbd.id
                ORDER BY cb.fecha, cb.hora";

        $stmt = $pdo->query($sql);
        echo json_encode(['success'=>true, 'data'=>$stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }
} catch(Exception $e){
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
?>