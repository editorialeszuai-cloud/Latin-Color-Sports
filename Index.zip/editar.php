<?php
require_once "dbfotografos.php";
$conn = conectar();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("<h2>ID de evento no especificado.</h2>");
}
$id = intval($_GET['id']);

// --- FUNCIÓN PARA SUBIR ARCHIVOS ---
function subirArchivo($file, $dir) {
    if (!empty($file['name'])) {
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $targetFile = $dir . uniqid() . "_" . time() . "." . $extension;
        if (move_uploaded_file($file['tmp_name'], $targetFile)) {
            return $targetFile;
        }
    }
    return null;
}

// 1. Obtener datos actuales para precargar el formulario y mantener archivos
$stmt = $conn->prepare("SELECT * FROM eventos WHERE id = :id");
$stmt->execute([':id' => $id]);
$evento = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$evento) die("<h2>Evento no encontrado.</h2>");

// 2. Procesar la actualización
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = "uploads/";

    // Si se sube archivo nuevo se usa, si no, se mantiene el actual de la DB
    $logoPath   = subirArchivo($_FILES['logo'] ?? [], $uploadDir) ?: $evento['logo'];
    $bannerPath = subirArchivo($_FILES['banner'] ?? [], $uploadDir) ?: $evento['banner'];
    $iconoPath  = subirArchivo($_FILES['icono_foto'] ?? [], $uploadDir) ?: $evento['icono_foto'];

    $titulo              = $_POST['titulo'];
    $descripcion         = $_POST['descripcion'];
    $fecha               = $_POST['fecha'];
    $fechafin            = $_POST['fechafin'];
    $tipo_evento         = $_POST['tipo_evento'];
    $metodo_monetizacion = $_POST['metodo_monetizacion'];
    $capacidad_gb        = $_POST['capacidad_gb'];
    $max_fotografos      = $_POST['max_fotografos'];
    $photo_licensing     = $_POST['photo_licensing'];
    $organizador_id      = $_POST['organizador_id'];
    $comercial_id        = $_POST['comercial_id'];
    $lugar_id            = $_POST['lugar_id'];

    // Encodificar arrays a JSON
    $paquetes_json    = json_encode($_POST['paquetes_eventos'] ?? [], JSON_UNESCAPED_UNICODE);
    $disciplinas_json = json_encode($_POST['disciplinas_evento'] ?? [], JSON_UNESCAPED_UNICODE);

    $sql = "UPDATE eventos SET 
        titulo = :titulo,
        descripcion = :descripcion,
        fecha = :fecha,
        fechafin = :fechafin,
        tipo_evento = :tipo_evento,
        metodo_monetizacion = :metodo_monetizacion,
        capacidad_gb = :capacidad_gb,
        max_fotografos = :max_fotografos,
        photo_licensing = :photo_licensing,
        organizador_id = :organizador_id,
        comercial_id = :comercial_id,
        lugar_id = :lugar_id,
        paquetes_eventos = :paquetes,
        disciplinas_evento = :disciplinas,
        logo = :logo,
        banner = :banner,
        icono_foto = :icono
        WHERE id = :id";

    $stmt = $conn->prepare($sql);
    $ok = $stmt->execute([
        ':titulo' => $titulo,
        ':descripcion' => $descripcion,
        ':fecha' => $fecha,
        ':fechafin' => $fechafin,
        ':tipo_evento' => $tipo_evento,
        ':metodo_monetizacion' => $metodo_monetizacion,
        ':capacidad_gb' => $capacidad_gb,
        ':max_fotografos' => $max_fotografos,
        ':photo_licensing' => $photo_licensing,
        ':organizador_id' => $organizador_id,
        ':comercial_id' => $comercial_id,
        ':lugar_id' => $lugar_id,
        ':paquetes' => $paquetes_json,
        ':disciplinas' => $disciplinas_json,
        ':logo' => $logoPath,
        ':banner' => $bannerPath,
        ':icono' => $iconoPath,
        ':id' => $id
    ]);

    if ($ok) {
        echo "<script>alert('✅ Evento actualizado con éxito'); window.location='eventos.php';</script>";
        exit;
    } else {
        echo "<p style='color:red;'>❌ Error al actualizar.</p>";
    }
}

// Datos para selects
$organizadores = $conn->query("SELECT id, nombre FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
$comerciales = $conn->query("SELECT id, nombre FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
$lugares = $conn->query("SELECT id, nombre_lugar AS nombre FROM lugares")->fetchAll(PDO::FETCH_ASSOC);

// Decodificar lo que ya está en la DB para el JS
$paquetesSeleccionados = !empty($evento['paquetes_eventos']) ? json_decode($evento['paquetes_eventos'], true) : [];
$disciplinasSeleccionadas = !empty($evento['disciplinas_evento']) ? json_decode($evento['disciplinas_evento'], true) : [];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Evento #<?php echo $id; ?></title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">

<div class="max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-lg">
    <h1 class="text-2xl font-semibold text-indigo-700 mb-6">Editar Evento #<?php echo $id; ?></h1>

    <form method="POST" enctype="multipart/form-data" class="space-y-6">
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 bg-blue-50 p-4 rounded-xl border border-blue-100">
            <div>
                <label class="block text-xs font-bold uppercase text-blue-600 mb-2">Logo</label>
                <?php if($evento['logo']): ?>
                    <img src="<?php echo $evento['logo']; ?>" class="w-20 h-20 object-cover rounded border mb-2">
                <?php endif; ?>
                <input type="file" name="logo" class="block w-full text-xs text-gray-500 file:mr-4 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:bg-blue-600 file:text-white hover:file:bg-blue-700">
            </div>
            <div>
                <label class="block text-xs font-bold uppercase text-blue-600 mb-2">Banner</label>
                <?php if($evento['banner']): ?>
                    <img src="<?php echo $evento['banner']; ?>" class="w-20 h-20 object-cover rounded border mb-2">
                <?php endif; ?>
                <input type="file" name="banner" class="block w-full text-xs text-gray-500 file:mr-4 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:bg-blue-600 file:text-white hover:file:bg-blue-700">
            </div>
            <div>
                <label class="block text-xs font-bold uppercase text-blue-600 mb-2">Icono Foto</label>
                <?php if($evento['icono_foto']): ?>
                    <img src="<?php echo $evento['icono_foto']; ?>" class="w-20 h-20 object-cover rounded border mb-2">
                <?php endif; ?>
                <input type="file" name="icono_foto" class="block w-full text-xs text-gray-500 file:mr-4 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:bg-blue-600 file:text-white hover:file:bg-blue-700">
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Título</label>
            <input type="text" name="titulo" value="<?php echo htmlspecialchars($evento['titulo']); ?>" required class="mt-1 w-full border rounded-lg p-2 focus:ring-indigo-500 focus:border-indigo-500">
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Descripción</label>
            <textarea name="descripcion" rows="3" class="mt-1 w-full border rounded-lg p-2"><?php echo htmlspecialchars($evento['descripcion']); ?></textarea>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Fecha inicio</label>
                <input type="date" name="fecha" value="<?php echo $evento['fecha']; ?>" class="mt-1 w-full border rounded-lg p-2">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Fecha fin</label>
                <input type="date" name="fechafin" value="<?php echo $evento['fechafin']; ?>" class="mt-1 w-full border rounded-lg p-2">
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Tipo de evento</label>
                <select name="tipo_evento" class="mt-1 w-full border rounded-lg p-2">
                    <?php
                    $tipos = ['Deportivo', 'Corporativo', 'Social', 'Educativo'];
                    foreach ($tipos as $tipo) {
                        $sel = ($tipo == $evento['tipo_evento']) ? 'selected' : '';
                        echo "<option value='$tipo' $sel>$tipo</option>";
                    }
                    ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Monetización</label>
                <select name="metodo_monetizacion" class="mt-1 w-full border rounded-lg p-2">
                    <option value="Pago" <?php echo ($evento['metodo_monetizacion']=='Pago') ? 'selected' : ''; ?>>Pago</option>
                    <option value="No Pago" <?php echo ($evento['metodo_monetizacion']=='No Pago') ? 'selected' : ''; ?>>No Pago</option>
                </select>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Lugar</label>
            <select name="lugar_id" class="mt-1 w-full border rounded-lg p-2">
                <?php foreach ($lugares as $l): ?>
                    <option value="<?php echo $l['id']; ?>" <?php echo ($l['id']==$evento['lugar_id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($l['nombre']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Organizador</label>
                <select name="organizador_id" class="mt-1 w-full border rounded-lg p-2">
                    <?php foreach ($organizadores as $o): ?>
                        <option value="<?php echo $o['id']; ?>" <?php echo ($o['id']==$evento['organizador_id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($o['nombre']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Comercial</label>
                <select name="comercial_id" class="mt-1 w-full border rounded-lg p-2">
                    <?php foreach ($comerciales as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo ($c['id']==$evento['comercial_id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['nombre']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Capacidad (GB)</label>
                <input type="number" name="capacidad_gb" value="<?php echo $evento['capacidad_gb']; ?>" class="mt-1 w-full border rounded-lg p-2">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Máx. fotógrafos</label>
                <input type="number" name="max_fotografos" value="<?php echo $evento['max_fotografos']; ?>" class="mt-1 w-full border rounded-lg p-2">
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700">Licencia</label>
            <textarea name="photo_licensing" rows="2" class="mt-1 w-full border rounded-lg p-2"><?php echo htmlspecialchars($evento['photo_licensing']); ?></textarea>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Paquetes disponibles</label>
                <select id="paquetes_eventos" name="paquetes_eventos[]" multiple class="w-full border rounded-lg p-2 h-40 focus:ring-2 focus:ring-indigo-200"></select>
                <p class="text-xs text-gray-400 mt-1">Mantén presionado Ctrl (o Cmd) para seleccionar varios.</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Disciplinas disponibles</label>
                <select id="disciplinas_evento" name="disciplinas_evento[]" multiple class="w-full border rounded-lg p-2 h-40 focus:ring-2 focus:ring-indigo-200"></select>
            </div>
        </div>

        <div class="flex justify-end space-x-3 pt-6 border-t">
            <a href="eventos.php" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-6 py-2 rounded-lg transition shadow">Cancelar</a>
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg transition shadow-md font-medium">Actualizar Evento</button>
        </div>
    </form>
</div>

<script>
async function cargarPaquetes() {
    try {
        const res = await fetch('paquetes.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({accion:'listar'})
        });
        const data = await res.json();
        const select = document.getElementById('paquetes_eventos');
        const seleccionados = <?php echo json_encode($paquetesSeleccionados); ?>;
        
        if(data.status === 'success') {
            data.data.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = `${p.nombre_paquete} - $${p.precio_por_unidad}`;
                if (seleccionados.includes(String(p.id)) || seleccionados.includes(Number(p.id))) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });
        }
    } catch (e) { console.error("Error cargando paquetes:", e); }
}

async function cargarDisciplinas() {
    try {
        const res = await fetch('disciplinas.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({accion:'listar'})
        });
        const data = await res.json();
        const select = document.getElementById('disciplinas_evento');
        const seleccionadas = <?php echo json_encode($disciplinasSeleccionadas); ?>;
        
        if(data.status === 'success') {
            data.data.forEach(d => {
                const opt = document.createElement('option');
                opt.value = d.id;
                opt.textContent = d.nombre_disciplina;
                if (seleccionadas.includes(String(d.id)) || seleccionadas.includes(Number(d.id))) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });
        }
    } catch (e) { console.error("Error cargando disciplinas:", e); }
}

document.addEventListener('DOMContentLoaded', () => {
    cargarPaquetes();
    cargarDisciplinas();
});
</script>

</body>
</html>