<?php
header('Content-Type: application/json');
require_once "conexion.php";
$conn = conectar();

$accion = $_POST['accion'] ?? '';
$id = $_POST['id'] ?? null;

// Campos del formulario
$evento_id     = $_POST['evento_id'] ?? '';
$sede_id       = $_POST['sede_id'] ?? '';
$escenario_id  = $_POST['escenario_id'] ?? '';
$disciplina_id = $_POST['disciplina_id'] ?? '';
$fecha         = $_POST['fecha'] ?? '';
$hora          = $_POST['hora'] ?? '';

try {
    if ($accion === 'crear') {
        $stmt = $conn->prepare("INSERT INTO calendarios (evento_id, sede_id, escenario_id, disciplina_id, fecha, hora) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiiss", $evento_id, $sede_id, $escenario_id, $disciplina_id, $fecha, $hora);
        $stmt->execute();
        echo json_encode(['success' => true]);

    } elseif ($accion === 'editar' && $id) {
        $stmt = $conn->prepare("UPDATE calendarios SET evento_id=?, sede_id=?, escenario_id=?, disciplina_id=?, fecha=?, hora=? WHERE id=?");
        $stmt->bind_param("iiiissi", $evento_id, $sede_id, $escenario_id, $disciplina_id, $fecha, $hora, $id);
        $stmt->execute();
        echo json_encode(['success' => true]);

    } elseif ($accion === 'eliminar' && $id) {
        $stmt = $conn->prepare("DELETE FROM calendarios WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        echo json_encode(['success' => true]);

    } elseif ($accion === 'listar') {
        $res = $conn->query("
            SELECT c.id, c.fecha, c.hora, 
                   e.titulo AS evento, s.nombre AS sede, 
                   esc.nombre AS escenario, d.nombre AS disciplina,
                   c.evento_id, c.sede_id, c.escenario_id, c.disciplina_id
            FROM calendarios c
            JOIN eventos e ON c.evento_id = e.id
            JOIN sedes s ON c.sede_id = s.id
            JOIN escenarios esc ON c.escenario_id = esc.id
            JOIN disciplinas d ON c.disciplina_id = d.id
            ORDER BY c.fecha, c.hora
        ");
        $data = [];
        while($row = $res->fetch_assoc()){
            $data[] = $row;
        }
        echo json_encode(['success'=>true, 'data'=>$data]);

    } else {
        echo json_encode(['success'=>false, 'message'=>'Acci��n no v��lida']);
    }

} catch (Exception $e) {
    echo json_encode(['success'=>false, 'message'=>$e->getMessage()]);
}
?>
