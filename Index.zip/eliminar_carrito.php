<?php
require 'dbfotografos.php';
$id = $_GET['id'] ?? 0;
$uid = $_GET['firebase_uid'] ?? '';

if ($id && $uid) {
    // Seguridad: solo borra si el UID coincide con el due�0�9o de la fila
    $stmt = $pdo->prepare("DELETE FROM carrito WHERE id = ? AND firebase_uid = ?");
    if($stmt->execute([$id, $uid])) {
        echo "ok";
    }
}
?>