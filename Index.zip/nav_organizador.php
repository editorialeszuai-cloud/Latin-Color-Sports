<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Organizador</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f9fafb; }
  </style>
</head>
<body class="bg-gray-100">

<!-- Navbar -->
<nav class="bg-[#0b1220] shadow sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between h-16 items-center">

      <!-- Logo -->
      <div class="flex-shrink-0 flex items-center gap-2">
        <img class="h-10 w-auto" src="uploads/LATIN-SPORTS.png" alt="Logo">
        <span class="font-bold text-xl text-white"></span>
      </div>

      <!-- Menú Desktop -->
      <div class="hidden md:flex md:items-center md:space-x-6">
        <a href="nav_organizador.php" class="text-white hover:text-orange-400 font-medium transition">Home</a>
        <a href="ver_eventosorganizador.php" class="text-white hover:text-orange-400 font-medium transition">Mis Eventos</a>
			<a href="eventosor.php" class="text-white hover:text-orange-400 font-medium transition">Gestionar Fotos</a>
					<a href="fotos_ocultas.php" class="text-white hover:text-orange-400 font-medium transition">Fotos Ocultas</a>
			
        
          <a href="eventosorganizador.php" class="text-white hover:text-orange-400 font-medium transition">Crear Eventos</a>
          
        <a href="comisionor.php" class="text-white hover:text-orange-400 font-medium transition">Comisión</a>
        <a href="datos_bancarios.php" class="text-white hover:text-orange-400 font-medium transition">Datos Bancarios</a>

        <!-- Notificaciones -->
        <button class="relative ml-4 text-gray-200 hover:text-orange-400">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          <span class="absolute top-0 right-0 inline-block w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        <!-- Usuario -->
        <div class="relative ml-4 flex items-center gap-2">
          <img id="userFotoPerfil" src="uploads/foto-perfil.jpg" alt="Usuario" class="w-10 h-10 rounded-full object-cover border border-gray-300">
          <div class="flex flex-col">
            <div class="flex items-center gap-2">
              <span id="userRole" class="text-xs font-semibold px-2 py-0.5 rounded-full bg-gray-200  ">Cargando...</span>
              <span id="userName" class="font-medium text-white">Cargando...</span>
              <button id="toggleInfo" class="ml-auto text-blue-600 text-sm flex items-center gap-1">
                <span>▾</span>
              </button>
            </div>
            <div id="moreInfo" class="mt-1 hidden text-xs text-gray-700">
              <p class="m-0 text-white"><strong>UID:</strong> <span id="userId">Cargando...</span></p>
              <p class="m-0 text-white"><strong>Email:</strong> <span id="userEmail">Cargando...</span></p>
            </div>
          </div>
        </div>
        
        <!-- Editar Perfil -->
<a href="editar_perfil.php" class="ml-4 py-2 px-4 rounded-lg bg-orange-600 text-white hover:bg-blue-700 transition">Editar Perfil</a>


        <!-- Cerrar sesión -->
        <button id="logoutButton" class="ml-4 py-2 px-4 rounded-lg bg-red-600 text-white hover:bg-red-700 transition">Cerrar Sesión</button>
        
      </div>

      <!-- Botón Mobile -->
      <div class="md:hidden flex items-center">
        <button id="mobile-menu-button" class="text-gray-200 focus:outline-none">
          <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
              d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </div>
  </div>

  <!-- Menú Mobile -->
  <div id="mobile-menu" class="md:hidden hidden bg-[#0b1220] text-white">
    <a href="#home" class="block px-4 py-2 hover:bg-indigo-500">Home</a>
    <a href="mis_eventos.php" class="block px-4 py-2 hover:bg-indigo-500">Mis Eventos</a>
	<a href="eventosor.php" class="block px-4 py-2 hover:bg-indigo-500">Edición de Eventos</a>
    <a href="comisionor.php" class="block px-4 py-2 hover:bg-indigo-500">Comisión</a>
    <a href="#contacto" class="block px-4 py-2 hover:bg-indigo-500">Contacto</a>

    <!-- Botón Editar Perfil -->
    <a href="editar_perfil.php" class="block px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-md mt-2">Editar Perfil</a>

    <button id="logoutButtonMobile" class="w-full text-left px-4 py-2 bg-red-600 hover:bg-red-700 rounded-md mt-2">Cerrar Sesión</button>
</div>

</nav>

<!-- Contenido -->
<main class="max-w-7xl mx-auto p-4 mt-8">
  <section id="home" class="relative overflow-hidden bg-black rounded-[3rem] shadow-[0_20px_50px_rgba(249,115,22,0.15)] border border-orange-900/30">
    
    <div class="absolute -top-24 -right-24 w-96 h-96 bg-orange-600/20 rounded-full blur-[100px]"></div>
    <div class="absolute -bottom-24 -left-24 w-72 h-72 bg-orange-500/10 rounded-full blur-[80px]"></div>

    <div class="relative z-10 px-8 py-16 md:py-24 flex flex-col items-center text-center">
      
      <div class="inline-flex items-center gap-2 px-5 py-2 mb-8 bg-orange-500/10 border border-orange-500/30 rounded-full backdrop-blur-sm">
        <span class="relative flex h-2 w-2">
          <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
          <span class="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
        </span>
        <span class="text-[10px] font-black text-orange-500 uppercase tracking-[0.2em]">Acceso Organizador</span>
      </div>

      <h1 class="text-6xl md:text-8xl font-black text-white leading-tight tracking-tighter">
        MASTER <span class="text-transparent bg-clip-text bg-gradient-to-b from-orange-400 to-orange-600">PANEL</span>
      </h1>
      
      <p class="mt-8 text-lg md:text-xl text-gray-400 max-w-2xl leading-relaxed font-light">
        Gestiona la logística, supervisa a los fotógrafos y controla el flujo de tus eventos con precisión milimétrica.
      </p>

      <div class="mt-12 flex flex-col sm:flex-row gap-6">
        <a href="ver_eventosorganizador.php" 
           class="group relative inline-flex items-center justify-center px-12 py-5 font-black text-black transition-all duration-300 bg-orange-500 rounded-2xl hover:bg-orange-400 shadow-[0_10px_30px_rgba(249,115,22,0.4)] hover:-translate-y-1 active:scale-95">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 002 2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
          GESTIONAR EVENTOS
        </a>

        <a href="comisionor.php" 
           class="inline-flex items-center justify-center px-12 py-5 font-black text-orange-500 transition-all duration-300 bg-transparent border-2 border-orange-500/50 rounded-2xl hover:bg-orange-500/10 hover:border-orange-500">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          BALANCES
        </a>
      </div>

      <div class="mt-20 grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-5xl px-4">
        <div class="bg-white/5 backdrop-blur-sm p-8 rounded-3xl border border-white/10 hover:border-orange-500/50 transition-colors">
          <p class="text-orange-500 text-[10px] font-black uppercase tracking-widest mb-2">Producción</p>
          <p class="text-2xl font-bold text-white uppercase">Eventos</p>
        </div>
        <div class="bg-white/5 backdrop-blur-sm p-8 rounded-3xl border border-white/10 hover:border-orange-500/50 transition-colors">
          <p class="text-orange-500 text-[10px] font-black uppercase tracking-widest mb-2">Curaduría</p>
          <p class="text-2xl font-bold text-white uppercase">Galerías</p>
        </div>
        <div class="bg-white/5 backdrop-blur-sm p-8 rounded-3xl border border-white/10 hover:border-orange-500/50 transition-colors">
          <p class="text-orange-500 text-[10px] font-black uppercase tracking-widest mb-2">Finanzas</p>
          <p class="text-2xl font-bold text-white uppercase">Pagos</p>
        </div>
        <div class="bg-white/5 backdrop-blur-sm p-8 rounded-3xl border border-white/10 hover:border-orange-500/50 transition-colors text-center">
          <p class="text-orange-500 text-[10px] font-black uppercase tracking-widest mb-2">Control</p>
          <p class="text-2xl font-bold text-white uppercase">Logs</p>
        </div>
      </div>
    </div>
  </section>

  <div id="roleContent" class="mt-12 transition-all duration-700"></div>
</main>

<script>
  // Toggle mobile menu
  const mobileBtn = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');
  mobileBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));

  // Toggle user info
  const toggleBtn = document.getElementById('toggleInfo');
  const moreInfo = document.getElementById('moreInfo');
  toggleBtn.addEventListener('click', () => {
    const isHidden = moreInfo.classList.contains('hidden');
    moreInfo.classList.toggle('hidden', !isHidden);
    toggleBtn.querySelector('span').textContent = isHidden ? '▴' : '▾';
  });
</script>

<script type="module">
  import { auth } from './firebase-config.js';
  import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

  const roleContentDiv = document.getElementById('roleContent');
  const userFotoImg = document.getElementById('userFotoPerfil');
  const userRoleSpan = document.getElementById('userRole');
  const userNameSpan = document.getElementById('userName');
  const userIdSpan = document.getElementById('userId');
  const userEmailSpan = document.getElementById('userEmail');
  const logoutButton = document.getElementById('logoutButton');
  const logoutButtonMobile = document.getElementById('logoutButtonMobile');

  function updateUI(uid,email,nombre,rol,foto){
    userIdSpan.textContent = uid;
    userEmailSpan.textContent = email;
    userNameSpan.textContent = nombre;
    userFotoImg.src = foto && foto.trim()!=='' ? foto : 'uploads/perfil.jpg';
    userRoleSpan.textContent = rol;

    // Acceso solo organizadores
    if(rol==='organizador'){
      roleContentDiv.innerHTML = `
       `;
    } else {
      roleContentDiv.innerHTML = `
        <section class="mt-6 p-4 bg-red-50 rounded">
          <h2 class="text-xl font-bold mb-2">Acceso limitado</h2>
          <p>Esta sección solo está disponible para organizadores.</p>
        </section>`;
    }
  }

  // Cerrar sesión
  async function logout(){
    await signOut(auth);
    window.location.href = 'login_app.html';
  }
  logoutButton.addEventListener('click', logout);
  logoutButtonMobile.addEventListener('click', logout);

  onAuthStateChanged(auth, async (user)=>{
    if(user){
      try{
        const token = await user.getIdToken();
        const res = await fetch('get_user_info.php',{
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({firebase_token:token})
        });
        const data = await res.json();
        if(data.status==='success' && data.user){
          updateUI(
            data.user.firebase_uid,
            data.user.email,
            data.user.nombre,
            data.user.rol,
            data.user.foto_perfil
          );
        } else {
          roleContentDiv.innerHTML = `<p class="text-red-600">Usuario no registrado en la base de datos.</p>`;
        }
      } catch(err){
        console.error(err);
        roleContentDiv.innerHTML = `<p class="text-red-600">Error al cargar los datos del usuario.</p>`;
      }
    } else {
      window.location.href = 'login_app.html';
    }
  });
</script>

</body>
</html>
