<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

require_once 'dbini.php';

$response = ['status' => 'error', 'message' => 'Rol no encontrado'];

try {
    if (!isset($_GET['firebase_uid'])) {
        throw new Exception("UID no proporcionado");
    }

    $firebaseUid = $_GET['firebase_uid'];
    $pdo = getDbConnection();

    $stmt = $pdo->prepare("SELECT rol FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$firebaseUid]);
    $rol = $stmt->fetchColumn();

    if ($rol) {
        $response['status'] = 'success';
        $response['rol'] = $rol;
    } else {
        throw new Exception("Usuario no encontrado");
    }

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>
