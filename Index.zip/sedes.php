<?php require 'menuadmin.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear Sedes</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">

  <div class="max-w-4xl mx-auto mt-10 bg-white p-6 rounded-lg shadow">
    <div class="flex justify-between items-center mb-4">
      <h1 class="text-2xl font-bold text-gray-700">Gestión de Sedes</h1>
      <button onclick="abrirModalCrear()" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700">
        + Nueva Sede
      </button>
    </div>

    <div id="sedesTableContainer" class="mt-4"></div>
  </div>

  <!-- Modal -->
  <div id="modal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
      <h2 id="modalTitulo" class="text-xl font-semibold mb-4">Nueva Sede</h2>

      <input type="hidden" id="id_sede">
      <div class="mb-3">
        <label class="block text-sm font-medium text-gray-700">Título</label>
        <input id="titulo" type="text" class="mt-1 block w-full border rounded p-2" placeholder="Ej: Sede Central">
      </div>

      <div class="mb-3">
        <label class="block text-sm font-medium text-gray-700">Dirección</label>
        <input id="direccion" type="text" class="mt-1 block w-full border rounded p-2" placeholder="Ej: Av. Principal 123">
      </div>

      <div class="flex justify-end space-x-2 mt-4">
        <button onclick="cerrarModal()" class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded">Cancelar</button>
        <button id="btnGuardar" class="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded">Guardar</button>
      </div>
    </div>
  </div>

  <script>
  // ===================== CRUD =====================
  async function cargarSedes() {
    const res = await fetch('sedes_api.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: new URLSearchParams({ accion: 'listar' })
    });
    const data = await res.json();

    const container = document.getElementById('sedesTableContainer');
    if (!data.success) {
      container.innerHTML = `<p class="text-red-500">${data.message}</p>`;
      return;
    }

    if (data.data.length === 0) {
      container.innerHTML = '<p class="text-gray-500">No hay sedes registradas.</p>';
      return;
    }

    let html = `
    <div class="overflow-x-auto border rounded-lg shadow-md">
      <table class="min-w-full text-sm divide-y divide-gray-200">
        <thead class="bg-gray-100">
          <tr>
            <th class="px-3 py-2 text-left font-medium text-gray-700">ID</th>
            <th class="px-3 py-2 text-left font-medium text-gray-700">Título</th>
            <th class="px-3 py-2 text-left font-medium text-gray-700">Dirección</th>
            <th class="px-3 py-2 text-center font-medium text-gray-700">Acciones</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 bg-white">`;

    data.data.forEach(s => {
      html += `
      <tr class="hover:bg-gray-50">
        <td class="px-3 py-2">${s.id}</td>
        <td class="px-3 py-2">${s.titulo}</td>
        <td class="px-3 py-2">${s.direccion}</td>
        <td class="px-3 py-2 text-center space-x-1">
          <button onclick='abrirModalEditar(${JSON.stringify(s)})' class="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded-md text-xs">Editar</button>
          <button onclick="eliminarSede(${s.id})" class="bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded-md text-xs">Eliminar</button>
        </td>
      </tr>`;
    });

    html += `</tbody></table></div>`;
    container.innerHTML = html;
  }

  async function guardarSede() {
    const id = document.getElementById('id_sede').value;
    const titulo = document.getElementById('titulo').value.trim();
    const direccion = document.getElementById('direccion').value.trim();

    if (!titulo || !direccion) {
      alert("Completa todos los campos.");
      return;
    }

    const accion = id ? 'editar' : 'crear';
    const params = new URLSearchParams({ accion, titulo, direccion });
    if (id) params.append('id', id);

    const res = await fetch('sedes_api.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: params
    });
    const data = await res.json();

    alert(data.message);
    if (data.success) {
      cerrarModal();
      cargarSedes();
    }
  }

  async function eliminarSede(id) {
    if (!confirm("¿Eliminar esta sede?")) return;
    const res = await fetch('sedes_api.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: new URLSearchParams({ accion: 'eliminar', id })
    });
    const data = await res.json();
    alert(data.message);
    if (data.success) cargarSedes();
  }

  // ===================== MODAL =====================
  function abrirModalCrear() {
    document.getElementById('modalTitulo').textContent = 'Nueva Sede';
    document.getElementById('id_sede').value = '';
    document.getElementById('titulo').value = '';
    document.getElementById('direccion').value = '';
    document.getElementById('btnGuardar').onclick = guardarSede;
    document.getElementById('modal').classList.remove('hidden');
  }

  function abrirModalEditar(sede) {
    document.getElementById('modalTitulo').textContent = 'Editar Sede';
    document.getElementById('id_sede').value = sede.id;
    document.getElementById('titulo').value = sede.titulo;
    document.getElementById('direccion').value = sede.direccion;
    document.getElementById('btnGuardar').onclick = guardarSede;
    document.getElementById('modal').classList.remove('hidden');
  }

  function cerrarModal() {
    document.getElementById('modal').classList.add('hidden');
  }

  // Cargar al iniciar
  cargarSedes();
  </script>
</body>
</html>
