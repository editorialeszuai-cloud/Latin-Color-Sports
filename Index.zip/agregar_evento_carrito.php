<?php
require_once 'dbfotografos.php';
$pdo = conectar();
header('Content-Type: application/json');

$evento_id = isset($_POST['evento_id']) ? intval($_POST['evento_id']) : 0;
$firebase_uid = $_POST['firebase_uid'] ?? '';

if (!$evento_id || !$firebase_uid) {
    echo json_encode(['status' => 'error', 'message' => 'Datos incompletos']);
    exit;
}

try {
    // 1. Obtener los IDs de paquetes del evento Y el país del evento para saber qué nombre buscar
    $stmtEv = $pdo->prepare("
        SELECT e.paquetes_eventos, l.pais 
        FROM eventos e
        JOIN lugares l ON e.lugar_id = l.id
        WHERE e.id = ? LIMIT 1
    ");
    $stmtEv->execute([$evento_id]);
    $resEv = $stmtEv->fetch(PDO::FETCH_ASSOC);

    if (!$resEv || empty($resEv['paquetes_eventos'])) {
        echo json_encode(['status' => 'error', 'message' => 'Configuración no encontrada para este evento.']);
        exit;
    }

    // Determinar qué paquete buscar según el país
    $nombre_buscado = (trim(strtolower($resEv['pais'])) === 'colombia') 
        ? 'Todas Las Fotos' 
        : 'Todas Las Fotos Internacional';

    $ids_paquetes = json_decode($resEv['paquetes_eventos'], true);

    // 2. Buscar el paquete correcto dentro de los permitidos para este evento
    $placeholders = implode(',', array_fill(0, count($ids_paquetes), '?'));
    $sql = "SELECT id, precio_por_unidad 
            FROM paquetes_fotos 
            WHERE id IN ($placeholders) 
            AND nombre_paquete = ? 
            LIMIT 1";
    
    $stmtPack = $pdo->prepare($sql);
    // Unimos los IDs con el nombre buscado en el execute
    $params = array_merge($ids_paquetes, [$nombre_buscado]);
    $stmtPack->execute($params);
    $paqueteFinal = $stmtPack->fetch(PDO::FETCH_ASSOC);

    if (!$paqueteFinal) {
        echo json_encode(['status' => 'error', 'message' => "No se encontró el paquete '$nombre_buscado' para este evento."]);
        exit;
    }

    $precio_real = $paqueteFinal['precio_por_unidad'];

    // 3. Verificar si ya está en el carrito
    $check = $pdo->prepare("SELECT id FROM carrito WHERE firebase_uid = ? AND evento_id = ? AND foto_id IS NULL");
    $check->execute([$firebase_uid, $evento_id]);
    
    if ($check->fetch()) {
        echo json_encode(['status' => 'ok', 'message' => 'El pack ya está en tu carrito.']);
        exit;
    }

    // 4. Insertar en carrito
    $ins = $pdo->prepare("INSERT INTO carrito (firebase_uid, evento_id, foto_id, precio, fecha_agregado) VALUES (?, ?, NULL, ?, NOW())");
    $ins->execute([$firebase_uid, $evento_id, $precio_real]);

    echo json_encode([
        'status' => 'ok', 
        'message' => 'Pack añadido correctamente.'
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
}