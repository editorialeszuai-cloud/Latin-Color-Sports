<?php require 'menuadmin.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Calendario Olímpico</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
<style>
.message { padding: 10px; border-radius: 5px; margin-top: 10px; display: none; }
.message.success { background-color: #D1FAE5; color: #065F46; }
.message.error { background-color: #FEE2E2; color: #991B1B; }
</style>
</head>
<body>

<div class="container mx-auto">
  <h1 class="text-2xl font-bold mb-4">Calendario Olímpico</h1>

  <!-- ================== FORMULARIO ================== -->
  <div class="bg-white p-4 rounded shadow mb-6">
    <label>Evento</label>
    <select id="evento_id" class="border p-2 rounded w-full mb-2"></select>

    <label>Nombre del Calendario</label>
    <input id="nombre_calendario" class="border p-2 rounded w-full mb-2">

    <div id="bloquesContainer"></div>

    <button onclick="agregarBloque()" class="bg-blue-600 text-white px-2 py-1 rounded mt-2">+ Fecha/Hora</button>
    <button onclick="guardarCalendario()" class="bg-green-600 text-white px-4 py-2 rounded mt-2">Guardar</button>

    <div id="message" class="message"></div>
  </div>

  <!-- ================== TABLA ================== -->
  <div id="calendariosTableContainer"></div>
</div>

<script>
// ================== Función para mostrar mensajes ==================
function showMessage(msg, type='success'){
  const div = document.getElementById('message');
  div.textContent = msg;
  div.className = `message ${type}`;
  div.style.display = 'block';
}

// ================== Cargar Eventos ==================
async function cargarEventos(){
  try{
    const res = await fetch('eventos_carg.php', {method:'POST', body: new URLSearchParams({accion:'listar'})});
    const data = await res.json();
    const sel = document.getElementById('evento_id');
    if(data.success){
      data.data.forEach(e=>{
        const opt = document.createElement('option');
        opt.value = e.id;
        opt.textContent = e.titulo;
        sel.appendChild(opt);
      });
    }
  }catch(err){
    showMessage('Error cargando eventos: ' + err.message, 'error');
  }
}
cargarEventos();

// ================== Bloques dinámicos ==================
function agregarBloque(){
  const cont = document.getElementById('bloquesContainer');
  const i = cont.children.length;
  const div = document.createElement('div');
  div.className = 'border p-3 my-2 bg-gray-50 rounded';
  div.innerHTML = `
    <div class="grid grid-cols-2 gap-2 mb-2">
      <input type="date" name="fecha[]" class="border p-2 rounded" required>
      <input type="time" name="hora[]" class="border p-2 rounded" required>
    </div>
    <div class="sedesContainer"></div>
    <button type="button" class="bg-green-600 text-white px-2 py-1 rounded" onclick="agregarSede(this,${i})">+ Sede</button>
  `;
  cont.appendChild(div);
}

// ================== Agregar Sede ==================
async function agregarSede(btn,i){
  const cont = btn.previousElementSibling;
  const j = cont.children.length;
  const div = document.createElement('div');
  div.className = 'border p-2 my-2 rounded';
  div.innerHTML = `
    <select name="sede_ids_${i}[]" class="border p-2 rounded w-full mb-2"></select>
    <div class="escenariosContainer"></div>
    <button type="button" class="bg-purple-600 text-white px-2 py-1 rounded" onclick="agregarEscenario(this,${i},${j})">+ Escenario</button>
  `;
  cont.appendChild(div);

  // Cargar sedes
  try{
    const res = await fetch('sedes_carg.php',{method:'POST',body:new URLSearchParams({accion:'listar'})});
    const data = await res.json();
    const sel = div.querySelector('select');
    if(data.success){
      data.data.forEach(s=>{
        const opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.nombre;
        sel.appendChild(opt);
      });
    }
  }catch(err){
    showMessage('Error cargando sedes: ' + err.message,'error');
  }
}

// ================== Agregar Escenario ==================
async function agregarEscenario(btn,i,j){
  const cont = btn.previousElementSibling;
  const k = cont.children.length;
  const div = document.createElement('div');
  div.className = 'border p-2 my-1 rounded';
  div.innerHTML = `
    <select name="escenario_ids_${i}_${j}[]" class="border p-2 rounded w-full mb-2"></select>
    <div class="disciplinasContainer"></div>
    <button type="button" class="bg-indigo-600 text-white px-2 py-1 rounded" onclick="agregarDisciplina(this,${i},${j},${k})">+ Disciplina</button>
  `;
  cont.appendChild(div);

  // Cargar escenarios
  try{
    const res = await fetch('escenarios_carg.php',{method:'POST',body:new URLSearchParams({accion:'listar'})});
    const data = await res.json();
    const sel = div.querySelector('select');
    if(data.success){
      data.data.forEach(e=>{
        const opt = document.createElement('option');
        opt.value = e.id;
        opt.textContent = e.nombre;
        sel.appendChild(opt);
      });
    }
  }catch(err){
    showMessage('Error cargando escenarios: '+err.message,'error');
  }
}

// ================== Agregar Disciplina ==================
async function agregarDisciplina(btn, i, j, k){
    const cont = btn.previousElementSibling;
    const div = document.createElement('div');
    div.className = 'border p-2 rounded my-1 bg-gray-50';
    const equipos = ['México', 'USA', 'Canadá', 'Brasil', 'Argentina', 'Alemania', 'Francia', 'España', 'República Checa', 'República de Corea', 'Marruecos', 'Costa de Marfil', 'Ecuador', 'Suecia', 
	'Túnez', 'Curazao', 'España', 'Cabo Verde', 'Uzbekistán', 'Senegal', 'Arabia Saudita', 'Uruguay', 'Argelia', 'Inglaterra', 'Croacia', 'Colombia', 'Corea', 'Bosnia', 'Suiza', 'Haiti', 'Paises Bajos', 'Tunez',
	'Japon', 'Costa de Marfil', 'Austria', 'Portugal', 'RD Congo', 'Sudafrica', 'Paraguay' ];
    div.innerHTML = `
        <select name="disciplina_ids_${i}_${j}_${k}[]" class="border p-2 rounded w-full mb-2"></select>
        <select name="categoria_${i}_${j}_${k}[]" class="border p-2 rounded w-full mb-2"><option value="M">Masculino</option><option value="F">Femenino</option></select>
        <div class="grid grid-cols-2 gap-2">
            <select name="partido_a_${i}_${j}_${k}[]" class="border p-2 rounded text-xs"><option value="">Equipo A</option>${equipos.map(e=>`<option value="${e}">${e}</option>`).join('')}</select>
            <select name="partido_b_${i}_${j}_${k}[]" class="border p-2 rounded text-xs"><option value="">Equipo B</option>${equipos.map(e=>`<option value="${e}">${e}</option>`).join('')}</select>
        </div>
    `;
    cont.appendChild(div);
    const res = await fetch('disciplinas_carg.php',{method:'POST',body:new URLSearchParams({accion:'listar'})});
    const data = await res.json();
    if(data.success) div.querySelector('select').innerHTML = data.data.map(d => `<option value="${d.id}">${d.nombre}</option>`).join('');
}
// ================== Guardar Calendario ==================
async function guardarCalendario(){
    const form = new FormData();
    form.append('accion', 'crear');
    form.append('evento_id', document.getElementById('evento_id').value);
    form.append('nombre_calendario', document.getElementById('nombre_calendario').value);

    document.querySelectorAll('#bloquesContainer > div').forEach((bloque, i)=>{
        form.append('fecha[]', bloque.querySelector('input[name="fecha[]"]').value);
        form.append('hora[]', bloque.querySelector('input[name="hora[]"]').value);
        bloque.querySelectorAll('.sedesContainer > div').forEach((sedeDiv, j)=>{
            form.append(`sede_ids_${i}[]`, sedeDiv.querySelector('select').value);
            sedeDiv.querySelectorAll('.escenariosContainer > div').forEach((escDiv, k)=>{
                form.append(`escenario_ids_${i}_${j}[]`, escDiv.querySelector('select').value);
                escDiv.querySelectorAll('.disciplinasContainer > div').forEach((discDiv, l)=>{
                    form.append(`disciplina_ids_${i}_${j}_${k}[]`, discDiv.querySelector('select[name^="disciplina"]').value);
                    form.append(`categoria_${i}_${j}_${k}[]`, discDiv.querySelector('select[name^="categoria"]').value);
                    form.append(`partido_a_${i}_${j}_${k}[]`, discDiv.querySelector('select[name^="partido_a"]').value);
                    form.append(`partido_b_${i}_${j}_${k}[]`, discDiv.querySelector('select[name^="partido_b"]').value);
                });
            });
        });
    });

    try {
        const res = await fetch('calendaris_api2.php', {method: 'POST', body: form});
        const data = await res.json();
        showMessage(data.message, data.success ? 'success' : 'error');
        if(data.success) listarCalendario();
    } catch(err) { showMessage('Error: ' + err.message, 'error'); }
}

async function listarCalendario(){
    const res = await fetch('calendaris_api2.php', {method: 'POST', body: new URLSearchParams({accion:'listar'})});
    const data = await res.json();
    if(!data.success) return;
    let html = `<table class="w-full border mt-4"><thead><tr class="bg-gray-100"><th>Calendario</th><th>Fecha/Hora</th><th>Sede</th><th>Disc</th><th>Encuentro</th></tr></thead><tbody>`;
    data.data.forEach(c => {
        html += `<tr><td class="p-2 border">${c.calendario}</td><td class="p-2 border">${c.fecha} ${c.hora}</td><td class="p-2 border">${c.sede}</td><td class="p-2 border">${c.disciplina}</td><td class="p-2 border font-bold">${c.equipo_a || '-'} vs ${c.equipo_b || '-'}</td></tr>`;
    });
    document.getElementById('calendariosTableContainer').innerHTML = html + '</tbody></table>';
}
listarCalendario();
</script>

</body>
</html>
