<?php
// 1. CONFIGURACIÓN
ini_set('display_errors', 0);
error_reporting(E_ALL);

try {
    require_once 'dbfotografos.php'; 

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        header('Content-Type: application/json');
        
        // --- BOTONES DE ROL ---
        if (isset($_POST['accion'])) {
            $resp = "";
            switch ($_POST['accion']) {
                case 'quiero_organizador': $resp = "¡Como **Organizador**, dominas el juego! Crea eventos, gestiona acreditaciones y mira ventas en tiempo real."; break;
                case 'como_faceid': $resp = "¡Es tecnología de punta! Comparamos vectores faciales de 128D para encontrar tus fotos en segundos. 📸"; break;
                case 'quiero_fotografo': $resp = "¡Sube tus ráfagas! Monetiza tu trabajo por paquete o foto individual usando nuestro sistema de carga masiva."; break;
            }
            echo json_encode(["texto" => $resp]);
            exit;
        }

        // --- BÚSQUEDA AVANZADA ---
        if (isset($_POST['pregunta_usuario'])) {
            $raw = trim($_POST['pregunta_usuario']);
            $low = mb_strtolower($raw);
            $texto = "";

            // A. LISTAR DISCIPLINAS QUE TIENEN EVENTOS
            if (strpos($low, 'disciplinas') !== false || strpos($low, 'que tienes') !== false) {
                $sql = "SELECT DISTINCT d.nombre_disciplina 
                        FROM disciplinas d
                        INNER JOIN eventos e ON (e.disciplinas_evento LIKE CONCAT('%\"', d.id, '\"%') 
                                             OR e.disciplinas_evento LIKE CONCAT('%', d.id, '%'))
                        ORDER BY d.nombre_disciplina ASC";
                $stmt = $pdo->query($sql);
                $discs = $stmt->fetchAll();

                if ($discs) {
                    $texto = "¡Jajaja! Estas son las disciplinas con eventos activos: <br>✅ " . implode("<br>✅ ", array_column($discs, 'nombre_disciplina'));
                } else {
                    $texto = "Por ahora no hay disciplinas con eventos vinculados.";
                }
            } 
            // B. BÚSQUEDA POR FECHA O NOMBRE
            else {
                // Traducción simple para fechas como "2 febrero" -> "02-02" o "-02-"
                $meses = ['enero'=>'01', 'febrero'=>'02', 'marzo'=>'03', 'abril'=>'04', 'mayo'=>'05', 'junio'=>'06', 'julio'=>'07', 'agosto'=>'08', 'septiembre'=>'09', 'octubre'=>'10', 'noviembre'=>'11', 'diciembre'=>'12'];
                $busqueda_sql = $raw;
                foreach($meses as $m => $v) { if(strpos($low, $m) !== false) $busqueda_sql = str_replace($m, "-$v-", $low); }
                
                $q = "%" . trim($busqueda_sql) . "%";
                
                $sql = "SELECT e.titulo, e.fecha, d.nombre_disciplina 
                        FROM eventos e
                        LEFT JOIN disciplinas d ON (e.disciplinas_evento LIKE CONCAT('%\"', d.id, '\"%') 
                                                OR e.disciplinas_evento LIKE CONCAT('%', d.id, '%'))
                        WHERE d.nombre_disciplina LIKE :q 
                           OR e.titulo LIKE :q 
                           OR e.fecha LIKE :q 
                        ORDER BY e.fecha DESC LIMIT 5";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':q' => $q]);
                $eventos = $stmt->fetchAll();

                if ($eventos) {
                    $texto = "¡Jajaja! Esto fue lo que encontré: <br><br>";
                    foreach ($eventos as $ev) {
                        $f = date("d/m/Y", strtotime($ev['fecha']));
                        $texto .= "🏆 **{$ev['titulo']}**<br>📍 " . ($ev['nombre_disciplina'] ?? 'Multidisciplina') . " | 📅 $f<br>---<br>";
                    }
                } else {
                    $texto = "¡Jajaja! El marcador está en cero. No encontré nada para '$raw'.";
                }
            }
            
            echo json_encode(["texto" => $texto]);
            exit;
        }
    }
} catch (Exception $e) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        echo json_encode(["texto" => "Falta técnica: " . $e->getMessage()]); exit;
    }
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <!-- CRÍTICO: Evita el zoom automático que descoloca la vista -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <title>LCS Support Pro</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@300;600;900&display=swap');
        :root { --lcs-orange: #f56c1e; --lcs-red: #e4312a; }

        /* Ajustes base para que no haya scroll en el body */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow: hidden;
            font-family: 'Figtree', sans-serif;
            background: white;
        }

        /* Contenedor principal como FLEXBOX VERTICAL */
        .chat-wrapper {
            display: flex;
            flex-direction: column;
            height: 100%; /* Usa el 100% real disponible */
            width: 100%;
        }

        .header { 
            flex-shrink: 0; /* No se encoge */
            background: linear-gradient(90deg, #fff 15%, #f8a700 20%, #f56c1e 60%, #e4312a 100%); 
            padding: 10px; 
            text-align: center; 
        }
        .header img { max-width: 100px; }

        /* El ChatBox es el que debe crecer y tener scroll */
        #chatBox { 
            flex: 1; 
            padding: 15px; 
            overflow-y: auto; 
            background: #f8f9fa; 
            display: flex; 
            flex-direction: column; 
            gap: 12px; 
            -webkit-overflow-scrolling: touch; /* Suavidad en iPhone */
        }

        .msg { max-width: 85%; padding: 12px; border-radius: 15px; font-size: 14px; line-height: 1.4; }
        .msg-ai { background: #fff; border: 1px solid #ddd; align-self: flex-start; border-bottom-left-radius: 2px; }
        .msg-user { background: var(--lcs-orange); color: #fff; align-self: flex-end; border-bottom-right-radius: 2px; font-weight: 600; }

        /* Las opciones y el input se quedan abajo siempre */
        .options { 
            flex-shrink: 0; 
            padding: 10px; 
            display: flex; 
            flex-wrap: wrap; 
            gap: 5px; 
            background: #fff; 
            border-top: 1px solid #eee; 
        }
        .opt-btn { background: #f1f1f1; border: 1px solid #ddd; padding: 6px 10px; border-radius: 20px; font-size: 11px; cursor: pointer; font-weight: bold; }

        .input-area { 
            flex-shrink: 0; 
            padding: 10px 15px; 
            display: flex; 
            gap: 5px; 
            background: #fff; 
            border-top: 1px solid #eee; 
            padding-bottom: env(safe-area-inset-bottom, 10px); /* Ajuste para iPhone con notch */
        }

        input { 
            flex: 1; 
            padding: 12px; 
            border-radius: 25px; 
            border: 1px solid #ddd; 
            outline: none; 
            background: #f9f9f9; 
            font-size: 16px; /* Evita zoom automático en iPhone */
        }

        #sendBtn { 
            background: var(--lcs-red); 
            color: #fff; 
            border: none; 
            padding: 10px 18px; 
            border-radius: 25px; 
            cursor: pointer; 
            font-weight: 900; 
        }
    </style>
</head>
<body>

<div class="chat-wrapper">
    <div class="header"><img src="https://latincolorsports.com/uploads/LATIN-SPORTS.png"></div>
    
    <div id="chatBox">
        <div class="msg msg-ai">¡Jajaja! ¡Hola! Soy el asistente de <b>Latin Color Sports</b>. <br><br>Busca por deporte (Squash), por fecha (2026-03) o elige una opción:</div>
    </div>

    <div class="options">
        <button class="opt-btn" onclick="enviarAccion('quiero_organizador', '🏆 Soy Organizador')">Organizador</button>
        <button class="opt-btn" onclick="enviarAccion('como_faceid', '📸 Info FaceID')">FaceID</button>
        <button class="opt-btn" onclick="enviarAccion('quiero_fotografo', '📷 Soy Fotógrafo')">Fotógrafo</button>
    </div>

    <div class="input-area">
        <input type="text" id="userInput" placeholder="Escribe aquí..." autocomplete="off">
        <button id="sendBtn">GO</button>
    </div>
</div>

<script>
    const chatBox = document.getElementById('chatBox');
    const userInput = document.getElementById('userInput');

    // Función para auto-scroll al final
    function scrollDown() {
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    async function hablar(dataBody) {
        try {
            const resp = await fetch('', { method: 'POST', body: dataBody });
            const data = await resp.json();
            chatBox.innerHTML += `<div class="msg msg-ai">${data.texto}</div>`;
            scrollDown();
        } catch (e) { 
            chatBox.innerHTML += `<div class="msg msg-ai">¡Jajaja! El sistema se fue a tiempo extra. Reintenta.</div>`;
        }
    }

    async function enviarPregunta() {
        const m = userInput.value.trim(); if(!m) return;
        chatBox.innerHTML += `<div class="msg msg-user">${m}</div>`;
        userInput.value = "";
        const fd = new FormData(); fd.append('pregunta_usuario', m);
        scrollDown(); // Scroll inmediato al enviar
        await hablar(fd);
    }

    function enviarAccion(id, texto) {
        chatBox.innerHTML += `<div class="msg msg-user">${texto}</div>`;
        const fd = new FormData(); fd.append('accion', id);
        scrollDown();
        hablar(fd);
    }

    document.getElementById('sendBtn').onclick = enviarPregunta;
    userInput.onkeypress = (e) => { if(e.key==='Enter') enviarPregunta(); };

    // Solución para teclado móvil: reajusta scroll al ganar foco
    userInput.addEventListener('focus', () => {
        setTimeout(scrollDown, 300);
    });
</script>
</body>
</html>