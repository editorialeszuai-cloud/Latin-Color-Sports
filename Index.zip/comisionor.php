<?php require 'navorganizador.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
	
    <title>Mis Comisiones</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: center; }
        th { background-color: orange; color: white; }
        h1 { text-align: center; color: orange; font-size: 45px; font-weight: bold; }
        #nombreUsuario { text-align: center; font-size: 20px; color: #555; margin-top: -10px; }
        #mensaje { color: red; font-weight: bold; margin-top: 20px; }
        #subtotalContainer { margin-top: 20px; font-size: 18px; }
        button { padding: 10px 20px; font-size: 16px; cursor: pointer; margin-top: 10px; }
        #retirarBtn {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        #retirarBtn:hover { background-color: #e60000; transform: scale(1.05); }
        #retirarBtn:active { background-color: #cc0000; transform: scale(0.98); }
        td.pendiente-de-retirar { background-color: #fff3cd; color: #856404; font-weight: bold; }
        td.en-proceso { background-color: #cce5ff; color: #004085; font-weight: bold; }
        td.pagado { background-color: #d4edda; color: #155724; font-weight: bold; }
    </style>
</head>
<body>
    <h1>Mis Comisiones</h1>
    <p id="nombreUsuario"></p>
    <div id="mensaje"></div>

    <table>
        <thead>
            <tr>
                <th>Seleccionar</th>
                <th>ID Comisión</th>
                <th>Monto</th>
                <th>ID Compra</th>
                <th>Foto</th>
                <th>Estado de Retiro</th>
            </tr>
        </thead>
        <tbody id="tablaComisiones"></tbody>
    </table>

    <div id="subtotalContainer">
        Subtotal a retirar: $<span id="subtotal">0.00</span><br>
        <button id="retirarBtn">Retirar seleccionadas</button>
    </div>

    <!-- Firebase -->
    <script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-auth-compat.js"></script>

   <script>
    const firebaseConfig = {
        apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
        authDomain: "latin-group-406b1.firebaseapp.com",
        projectId: "latin-group-406b1",
        storageBucket: "latin-group-406b1.firebasestorage.app",
        messagingSenderId: "21494348297",
        appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
        measurementId: "G-NXZW7KNWW1"
    };

    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
    const auth = firebase.auth();

    const mensajeDiv   = document.getElementById('mensaje');
    const tablaBody    = document.getElementById('tablaComisiones'); // Nota: asegúrate que este sea el id del tbody
    const subtotalSpan = document.getElementById('subtotal');
    const nombreUsuario = document.getElementById('nombreUsuario');

    auth.onAuthStateChanged(async (user) => {
        if (!user) {
            window.location.href = 'login_app.html';
            return;
        }

        try {
            const token = await user.getIdToken();
            const resUser = await fetch('get_user_info.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firebase_token: token })
            });

            const userData = await resUser.json();

            if (userData.status === 'success' && userData.user) {
                nombreUsuario.textContent = 'Bienvenido, ' + userData.user.nombre;
                cargarComisiones(userData.user.firebase_uid);
            } else {
                mensajeDiv.textContent = 'Error: ' + (userData.message || 'No se pudo cargar el usuario');
            }
        } catch (err) {
            console.error(err);
            mensajeDiv.textContent = 'Error crítico de conexión.';
        }
    });

    async function cargarComisiones(firebase_uid) {
        try {
            const res = await fetch('get_comisionesorganizador.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firebase_uid: firebase_uid })
            });

            const data = await res.json();
            tablaBody.innerHTML = '';

            if (data.status !== 'success') {
                mensajeDiv.innerHTML = `<p>⚠️ ${data.message}</p>`;
                return;
            }

            data.comisiones.forEach(c => {
                const tr = document.createElement('tr');
                // Limpieza de monto (por si viene con coma)
                const monto = parseFloat(String(c.monto).replace(',', '.')) || 0;

                tr.innerHTML = `
                    <td><input type="checkbox" class="checkComision" data-monto="${monto}" value="${c.comision_id}"></td>
                    <td>#${c.comision_id}</td>
                    <td>$${monto.toFixed(2)}</td>
                    <td>${c.compra_id}</td>
                    <td>${c.foto_url ? `<img src="${c.foto_url}" width="50" class="rounded">` : 'N/A'}</td>
                    <td class="estado-${c.estado_retiro.toLowerCase().replace(/ /g, '-')}">${c.estado_retiro}</td>
                `;
                tablaBody.appendChild(tr);
            });

            document.querySelectorAll('.checkComision').forEach(cb => {
                cb.addEventListener('change', actualizarSubtotal);
            });

        } catch (err) {
            console.error(err);
        }
    }

    function actualizarSubtotal() {
        let totalCentavos = 0;
        
        document.querySelectorAll('.checkComision:checked').forEach(cb => {
            const monto = parseFloat(cb.dataset.monto) || 0;
            // Sumamos en centavos para evitar el error de 0.1
            totalCentavos += Math.round(monto * 100);
        });
        
        const subtotal = totalCentavos / 100;
        subtotalSpan.textContent = subtotal.toLocaleString('es-CO', { 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 2 
        });
    }
</script>
</body>
</html>