<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'dbfotografos.php';
$pdo = conectar();

// Obtener firebase_uid desde GET
$firebase_uid = $_GET['firebase_uid'] ?? '';
if (!$firebase_uid) {
    die("<p style='color:red'>Usuario no identificado.</p>");
}

// Obtener items del carrito (Fotos individuales)
$stmt = $pdo->prepare("
    SELECT 
        c.id AS carrito_id,
        c.precio AS precio_unitario,
        c.foto_id,
        e.titulo AS evento_titulo
    FROM carrito c
    INNER JOIN fotos f ON c.foto_id = f.id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    INNER JOIN eventos e ON p.evento_id = e.id
    WHERE c.firebase_uid = ?
    ORDER BY c.fecha_agregado DESC
");
$stmt->execute([$firebase_uid]);
$carrito = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$carrito) {
    die("<p style='color:red'>Tu carrito está vacío.</p>");
}

// Calcular total
$total = 0;
foreach ($carrito as $item) {
    $total += $item['precio_unitario'];
}

// Generar referencia única (EC para fotos individuales)
$ref_local = "EC-" . time();

// Insertar compra pendiente (Fotos)
$stmt = $pdo->prepare("INSERT INTO compras (firebase_uid, referencia, total, estado) VALUES (?, ?, ?, 'Pendiente')");
$stmt->execute([$firebase_uid, $ref_local, $total]);
$id_compra = $pdo->lastInsertId();

// Insertar detalle_compras
foreach ($carrito as $item) {
    $stmt = $pdo->prepare("INSERT INTO detalle_compras (id_compra, id_foto, precio) VALUES (?, ?, ?)");
    $stmt->execute([$id_compra, $item['foto_id'], $item['precio_unitario']]);
}

// Registrar comisiones de cada foto (Siguiendo la estructura limpia de paquetes)
foreach ($carrito as $item) {
    $precio = $item['precio_unitario'];
    $stmt = $pdo->prepare("
        INSERT INTO comisiones_usuario (compra_id, foto_id, admin, fotografo, organizador, soporte, comercial)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $id_compra,
        $item['foto_id'],
        $precio * 0.45, // admin 45%
        $precio * 0.25, // fotografo 25%
        $precio * 0.10, // organizador 10%
        $precio * 0.03, // soporte 3%
        $precio * 0.05  // comercial 5%
    ]);
}

// Redirigir al checkout Wompi
header("Location: wompi_checkout.php?compra_id=$id_compra");
exit;