<?php
require_once 'dbfotografos.php';
$stmt = $pdo->query("SELECT id, titulo FROM eventos ORDER BY fecha DESC");
$eventos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Latin Colors Sports</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
<style>
#resultadosPanel { left: 2rem; width: 260px; transition: all 2s ease; }
#resultados img:hover { transform: scale(1.05); }
</style>
</head>
<body class="bg-gray-100">

<nav class="bg-black shadow sticky top-0 z-50 relative">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex justify-between items-center py-3">

      <div class="flex items-center space-x-2">
        <img class="h-10" src="uploads/LATIN-SPORTS.png" alt="Logo">
        <span class="font-bold text-xl text-white">Latin Colors Sports</span>
      </div>
      
      <div class="flex items-center gap-6">

  <!-- Home -->
  <a href="index.php" class="text-white hover:text-orange-600 font-medium transition flex items-center gap-1">
 <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
    <path d="M12 3l9 8h-3v9h-4v-6H10v6H6v-9H3l9-8z" />
  </svg>
    Home
  </a>

  <div class="relative group">
  <button class="text-white hover:text-orange-600 font-medium transition flex items-center gap-1">
    Mis Compras
    <svg class="w-4 h-4 mt-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
    </svg>
  </button>

  <div class="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-lg
              invisible opacity-0 group-hover:visible group-hover:opacity-100
              transition-all duration-200 z-50">

    <a href="migaleria.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Mis Colecciones</a>
    <a href="miscomprasfotos.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Mis Fotos</a>
    <a href="miscomprasvideos.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Mis Videos</a>
    <a href="miscompraspaquetes.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">Mis Paquetes</a>

  </div>
</div>



</div>


     <div class="relative flex items-center gap-2 bg-gray-900 p-2 rounded-xl shadow-lg">
    
    <!-- Icono de persona -->
    <div class="flex items-center justify-center w-10 h-10 bg-orange-600 rounded-full">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5.121 17.804A9 9 0 1112 21a9 9 0 01-6.879-3.196z" />
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
    </div>

    <!-- Selector de evento -->
    <select id="eventoSelect" class="text-sm bg-gray-800 text-white border border-gray-600 rounded-lg p-2 focus:ring-2 focus:ring-orange-500 focus:border-orange-500">
        <option value="">Seleccione un evento</option>
        <?php foreach($eventos as $e): ?>
        <option value="<?= htmlspecialchars($e['id']) ?>"><?= htmlspecialchars($e['titulo']) ?></option>
        <?php endforeach; ?>
    </select>

    <!-- Input de archivo -->
    <label class="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 cursor-pointer text-white rounded-lg px-3 py-2 text-sm">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V8m0 0l5 5m-5-5l-5 5M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <span>Seleccionar foto</span>
        <input type="file" id="faceInput" accept="image/*" class="hidden">
    </label>

    <!-- Botón Buscar -->
    <button id="btnFaceSearch" class="bg-orange-600 hover:bg-orange-700 text-white font-semibold px-4 py-2 rounded-lg transition-all duration-200 shadow-md hover:shadow-lg">
        Buscar
    </button>

    <!-- Panel de resultados -->
    <div id="resultadosPanel" class="hidden absolute left-0 top-full mt-3 bg-white shadow-xl rounded-lg p-4 w-[280px] z-50">
        <p id="resultadoIA" class="text-gray-700 mb-2 font-medium"></p>
        <div id="resultados" class="grid grid-cols-2 gap-2"></div>
        <div id="verMasBtn" class="mt-3 text-center"></div>
    </div>

</div>

    </div>
  </div>
</nav>

<script>
let registeredFaces = []; // Aquí normalmente cargarías descriptores de fotos registradas si quieres comparar client-side

window.addEventListener('load', async () => {
    await Promise.all([
        faceapi.nets.ssdMobilenetv1.loadFromUri('../face-demo/models/'),
        faceapi.nets.faceLandmark68Net.loadFromUri('../face-demo/models/'),
        faceapi.nets.faceRecognitionNet.loadFromUri('../face-demo/models/')
    ]);
    console.log("Modelos cargados");
});

document.getElementById('btnFaceSearch').addEventListener('click', async () => {
    const input = document.getElementById('faceInput');
    const resultado = document.getElementById('resultadoIA');
    const cont = document.getElementById('resultados');
    const verMas = document.getElementById('verMasBtn');
    const panel = document.getElementById('resultadosPanel');
    panel.classList.remove('hidden');

    if (!input.files[0]) return alert('Selecciona una foto primero');

    const evento = document.getElementById('eventoSelect').value;
    if (!evento) return alert('Selecciona un evento');

    resultado.textContent = "Detectando rostro...";
    cont.innerHTML = "";
    verMas.innerHTML = "";

    const file = input.files[0];
    const img = await faceapi.bufferToImage(file);
    const detection = await faceapi.detectSingleFace(img).withFaceLandmarks().withFaceDescriptor();
    if (!detection) return alert('No se detectó rostro');

    const descriptorUser = detection.descriptor;

    const fd = new FormData();
    fd.append('evento_id', evento);
    fd.append('foto', file);
    fd.append('descriptors', JSON.stringify(Array.from(descriptorUser)));

    const res = await fetch('buscar_rosto.php', { method:'POST', body:fd });
    const data = await res.json();

    if (!data.fotos || !data.fotos.length) {
        resultado.textContent = "No se encontraron coincidencias";
        return;
    }

    resultado.textContent = `Coincidencias: ${data.fotos.length}`;
    cont.innerHTML = "";

    data.fotos.forEach(f => {
        const imgEl = document.createElement('img');
        imgEl.src = "miniatura.php?img="+encodeURIComponent(f.url)+"&w=60";
        imgEl.className = "w-[150px] h-[150px] object-cover rounded border border-gray-300";
        cont.appendChild(imgEl);
    });

    if (data.total > 4) {
        verMas.innerHTML = `<a href="${data.ver_mas}" class="block bg-orange-600 hover:bg-orange-700 text-white py-2 px-4 rounded text-sm font-semibold">
        Ver más resultados (${data.total})
        </a>`;
    }
});
</script>

</body>
</html>
