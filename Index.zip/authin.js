// auth-handler.js - Modo libre activado
console.log("✅ Sistema de autenticación en modo libre (Invitado).");