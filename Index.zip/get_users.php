<?php
require_once "conexion.php";
$conn = conectar();

// --- Obtener todos los usuarios directamente ---
$sql = "SELECT * FROM usuarios ORDER BY id DESC";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['status'=>'error','message'=>$conn->error]);
    exit;
}

$usuarios = [];
while($row = $result->fetch_assoc()){
    $usuarios[] = $row;
}

echo json_encode(['status'=>'success','usuarios'=>$usuarios]);
?>
