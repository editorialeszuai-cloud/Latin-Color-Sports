<?php
// Conexión a la base de datos
require_once 'dbfotografos.php';

$evento_id = isset($_GET['evento_id']) ? intval($_GET['evento_id']) : 1;

// --- INFO DEL EVENTO ---
$stmtEvento = $pdo->prepare("
    SELECT e.titulo, l.ciudad, l.pais 
    FROM eventos e 
    LEFT JOIN lugares l ON e.lugar_id = l.id 
    WHERE e.id = ? LIMIT 1
");
$stmtEvento->execute([$evento_id]);
$eventoInfo = $stmtEvento->fetch(PDO::FETCH_ASSOC) ?: ['titulo' => '', 'ciudad' => '', 'pais' => ''];

// --- DATOS PARA FILTROS ---
function fetchAll2($pdo, $sql, $params = []) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$disciplinas = fetchAll2($pdo, "
    SELECT DISTINCT d.id, d.nombre_disciplina AS nombre
    FROM disciplinas d
    INNER JOIN calendario_fotografos cf ON cf.disciplina_id = d.id
    INNER JOIN fotos f ON f.postulacion_id = cf.postulacion_id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    WHERE p.evento_id = ?
", [$evento_id]);

$sedes = fetchAll2($pdo, "
    SELECT DISTINCT s.id, s.titulo AS nombre
    FROM sedes s
    INNER JOIN calendario_fotografos cf ON cf.sede_id = s.id
    INNER JOIN fotos f ON f.postulacion_id = cf.postulacion_id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    WHERE p.evento_id = ?
", [$evento_id]);

$escenarios = fetchAll2($pdo, "
    SELECT DISTINCT esc.id, esc.nombre
    FROM escenarios esc
    INNER JOIN calendario_fotografos cf ON cf.escenario_id = esc.id
    INNER JOIN fotos f ON f.postulacion_id = cf.postulacion_id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    WHERE p.evento_id = ?
", [$evento_id]);

$categorias = fetchAll2($pdo, "
    SELECT DISTINCT cbd.id, cbd.categoria AS nombre
    FROM calendario_bloque_disciplina cbd
    INNER JOIN calendario_fotografos cf ON cf.bloque_dis_id = cbd.id
    INNER JOIN fotos f ON f.postulacion_id = cf.postulacion_id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    WHERE p.evento_id = ?
    AND cbd.categoria IS NOT NULL AND cbd.categoria != ''
", [$evento_id]);

$partidos_list = fetchAll2($pdo, "
    SELECT DISTINCT p2.id, 
           CONCAT(p2.equipo_a, ' vs ', p2.equipo_b) AS nombre_partido,
           cf.sede_id
    FROM partidos p2
    INNER JOIN calendario_fotografos cf ON cf.partido_id = p2.id
    INNER JOIN fotos f ON f.postulacion_id = cf.postulacion_id
    WHERE cf.evento_id = ? AND p2.equipo_a IS NOT NULL
", [$evento_id]);

// Fotos iniciales — con miniatura, 40 registros
$stmt = $pdo->prepare("
    SELECT 
        f.id, 
        f.url, 
        MIN(p2.equipo_a) AS equipo_a, 
        MIN(p2.equipo_b) AS equipo_b 
    FROM fotos f 
    -- 1. Unimos fotos con calendario_fotografos usando el id (según tu indicación)
    INNER JOIN calendario_fotografos cf ON f.postulacion_id = cf.id
    -- 2. Unimos con postulaciones para poder filtrar por evento_id
    INNER JOIN postulaciones p ON cf.postulacion_id = p.id
    -- 3. Unimos con partidos
    LEFT JOIN partidos p2 ON cf.partido_id = p2.id 
    -- 4. Excluir moderadas
    LEFT JOIN fotos_moderacion fm ON f.id = fm.foto_id 
    WHERE p.evento_id = ? 
    AND fm.foto_id IS NULL 
    GROUP BY f.id 
    ORDER BY f.id DESC
");
$stmt->execute([$evento_id]);
$fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);
$fotosJson = json_encode($fotos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imágenes de Deporte - Latin Color Sports</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script defer src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <script type="module" src="authin.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;700;900&display=swap');

        :root {
            --orange: #f56c1e;
            --orange-dark: #ea580c;
            --bg: #050505;
            --surface: #0f0f0f;
            --border: rgba(255,255,255,0.07);
        }

        * { box-sizing: border-box; }
        body { background: var(--bg); color: #fafafa; font-family: 'Inter', sans-serif; overflow-x: hidden; }

        .glass {
            background: rgba(0,0,0,0.72);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-bottom: 1px solid var(--border);
        }

        /* ══ FOTO CARD ══ */
        .foto-card {
            position: relative;
            background: var(--surface);
            border-radius: 14px;
            overflow: hidden;
            border: 1px solid #1a1a1a;
            aspect-ratio: 3/4;
            transition: transform .3s cubic-bezier(.175,.885,.32,1.275), border-color .3s, box-shadow .3s;
        }
        .foto-card:hover {
            transform: scale(1.025);
            border-color: var(--orange);
            box-shadow: 0 16px 32px rgba(0,0,0,.7), 0 0 0 1px rgba(245,108,30,.2);
        }
        .foto-card > a {
            display: block;
            width: 100%;
            height: 100%;
        }
        /* Imagen optimizada: invisible hasta cargar */
        .foto-card > a img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform .5s ease, opacity .3s;
            opacity: 0;
        }
        .foto-card > a img.loaded { opacity: 1; }
        .foto-card:hover > a img { transform: scale(1.06); }

        .foto-card .overlay-hover {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0,0,0,.6) 0%, transparent 60%);
            opacity: 0;
            transition: opacity .3s;
            pointer-events: none;
            z-index: 5;
        }
        .foto-card:hover .overlay-hover { opacity: 1; }

        .foto-card .watermark {
            position: absolute;
            inset: 0;
            z-index: 6;
            pointer-events: none;
            opacity: 0.28;
            background-image: url('uploads/watermark.png');
            background-repeat: repeat;
            background-size: 100px;
        }

        .foto-card .foto-actions {
            position: absolute;
            bottom: 8px;
            right: 8px;
            z-index: 10;
            display: flex;
            flex-direction: column;
            gap: 6px;
            opacity: 0;
            transform: translateY(6px);
            transition: opacity .25s, transform .25s;
        }
        .foto-card:hover .foto-actions { opacity: 1; transform: translateY(0); }

        .foto-card .foto-share {
            position: absolute;
            top: 8px;
            right: 8px;
            z-index: 10;
            display: flex;
            gap: 5px;
            opacity: 0;
            transition: opacity .25s;
        }
        .foto-card:hover .foto-share { opacity: 1; }

        .foto-card .foto-check {
            position: absolute;
            top: 8px;
            left: 8px;
            z-index: 10;
            opacity: 0;
            transition: opacity .25s;
        }
        .foto-card:hover .foto-check { opacity: 1; }

        /* Drawer */
        .drawer { transition: transform .5s cubic-bezier(.4,0,.2,1); }

        @keyframes slideUp {
            from { opacity:0; transform:translateY(30px) scale(.97); }
            to   { opacity:1; transform:translateY(0)    scale(1);   }
        }
        .asistente-card { animation: slideUp .35s cubic-bezier(.34,1.56,.64,1) both; }

        @keyframes fadeIn { from{opacity:0;transform:translateX(10px)} to{opacity:1;transform:translateX(0)} }
        .opcion-btn { animation: fadeIn .25s ease both; }

        .analyzing { animation: pulse-orange 1.4s infinite; }
        @keyframes pulse-orange { 0%,100%{box-shadow:0 0 0 var(--orange)} 50%{box-shadow:0 0 20px var(--orange)} }

        #bannerPack { transition: all .6s ease; overflow:hidden; }
        #bannerPack.hidden-custom { max-height:0; opacity:0; margin:0; padding:0; pointer-events:none; }

        #mainContent::-webkit-scrollbar { width:5px; }
        #mainContent::-webkit-scrollbar-track { background:var(--bg); }
        #mainContent::-webkit-scrollbar-thumb { background:#222; border-radius:10px; }
        #mainContent::-webkit-scrollbar-thumb:hover { background:var(--orange); }
        .scrollbar-hide { scrollbar-width:none; }
        .scrollbar-hide::-webkit-scrollbar { display:none; }

        .btn-modern {
            display:flex; align-items:center; gap:7px;
            padding:9px 16px; border-radius:12px;
            font-size:10px; font-weight:900; text-transform:uppercase; letter-spacing:.1em;
            background:rgba(255,255,255,.05); color:#fff;
            border:1px solid rgba(255,255,255,.1);
            transition:all .25s cubic-bezier(.4,0,.2,1); cursor:pointer; text-decoration:none;
            white-space:nowrap; flex-shrink:0;
        }
        .btn-modern:hover { background:var(--orange); border-color:var(--orange); box-shadow:0 4px 14px rgba(245,108,30,.4); transform:translateY(-1px); }

        .idiomas { display:flex; gap:8px; align-items:center; }
        .idiomas img { cursor:pointer; transition:transform .2s; }
        .idiomas img:hover { transform:scale(1.15); }

        .upload-zone {
            border:2px dashed rgba(255,255,255,.15); border-radius:16px;
            background:rgba(255,255,255,.03);
            transition:all .3s ease; cursor:pointer;
        }
        .upload-zone:hover, .upload-zone.drag-over {
            border-color: var(--orange);
            background: rgba(245,108,30,.07);
        }

        #video {
            width:100%; max-width:340px;
            height:auto; max-height:260px;
            object-fit:cover;
            display:block; margin:0 auto;
            border-radius:12px;
        }

        @media (max-width:640px) {
            .text-2xl { font-size:1.2rem !important; }
            #video { max-height:200px; }
        }

        .difuminado-lados {
            background:white;
            mask-image: linear-gradient(to right, transparent, white 10%, white 90%, transparent);
            -webkit-mask-image: linear-gradient(to right, transparent, white 10%, white 90%, transparent);
        }

        #filtrosBadge {
            display: none;
            align-items: center;
            gap: 6px;
            background: rgba(245,108,30,.15);
            border: 1px solid rgba(245,108,30,.35);
            border-radius: 10px;
            padding: 4px 10px;
            font-size: 9px;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: .1em;
            color: #f97316;
            flex-wrap: wrap;
        }
        #filtrosBadge.visible { display: flex; }
    </style>
</head>
<body class="h-screen overflow-hidden flex flex-col">

<!-- ════════════════════════════════════════
     HEADER SUPERIOR
════════════════════════════════════════ -->
<header class="flex-none">
<div class="flex justify-between items-center py-[5px] px-4 w-full"
     style="background:linear-gradient(90deg,#f8a700 0%,#f56c1e 50%,#e4312a 100%);">

    <div class="difuminado-lados px-1 py-1 rounded-xl shrink-0">
        <a href="index.php">
            <img src="../uploads/LATIN-SPORTS.png" alt="Logo" style="width:46px;">
        </a>
    </div>

    <a href="conjuntodeventos.php" class="btn-modern text-white border-white/20 hover:bg-white hover:text-orange-600">
        <span class="material-icons text-sm">home</span>
        <span class="hidden md:inline">Home</span>
    </a>

    <div class="idiomas">
        <img src="imagenes/idioma-01.webp" width="22" alt="EN" onclick="applyLanguage('en')">
        <img src="imagenes/idioma-02.webp" width="22" alt="ES" onclick="applyLanguage('es')">
    </div>

    <div class="flex flex-wrap justify-end items-center gap-2 text-[10px] font-bold text-white uppercase italic tracking-tight">
        <?php if (!empty($eventoInfo['titulo'])): ?>
        <div class="flex items-center gap-1.5 bg-white/20 px-2.5 py-1 rounded-lg border border-white/10 shrink-0">
            <span class="material-icons text-white" style="font-size:14px">event</span>
            <span class="truncate max-w-[120px] md:max-w-none"><?= htmlspecialchars($eventoInfo['titulo']) ?></span>
        </div>
        <?php endif; ?>
        <?php if (!empty($eventoInfo['ciudad'])): ?>
        <div class="flex items-center gap-1.5 bg-white/20 px-2.5 py-1 rounded-lg border border-white/10 shrink-0 hidden sm:flex">
            <span class="material-icons text-white" style="font-size:14px">place</span>
            <span><?= htmlspecialchars($eventoInfo['ciudad']) ?><?= !empty($eventoInfo['pais']) ? ', '.$eventoInfo['pais'] : '' ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Banner Pack -->
<div id="bannerPack" class="hidden bg-[#0f0f0f] border-b border-white/5 px-4 py-3 flex items-center justify-between gap-3 relative overflow-hidden">
    <div class="absolute inset-0 bg-gradient-to-r from-orange-500/8 to-transparent pointer-events-none"></div>
    <div class="flex items-center gap-3 z-10">
        <div class="w-8 h-8 rounded-lg bg-orange-600/20 flex items-center justify-center shrink-0">
            <span class="material-icons text-orange-500 text-sm">photo_library</span>
        </div>
        <div>
            <p class="text-white font-black text-[11px] uppercase tracking-widest italic">Pack "Full Access"</p>
            <p class="text-[9px] text-gray-500 uppercase tracking-widest font-bold hidden sm:block">Todas las fotos del evento en alta calidad</p>
        </div>
    </div>
    <button onclick="window.addFullPack(<?= $evento_id ?>)" id="btnPackAction" 
            class="z-10 bg-orange-600 text-white font-black px-4 py-2 rounded-xl text-[9px] uppercase tracking-widest hover:bg-white hover:text-orange-600 transition-all active:scale-95 shrink-0">
        Comprar
    </button>
</div>

<!-- NAV PRINCIPAL -->
<nav class="glass px-3 py-2 z-[60]">
    <div class="flex items-center justify-between gap-2 overflow-x-auto scrollbar-hide">

        <button id="btnOpenFilters" class="btn-modern">
            <span class="material-icons text-orange-500 text-sm">tune</span>
            <span class="hidden sm:inline">Fan Fest</span>
        </button>

       <a id="btnIAUnificado" href="https://fanpic.latincolorsports.com/panel" 
   class="btn-modern bg-orange-600/20 border-orange-500/40 hover:bg-orange-600">
    <span class="material-icons text-orange-400 text-sm">face_retouching_natural</span>
    <span class="hidden sm:inline">¡No encuentras tu foto!</span>
</a>

        <button id="btnAbrirRegistroIA" class="btn-modern">
            <span class="material-icons text-sm">how_to_reg</span>
            <span class="hidden sm:inline">Selfie</span>
        </button>

        <a href="login_app.html" class="btn-modern">
            <span class="material-icons text-sm">dashboard</span>
            <span class="hidden sm:inline">Registro</span>
        </a>

        <button id="btnBulkCart" class="btn-modern hidden">
            <span class="material-icons text-sm">add_shopping_cart</span>
            <span>Seleccionados</span>
        </button>

        <button id="btnOpenCart" class="relative shrink-0" style="padding:10px;background:rgba(255,255,255,.05);border-radius:50%;border:1px solid rgba(255,255,255,.1);transition:all .25s;">
            <span class="material-icons text-white text-sm">shopping_bag</span>
            <span id="cartCount" class="absolute -top-1 -right-1 bg-orange-600 text-white text-[8px] font-black w-5 h-5 flex items-center justify-center rounded-full">0</span>
        </button>
    </div>
</nav>
</header>

<!-- ════════════════════════════════════════
     LAYOUT PRINCIPAL
════════════════════════════════════════ -->
<div class="flex flex-1 overflow-hidden">
    <div id="overlay" class="fixed inset-0 bg-black/90 z-[70] hidden backdrop-blur-sm"></div>

    <!-- SIDEBAR FILTROS -->
    <aside id="sidebarFiltros" class="drawer fixed inset-y-0 left-0 w-full sm:w-80 bg-[#090909]/95 backdrop-blur-xl z-[80] transform -translate-x-full flex flex-col border-r border-white/8 shadow-2xl">
        <div class="px-6 pt-6 pb-3 flex justify-between items-center border-b border-white/5">
            <h3 class="text-[10px] font-black uppercase tracking-[.3em] text-orange-500">Filtros Avanzados</h3>
            <button onclick="window.toggleFiltros(false)" class="material-icons text-gray-500 hover:text-white transition-colors">close</button>
        </div>
        <div class="flex-1 overflow-y-auto px-6 py-5 space-y-5">
            <div id="filtrosInternos"></div>
        </div>
        <div class="p-5 border-t border-white/5">
            <button id="btnAplicarFiltros" class="w-full bg-orange-600 hover:bg-orange-500 text-white font-black py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95">
                Aplicar Filtros
            </button>
            <button id="btnLimpiarFiltros" class="w-full mt-2 bg-white/5 hover:bg-white/10 text-gray-400 font-bold py-3 rounded-xl text-[10px] uppercase tracking-widest transition-all">
                Limpiar Todo
            </button>
        </div>
    </aside>

    <!-- MAIN -->
    <main class="flex-1 overflow-y-auto p-3 md:p-6" id="mainContent">
        <div class="max-w-7xl mx-auto">

            <div class="flex flex-wrap items-center justify-between gap-2 mb-5 px-1">
                <div class="flex items-center gap-3 flex-wrap">
                    <span id="resultadoIA" class="text-orange-500 text-[10px] font-black uppercase tracking-[.3em]">Galería Pública</span>
                    <div id="filtrosBadge">
                        <span class="material-icons" style="font-size:13px">filter_list</span>
                        <span id="filtrosBadgeTexto"></span>
                    </div>
                </div>
                <button id="btnResetAll" class="text-gray-500 hover:text-white text-[10px] font-black uppercase tracking-widest flex items-center gap-2 transition-colors">
                    <span class="material-icons text-sm">restart_alt</span> Resetear
                </button>
            </div>

            <!-- GRID responsive -->
            <div id="galeria" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 md:gap-4"></div>

            <!-- Sentinel de infinite scroll -->
            <div class="w-full flex justify-center py-10">
                <div id="btnLoadMore" class="px-6 py-3 bg-[#0f0f0f]/60 border border-white/5 text-gray-400 font-mono text-xs uppercase tracking-widest rounded-2xl flex items-center gap-3">
                    <span class="w-4 h-4 rounded-full border-2 border-t-transparent border-orange-500 animate-spin"></span>
                    Cargando galería...
                </div>
            </div>
        </div>
    </main>

    <!-- CARRITO -->
    <aside id="carritoContainer" class="drawer fixed inset-y-0 right-0 w-full sm:w-96 bg-[#090909] border-l border-white/5 z-[80] transform translate-x-full flex flex-col">
        <div class="p-5 border-b border-white/5 flex justify-between items-center">
            <div>
                <p class="text-[10px] font-black text-orange-500 uppercase tracking-widest">Tu Carrito</p>
                <p class="text-[9px] text-gray-500 uppercase">Selección de fotos</p>
            </div>
            <button id="btnCloseCart" class="material-icons text-gray-500 hover:text-white transition-colors">close</button>
        </div>
        <div id="carritoContent" class="flex-1 overflow-y-auto p-5 space-y-3"></div>
        <div class="p-5 border-t border-white/5">
            <button id="btnBackToGallery" class="w-full bg-orange-600/10 hover:bg-orange-600 text-orange-500 hover:text-white font-black py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all border border-orange-500/20 active:scale-95 flex items-center justify-center gap-2">
                <span class="material-icons text-sm">arrow_back</span>
                Seguir Explorando
            </button>
        </div>
    </aside>
</div>

<!-- ════════════════════════════════════════
     MODAL ASISTENTE DE FILTROS
════════════════════════════════════════ -->
<div id="modalAsistente" class="fixed inset-0 z-[110] hidden items-center justify-center bg-black/95 backdrop-blur-xl p-4">
    <div class="asistente-card bg-[#0d0d0d] border border-white/10 rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden">
        <div class="w-full bg-white/8 h-1">
            <div id="assistProgress" class="bg-orange-500 h-1 transition-all duration-500" style="width:0%"></div>
        </div>
        <div class="flex items-center justify-between px-6 pt-5 pb-2">
            <span id="assistStepLabel" class="text-[9px] text-gray-600 uppercase font-black tracking-[.25em]">Paso 1</span>
            <button onclick="cerrarAsistente()" class="text-gray-600 hover:text-white transition-colors p-1 rounded-lg hover:bg-white/10">
                <span class="material-icons text-lg">close</span>
            </button>
        </div>
        <div class="px-6 pb-4">
            <h2 id="assistTitle" class="text-xl font-black text-white leading-tight"></h2>
        </div>
        <div id="assistOptions" class="px-4 pb-4 space-y-2 max-h-[50vh] overflow-y-auto scrollbar-hide"></div>
        <div class="px-6 pb-6">
            <button id="assistSkip" onclick="asistenteSiguiente(null)" class="w-full text-gray-600 hover:text-gray-300 font-black text-[9px] uppercase tracking-[.2em] py-3 rounded-xl border border-white/5 hover:bg-white/5 transition-all flex items-center justify-center gap-2">
                <span class="material-icons text-sm">skip_next</span>
                Saltar esta pregunta
            </button>
        </div>
    </div>
</div>


<!-- ════════════════════════════════════════
     MODAL REGISTRO BIOMÉTRICO
════════════════════════════════════════ -->
<div id="modalRegistro" class="fixed inset-0 z-[130] hidden items-center justify-center bg-black/90 backdrop-blur-xl p-4">
    <div class="asistente-card bg-white rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden">
        <div class="flex justify-between items-center px-6 pt-5 pb-2">
            <h2 class="text-xl font-bold text-gray-800">Vincular Rostro</h2>
            <button id="btnCerrarRegistro" class="text-gray-400 hover:text-gray-700 p-1">
                <span class="material-icons">close</span>
            </button>
        </div>
        <p class="px-6 pb-4 text-sm text-gray-500">Registra tu perfil biométrico para encontrarte en todas las fotos del evento.</p>
        <div class="px-6 pb-4 bg-gray-950 mx-6 rounded-xl overflow-hidden relative">
            <video id="videoReg" autoplay muted playsinline style="width:100%;max-height:220px;object-fit:cover;border-radius:8px;display:block;"></video>
        </div>
        <div class="px-6 pt-4 pb-2">
            <div id="statusReg" class="text-orange-600 font-semibold text-sm bg-orange-50 py-2 px-4 rounded-xl text-center">Iniciando cámara...</div>
        </div>
        <div class="px-6 pb-6 space-y-2">
            <button id="btnCapturarReg" disabled
                class="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-bold py-4 rounded-xl text-[10px] uppercase tracking-widest transition-all active:scale-95">
                Registrar Ahora
            </button>
            <button id="btnOmitirReg"
                class="w-full text-gray-400 hover:text-gray-600 text-xs uppercase font-bold py-2 underline transition-all">
                Omitir por ahora
            </button>
        </div>
    </div>
</div>


<!-- ════════════════════════════════════════
     SCRIPTS
════════════════════════════════════════ -->
<script>
// ── UID ANÓNIMO PERSISTENTE ──
(function() {
    let uid = localStorage.getItem('guest_uid');
    if (!uid) {
        uid = 'guest_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
        localStorage.setItem('guest_uid', uid);
    }
    window.firebase_uid = uid;
})();

window.currentFotos       = <?= $fotosJson ?>;
window.isIAActive         = false;
window.fotosEncontradasIA = [];
window.filtrosActivos     = {};

// ── DATOS DE FILTROS DESDE PHP ──
const FILTROS_CONFIG = [
    { id:'sede_id', label:'¿En qué sede?', datos: <?= json_encode(array_column($sedes, 'nombre', 'id')) ?> }
];

const PASOS_ACTIVOS = FILTROS_CONFIG.filter(p => Object.keys(p.datos).length > 0);
</script>

<script>
// ════════════════════════════════════
//  HELPER — buildFotoCardHTML
//  Usa url_miniatura con fallback a minion.php
// ════════════════════════════════════
function buildFotoCardHTML(f) {
    const fotoUrl = `ver_foto.php?id=${f.id}`;
    const shareUrl = encodeURIComponent(`${window.location.origin}/${fotoUrl}`);
    
    // Si f.url_miniatura es una URL absoluta externa, úsala directamente.
    // Si no, usa el proxy local minion.php.
    const imgSrc = f.url_miniatura 
        ? f.url_miniatura 
        : `minion.php?id=${f.id}&tipo=mini`;


    return `
        <!-- Checkbox -->
        <div class="foto-check">
            <input type="checkbox" id="chk-${f.id}" value="${f.id}" class="hidden peer" onchange="window.toggleSelection(this)">
            <label for="chk-${f.id}"
                   class="w-5 h-5 border-2 border-white/40 rounded-md block cursor-pointer
                          peer-checked:bg-orange-600 peer-checked:border-orange-600
                          bg-black/50 backdrop-blur-sm transition-all"></label>
        </div>

        <!-- Imagen principal -->
        <a href="${fotoUrl}" oncontextmenu="return false;" draggable="false">
            <img src="${imgSrc}"
                 alt="Foto deportiva"
                 loading="lazy"
                 decoding="async"
                 draggable="false"
                 onload="this.classList.add('loaded')">
        </a>

        <!-- Watermark -->
        <div class="watermark"></div>

        <!-- Overlay hover -->
        <div class="overlay-hover"></div>

        <!-- Compartir (top-right) -->
        <div class="foto-share">
            <a href="https://wa.me/?text=Mira esta foto: ${fotoUrl}" target="_blank"
               class="bg-green-500 text-white rounded-full shadow-lg hover:scale-110 transition-transform flex items-center justify-center"
               style="width:30px;height:30px;">
                <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" class="w-4 h-4">
            </a>
            <a href="https://www.facebook.com/sharer/sharer.php?u=${shareUrl}" target="_blank"
               class="bg-blue-600 text-white rounded-full shadow-lg hover:scale-110 transition-transform flex items-center justify-center"
               style="width:30px;height:30px;">
                <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Facebook_Logo_%282019%29.png" class="w-4 h-4">
            </a>
        </div>

        <!-- Acciones (bottom-right): carrito -->
        <div class="foto-actions">
            <button onclick="window.addToCart(${f.id})"
                    class="bg-orange-600 text-white p-2 rounded-xl shadow-lg hover:bg-orange-500 transition-all">
                <span class="material-icons text-sm">add_shopping_cart</span>
            </button>
        </div>
    `;
}
</script>

<script>
// ════════════════════════════════════
//  ASISTENTE DE FILTROS
// ════════════════════════════════════
let pasoAsistente = 0;
let respAsistente = {};

function abrirAsistente() {
    pasoAsistente = 0;
    respAsistente = {};
    document.getElementById('modalAsistente').classList.remove('hidden');
    document.getElementById('modalAsistente').classList.add('flex');
    renderPasoAsistente();
}
function cerrarAsistente() {
    document.getElementById('modalAsistente').classList.add('hidden');
    document.getElementById('modalAsistente').classList.remove('flex');
}
function renderPasoAsistente() {
    if (pasoAsistente >= PASOS_ACTIVOS.length) {
        cerrarAsistente();
        aplicarFiltrosDesdeAsistente();
        return;
    }
    const paso  = PASOS_ACTIVOS[pasoAsistente];
    const total = PASOS_ACTIVOS.length;

    document.getElementById('assistProgress').style.width = ((pasoAsistente / total) * 100) + '%';
    document.getElementById('assistStepLabel').innerText  = `Paso ${pasoAsistente + 1} de ${total}`;
    document.getElementById('assistTitle').innerText      = paso.label;

    const container = document.getElementById('assistOptions');
    container.innerHTML = '';
    let delay = 0;
    for (const [key, nombre] of Object.entries(paso.datos)) {
        const btn = document.createElement('button');
        btn.className = 'opcion-btn w-full text-left px-4 py-3 rounded-xl bg-white/5 border border-white/8 text-white text-sm font-semibold hover:bg-orange-600 hover:border-orange-500 transition-all active:scale-[.98]';
        btn.style.animationDelay = delay + 'ms';
        btn.innerText = nombre;
        btn.onclick   = () => asistenteSiguiente({ key, nombre, id: paso.id });
        container.appendChild(btn);
        delay += 40;
    }
}
function asistenteSiguiente(seleccion) {
    if (seleccion) respAsistente[seleccion.id] = { key: seleccion.key, nombre: seleccion.nombre };
    pasoAsistente++;
    renderPasoAsistente();
}
function aplicarFiltrosDesdeAsistente() {
    window.filtrosActivos = { ...respAsistente };
    for (const [id, val] of Object.entries(respAsistente)) {
        const sel = document.querySelector(`#filtrosInternos select[name="${id}"]`);
        if (sel) sel.value = val.key;
    }
    cargarFotosConFiltros();
}

// ── Construir selects del sidebar ──
function buildSidebarFiltros() {
    const container = document.getElementById('filtrosInternos');
    container.innerHTML = '';
    PASOS_ACTIVOS.forEach(p => {
        const wrap = document.createElement('div');
        wrap.innerHTML = `
            <label class="text-[9px] text-gray-500 uppercase font-black tracking-widest mb-1.5 block">
                ${p.label.replace('¿','').replace('?','')}
            </label>
            <select name="${p.id}"
                    class="w-full bg-white/5 border border-white/10 p-3 rounded-xl text-xs text-gray-200
                           focus:border-orange-500 outline-none transition appearance-none cursor-pointer">
                <option value="">-- Todos --</option>
                ${Object.entries(p.datos).map(([k,v]) => `<option value="${k}">${v}</option>`).join('')}
            </select>`;
        container.appendChild(wrap);
    });
}

document.getElementById('btnAplicarFiltros').onclick = () => {
    const selects = document.querySelectorAll('#filtrosInternos select');
    window.filtrosActivos = {};
    selects.forEach(s => {
        if (s.value && s.value !== "") {
            window.filtrosActivos[s.name] = { 
                key: s.value, 
                nombre: s.options[s.selectedIndex].text 
            };
        }
    });
    window.toggleFiltros(false);
    cargarFotosConFiltros(); 
};

document.getElementById('btnLimpiarFiltros').onclick = () => {
    document.querySelectorAll('#filtrosInternos select').forEach(s => s.value = '');
    window.filtrosActivos = {};
    actualizarBadgeFiltros();
    cargarFotosConFiltros();
};

function actualizarBadgeFiltros() {
    const badge  = document.getElementById('filtrosBadge');
    const texto  = document.getElementById('filtrosBadgeTexto');
    const entradas = Object.values(window.filtrosActivos).filter(v => v && v.nombre);
    if (entradas.length > 0) {
        texto.innerText = entradas.map(v => v.nombre).join(' · ');
        badge.classList.add('visible');
    } else {
        badge.classList.remove('visible');
    }
}

// ════ FUNCIÓN CENTRAL: carga fotos con filtros activos ════
async function cargarFotosConFiltros() {
    currentOffset     = 40;
    cargandoFotos     = false;
    window.isIAActive = false;

    const params = new URLSearchParams({ evento_id: '<?= $evento_id ?>' });
    for (const [key, val] of Object.entries(window.filtrosActivos)) {
        if (val && val.key) params.append(key, val.key);
    }

    const galeria = document.getElementById('galeria');
    galeria.innerHTML = `
        <div class="col-span-full flex flex-col items-center justify-center py-20 gap-4">
            <span class="w-10 h-10 rounded-full border-4 border-t-transparent border-orange-500 animate-spin"></span>
            <p class="text-gray-500 text-xs uppercase tracking-widest font-bold">Filtrando fotos...</p>
        </div>`;

    const btn = document.getElementById('btnLoadMore');
    btn.innerHTML = `<span class="w-4 h-4 rounded-full border-2 border-t-transparent border-orange-500 animate-spin"></span> Cargando...`;

    try {
        const res   = await fetch(`obtener_fotos_filtradas.php?${params.toString()}`);
        const fotos = await res.json();

        window.currentFotos = fotos;
        window.renderGaleria();

        actualizarBadgeFiltros();

        const count = Object.keys(window.filtrosActivos).length;
        document.getElementById('resultadoIA').innerText = count > 0
            ? `FILTRADAS: ${fotos.length}`
            : 'Galería Pública';

        currentOffset = fotos.length;

        if (fotos.length === 0) {
            galeria.innerHTML = `
                <div class="col-span-full flex flex-col items-center justify-center py-20 gap-3">
                    <span class="material-icons text-gray-700" style="font-size:48px">image_search</span>
                    <p class="text-gray-500 text-sm font-bold uppercase tracking-widest">Sin fotos para estos filtros</p>
                    <p class="text-gray-600 text-xs">Prueba con otras combinaciones</p>
                </div>`;
            btn.innerText = 'SIN MÁS FOTOS';
        } else {
            btn.innerHTML = `<span class="w-4 h-4 rounded-full border-2 border-t-transparent border-orange-500 animate-spin"></span> Cargando galería...`;
        }

        document.getElementById('mainContent').scrollTo({ top: 0, behavior: 'smooth' });

    } catch(e) {
        console.error(e);
        galeria.innerHTML = `
            <div class="col-span-full flex flex-col items-center justify-center py-20 gap-3">
                <span class="material-icons text-red-700" style="font-size:48px">error_outline</span>
                <p class="text-red-500 text-sm font-bold">Error al filtrar. Reintenta.</p>
            </div>`;
        btn.innerText = 'ERROR';
    }
}
</script>

<script>
// ════════════════════════════════════
//  MODAL IA — TABS + BÚSQUEDA
// ════════════════════════════════════
let iaTabActual = 'subir';
let camaraStream = null;

function abrirModalIA() {
    document.getElementById('modalIA').classList.remove('hidden');
    document.getElementById('modalIA').classList.add('flex');
    setIATab('subir');
}
function cerrarModalIA() {
    document.getElementById('modalIA').classList.add('hidden');
    document.getElementById('modalIA').classList.remove('flex');
    pararCamara('video');
}
function setIATab(tab) {
    iaTabActual = tab;
    const esSub = tab === 'subir';
    document.getElementById('panelSubir').classList.toggle('hidden', !esSub);
    document.getElementById('panelCamara').classList.toggle('hidden', esSub);
    document.getElementById('tabSubir').className  = 'flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-1.5 ' + (esSub  ? 'bg-orange-600 text-white' : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10');
    document.getElementById('tabCamara').className = 'flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-1.5 ' + (!esSub ? 'bg-orange-600 text-white' : 'bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10');
    if (!esSub) iniciarCamara('video', 'btnCapturar', document.getElementById('statusIA'));
    else pararCamara('video');
}

async function iniciarCamara(videoId, btnId, statusEl) {
    pararCamara(videoId);
    try {
        camaraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        const video  = document.getElementById(videoId);
        if (video) video.srcObject = camaraStream;
        const btn = document.getElementById(btnId);
        if (btn)  btn.disabled = false;
        if (statusEl) { statusEl.innerText = 'Encuadra tu rostro'; statusEl.classList.remove('hidden'); }
    } catch(err) {
        if (statusEl) { statusEl.innerText = 'Error de cámara: ' + err.message; statusEl.classList.remove('hidden'); }
    }
}
function pararCamara(videoId) {
    if (camaraStream) { camaraStream.getTracks().forEach(t => t.stop()); camaraStream = null; }
    const v = document.getElementById(videoId);
    if (v) v.srcObject = null;
}

document.getElementById('btnIAUnificado').onclick    = abrirModalIA;
document.getElementById('btnCerrarModalIA').onclick  = cerrarModalIA;
document.getElementById('modalIA').addEventListener('click', function(e) {
    if (e.target === this) cerrarModalIA();
});

document.getElementById('faceInput').onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
        const prev = document.getElementById('facePreview');
        prev.src = ev.target.result;
        prev.classList.remove('hidden');
        document.getElementById('uploadPlaceholder').classList.add('hidden');
    };
    reader.readAsDataURL(file);
};

const uploadZone = document.getElementById('uploadZone');
uploadZone.addEventListener('dragover',  e => { e.preventDefault(); uploadZone.classList.add('drag-over'); });
uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('drag-over'));
uploadZone.addEventListener('drop', e => {
    e.preventDefault(); uploadZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
        const dt = new DataTransfer(); dt.items.add(file);
        document.getElementById('faceInput').files = dt.files;
        document.getElementById('faceInput').dispatchEvent(new Event('change'));
    }
});

function mostrarResultadosIA(fotos, total) {
    window.isIAActive         = true;
    window.fotosEncontradasIA = fotos;
    window.renderGaleria();
    document.getElementById('resultadoIA').innerText = `ENCONTRADAS: ${total}`;
    actualizarBadgeFiltros();
    document.getElementById('mainContent').scrollTo({ top: 0, behavior: 'smooth' });
    cerrarModalIA();
}

document.getElementById('btnBuscarFoto').onclick = async () => {
    const input  = document.getElementById('faceInput');
    const status = document.getElementById('statusIA');
    if (!input.files[0]) { status.innerText = 'Primero sube una foto'; status.classList.remove('hidden'); return; }

    status.innerText = 'Detectando rostro...';
    status.classList.remove('hidden');
    status.classList.add('analyzing');

    try {
        const preview = document.getElementById('facePreview');
        let imgEl = (preview && preview.src) ? preview : await faceapi.bufferToImage(input.files[0]);

        let detection = await faceapi
            .detectSingleFace(imgEl, new faceapi.TinyFaceDetectorOptions({ inputSize: 224, scoreThreshold: 0.2 }))
            .withFaceLandmarks().withFaceDescriptor();

        if (!detection) {
            status.innerText = 'Reintentando con más resolución...';
            detection = await faceapi
                .detectSingleFace(imgEl, new faceapi.TinyFaceDetectorOptions({ inputSize: 416, scoreThreshold: 0.15 }))
                .withFaceLandmarks().withFaceDescriptor();
        }

        if (!detection) { status.innerText = '❌ No se detectó rostro. Intenta con otra foto.'; status.classList.remove('analyzing'); return; }

        status.innerText = 'Buscando en la galería...';
        const fd = new FormData();
        fd.append('evento_id', '<?= $evento_id ?>');
        fd.append('descriptor', JSON.stringify(Array.from(detection.descriptor)));
        const res  = await fetch('buscar_rostro.php', { method:'POST', body:fd });
        const data = await res.json();

        status.classList.remove('analyzing');
        if (data.success && data.total > 0) {
            mostrarResultadosIA(data.fotos, data.total);
        } else {
            status.innerText = '🔍 No se encontraron fotos tuyas. Prueba registrando tu selfie.';
        }
    } catch(err) { console.error(err); status.innerText = 'Error técnico. Inténtalo de nuevo.'; status.classList.remove('analyzing'); }
};

document.getElementById('btnCapturar').onclick = async () => {
    const video  = document.getElementById('video');
    const status = document.getElementById('statusIA');
    if (!video) return;

    status.innerText = 'Analizando rostro...';
    status.classList.remove('hidden');
    document.getElementById('btnCapturar').disabled = true;

    try {
        const detection = await faceapi
            .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize:320, scoreThreshold:0.25 }))
            .withFaceLandmarks().withFaceDescriptor();

        if (!detection) { status.innerText = '❌ No detectado. Asegúrate de buena iluminación.'; document.getElementById('btnCapturar').disabled = false; return; }

        status.innerText = 'Buscando coincidencias...';
        const fd = new FormData();
        fd.append('evento_id', '<?= $evento_id ?>');
        fd.append('descriptor', JSON.stringify(Array.from(detection.descriptor)));
        const res  = await fetch('buscar_rostro.php', { method:'POST', body:fd });
        const data = await res.json();

        if (data.success && data.total > 0) {
            mostrarResultadosIA(data.fotos, data.total);
        } else {
            status.innerText = '🔍 Sin resultados. ¿Quieres registrar tu rostro?';
            document.getElementById('btnCapturar').disabled = false;
        }
    } catch(e) { console.error(e); status.innerText = 'Error técnico.'; document.getElementById('btnCapturar').disabled = false; }
};

window.buscarConMiPerfil = async () => {
    const status = document.getElementById('statusIA');
    if (status) { status.innerText = 'Buscando en tu perfil...'; status.classList.remove('hidden'); }
    try {
        const res  = await fetch('buscar_rostro_perfil.php', {
            method:'POST',
            headers:{ 'Content-Type':'application/x-www-form-urlencoded' },
            body:`firebase_uid=${encodeURIComponent(window.firebase_uid)}&evento_id=<?= $evento_id ?>`
        });
        const data = await res.json();
        if (data.success) {
            mostrarResultadosIA(data.fotos, data.total);
        } else {
            if (status) status.innerText = data.message || 'No tienes perfil registrado aún.';
        }
    } catch(e) { if (status) status.innerText = 'Error en búsqueda.'; }
};
</script>

<script>
// ════════════════════════════════════
//  MODAL REGISTRO BIOMÉTRICO
// ════════════════════════════════════
let regStream = null;

function abrirModalRegistro() {
    document.getElementById('modalRegistro').classList.remove('hidden');
    document.getElementById('modalRegistro').classList.add('flex');
    iniciarCamaraReg();
}
function cerrarModalRegistro() {
    document.getElementById('modalRegistro').classList.add('hidden');
    document.getElementById('modalRegistro').classList.remove('flex');
    if (regStream) { regStream.getTracks().forEach(t => t.stop()); regStream = null; }
    const v = document.getElementById('videoReg'); if (v) v.srcObject = null;
}

async function iniciarCamaraReg() {
    const video  = document.getElementById('videoReg');
    const status = document.getElementById('statusReg');
    const btn    = document.getElementById('btnCapturarReg');
    try {
        regStream = await navigator.mediaDevices.getUserMedia({ video:{ facingMode:'user' } });
        if (video) video.srcObject = regStream;
        if (status) status.innerText = 'IA Lista. Encuadra tu rostro.';
        if (btn)   btn.disabled = false;
    } catch(err) {
        if (status) status.innerText = 'Error de cámara: ' + err.message;
    }
}

document.getElementById('btnAbrirRegistroIA').onclick = abrirModalRegistro;
document.getElementById('btnCerrarRegistro').onclick  = cerrarModalRegistro;
document.getElementById('btnOmitirReg').onclick       = cerrarModalRegistro;
document.getElementById('modalRegistro').addEventListener('click', function(e) {
    if (e.target === this) cerrarModalRegistro();
});

document.getElementById('btnCapturarReg').onclick = async () => {
    const video  = document.getElementById('videoReg');
    const status = document.getElementById('statusReg');
    const btn    = document.getElementById('btnCapturarReg');
    if (!video) return;

    status.innerText = 'Analizando facciones...';
    btn.disabled     = true;

    try {
        const detection = await faceapi
            .detectSingleFace(video, new faceapi.TinyFaceDetectorOptions({ inputSize:320 }))
            .withFaceLandmarks().withFaceDescriptor();

        if (detection) {
            status.innerText = '¡Rostro detectado! Guardando...';
            const descriptor = JSON.stringify(Array.from(detection.descriptor));
            const response   = await fetch('api_guardar_biometria.php', {
                method:'POST',
                headers:{ 'Content-Type':'application/json' },
                body: JSON.stringify({ firebase_uid: window.firebase_uid, descriptor })
            });
            const result = await response.json();
            if (result.status === 'ok') {
                status.innerHTML = "<span style='color:#16a34a'>✓ Perfil vinculado correctamente</span>";
                setTimeout(() => { cerrarModalRegistro(); window.buscarConMiPerfil(); }, 1800);
            } else {
                status.innerText = 'Error al guardar. Inténtalo de nuevo.';
                btn.disabled = false;
            }
        } else {
            status.innerText = 'No se detectó rostro. Intenta de nuevo.';
            btn.disabled = false;
        }
    } catch(e) { console.error(e); status.innerText = 'Error técnico.'; btn.disabled = false; }
};
</script>

<script>
// ════════════════════════════════════
//  GALERÍA — RENDER + PAGINACIÓN INFINITA
// ════════════════════════════════════
async function loadIAModels() {
    try {
        const MODEL_PATH = '../face-demo/models/';
        await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_PATH),
            faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_PATH),
            faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_PATH)
        ]);
        document.getElementById('resultadoIA').innerText = 'IA LISTA';
    } catch(e) { console.error('Error cargando modelos IA:', e); }
}
window.renderGaleria = function() {
    const container = document.getElementById('galeria');
    if (!container) return;
    
    const source = window.isIAActive ? window.fotosEncontradasIA : window.currentFotos;

    if (!source || source.length === 0) {
        container.innerHTML = `
            <div class="col-span-full flex flex-col items-center justify-center py-20 gap-3">
                <span class="material-icons text-gray-700" style="font-size:48px">image_search</span>
                <p class="text-gray-500 text-sm font-bold uppercase tracking-widest">Sin fotos disponibles</p>
            </div>`;
        return;
    }

    container.innerHTML = source.map(f => {
        const partidoInfo = (f.equipo_a && f.equipo_b) ? `${f.equipo_a} vs ${f.equipo_b}` : '';
        return `
        <div class="foto-card relative">
            ${buildFotoCardHTML(f)}
            ${partidoInfo ? `
                <div class="absolute bottom-16 left-3 z-10">
                    <span class="px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[8px] font-black uppercase text-orange-500 tracking-widest border border-white/10">
                        ${partidoInfo}
                    </span>
                </div>
            ` : ''}
        </div>`;
    }).join('');

    // 🔥 AGREGA ESTAS LÍNEAS JUSTO AQUÍ PARA CORREGIR EL BUG DE IPHONE 🔥
    document.querySelectorAll('#galeria img').forEach(img => {
        if (img.complete) {
            img.classList.add('loaded');
        }
    });
};

// Offset inicial = 40 (coincide con LIMIT de la consulta PHP)
let currentOffset = 40;
let cargandoFotos = false;

async function cargarMasFotos() {
    if (cargandoFotos || window.isIAActive) return;

    const btn = document.getElementById('btnLoadMore');
    cargandoFotos = true;
    btn.innerHTML = `<span class="w-4 h-4 rounded-full border-2 border-t-transparent border-orange-500 animate-spin"></span> Cargando más...`;

    try {
        const params = new URLSearchParams({ evento_id: '<?= $evento_id ?>', offset: currentOffset });
        for (const [k, v] of Object.entries(window.filtrosActivos || {})) {
            if (v && v.key) params.set(k, v.key);
        }

        const res   = await fetch(`obtener_mas_fotos.php?${params.toString()}`);
        const fotos = await res.json();

        if (fotos.length > 0) {
            window.currentFotos = window.currentFotos.concat(fotos);
            const container = document.getElementById('galeria');

            // Insertamos con DocumentFragment para no repintar todo el DOM
            const frag = document.createDocumentFragment();
            fotos.forEach(f => {
                const div = document.createElement('div');
                div.className = 'foto-card relative';
                div.innerHTML = buildFotoCardHTML(f);
                frag.appendChild(div);
            });
            container.appendChild(frag);

            currentOffset += fotos.length;
            cargandoFotos  = false;
            btn.innerHTML  = `<span class="w-4 h-4 rounded-full border-2 border-t-transparent border-orange-500 animate-spin"></span> Baja para cargar más`;

            // Si vino menos de 20, ya no hay más
            if (fotos.length < 20) {
                btn.innerText = 'YA VISTE TODO 🎉';
                if (window.galeriaObserver) window.galeriaObserver.disconnect();
            }
        } else {
            btn.innerText = 'YA VISTE TODO 🎉';
            if (window.galeriaObserver) window.galeriaObserver.disconnect();
        }
    } catch(e) {
        console.error(e);
        btn.innerText  = 'ERROR – REINTENTANDO...';
        cargandoFotos  = false;
        setTimeout(cargarMasFotos, 3000);
    }
}

// Intersection Observer con rootMargin amplio para precargar
const targetBtn = document.getElementById('btnLoadMore');
if (targetBtn) {
    window.galeriaObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => { if (entry.isIntersecting) cargarMasFotos(); });
    }, { root: null, rootMargin: '800px', threshold: 0 });
    window.galeriaObserver.observe(targetBtn);
}

// ── CARRITO ──
window.loadCarrito = async function() {
    const content   = document.getElementById('carritoContent');
    const cartCount = document.getElementById('cartCount');
    try {
        const res  = await fetch(`ver_carrito.php?firebase_uid=${encodeURIComponent(window.firebase_uid)}&t=${Date.now()}`);
        const html = await res.text();
        content.innerHTML = html;
        const inp = document.getElementById('total_items_real');
        if (cartCount) cartCount.innerText = inp ? inp.value : '0';
    } catch(e) { console.error(e); }
};

window.addToCart = async (id) => {
    await fetch(`agregarcarrito.php?firebase_uid=${encodeURIComponent(window.firebase_uid)}&foto_id=${id}`);
    window.loadCarrito();
    window.toggleCarrito(true);
};

window.addFullPack = async (eventoId) => {
    const btn  = document.getElementById('btnPackAction');
    const orig = btn.innerHTML;
    btn.innerHTML = '<span class="material-icons animate-spin text-xs">sync</span> Agregando...';
    btn.disabled  = true;
    try {
        const fd = new FormData();
        fd.append('evento_id', eventoId);
        fd.append('firebase_uid', window.firebase_uid);
        const res = await fetch('agregar_evento_carrito.php', { method:'POST', body:fd });
        const r   = await res.json();
        if (r.status === 'ok') { await window.loadCarrito(); window.toggleCarrito(true); }
        else alert(r.message || 'Error al agregar el pack');
    } catch(e) { alert('Error de conexión'); }
    finally { btn.innerHTML = orig; btn.disabled = false; }
};

// ── UI PANELES ──
window.toggleFiltros = (show) => {
    document.getElementById('sidebarFiltros').classList.toggle('-translate-x-full', !show);
    document.getElementById('overlay').classList.toggle('hidden', !show);
    document.body.style.overflow = show ? 'hidden' : 'auto';
};
window.toggleCarrito = (show) => {
    document.getElementById('carritoContainer').classList.toggle('translate-x-full', !show);
    document.getElementById('overlay').classList.toggle('hidden', !show);
    document.body.style.overflow = show ? 'hidden' : 'auto';
};

document.getElementById('btnOpenFilters').onclick   = () => abrirAsistente();
document.getElementById('btnOpenCart').onclick      = () => window.toggleCarrito(true);
document.getElementById('btnCloseCart').onclick     = () => window.toggleCarrito(false);
document.getElementById('btnBackToGallery').onclick = () => window.toggleCarrito(false);
document.getElementById('overlay').onclick          = () => { window.toggleFiltros(false); window.toggleCarrito(false); };

document.getElementById('btnResetAll').onclick = () => {
    window.isIAActive         = false;
    window.fotosEncontradasIA = [];
    window.filtrosActivos     = {};
    currentOffset             = 40;
    cargandoFotos             = false;
    document.querySelectorAll('#filtrosInternos select').forEach(s => s.value = '');
    window.currentFotos       = <?= $fotosJson ?>;
    window.renderGaleria();
    actualizarBadgeFiltros();
    document.getElementById('resultadoIA').innerText = 'Galería Pública';
    if (window.galeriaObserver && targetBtn) {
        window.galeriaObserver.observe(targetBtn);
    }
};

window.toggleSelection = (el) => {
    const btn      = document.getElementById('btnBulkCart');
    const selected = document.querySelectorAll('input[type="checkbox"]:checked');
    if (btn) {
        btn.classList.toggle('hidden', selected.length === 0);
        btn.querySelector('span:last-child').innerText = `${selected.length} Fotos`;
    }
};

document.getElementById('btnBulkCart').onclick = async function() {
    const sel = Array.from(document.querySelectorAll('input[type="checkbox"]:checked'));
    if (!sel.length) return;
    this.disabled = true;
    for (const chk of sel) {
        await fetch(`agregarcarrito.php?firebase_uid=${encodeURIComponent(window.firebase_uid)}&foto_id=${chk.value}`);
        chk.checked = false;
        await new Promise(r => setTimeout(r, 40));
    }
    await window.loadCarrito();
    window.toggleCarrito(true);
    this.disabled = false;
};

document.addEventListener('click', async (e) => {
    const el = e.target.closest('.js-btn-eliminar');
    if (el) {
        el.disabled = true; el.closest('div').style.opacity = '.4';
        try {
            const r = await (await fetch('eliminar_item.php', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`id=${el.dataset.id}` })).json();
            if (r.success) window.loadCarrito();
            else { alert(r.message); el.closest('div').style.opacity='1'; el.disabled=false; }
        } catch(err) { el.closest('div').style.opacity='1'; el.disabled=false; }
    }
    const elP = e.target.closest('.js-btn-eliminar-evento');
    if (elP) {
        elP.disabled = true;
        const fd = new FormData(); fd.append('evento_id', elP.dataset.eventoId); fd.append('firebase_uid', window.firebase_uid);
        const r = await (await fetch('eliminar_pack_carrito.php', { method:'POST', body:fd })).json();
        if (r.status === 'ok') window.loadCarrito();
        else elP.disabled = false;
    }
});

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
    loadIAModels();
    buildSidebarFiltros();
    window.renderGaleria();
    window.loadCarrito();
    window.addEventListener('load', () => applyLanguage(localStorage.getItem('lang') || 'es'));

    // Filtro dependiente: sede → partidos
    const sedeSelect    = document.querySelector('select[name="sede_id"]');
    const partidoSelect = document.querySelector('select[name="partido_id"]');
    if (sedeSelect && partidoSelect) {
        const todasLasOpciones = Array.from(partidoSelect.options);
        sedeSelect.addEventListener('change', function() {
            const sede_id = this.value;
            if (sede_id === "") {
                partidoSelect.innerHTML = todasLasOpciones.map(o => o.outerHTML).join('');
            } else {
                const opcionesFiltradas = todasLasOpciones.filter(o =>
                    o.value === "" || o.getAttribute('data-sede') === sede_id
                );
                partidoSelect.innerHTML = opcionesFiltradas.map(o => o.outerHTML).join('');
            }
        });
    }
});
</script>

<script>
// ════════════════════════════════════
//  IDIOMAS
// ════════════════════════════════════
const langData = {
    es: {
        btnFiltros:'Partidos', btnSelfie:'Selfie', btnRegistro:'Registro',
        btnIAUnificado:'¡Encuéntrame!', btnSeleccionados:'Seleccionados',
        packTitle:'Pack "Full Access"', packDesc:'Todas tus fotos del evento en alta calidad',
        btnPackComprar:'Comprar', statusIA:'Galería Pública', btnReset:'Resetear',
        btnLoadMore:'Cargar más', btnSeguir:'Seguir Explorando',
        carritoTitle:'Tu Carrito', carritoSub:'Selección de fotos',
        modalRegTitle:'Vincular Rostro', btnCapturar:'Registrar Ahora', btnOmitir:'Omitir por ahora',
        btnCerrarFiltros:'Cerrar Filtros', btnAplicar:'Aplicar Filtros', btnLimpiar:'Limpiar Todo',
        iaTitle:'Búsqueda por Rostro', tabSubir:'Subir Foto', tabCamara:'En Vivo',
        btnBuscarFoto:'Buscar mis fotos', btnBuscarPerfil:'Usar mi perfil guardado',
    },
    en: {
        btnFiltros:'Matches', btnSelfie:'Selfie', btnRegistro:'Register',
        btnIAUnificado:'Find Me!', btnSeleccionados:'Selected',
        packTitle:'Pack "Full Access"', packDesc:'All your event photos in high quality',
        btnPackComprar:'Buy', statusIA:'Public Gallery', btnReset:'Reset',
        btnLoadMore:'Load more', btnSeguir:'Keep Exploring',
        carritoTitle:'Your Cart', carritoSub:'Photo selection',
        modalRegTitle:'Link Face', btnCapturar:'Register Now', btnOmitir:'Skip for now',
        btnCerrarFiltros:'Close Filters', btnAplicar:'Apply Filters', btnLimpiar:'Clear All',
        iaTitle:'Face Search', tabSubir:'Upload Photo', tabCamara:'Live Camera',
        btnBuscarFoto:'Find my photos', btnBuscarPerfil:'Use saved profile',
    }
};

function applyLanguage(lang) {
    const t = langData[lang] || langData.es;
    const setText = (id, txt) => {
        const el = document.getElementById(id);
        if (!el || !txt) return;
        const sp = el.querySelector('span:last-child');
        if (sp) sp.innerText = txt; else el.innerText = txt;
    };
    setText('btnOpenFilters',     t.btnFiltros);
    setText('btnIAUnificado',     t.btnIAUnificado);
    setText('btnAbrirRegistroIA', t.btnSelfie);
    setText('btnPackAction',      t.btnPackComprar);
    setText('btnBuscarFoto',      t.btnBuscarFoto);
    setText('btnBuscarPerfil',    t.btnBuscarPerfil);
    setText('tabSubir',           t.tabSubir);
    setText('tabCamara',          t.tabCamara);

    const cTitle = document.querySelector('#carritoContainer p.text-orange-500'); if(cTitle) cTitle.innerText = t.carritoTitle;
    const cSub   = document.querySelector('#carritoContainer p.text-gray-500');   if(cSub)   cSub.innerText   = t.carritoSub;

    localStorage.setItem('lang', lang);
}

document.querySelectorAll('.idiomas img').forEach((img, i) => {
    img.onclick = () => applyLanguage(i === 0 ? 'en' : 'es');
});
</script>

</body>
</html>