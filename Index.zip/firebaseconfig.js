const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};