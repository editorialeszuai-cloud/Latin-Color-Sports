<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marca Personal Deportiva - Latin Colors Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&display=swap');

  .lcs-nav {
    font-family: 'Montserrat', sans-serif;
  }

  /* Header más delgado y estilizado */
  .header-lcs {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 30px;
    background: linear-gradient(90deg, 
        #ffffff 0%, 
        #ffffff 15%, 
        #f8a700 20%, 
        #f56c1e 60%, 
        #e4312a 100%
    );
    border-top: 8px solid white; /* Menos ancho */
    border-bottom: 8px solid white; /* Menos ancho */
    height: 70px; /* Altura reducida */
    position: sticky;
    top: 0;
    z-index: 1000;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  }

  .nav-container {
    display: flex;
    align-items: center;
    flex-grow: 1;
    margin-left: 30px;
  }

  .nav-links {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 18px; /* Espacio más ajustado */
    margin-left:80px;
  }

  .nav-links a {
    text-decoration: none;
    color: white;
    font-weight: 800;
    text-transform: uppercase;
    font-size: 12px; /* Letra un poco más pequeña */
    letter-spacing: 0.3px;
    transition: 0.3s;
    white-space: nowrap;
    text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
  }

  .nav-links a:hover {
    color: #ffc72c;
  }

  /* Botón Login más compacto */
  .btn-login-lcs {
    background-color: #ffc72c !important;
    color: #000 !important;
    padding: 6px 15px !important;
    border-radius: 6px !important;
    transform: skewX(-12deg);
    margin-left: 10px;
    display: inline-block;
  }
  
  .btn-login-lcs span { 
    transform: skewX(12deg); 
    display: inline-block;
    font-size: 11px;
    font-weight: 900;
  }

  .idiomas { 
    display: flex; 
    gap: 8px; 
    align-items: center; 
    margin-left: 15px; 
  }

  @media (max-width: 1100px) {
    .nav-links { gap: 10px; }
    .nav-links a { font-size: 10px; }
    .header-lcs { padding: 0 15px; }
  }
</style>

<header class="header-lcs lcs-nav">
  <div class="logo flex items-center" style="z-index: 10;">
    <a href="index.php" class="flex items-center" style="text-decoration: none;">
  <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;height:auto;">
                <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="margin-left: 5px;width:85px;height:auto;">
    </a>
  </div>

  <div class="nav-container">
    <nav class="nav-links">
      <a href="conjuntodeventos.php">EVENTOS</a>
      <a href="soyorganizador.php">ORGANIZADOR</a>
      <a href="soyfotografo.php">FOTÓGRAFO</a>
      <a href="soydeportista.php">DEPORTISTA</a>
      <a href="soypatrocinador.php">PATROCINADORES</a>
      <a href="marcas.php">ESCUELA</a>
      
      <a href="login_app.html" class="btn-login-lcs">
        <span>INICIAR SESIÓN</span>
      </a>
    </nav>
  </div>

  <div class="idiomas">
    <img src="imagenes/idioma-01.webp" width="22px" alt="EN" style="cursor:pointer;">
    <img src="imagenes/idioma-02.webp" width="22px" alt="ES" style="cursor:pointer;">
  </div>
</header>



<body>

 
    <main class="content-wrapper">
        <section class="personal-brand-section">
            <div class="title-bar">
                <h1>MARCA PERSONAL DEPORTIVA</h1>
                <p>Construye tu identidad.</p>
                <div class="sporta-logo"></div> </div>

            <div class="brand-details-container">
                <div class="media-column">
                    <div class="image-gallery">
                        <div class="main-image-placeholder">
                                                    </div>
                    </div>
                    <div class="speaker-info">
                        <img src="../uploads/LATIN-SPORTS.png" alt="LatinColorSports Logo" width="50px">
                        <p>**Goretty Castro**</p>
                        <p class="subtitle">Especialista en comunicación y proyección de marca</p>
                    </div>
                </div>

                <div class="text-column">
                    <h2>Integra herramientas a tu carrera profesional. Vuelve virai en el mercado deportivo.</h2>
                    <p>Diseñamos marcas deportivas con **alma, fuerza y estrategia.**</p>
                    <p>Cada atleta tiene un objetivo: **destacar.**</p>
                    <p>Nuestro equipo de diseño y producción crea identidades deportivas que proyectan **fuerza, profesionalismo y autenticidad.**</p>
                    <p class="highlight-text">Te ayudamos a construir una marca preparada para triunfar dentro y fuera del campo.</p>

                    <div class="purchase-box">
                        <p class="product-name">Adquiere tu Taller de Marca Personal Deportiva</p>
                        <div class="price-and-actions">
                            <span class="price">$ 1.499.000</span>
                            <button class="add-to-cart-btn"><i class="fa-solid fa-cart-shopping"></i> Añadir al carrito</button>
                            <i class="fa-solid fa-shopping-cart"></i>
                        </div>
                    </div>

                    <div class="contact-info">
                        <p class="more-info">Más información</p>
                        <p>**Carolina Acevedo Rodríguez**</p>
                        <p>CEO</p>
                        <p>57 314 7958643</p>
                    </div>

                    <div class="latincolor-college-logo">
                                            </div>
                </div>
            </div>
        </section>

        <div class="background-decor left-yellow"></div>
        <div class="background-decor right-yellow-gray"></div>
    </main>
</body>
</html>
<style>
/* Variables CSS para consistencia de colores */
:root {
    --primary-orange: #ff6600; /* Naranja del título */
    --secondary-red: #cc0000; /* Rojo de los enlaces del menú */
    --dark-text: #333;
    --light-text: #666;
    --background-white: #ffffff;
    --yellow-accent: #fcd703;
    --gray-bg: #f0f0f0;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: sans-serif; /* Simulación de la fuente */
}

body {
    background-color: var(--background-white);
    position: relative;
}

/* --- Estilos del Header/Menú Superior --- */

.main-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: var(--background-white);
    border-bottom: 2px solid var(--gray-bg);
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    z-index: 10;
}

.logo-area img {
    height: 40px; /* Ajusta según el logo real */
}

.main-nav ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

.main-nav a {
    text-decoration: none;
    color: var(--secondary-red); /* Color principal del menú */
    font-size: 14px;
    font-weight: bold;
    padding: 5px 0;
    transition: color 0.3s;
}

.main-nav a.active-link {
    color: var(--primary-orange); /* El enlace 'Patrocinadores y marca' es naranja */
}

/* --- Contenido Principal y Layout General --- */

.content-wrapper {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    position: relative;
    z-index: 5;
}

.personal-brand-section {
    background-color: var(--background-white);
    border-radius: 8px;
    overflow: hidden;
}

/* --- Barra de Título Naranja --- */

.title-bar {
    background-color: var(--primary-orange);
    color: var(--background-white);
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
}

.title-bar h1 {
    font-size: 24px;
    font-weight: 900;
    margin-right: 20px;
}

.title-bar p {
    font-size: 16px;
    font-weight: 300;
    margin-left: auto;
}

.sporta-logo {
    font-size: 24px; /* Simulación del logo Sporta con un icono o texto */
    font-weight: bold;
    margin-left: 20px;
}

/* --- Contenedor de Detalles (Flex/Grid) --- */

.brand-details-container {
    display: flex;
    gap: 40px;
    padding: 30px;
}

/* --- Columna Izquierda (Media) --- */

.media-column {
    flex: 0 0 450px; /* Ancho fijo o basado en el contenido */
}

.image-gallery {
    border: 1px solid #ddd; /* Borde sutil alrededor de la imagen */
    margin-bottom: 15px;
    position: relative;
}

.main-image-placeholder {
    height: 400px; /* Altura para simular la imagen */
    background-color: var(--gray-bg);
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.speaker-info {
    background-color: var(--primary-orange);
    color: var(--background-white);
    padding: 10px 15px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
}

.speaker-info .fa-play {
    font-size: 18px;
}

.speaker-info p {
    margin: 0;
}

.speaker-info .subtitle {
    font-size: 12px;
    font-weight: 300;
    opacity: 0.8;
}


/* --- Columna Derecha (Texto y Compra) --- */

.text-column {
    flex-grow: 1;
    color: var(--dark-text);
}

.text-column h2 {
    font-size: 24px;
    color: var(--primary-orange);
    margin-bottom: 20px;
    font-weight: 700;
}

.text-column p {
    margin-bottom: 10px;
    line-height: 1.6;
    font-size: 15px;
    color: var(--light-text);
}

.text-column p.highlight-text {
    background-color: #fff0e0; /* Fondo muy claro para destacar */
    padding: 10px;
    border-left: 3px solid var(--primary-orange);
    font-weight: bold;
    margin-top: 15px;
}

/* --- Caja de Compra --- */

.purchase-box {
    margin-top: 30px;
    border: 1px solid #ddd;
    padding: 15px;
    background-color: #f9f9f9;
    border-radius: 4px;
}

.product-name {
    font-weight: bold;
    margin-bottom: 10px;
    color: var(--dark-text);
}

.price-and-actions {
    display: flex;
    align-items: center;
    gap: 15px;
}

.price {
    font-size: 28px;
    font-weight: bold;
    color: var(--primary-orange);
}

.add-to-cart-btn {
    background-color: var(--primary-orange);
    color: var(--background-white);
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background-color 0.3s;
}

.add-to-cart-btn:hover {
    background-color: #e05c00;
}

.price-and-actions .fa-shopping-cart {
    font-size: 24px;
    color: var(--primary-orange);
}

/* --- Información de Contacto --- */

.contact-info {
    margin-top: 20px;
    padding-top: 15px;
    border-top: 1px solid #eee;
    font-size: 14px;
}

.contact-info .more-info {
    font-style: italic;
    color: var(--light-text);
    margin-bottom: 5px;
}

.latincolor-college-logo {
    margin-top: 20px;
}

/* --- Decoraciones de Fondo (Banners) --- */

.background-decor {
    position: absolute;
    z-index: 1; /* Estará detrás del contenido principal */
    pointer-events: none;
}

.left-yellow {
    width: 200px; /* Ancho estimado */
    height: 100vh;
    background: linear-gradient(135deg, var(--yellow-accent) 50%, transparent 50%);
    top: 60px;
    left: 0;
    opacity: 0.5;
}

.right-yellow-gray {
    width: 300px; /* Ancho estimado */
    height: 100vh;
    background: linear-gradient(135deg, var(--gray-bg) 50%, var(--yellow-accent) 50%);
    top: 60px;
    right: 0;
    opacity: 0.5;
    transform: skewX(-15deg); /* Para darle la forma angular */
}
</style>