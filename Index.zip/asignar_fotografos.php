<?php
require 'dbfotografos.php'; // conexión centralizada

// =======================
// Obtener datos desde la BD
// =======================
$eventos = $pdo->query("SELECT * FROM eventos ORDER BY fecha ASC")->fetchAll();
$fotografos = $pdo->query("SELECT * FROM usuarios WHERE rol='fotografo' ORDER BY nombre ASC")->fetchAll();

// Asignaciones actuales
$asignaciones = $pdo->query("SELECT * FROM asignar_eventos")->fetchAll();
$asign_map = [];
foreach ($asignaciones as $a) {
  $asign_map[$a['evento_id']][] = $a['fotografo_id'];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Asignar Fotógrafos a Eventos</title>
  <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>


<!-- PANEL USUARIO -->
<div id="dashboardContainer" class="w-full bg-white p-0 rounded-2xl shadow-xl hidden fade-in">

  <!-- === NAV SUPERIOR === -->
  <nav class="flex items-center justify-between bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 text-white px-6 py-4 rounded-t-2xl shadow-md">
    <div class="flex items-center space-x-3">
      <img src="https://cdn-icons-png.flaticon.com/512/1828/1828884.png" class="w-8 h-8" alt="Logo">
      <h1 class="text-lg font-semibold tracking-wide">Panel de Usuario</h1>
    </div>

    <div class="flex items-center space-x-4">
<a href="menu.php">  <button id="homeButton" class="hover:underline hidden sm:inline">Inicio</button></a>
      <button id="helpButton" class="hover:underline hidden sm:inline">Ayuda</button>

      <!-- Botón Cerrar Sesión destacado -->
      <button id="logoutButton" class="flex items-center space-x-2 bg-red-600 hover:bg-red-700 active:scale-95 transition-all px-4 py-2 rounded-full text-white font-medium shadow-md">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 002 2h3a2 2 0 002-2V5a2 2 0 00-2-2h-3a2 2 0 00-2 2v1" />
        </svg>
        <span>Cerrar Sesión</span>
      </button>
    </div>
  </nav>

  <!-- === CONTENIDO DEL DASHBOARD === -->
  <div class="p-8">
    <div class="bg-indigo-50 p-6 rounded-lg border border-indigo-200 shadow-inner hidden">
      <h2 class="text-xl font-semibold text-indigo-700 mb-4">Detalles del Usuario</h2>
      <div class="space-y-2 text-gray-700">
        <p><strong>UID:</strong> <span id="userId" class="font-mono text-sm block">Cargando...</span></p>
        <p><strong>Email:</strong> <span id="userEmail" class="font-medium">Cargando...</span></p>
        <p><strong>Nombre:</strong> <span id="userName" class="font-medium">Cargando...</span></p>
        <p><strong>Rol:</strong> <span id="userRole" class="inline-block px-3 py-1 text-xs font-semibold rounded-full">Cargando...</span></p>
      </div>
    </div>
    <style>
        /* Contenedor principal */
#adminSection {
  margin: 0 auto;
  padding: 1rem;
  max-width: 1024px;
  font-family: 'Inter', sans-serif;
}

/* Título de la sección */
#adminSection h2 {
  border-bottom: 2px solid #e5e7eb;
  padding-bottom: 0.5rem;
  margin-bottom: 1.5rem;
  font-weight: 600;
  color: #111827;
}

/* Tarjetas de eventos */
#adminSection .bg-white {
  transition: all 0.3s ease;
}

#adminSection .bg-white:hover {
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
}

/* Títulos de eventos */
#adminSection h3 {
  font-size: 1.25rem;
  font-weight: 600;
  color: #111827;
}

/* Información de fecha y fotógrafos asignados */
#adminSection p {
  color: #4b5563;
  font-size: 0.875rem;
  margin-top: 0.25rem;
}

/* Formularios */
#adminSection form {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
  margin-top: 0.75rem;
}

/* Inputs y selects */
#adminSection input,
#adminSection select {
  border: 1px solid #d1d5db;
  border-radius: 0.375rem;
  padding: 0.5rem 0.75rem;
  font-size: 0.875rem;
  transition: all 0.2s ease;
}

#adminSection input:focus,
#adminSection select:focus {
  outline: none;
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.3);
}

/* Botones */
#adminSection button {
  font-weight: 500;
  border-radius: 0.375rem;
  padding: 0.5rem 1rem;
  cursor: pointer;
  transition: all 0.2s ease;
}

#adminSection button:hover {
  filter: brightness(0.9);
}

/* Botón eliminar */
#adminSection button.bg-red-600 {
  font-size: 0.75rem;
  padding: 0.25rem 0.5rem;
}

/* Lista de fotógrafos asignados */
#adminSection ul {
  margin-left: 1.5rem;
  list-style-type: disc;
  margin-top: 0.5rem;
}

#adminSection li {
  background-color: #f9fafb;
  padding: 0.5rem 0.75rem;
  border-radius: 0.375rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: background-color 0.2s ease;
}

#adminSection li:hover {
  background-color: #f3f4f6;
}

/* Mensajes de error */
#adminSection p.text-red-600 {
  font-weight: 600;
  margin-top: 0.75rem;
}

    </style>

   <section id="adminSection" class="w-full max-w-6xl hidden">
  <h2 class="text-3xl font-semibold mb-6 text-gray-900">Asignar Fotógrafos a Eventos</h2>

  <?php foreach($eventos as $evento): ?>
    <?php 
      $asignados = isset($asign_map[$evento['id']]) ? count($asign_map[$evento['id']]) : 0;
      $max = (int)$evento['max_fotografos'];
      $disponible = $asignados < $max;
    ?>

    <div class="bg-white p-6 mb-6 rounded-xl shadow border border-gray-200">
      <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
        <div>
          <h3 class="text-xl font-semibold text-gray-900"><?= htmlspecialchars($evento['titulo']) ?></h3>
          <p class="text-gray-500 text-sm">Fecha: <?= htmlspecialchars($evento['fecha']) ?></p>
          <p class="text-gray-600 text-sm mt-1">
            <strong><?= $asignados ?>/<?= $max ?></strong> fotógrafos asignados
          </p>
        </div>
      </div>

      <?php if ($disponible): ?>
<form method="POST" action="acciones_asignar.php" class="flex flex-wrap gap-3 items-center mt-3">
  <input type="hidden" name="evento_id" value="<?= $evento['id'] ?>">

  <select name="fotografo_id" class="border border-gray-300 rounded-md p-2 w-60 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
    <option value="">-- Seleccionar fotógrafo --</option>
    <?php foreach($fotografos as $f): ?>
      <?php $asignado = isset($asign_map[$evento['id']]) && in_array($f['id'], $asign_map[$evento['id']]); ?>
      <option value="<?= $f['id'] ?>" <?= $asignado ? 'disabled' : '' ?>>
        <?= htmlspecialchars($f['nombre']) ?> <?= $asignado ? '(Asignado)' : '' ?>
      </option>
    <?php endforeach; ?>
  </select>

  <input type="number" name="capacidad_mb" min="1" 
         max="<?= ($evento['capacidad_gb']*1024) - ($asignados_capacidad[$evento['id']] ?? 0) ?>" 
         placeholder="MB que aportará" required
         class="border p-2 rounded-md w-32">

  <input type="number" name="capacidad_de_fotos" min="1" placeholder="Cantidad de fotos" required
         class="border p-2 rounded-md w-32">

  <button type="submit"
    class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition font-medium">
    Asignar
  </button>
</form>


      <?php else: ?>
        <p class="text-red-600 font-semibold mt-3">Límite alcanzado: no se pueden asignar más fotógrafos.</p>
      <?php endif; ?>

      <?php if(isset($asign_map[$evento['id']])): ?>
        <div class="mt-4">
          <h4 class="text-gray-800 font-semibold mb-2">Fotógrafos asignados:</h4>
          <ul class="list-disc ml-6 space-y-1">
            <?php foreach($asign_map[$evento['id']] as $fid): ?>
              <?php
                $filtro = array_filter($fotografos, fn($u) => $u['id'] == $fid);
                $fotografo = array_values($filtro)[0];
              ?>
              <li class="flex justify-between items-center bg-gray-50 px-3 py-1 rounded-md">
                <span><?= htmlspecialchars($fotografo['nombre']) ?></span>
                <form method="POST" action="acciones_asignar.php" class="inline">
                  <input type="hidden" name="evento_id" value="<?= $evento['id'] ?>">
                  <input type="hidden" name="fotografo_id" value="<?= $fotografo['id'] ?>">
                  <input type="hidden" name="eliminar" value="1">
                  <button type="submit"
                    class="bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700 text-xs transition">
                    Eliminar
                  </button>
                </form>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</section>



    <p id="errorMessage" class="mt-4 text-center text-red-600 hidden"></p>
  </div>
</div>

<!-- ======================= -->
<!-- SECCIÓN DE ASIGNACIÓN -->
<!-- ======================= -->


<!-- Mensaje de restricción -->
<section id="restrictedSection" class="w-full max-w-4xl text-center mt-20 hidden">
  <p class="text-red-600 font-bold text-lg">Acceso restringido: solo administradores pueden asignar fotógrafos.</p>
</section>

<!-- ======================= -->
<!-- SCRIPT FIREBASE Y DASHBOARD -->
<!-- ======================= -->
<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut, getIdToken } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const dashboardContainer = document.getElementById('dashboardContainer');
const logoutButton = document.getElementById('logoutButton');
const userRoleSpan = document.getElementById('userRole');
const adminSection = document.getElementById('adminSection');
const restrictedSection = document.getElementById('restrictedSection');

function updateUI(uid, email, nombre, rol){
  document.getElementById('userId').textContent = uid;
  document.getElementById('userEmail').textContent = email;
  document.getElementById('userName').textContent = nombre;
  userRoleSpan.textContent = rol;
  dashboardContainer.classList.remove('hidden');

  if (rol === 'admin') {
    adminSection.classList.remove('hidden');
    restrictedSection.classList.add('hidden');
  } else {
    adminSection.classList.add('hidden');
    restrictedSection.classList.remove('hidden');
  }
}

logoutButton.addEventListener('click', async () => {
  await signOut(auth);
  window.location.href = 'login_app.html';
});

onAuthStateChanged(auth, async (user) => {
  if (user) {
    try {
      const token = await user.getIdToken();
      const res = await fetch('get_user_info.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ firebase_token: token })
      });
      const data = await res.json();
      if (data.status === 'success' && data.user) {
        updateUI(data.user.firebase_uid, data.user.email, data.user.nombre, data.user.rol);
      } else {
        restrictedSection.classList.remove('hidden');
      }
    } catch (err) {
      console.error(err);
      restrictedSection.classList.remove('hidden');
    }
  } else {
    window.location.href = 'login_app.html';
  }
});
</script>

<!-- ======================= -->
<!-- SCRIPT FORMULARIOS (FUNCIONAL) -->
<!-- ======================= -->
<script type="module">
import { auth } from './firebase-config.js';
import { getIdToken } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// Interceptar todos los formularios
document.querySelectorAll('form[action="acciones_asignar.php"]').forEach(form => {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(form);

    try {
      const user = auth.currentUser;
      if (!user) {
        alert('Debes iniciar sesión.');
        return;
      }

      const token = await getIdToken(user);
      formData.append('firebase_token', token);

      const res = await fetch('acciones_asignar.php', {
        method: 'POST',
        body: formData
      });

      const data = await res.json();

      // Crear el contenedor del mensaje si no existe
      let msgDiv = form.querySelector('.respuesta-servidor');
      if (!msgDiv) {
        msgDiv = document.createElement('div');
        msgDiv.className = 'respuesta-servidor text-sm mt-2';
        form.appendChild(msgDiv);
      }

      msgDiv.textContent = data.message;
      msgDiv.style.color = data.status === 'success' ? 'green' : 'red';

      if (data.status === 'success') {
        setTimeout(() => location.reload(), 800);
      }

    } catch (err) {
      console.error(err);
      alert('Error al procesar la solicitud.');
    }
  });
});
</script>

<!-- ======================= -->
<!-- SCRIPT PANEL USUARIO -->
<!-- ======================= -->
<script>
const dashboard = document.getElementById('dashboardContainer');
const toggleBtn = document.getElementById('toggleDashboard');
const closeBtn = document.getElementById('closeDashboard');

toggleBtn.addEventListener('click', () => {
  dashboard.classList.toggle('translate-x-full');
});
closeBtn.addEventListener('click', () => {
  dashboard.classList.add('translate-x-full');
});
</script>

</body>
</html>
