<?php
require 'dbfotografos.php';
$pdo = conectar(); // Asumimos que dbfotografos.php devuelve la instancia PDO

// 🔹 Si se solicita galería de un evento vía POST
if (isset($_POST['evento_id'])) {
    $evento_id = intval($_POST['evento_id']);
    $uid = $_POST['uid'] ?? null;

    // Validar usuario
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$uid]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$usuario) die('<p class="text-red-500">Usuario no encontrado</p>');

    $organizador_id = $usuario['id'];

    // Validar que el evento pertenece al organizador
    $stmt = $pdo->prepare("SELECT id, titulo FROM eventos WHERE id = ? AND organizador_id = ?");
    $stmt->execute([$evento_id, $organizador_id]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$evento) die('<p class="text-red-500">❌ No tienes permiso para ver este evento.</p>');

    // Obtener fotos mediante el JOIN de postulaciones
    $stmt = $pdo->prepare("
        SELECT f.url, f.id, f.descripcion, u.nombre AS fotografo
        FROM fotos f
        INNER JOIN postulaciones p ON f.postulacion_id = p.id
        INNER JOIN usuarios u ON p.usuario_id = u.id
        WHERE p.evento_id = ?
        ORDER BY f.id DESC
    ");
    $stmt->execute([$evento_id]);
    $fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "<h3 class='text-2xl font-bold mb-6 text-gray-800 border-b pb-2'>Galería: ".htmlspecialchars($evento['titulo'])."</h3>";

    if ($fotos) {
        echo '<div class="grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in">';
        foreach ($fotos as $f) {
            $path = htmlspecialchars($f['url']);
            $foto_id = intval($f['id']);
            
            echo "
            <div class='group bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300'>
                <div class='relative overflow-hidden aspect-square'>
                    <a href='foto_detallead.php?id={$foto_id}'>
                        <img src='$path' 
                             loading='lazy' 
                             class='w-full h-full object-cover transition duration-500 group-hover:scale-110 cursor-pointer'>
                    </a>
                </div>
                <div class='p-3 text-center'>
                    <p class='text-xs font-bold text-orange-600 mb-1'>📷 " . htmlspecialchars($f['fotografo']) . "</p>
                </div>
            </div>";
        }
        echo '</div>';
    } else {
        echo '<div class="text-center py-10 bg-gray-50 rounded-2xl border-2 border-dashed"><p class="text-gray-400">No hay fotos en este evento.</p></div>';
    }
    exit;
}

// 🔹 Listado de Eventos (Petición Inicial o AJAX)
$uid = $_POST['uid'] ?? null;
if ($uid && isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ?");
    $stmt->execute([$uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($user) {
        $stmt = $pdo->prepare("SELECT id, banner, titulo, fecha FROM eventos WHERE organizador_id = ? ORDER BY fecha DESC");
        $stmt->execute([$user['id']]);
        $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if($eventos): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php foreach($eventos as $ev): ?>
                <div class="bg-white rounded-[2rem] shadow-lg overflow-hidden border border-gray-100 hover:-translate-y-2 transition-all duration-300">
                    <div class="h-48 overflow-hidden">
                        <img src="<?= htmlspecialchars($ev['banner']) ?>" class="w-full h-full object-cover">
                    </div>
                    <div class="p-6 text-center">
                        <h2 class="text-xl font-black text-gray-900 mb-1"><?= htmlspecialchars($ev['titulo']) ?></h2>
                        <p class="text-sm text-gray-400 mb-6"><?= htmlspecialchars($ev['fecha']) ?></p>
                        <button onclick="verGaleria(<?= $ev['id'] ?>)" 
                                class="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-2xl shadow-lg shadow-orange-200 transition-all">
                            📸 Ver Galería
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
        <?php else:
            echo '<p class="text-gray-500 text-center">No tienes eventos creados.</p>';
        endif;
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Organizador | Eventos</title>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .animate-fade-in { animation: fadeIn 0.5s ease-in; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="bg-gray-50 min-h-screen pb-20">
    
    <?php require 'navorganizador.php'; ?>
    
    <div class="max-w-7xl mx-auto px-4 mt-12">
        <header class="text-center mb-12">
            <h1 class="text-5xl font-black text-gray-900 tracking-tight">Mis Eventos</h1>
            <p class="text-gray-500 mt-2">Gestiona y visualiza las fotos de tus producciones</p>
        </header>

        <div id="eventosContainer" class="min-h-[200px]">
            <div class="flex justify-center items-center py-20">
                <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
            </div>
        </div>

        <div id="galeriaContainer" class="mt-20 hidden">
            <div id="fotosContainer" class="bg-white p-8 rounded-[3rem] shadow-xl shadow-gray-200/50"></div>
        </div>
    </div>

    <script type="module">
        import { auth } from './firebase-config.js';
        import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

        async function loadEventos(uid) {
            const fd = new FormData();
            fd.append('uid', uid);
            const res = await fetch(window.location.href, {
                method: 'POST',
                body: fd,
                headers: {'X-Requested-With': 'XMLHttpRequest'}
            });
            document.getElementById('eventosContainer').innerHTML = await res.text();
        }

        window.verGaleria = async (eventoId) => {
            const uid = document.body.dataset.uid;
            const fd = new FormData();
            fd.append('uid', uid);
            fd.append('evento_id', eventoId);

            const res = await fetch(window.location.href, { method: 'POST', body: fd });
            document.getElementById('fotosContainer').innerHTML = await res.text();
            document.getElementById('galeriaContainer').classList.remove('hidden');
            window.scrollTo({ top: document.getElementById('galeriaContainer').offsetTop - 50, behavior: 'smooth' });
        };

        onAuthStateChanged(auth, async (user) => {
            if (user) {
                document.body.dataset.uid = user.uid;
                loadEventos(user.uid);
            } else {
                window.location.href = 'login_app.html';
            }
        });
    </script>
</body>
</html>