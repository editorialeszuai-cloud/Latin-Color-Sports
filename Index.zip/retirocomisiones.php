<?php
require 'dbfotografos.php';
$pdo = conectar();

// 1. PROCESAR ACCI�0�7N AJAX (Antes de cualquier salida HTML)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    if (ob_get_length()) ob_clean(); // Limpia espacios accidentales
    header('Content-Type: application/json; charset=utf-8');

    $id = intval($_POST['id']);
    try {
        // Actualizamos estado a 0 (Pagado)
        $stmt = $pdo->prepare("UPDATE retiros_comisiones SET retirada = 0 WHERE id = ?");
        $stmt->execute([$id]);
        
        echo json_encode(['status' => 'success']);
        exit; 
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}

// 2. CARGAR EL MEN�0�3
require 'menuadmin.php'; 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Listado de Retiros</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f4f4; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); max-width: 1200px; margin: auto; }
        h1 { color: #333; border-bottom: 2px solid #f97316; padding-bottom: 10px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f97316; color: white; text-transform: uppercase; font-size: 13px; }
        tr:hover { background-color: #fdf2e9; }
        .pagado { color: #16a34a; font-weight: bold; background: #dcfce7; padding: 4px 8px; border-radius: 4px; display: inline-block; }
        .pendiente { color: #dc2626; font-weight: bold; background: #fee2e2; padding: 4px 8px; border-radius: 4px; display: inline-block; }
        button { background-color: #2563eb; color: white; border: none; padding: 8px 12px; cursor: pointer; border-radius: 4px; font-weight: bold; }
        button:hover { background-color: #1d4ed8; }
    </style>
</head>
<body>

<div class="card">
    <h1>Listado de Retiros de Comisiones</h1>

    <table>
        <thead>
            <tr>
                <th>ID Retiro</th>
                <th>ID Comisi��n</th>
                <th>Usuario</th>
                <th>Tipo</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Acci��n</th>
            </tr>
        </thead>
        <tbody id="tabla-retiros">
            <?php
            try {
                // CORRECCI�0�7N DE COLLATION: Forzamos la comparaci��n compatible
                // En la parte del SQL del Admin, aseg��rate de que el WHERE refleje lo que quieres ver
$sql = "
    SELECT  
        r.id, r.comision_id, r.firebase_uid, r.tipo, r.total, r.retirada, r.fecha,
        u.nombre AS nombre_usuario, u.email AS email_usuario
    FROM retiros_comisiones r
    LEFT JOIN usuarios u ON r.firebase_uid COLLATE utf8mb4_unicode_ci = u.firebase_uid COLLATE utf8mb4_unicode_ci
    ORDER BY r.retirada DESC, r.fecha DESC
";

                $stmt = $pdo->query($sql);
                $retiros = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($retiros):
                    foreach ($retiros as $r):
                        $isPendiente = ($r['retirada'] == 1);
                        $estadoHtml = $isPendiente 
                            ? '<span class="pendiente">Pendiente</span>' 
                            : '<span class="pagado">Pagado</span>';
                        
                        $botonHtml = $isPendiente 
                            ? '<button onclick="marcarPagado('.(int)$r['id'].', this)">Marcar Pagado</button>' 
                            : '---';
                ?>
                <tr id="fila-<?= $r['id'] ?>">
                    <td><strong>#<?= $r['id'] ?></strong></td>
                    <td>#<?= $r['comision_id'] ?></td>
                    <td>
                        <strong><?= htmlspecialchars($r['nombre_usuario'] ?? 'Desconocido') ?></strong><br>
                        <small style="color: #666;"><?= htmlspecialchars($r['email_usuario'] ?? 'Sin email') ?></small>
                    </td>
                    <td><span style="text-transform: capitalize;"><?= htmlspecialchars($r['tipo']) ?></span></td>
                    <td style="font-weight: bold; color: #333;">$<?= number_format($r['total'], 2) ?></td>
                    <td class="estado"><?= $estadoHtml ?></td>
                    <td style="font-size: 12px; color: #555;"><?= $r['fecha'] ?></td>
                    <td class="accion-cell"><?= $botonHtml ?></td>
                </tr>
                <?php 
                    endforeach;
                else: 
                ?>
                <tr><td colspan="8" style="text-align:center; padding: 40px; color: #999;">No hay solicitudes de retiro pendientes.</td></tr>
                <?php endif; ?>
            <?php } catch (Exception $e) { ?>
                <tr><td colspan="8" style="color:red; background: #fee2e2; padding: 20px;">
                    <strong>Error de base de datos:</strong> <?= htmlspecialchars($e->getMessage()) ?>
                </td></tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script>
function marcarPagado(id, boton) {
    if (!confirm('�0�7Confirmas que ya has realizado el pago de este retiro?')) return;

    const formData = new FormData();
    formData.append('id', id);

    boton.disabled = true;
    boton.textContent = 'Procesando...';

    fetch(window.location.href, {
        method: 'POST',
        body: formData,
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(async res => {
        const contentType = res.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
            return res.json();
        } else {
            const text = await res.text();
            throw new Error("Respuesta no v��lida del servidor.");
        }
    })
    .then(data => {
        if (data.status === 'success') {
            const fila = document.getElementById('fila-' + id);
            fila.querySelector('.estado').innerHTML = '<span class="pagado">Pagado</span>';
            fila.querySelector('.accion-cell').innerHTML = '---';
        } else {
            alert('Error: ' + data.message);
            boton.disabled = false;
            boton.textContent = 'Marcar Pagado';
        }
    })
    .catch(err => {
        alert('Hubo un error al procesar la solicitud.');
        console.error(err);
        boton.disabled = false;
        boton.textContent = 'Marcar Pagado';
    });
}
</script>

</body>
</html>