<?php require 'navfotografo.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <title>Mis Comisiones - Panel Fotógrafo</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f9; color: #333; margin: 0; padding: 0; }
        .container { max-width: 1000px; margin: 20px auto; padding: 20px; background: white; border-radius: 12px; shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #f97316; }
        
        table { border-collapse: collapse; width: 100%; margin-top: 20px; background: white; border-radius: 8px; overflow: hidden; }
        th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
        th { background-color: #f97316; color: white; text-transform: uppercase; font-size: 14px; }
        tr:hover { background-color: #fff7ed; }

        #mensaje { text-align: center; margin: 10px 0; padding: 10px; border-radius: 6px; display: none; }
        .error { background-color: #fee2e2; color: #dc2626; display: block !important; }

        #subtotalContainer { margin-top: 20px; padding: 20px; background: #fef3c7; border-radius: 8px; text-align: right; font-size: 20px; font-weight: bold; }
        
        button#retirarBtn {
            background-color: #ef4444;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        button#retirarBtn:hover { background-color: #dc2626; transform: translateY(-2px); }
        button#retirarBtn:disabled { background-color: #9ca3af; cursor: not-allowed; }

        /* Estados dinámicos */
        .status-badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .pendiente-de-retirar { background-color: #fef3c7; color: #92400e; }
        .en-proceso { background-color: #dbeafe; color: #1e40af; }
        .pagado { background-color: #d1fae5; color: #065f46; }
        
        .img-preview { width: 60px; height: 60px; object-fit: cover; border-radius: 4px; border: 1px solid #ddd; }
    </style>
</head>
<body>

<div class="container">
    <h1>Mis Comisiones</h1>
    <div id="mensaje"></div>

    <div class="overflow-x-auto">
        <table>
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>ID Comisión</th>
                    <th>Foto</th>
                    <th>Monto</th>
                    <th>ID Compra</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody id="tablaComisiones">
                </tbody>
        </table>
    </div>

    <div id="subtotalContainer">
        Subtotal Seleccionado: <span id="subtotal">$0.00</span><br>
        <button id="retirarBtn" disabled>Solicitar Retiro</button>
    </div>
</div>

<script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-auth-compat.js"></script>

<script>
    const firebaseConfig = {
        apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
        authDomain: "latin-group-406b1.firebaseapp.com",
        projectId: "latin-group-406b1",
        storageBucket: "latin-group-406b1.firebasestorage.app",
        messagingSenderId: "21494348297",
        appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
    };
    firebase.initializeApp(firebaseConfig);
    const auth = firebase.auth();

    const tablaBody = document.getElementById('tablaComisiones');
    const subtotalSpan = document.getElementById('subtotal');
    const retirarBtn = document.getElementById('retirarBtn');
    const mensajeDiv = document.getElementById('mensaje');

    // 1. Monitorear Autenticación
    auth.onAuthStateChanged(user => {
        if (user) {
            cargarComisiones(user.uid);
        } else {
            window.location.href = 'login_app.html';
        }
    });

    // 2. Cargar datos del servidor
    async function cargarComisiones(firebase_uid) {
        try {
            const res = await fetch('get_comisiones.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ firebase_uid })
            });
            const data = await res.json();

            if (data.status !== 'success') {
                mostrarError(data.message);
                return;
            }

            renderTabla(data.comisiones);
        } catch (err) {
            mostrarError("Error de conexión con el servidor.");
        }
    }

    // 3. Dibujar la tabla
    function renderTabla(comisiones) {
        tablaBody.innerHTML = '';
        if (comisiones.length === 0) {
            tablaBody.innerHTML = '<tr><td colspan="6">No tienes comisiones disponibles.</td></tr>';
            return;
        }

        comisiones.forEach(c => {
            const tr = document.createElement('tr');
            const statusClass = c.estado_retiro.toLowerCase().replace(/\s+/g, '-');
            const isRetirable = c.estado_retiro === 'Pendiente de retirar';

            tr.innerHTML = `
                <td>
                    ${isRetirable ? `<input type="checkbox" class="checkComision" data-monto="${c.monto}" value="${c.comision_id}">` : ''}
                </td>
                <td>#${c.comision_id}</td>
                <td>
                    <img src="${c.foto_url}" class="img-preview" onerror="this.src='placeholder.jpg'">
                </td>
                <td class="font-bold">$${parseFloat(c.monto).toFixed(2)}</td>
                <td>${c.compra_id}</td>
                <td><span class="status-badge ${statusClass}">${c.estado_retiro}</span></td>
            `;
            tablaBody.appendChild(tr);
        });

        // Listeners para checkboxes
        document.querySelectorAll('.checkComision').forEach(cb => {
            cb.addEventListener('change', actualizarSubtotal);
        });
    }

    function actualizarSubtotal() {
        let total = 0;
        const seleccionados = document.querySelectorAll('.checkComision:checked');
        seleccionados.forEach(cb => total += parseFloat(cb.dataset.monto));
        
        subtotalSpan.textContent = `$${total.toFixed(2)}`;
        retirarBtn.disabled = seleccionados.length === 0;
    }

    // 4. Procesar Retiro
    retirarBtn.addEventListener('click', async () => {
        const seleccionadas = Array.from(document.querySelectorAll('.checkComision:checked')).map(cb => cb.value);
        if (!confirm(`¿Deseas solicitar el retiro de ${seleccionadas.length} comisiones?`)) return;

        try {
            retirarBtn.disabled = true;
            retirarBtn.textContent = 'Procesando...';
            
            const res = await fetch('retirar_comisiones.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    firebase_uid: auth.currentUser.uid,
                    comisiones: seleccionadas
                })
            });
            const data = await res.json();

            if (data.status === 'success') {
                alert('Solicitud enviada con éxito.');
                cargarComisiones(auth.currentUser.uid);
            } else {
                alert('Error: ' + data.message);
            }
        } catch (e) {
            alert('Error en la solicitud.');
        } finally {
            retirarBtn.textContent = 'Solicitar Retiro';
            retirarBtn.disabled = false;
        }
    });

    function mostrarError(msg) {
        mensajeDiv.textContent = msg;
        mensajeDiv.className = 'error';
    }

    // Seleccionar todo
    document.getElementById('selectAll').addEventListener('change', (e) => {
        document.querySelectorAll('.checkComision').forEach(cb => {
            cb.checked = e.target.checked;
        });
        actualizarSubtotal();
    });
</script>

</body>
</html>