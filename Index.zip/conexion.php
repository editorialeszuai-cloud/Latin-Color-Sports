<?php
function conectar() {
    $servername = "database-1.c8302k404lkf.us-east-1.rds.amazonaws.com";
    $username   = "admin";
    $password   = "DannyCruxTecnoLoad!#";
    $dbname     = "latincolors";
    $port       = 3306;

    $conn = new mysqli($servername, $username, $password, $dbname, $port);

    if ($conn->connect_error) {
        die("❌ Error al conectar con la base de datos: " . $conn->connect_error);
    }

    $conn->set_charset("utf8mb4");
    return $conn;
}
?>
