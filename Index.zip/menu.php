<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <title>Administrador Latin Colors Sports</title>
    <style>
        :root{--bg:#0f1724;--panel:#0b1220;--accent:#4f46e5;--text:#e6eef8;--muted:#99a3b2;--width:260px}
        *{box-sizing:border-box}body{margin:0;font-family:Inter,sans-serif;color:var(--text);background:#f6f8fb}.app{display:flex;min-height:100vh}
        .sidebar{width:var(--width);background:linear-gradient(180deg,var(--bg),var(--panel));padding:1rem 0;display:flex;flex-direction:column;gap:1rem;position:fixed;left:0;top:0;bottom:0;z-index:40;transition:transform .25s ease;overflow-y:auto;-webkit-overflow-scrolling:touch}
        .sidebar::-webkit-scrollbar{width:8px}.sidebar::-webkit-scrollbar-track{background:rgba(255,255,255,.05);border-radius:10px;margin:4px 0}.sidebar::-webkit-scrollbar-thumb{background:rgba(255,255,255,.15);border-radius:10px;transition:background .3s}.sidebar::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,.3)}.sidebar{scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.15) rgba(255,255,255,.05)}
        .sidebar.closed{transform:translateX(-110%)}.brand{display:flex;align-items:center;gap:.75rem;padding:0 1rem;margin-bottom:.5rem}.brand .logo{width:50px;height:50px;border-radius:8px;background:linear-gradient(135deg,var(--accent),#000);display:flex;align-items:center;justify-content:center;font-weight:700}.brand h1{font-size:16px;margin:0}
        nav{flex:1;display:flex;flex-direction:column;padding:0 .5rem}.nav-item{display:flex;align-items:center;gap:.75rem;padding:.65rem .75rem;border-radius:10px;color:var(--text);text-decoration:none;margin:.25rem 0;cursor:pointer;transition:background .2s}.nav-item:hover{background:rgba(255,255,255,.03)}.nav-item.active{background:linear-gradient(90deg,rgba(79,70,229,.12),rgba(6,182,212,.04));box-shadow:inset 0 0 0 1px rgba(255,255,255,.02)}.nav-item svg{width:20px;height:20px;flex-shrink:0;opacity:.95}.label{font-size:14px}.muted{font-size:12px;color:var(--muted)}
        .bottom{padding:.75rem;border-top:1px solid rgba(255,255,255,.03);display:flex;flex-direction:column;gap:.35rem}.bottom .nav-item{margin:0}
        .content{margin-left:var(--width);flex:1;padding:1.25rem;transition:margin-left .25s}
        .topbar{height:60px;background:#fff;border-bottom:1px solid #e6eef8;display:flex;align-items:center;justify-content:space-between;gap:.5rem;padding:0 1rem;position:sticky;top:0;z-index:20}
        .left-topbar{display:flex;align-items:center;gap:.75rem}.hamburger{width:40px;height:40px;border-radius:8px;background:#0b1220;color:var(--text);display:inline-flex;align-items:center;justify-content:center;cursor:pointer}.page-title{font-weight:600;color:#0f1724}
        .right-topbar{display:flex;align-items:center;gap:1rem}.notif-btn{background:none;border:none;cursor:pointer;position:relative;color:#0f1724}.notif-btn svg{width:22px;height:22px}.notif-badge{position:absolute;top:0;right:0;width:8px;height:8px;background:#ef4444;border-radius:50%}
        .user-info{display:flex;align-items:center;gap:.5rem}.user-info img{width:32px;height:32px;border-radius:50%;object-fit:cover}.user-text{display:flex;flex-direction:column;line-height:1}.user-name{font-size:14px;color:#111;font-weight:600}.user-role{font-size:12px;color:#777}

        @media(max-width:767px){.sidebar{width:80%;max-width:340px;transform:translateX(-110%);box-shadow:0 10px 30px rgba(2,6,23,.6)}.sidebar.open{transform:translateX(0)}.content{margin-left:0;padding-top:0}.topbar{display:flex}.app-overlay{position:fixed;inset:0;background:rgba(2,6,23,.45);z-index:30;display:none}.app-overlay.visible{display:block}}
        @media(min-width:768px){.topbar{display:flex}.sidebar{transform:translateX(0)}.sidebar.closed{transform:translateX(0)}}
        .badge{background:rgba(79,70,229,.12);color:var(--accent);font-weight:600;font-size:12px;padding:2px 6px;border-radius:999px}

        /* Submenú */
        .nav-item.has-submenu{display:block;padding:0;margin:.25rem 0}
        .nav-item.has-submenu>.nav-link{display:flex;align-items:center;gap:.75rem;padding:.65rem .75rem;border-radius:10px;color:var(--text);text-decoration:none;cursor:pointer;transition:background .2s}
        .nav-item.has-submenu>.nav-link:hover{background:rgba(255,255,255,.03)}
        .submenu-items{max-height:0;overflow:hidden;transition:max-height .35s ease,padding .3s ease;padding-left:1rem}
        .nav-item.has-submenu.open>.submenu-items{max-height:500px;padding-top:.25rem;padding-bottom:.25rem}
        .sub-nav-item{display:block;padding:.4rem .75rem;margin:.1rem 0;font-size:13px;color:var(--muted);text-decoration:none;border-radius:8px;transition:background .2s,color .2s}
        .sub-nav-item:hover{background:rgba(255,255,255,.05);color:var(--text)}
        .submenu-arrow{margin-left:auto;transition:transform .25s}.nav-item.has-submenu.open>.nav-link .submenu-arrow{transform:rotate(180deg)}
    </style>
</head>
<body>
<div class="app">

    <aside class="sidebar" id="sidebar">
        <a href="menu.php">
            <div class="brand">
                <div class="logo"><img src="uploads/LATIN-SPORTS.png" width="60"></div>
                <div><h1 style="color:white">Mi Dashboard</h1><div class="muted">Panel de administración</div></div>
            </div>
        </a>
        <nav role="navigation" aria-label="Menú principal">

            <!-- Usuarios -->
            <div class="nav-item has-submenu" id="usuariosNavItem">
                <a class="nav-link">
                    <span class="label">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                            <circle cx="12" cy="7" r="4"/>
                            <path d="M5.5 21a6.5 6.5 0 0 1 13 0"/>
                        </svg> Usuarios
                    </span>
                    <svg class="submenu-arrow" viewBox="0 0 24 24" width="16"><path d="m6 9 6 6 6-6"/></svg>
                </a>
                <div class="submenu-items">
                    <a href="usuarios.php" class="sub-nav-item">Todos</a>
					  <a href="clientes.php" class="sub-nav-item">Clientes</a>
                    <div class="nav-item has-submenu">
                        <a class="nav-link">Fotógrafos <svg class="submenu-arrow" viewBox="0 0 24 24" width="12"><path d="m6 9 6 6 6-6"/></svg></a>
                        <div class="submenu-items">
                            <a href="fotografos.php" class="sub-nav-item">Editar Fotografos</a>
                            <a href="postulaciones.php" class="sub-nav-item">Postulaciones</a>
                        </div>
                    </div>
                    <a href="comerciales.php" class="sub-nav-item">Comerciales</a>
                    <a href="organizadores.php" class="sub-nav-item">Organizadores</a>
                </div>
            </div>

            <br>

            <a href="lugar.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2C8 2 5 5 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-4-3-7-7-7z"/><circle cx="12" cy="9" r="2"/></svg><span class="label">Lugares</span></a>
            <a href="sedes.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 6-9 12-9 12S3 16 3 10a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg><span class="label">Sedes</span></a>
            <a href="escenarios.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 5v14M5 12h14"/></svg><span class="label">Escenarios</span></a>
            <a href="disciplina.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M4 4.5A2.5 2.5 0 0 1 6.5 7H20V19H6.5A2.5 2.5 0 0 1 4 16.5V4.5Z"/></svg><span class="label">Disciplinas</span></a>
 <a href="eventosadmin.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M4 4.5A2.5 2.5 0 0 1 6.5 7H20V19H6.5A2.5 2.5 0 0 1 4 16.5V4.5Z"/></svg><span class="label">Gestionar Fotos</span></a>
 <a href="fotos_ocultas.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M4 4.5A2.5 2.5 0 0 1 6.5 7H20V19H6.5A2.5 2.5 0 0 1 4 16.5V4.5Z"/></svg><span class="label">Fotos Ocultas</span></a>
                      
		   <a href="eventos.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span class="label">Eventos</span></a>

            <div class="nav-item has-submenu">
                <a class="nav-link"><span class="label">Postulaciones</span><svg class="submenu-arrow" viewBox="0 0 24 24" width="16"><path d="m6 9 6 6 6-6"/></svg></a>
                <div class="submenu-items">
                    <a href="calendariomega.php" class="sub-nav-item">Crear Calendario</a>
                    <a href="postulaciones.php" class="sub-nav-item">Aceptar Postulaciones</a>
               <a href="ver_calendario.php" class="sub-nav-item">Asignar Calendario</a>
					<a href="asignaciones.php" class="sub-nav-item">Fotografos Asignados</a>
                    <a href="ventas.php" class="sub-nav-item">Ventas</a>
                </div>
            </div>

            <a href="paquete.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.5 8.5 12 13 20.5 8.5"/></svg><span class="label">Paquetes</span></a>
            <a href="comision.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="7" r="4"/><path d="M6 21v-2a4 4 0 0 1 8 0v2"/></svg><span class="label">Comisión</span></a>
            <a href="retirocomisiones.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="7" r="4"/><path d="M6 21v-2a4 4 0 0 1 8 0v2"/></svg><span class="label">Retiros</span></a>
            <a href="analitica.php" class="nav-item"><svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 3v18h18"/><path d="M18 13v6M13 7v12M8 11v8M6 15v4"/></svg><span class="label">Analíticas</span><span class="ml-auto badge">Pro</span></a>

        </nav>
        <div class="bottom">
            <a class="nav-item" href="logout.php">
                <button id="logoutButton" style="width: 100%; padding: 0.5rem 0.75rem; border: none; border-radius: 8px; background-color: #ef4444; color: white; font-weight: 600; cursor: pointer;">
                    Cerrar Sesión
                </button>
            </a>
        </div>
    </aside>

    <div id="overlay" class="app-overlay"></div>

    <div class="main-area" style="flex:1">
        <header class="topbar">
            <div class="left-topbar">
                <button class="hamburger" id="openBtn"><svg width="20" height="20" viewBox="0 0 24 24"><path d="M3 12h18M3 6h18M3 18h18" stroke="currentColor" stroke-width="2"/></svg></button>
                <div class="page-title">Dashboard</div>
            </div>
            <div class="right-topbar" style="background-color:#f97316; padding:0.5rem 1rem; border-radius:8px;">
                <div class="user-info">
                    <img id="userFotoPerfil" src="uploads/perfil.jpg" alt="Foto perfil">
                    <div class="user-text" style="color:white;">
                        <div><strong>Nombre:</strong> <span id="userName">Cargando...</span></div>
                        <div><strong>Rol:</strong> <span id="userRole">Cargando...</span></div>
                    </div>
                </div>
            </div>
        </header>

        <div class="content" style="background:#fff;margin:1rem;padding:1.5rem;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,.05)">
            <h1 style="text-align:center;margin-bottom:1rem;color:black;">Latin Color Sports</h1>

            <div style="text-align:center;margin-top:1.5rem">
                <a href="eventos.php" style="display:inline-block;padding:0.75rem 1.75rem;background:#f97316;color:white;font-weight:600;border-radius:8px;text-decoration:none;box-shadow:0 4px 8px rgba(0,0,0,0.1)">
                    🔥 Ver Próximos Eventos
                </a>
            </div>

            <!-- CONTENEDOR DINÁMICO PARA LOS BOTONES MAESTROS -->
            <div id="roleContent"></div>
        </div>
    </div>
</div>

<script type="module">
import { auth } from './firebase-config.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const UID_MAESTRO = "A85J1BjknDQCusE3058azg2AJrw1";


// 🔁 Mantener sesión activa - CORREGIDO
// Flag anti-loop de logout
const LOGGING_OUT_KEY = 'logging_out';

// Función global para cambio de rol
window.ejecutarCambioRol = async (nuevoRol, uid) => {
    try {
        const res = await fetch('cambiar_rol.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ nuevo_rol: nuevoRol, uid: uid })
        });
        const data = await res.json();
        if (data.status === 'success') {
            alert(`Rol actualizado a: ${nuevoRol.toUpperCase()}`);
            window.location.reload();
        } else {
            alert("Error: " + (data.message || "No se pudo cambiar el rol"));
        }
    } catch (e) {
        alert("Error de conexión");
    }
};

// Función global de logout
window.cerrarSesion = async () => {
    sessionStorage.setItem(LOGGING_OUT_KEY, 'true');
    await signOut(auth);
    await fetch('logout.php');
    window.location.href = 'login_app.html';
};

// Auth state
onAuthStateChanged(auth, async (user) => {

    // Venimos de logout — no redirigir
    if (sessionStorage.getItem(LOGGING_OUT_KEY) === 'true') {
        sessionStorage.removeItem(LOGGING_OUT_KEY);
        return;
    }

    if (user) {
        try {
            const token = await user.getIdToken();
            const res = await fetch('get_user_info.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ firebase_token: token })
            });

            if (!res.ok) throw new Error('Error servidor: ' + res.status);

            const data = await res.json();

            if (data.status === 'success' && data.user) {
                const u = data.user;

                // Llenar interfaz
                if (document.getElementById('userRole'))      document.getElementById('userRole').textContent      = u.rol || '';
                if (document.getElementById('userName'))      document.getElementById('userName').textContent      = u.nombre || '';
                if (document.getElementById('userFotoPerfil')) document.getElementById('userFotoPerfil').src = u.foto_perfil || 'uploads/perfil.jpg';

                // Panel maestro / admin / soporte
                const roleContent = document.getElementById('roleContent');
                if (roleContent) {
                    const r = (u.rol || '').toLowerCase();

                    if (user.uid === UID_MAESTRO || r === 'admin') {
                        roleContent.innerHTML = `
                            <div>
                             
                            </div>`;

                    } else if (r === 'soporte') {
                        roleContent.innerHTML = `
                            <div style="margin-top:2rem; padding:1.5rem; border:1px solid #e2e8f0; border-radius:12px; background:#f8fafc; text-align:center;">
                                <h3 style="color:#1e293b; margin-top:0;">Panel Soporte</h3>
                                <div style="display:flex; gap:10px; justify-content:center; flex-wrap:wrap; margin-top:1rem;">
                                    <a href="revisar_postulaciones.php" style="padding:10px 16px; background:#ecfdf5; color:#065f46; border:1px solid #10b981; border-radius:8px; font-weight:bold; text-decoration:none;">Análisis</a>
                                    <a href="logs_sistema.php"          style="padding:10px 16px; background:#f8fafc; color:#1e293b; border:1px solid #e2e8f0; border-radius:8px; text-decoration:none;">Logs</a>
                                    <a href="nav_comercial.php"         style="padding:10px 16px; background:#f8fafc; color:#1e293b; border:1px solid #e2e8f0; border-radius:8px; text-decoration:none;">Comercial</a>
                                    <a href="nav_fotografo.php"         style="padding:10px 16px; background:#f8fafc; color:#1e293b; border:1px solid #e2e8f0; border-radius:8px; text-decoration:none;">Fotógrafo</a>
                                    <a href="nav_organizador.php"       style="padding:10px 16px; background:#f8fafc; color:#1e293b; border:1px solid #e2e8f0; border-radius:8px; text-decoration:none;">Organizador</a>
                                     <a href="soporte.php"
                                        style="padding:10px 20px; background:#f97316; color:white; border-radius:8px; font-weight:bold; text-decoration:none;">
                                        IR A SOPORTE
                                    </a>
                                </div>
                            </div>`;
                    }
                }

            } else {
                console.warn("Usuario no encontrado en BD:", data.message);
            }

        } catch (err) {
            console.error("Error al obtener info del usuario:", err);
        }

    } else {
        // No logueado — redirigir al login si no estamos ya ahí
        if (!window.location.pathname.includes('login_app.html')) {
            window.location.href = 'login_app.html';
        }
    }
});

// Botón logout — usa la función global
const logoutBtn = document.getElementById('logoutButton');
if (logoutBtn) {
    logoutBtn.onclick = () => window.cerrarSesion();
}

    // Función de cambio de rol expuesta globalmente
    window.ejecutarCambioRol = async (nuevoRol, uid) => {
        if(!confirm(`¿Deseas cambiar el sistema al modo ${nuevoRol.toUpperCase()}?`)) return;
        try {
            const res = await fetch('cambiar_rol.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ nuevo_rol: nuevoRol, uid: uid })
            });
            const result = await res.json();
            if(result.status === 'success') {
                window.location.reload();
            } else {
                alert("Error: " + result.message);
            }
        } catch (e) {
            console.error(e);
        }
    };
</script>

<script>
    // Lógica de Menú Lateral y Submenús
    document.addEventListener('DOMContentLoaded', () => {
        const sidebar = document.getElementById('sidebar');
        const openBtn = document.getElementById('openBtn');
        const overlay = document.getElementById('overlay');

        if (openBtn) openBtn.onclick = () => { sidebar.classList.toggle('open'); overlay.classList.toggle('visible'); };
        if (overlay) overlay.onclick = () => { sidebar.classList.remove('open'); overlay.classList.remove('visible'); };

        const submenus = document.querySelectorAll('.nav-item.has-submenu');
        submenus.forEach(item => {
            const link = item.querySelector(':scope > .nav-link');
            if (link) {
                link.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    item.classList.toggle('open');
                };
            }
        });
    });
</script>

</body>
</html>