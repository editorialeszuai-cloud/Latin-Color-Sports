<?php
// webhook_paypal.php - Versión final profesional
$raw_input = file_get_contents('php://input');

// 1. Log para tener registro de todo lo que PayPal nos dice
file_put_contents('webhook_log.txt', "[" . date('Y-m-d H:i:s') . "] Recibido: " . $raw_input . PHP_EOL, FILE_APPEND);

if (empty($raw_input)) {
    http_response_code(400);
    exit;
}

$data = json_decode($raw_input, true);

if ($data && isset($data['event_type'])) {
    require_once __DIR__ . '/dbfotografos.php';
    $pdo = conectar();
    
    // Extraemos el recurso de forma segura
    $resource = $data['resource'] ?? [];
    $purchase_units = $resource['purchase_units'][0] ?? [];
    
    // Buscamos la referencia en el campo reference_id (el estándar en webhooks)
    $referencia = $purchase_units['custom_id'] ?? $purchase_units['reference_id'] ?? null;

    if ($referencia) {
        
        // EVENTOS DE ÉXITO
        if ($data['event_type'] === 'CHECKOUT.ORDER.APPROVED' || $data['event_type'] === 'PAYMENT.CAPTURE.COMPLETED') {
            
            $stmt = $pdo->prepare("UPDATE compras SET estado = 'APPROVED' WHERE referencia = ?");
            $result = $stmt->execute([$referencia]);
            
            if ($result) {
                file_put_contents('webhook_log.txt', "-> ÉXITO: Referencia $referencia marcada como APPROVED." . PHP_EOL, FILE_APPEND);
            }
        } 
        
        // EVENTOS DE FALLO O RECHAZO
        elseif (
            $data['event_type'] === 'PAYMENT.CAPTURE.DENIED' || 
            $data['event_type'] === 'PAYMENT.CAPTURE.DECLINED' || 
            $data['event_type'] === 'CHECKOUT.ORDER.DECLINED' || 
            $data['event_type'] === 'CHECKOUT.ORDER.VOIDED'
        ) {
            
            $stmt = $pdo->prepare("UPDATE compras SET estado = 'FAILED' WHERE referencia = ?");
            $result = $stmt->execute([$referencia]);
            
            if ($result) {
                file_put_contents('webhook_log.txt', "-> PAGO FALLIDO: Referencia $referencia marcada como FAILED debido a evento: " . $data['event_type'] . PHP_EOL, FILE_APPEND);
            }
        }
    } else {
        file_put_contents('webhook_log.txt', "-> ERROR: No se pudo extraer la referencia del JSON." . PHP_EOL, FILE_APPEND);
    }
}

// Respondemos 200 siempre a PayPal para que deje de enviar la notificación
http_response_code(200);
?>