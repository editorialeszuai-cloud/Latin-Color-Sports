import { auth } from './firebase-config.js';
import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  FacebookAuthProvider,
  signInWithPopup,
  updateProfile,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// 1. REFERENCIAS AL DOM
const nombreInput = document.getElementById('nombre');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const userRoleSelect = document.getElementById('userRole');
const registerEmailButton = document.getElementById('registerEmail');
const googleRegisterButton = document.getElementById('googleRegister');
const facebookRegisterButton = document.getElementById('facebookRegister');
const messageDiv = document.getElementById('message');

// 2. UTILIDAD PARA MENSAJES
function showMessage(text, type = 'info') {
  if (messageDiv) {
    messageDiv.textContent = text;
    messageDiv.className = `message ${type}`;
    messageDiv.style.display = 'block';
  }
  console.log(`[${type.toUpperCase()}] ${text}`);
}

// 3. COMUNICACIÓN CON EL BACKEND (PHP)
async function sendUserToPHP(user, rol) {
  if (!user || !rol) return;

  try {
    const idToken = await user.getIdToken(true);
    
    const response = await fetch('roles.php', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache'
      },
      body: JSON.stringify({
        idToken,
        firebase_uid: user.uid,
        email: user.email,
        nombre: user.displayName || nombreInput?.value || '',
        rol: rol
      })
    });

    const data = await response.json();
    
    if (data.status === 'success') {
      showMessage('¡Operación exitosa!', 'success');
      // Redirección segura tras éxito
      setTimeout(() => { window.location.href = 'nav_usuarios.php'; }, 1000);
    } else {
      throw new Error(data.message || 'Error en el servidor');
    }
  } catch (error) {
    console.error('❌ Error crítico en sendUserToPHP:', error);
    showMessage('Error: ' + error.message, 'error');
  }
}

// 4. OBSERVADOR DE ESTADO (El corazón del flujo para iPhone)
onAuthStateChanged(auth, (user) => {
  if (user) {
    const rolGuardado = localStorage.getItem('rolSeleccionado');
    if (rolGuardado) {
      console.log("Sesión activa detectada en iPhone, procesando...");
      sendUserToPHP(user, rolGuardado);
      // Limpiamos para evitar doble envío
      localStorage.removeItem('rolSeleccionado');
    }
  }
});

// 5. REGISTRO EMAIL
registerEmailButton?.addEventListener('click', async () => {
  const rol = userRoleSelect?.value;
  if (!rol) return showMessage('Selecciona un rol.', 'error');

  try {
    const cred = await createUserWithEmailAndPassword(auth, emailInput.value, passwordInput.value);
    await updateProfile(cred.user, { displayName: nombreInput.value });
    // Guardamos rol y el observador disparará la lógica
    localStorage.setItem('rolSeleccionado', rol);
  } catch (err) {
    showMessage('Error Auth: ' + err.message, 'error');
  }
});

// 6. GOOGLE
googleRegisterButton?.addEventListener('click', () => {
  const rol = userRoleSelect?.value;
  if (!rol) return showMessage('Selecciona un rol.', 'error');
  
  localStorage.setItem('rolSeleccionado', rol);
  signInWithPopup(auth, new GoogleAuthProvider()).catch(e => showMessage(e.message, 'error'));
});

// 7. FACEBOOK
facebookRegisterButton?.addEventListener('click', () => {
  const rol = userRoleSelect?.value;
  if (!rol) return showMessage('Selecciona un rol.', 'error');
  
  localStorage.setItem('rolSeleccionado', rol);
  signInWithPopup(auth, new FacebookAuthProvider()).catch(e => showMessage(e.message, 'error'));
});