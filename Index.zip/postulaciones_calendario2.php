<?php
header('Content-Type: application/json; charset=utf-8');
require 'dbfotografos.php'; // Conexión PDO

$accion = $_POST['accion'] ?? '';
$usuario_id = $_POST['usuario_id'] ?? '';
$postulacion_id = $_POST['postulacion_id'] ?? '';
$evento_id = $_POST['evento_id'] ?? '';

try {
    if ($accion === 'listar') {
        if (!$usuario_id) throw new Exception('Falta el usuario_id');

        $stmt = $pdo->prepare("
            SELECT p.id AS postulacion_id, e.id AS evento_id, e.titulo AS evento_nombre,
                   e.disciplina, e.categoria, e.fecha, e.hora, e.escenario, e.sede, e.calendario
            FROM postulaciones p
            JOIN eventos e ON p.evento_id = e.id
            WHERE p.usuario_id = ? AND p.estado = 'aceptado'
            ORDER BY e.calendario, e.sede, e.fecha, e.hora
        ");
        $stmt->execute([$usuario_id]);
        $postulaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $postulaciones]);
        exit;
    }

    if ($accion === 'datos_evento') {
        if (!$postulacion_id || !$evento_id) throw new Exception('Faltan parámetros postulacion_id o evento_id');

        $stmt = $pdo->prepare("
            SELECT p.id AS postulacion_id, e.id AS evento_id, e.titulo AS evento_nombre,
                   e.disciplina, e.categoria, e.fecha, e.hora, e.escenario, e.sede, e.calendario
            FROM postulaciones p
            JOIN eventos e ON p.evento_id = e.id
            WHERE p.id = ? AND e.id = ?
            LIMIT 1
        ");
        $stmt->execute([$postulacion_id, $evento_id]);
        $evento = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$evento) {
            echo json_encode(['success' => false, 'message' => 'Evento no encontrado']);
            exit;
        }

        echo json_encode(['success' => true, 'evento' => $evento]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Acción no válida']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
