<?php
// track_logs.php
function registrarAccesoIndex($conn, $userId, $nombre, $rol) {
    $pagina = "INDEX / LOGIN SUCCESS";
    $ip = $_SERVER['REMOTE_ADDR'];
    // Detectar IP detrás de proxies si es necesario
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    $ua = $_SERVER['HTTP_USER_AGENT'];

    $stmt = $conn->prepare("INSERT INTO auditoria_navegacion (usuario_id, nombre_usuario, rol, pagina_visitada, ip_acceso, user_agent) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $userId, $nombre, $rol, $pagina, $ip, $ua);
    $stmt->execute();
    $stmt->close();
}
?>