<?php
error_reporting(0);
ob_start();

require 'dbfotografos.php';
require 'vendor/autoload.php';

use Aws\S3\S3Client;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__, 'claves.env');
$dotenv->load();

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => $_ENV['AWS_REGION'],
    'credentials' => ['key' => $_ENV['AWS_KEY'], 'secret' => $_ENV['AWS_SECRET']],
]);

$foto_id = $_GET['id'] ?? null;

if (!$foto_id) {
    die('<p style="color:red; text-align:center; padding:20px;">Error: ID no especificado.</p>');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 1. MODO DESCARGA / STREAM
if (isset($_GET['stream']) && $_GET['stream'] == '1') {
    ob_end_clean();
    try {
        $stmtF = $pdo->prepare("SELECT url FROM fotos WHERE id = ?");
        $stmtF->execute([$foto_id]);
        $foto = $stmtF->fetch(PDO::FETCH_ASSOC);

        if ($foto) {
            // REGISTRAR DESCARGA
            $stmtLog = $pdo->prepare("INSERT INTO descargas_log (foto_id, fecha) VALUES (?, NOW())");
            $stmtLog->execute([$foto_id]);

            $url_parts = parse_url($foto['url']);
            $s3_key = ltrim($url_parts['path'], '/');

            $result = $s3->getObject([
                'Bucket' => $_ENV['AWS_BUCKET'] ?? 'latincolorsports-bucket',
                'Key'    => $s3_key,
            ]);

            header("Content-Type: image/jpeg");
            header("Content-Disposition: attachment; filename=\"LatinColorSports_Foto_{$foto_id}.jpg\"");
            header("Cache-Control: private, max-age=86400");
            echo $result['Body'];
            exit;
        }
    } catch (Exception $e) {
        exit("Error en el servidor.");
    }
}

// 2. LÓGICA ELIMINACIÓN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'eliminar') {
    ob_end_clean();
    header('Content-Type: application/json');
    try {
        $stmtF = $pdo->prepare("SELECT url FROM fotos WHERE id = ?");
        $stmtF->execute([$foto_id]);
        $foto = $stmtF->fetch(PDO::FETCH_ASSOC);
        
        if ($foto) {
            $s3_key = ltrim(parse_url($foto['url'])['path'], '/');
            $s3->deleteObject(['Bucket' => $_ENV['AWS_BUCKET'] ?? 'latincolorsports-bucket', 'Key' => $s3_key]);
            
            $pdo->prepare("DELETE FROM fotos WHERE id = ?")->execute([$foto_id]);
            exit(json_encode(['success' => true]));
        }
    } catch (Exception $e) {
        exit(json_encode(['success' => false, 'error' => $e->getMessage()]));
    }
}

// 3. CARGA DE DATOS
$stmt = $pdo->prepare("
    SELECT f.*, g.titulo as galeria_titulo, e.titulo as evento_titulo 
    FROM fotos f
    INNER JOIN galerias g ON f.galeria_id = g.id
    INNER JOIN postulaciones p ON g.postulacion_id = p.id
    LEFT JOIN eventos e ON p.evento_id = e.id
    WHERE f.id = ?
");
$stmt->execute([$foto_id]);
$detalles = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle Foto #<?= $foto_id ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <style>
        * { -webkit-user-select: none; user-select: none; }
    </style>
</head>
<body class="bg-[#050505] text-white min-h-screen flex flex-col">
    <?php require 'navpublicidad.php' ?>

    <div class="flex-1 flex items-center justify-center p-4 mt-20">
        <div class="w-full max-w-lg bg-[#0f0f0f] border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
            <div class="relative w-full aspect-square bg-black flex items-center justify-center overflow-hidden">
                <img src="foto_detalle.php?id=<?= $foto_id ?>&stream=1" class="w-full h-full object-contain pointer-events-none">
            </div>
            
            <div class="p-6 space-y-4">
                <div class="bg-white/5 p-4 rounded-2xl border border-white/5">
                    <p class="text-orange-500 font-black text-[9px] uppercase">Evento</p>
                    <p class="text-sm font-bold"><?= htmlspecialchars($detalles['evento_titulo'] ?? 'Sin evento') ?></p>
                </div>
                
                <div class="grid grid-cols-2 gap-3">
                    <a href="foto_detalle.php?id=<?= $foto_id ?>&stream=1" class="bg-orange-500 text-black font-black text-xs uppercase py-3 rounded-xl text-center">📥 Descargar</a>
                    </div>
            </div>
        </div>
    </div>

<script>
    document.addEventListener('contextmenu', e => e.preventDefault());
    
    window.confirmarEliminacion = async function() {
        if(confirm("¿Eliminar permanentemente?")) {
            const res = await fetch(window.location.href, { method: 'POST', body: new URLSearchParams('action=eliminar') });
            const data = await res.json();
            if(data.success) { window.location.href = "mis_galerias.php"; }
            else { alert("Error al eliminar"); }
        }
    }
</script>
</body>
</html>