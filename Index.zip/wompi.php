<?php
require 'dbfotografos.php';
$pdo = conectar();

// 1. Validar parámetros de entrada
$compra_id = $_GET['compra_id'] ?? '';
if (!$compra_id) {
    die('<p style="color:red; font-family:sans-serif; text-align:center; padding:20px;">Error: ID de compra no especificado.</p>');
}

try {
    // 2. Obtener datos maestros de la compra
    $stmt = $pdo->prepare("SELECT * FROM compras WHERE id = ?");
    $stmt->execute([$compra_id]);
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$compra) {
        die('<p style="color:red; text-align:center; padding:20px;">Error: La orden de compra no existe.</p>');
    }

    // 3. Obtener el detalle con conteo dinámico de unidades
    // Si id_foto es NULL, es un pack y contamos las fotos de ese evento_id
    $stmt = $pdo->prepare("
        SELECT 
            d.precio, 
            d.id_foto, 
            d.evento_id,
            e.titulo AS evento_titulo,
            (SELECT url FROM fotos WHERE id = d.id_foto LIMIT 1) as foto_url,
            CASE 
                WHEN d.id_foto IS NULL THEN (SELECT COUNT(*) FROM fotos WHERE evento_id = d.evento_id)
                ELSE 1 
            END as fotos_incluidas
        FROM detalle_compras d
        INNER JOIN eventos e ON d.evento_id = e.id
        WHERE d.id_compra = ?
    ");
    $stmt->execute([$compra_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Totales calculados
    $total_unidades_reales = array_sum(array_column($items, 'fotos_incluidas'));
    $total_precio = (float)$compra['total'];

    // 4. Configuración de Wompi (Producción)
    $public_key = "pub_prod_qDvUDoTJtgy1bVkcuQJ7rcgkOM4oxbLw";
    $secret_integrity = "prod_integrity_BWG58peE6yhM382mYETKtAjra3xNEARl"; 
    
    $transaccion_id = $compra['referencia'];
    $amount_in_cents = intval($total_precio * 100);
	$amount_in_cents2 = intval($total_precio * 100 * 4000);
    $currency = "COP";

    // Firma de Integridad: referencia + monto_en_centavos + moneda + llave_secreta
    $cadena_firma = $transaccion_id . $amount_in_cents . $currency . $secret_integrity;
    $firma = hash("sha256", $cadena_firma);

} catch (PDOException $e) {
    die("Error de base de datos: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Checkout Seguro | Latin Color Sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background: #050505; color: #eee; font-family: 'Inter', sans-serif; }
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #333; border-radius: 10px; }
        .glass { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(10px); }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-[#0f0f0f] border border-white/10 rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        
        <div class="p-6 border-b border-white/5 bg-black/40 text-center">
            <div class="inline-block bg-orange-500/10 p-2 rounded-2xl mb-3">
                <svg class="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
            </div>
            <h1 class="text-xl font-black italic text-white tracking-tighter uppercase">Latin Color <span class="text-orange-500">Sports</span></h1>
            <p class="text-[10px] text-gray-500 uppercase tracking-[0.2em] font-bold mt-1">Checkout Seguro</p>
        </div>

        <div class="p-6">
            <div class="flex justify-between items-center mb-6 glass p-4 rounded-2xl border border-white/5">
                <div>
                    <p class="text-[10px] text-gray-500 uppercase font-bold">Referencia</p>
                    <p class="text-sm font-bold text-white"><?= htmlspecialchars($transaccion_id) ?></p>
                </div>
                <div class="text-right">
                    <p class="text-[10px] text-gray-500 uppercase font-bold">Total Fotos</p>
                    <p class="text-sm font-bold text-orange-500"><?= $total_unidades_reales ?> unidades</p>
                </div>
            </div>

            <div class="space-y-3 max-h-60 overflow-y-auto custom-scroll pr-2 mb-8">
                <?php foreach($items as $item): ?>
                    <div class="flex items-center gap-3 bg-white/5 p-2 rounded-xl border border-white/5">
                        <div class="relative">
                            <img src="uploads/<?= $item['foto_url'] ?? 'pack_icon.png' ?>" 
                                 class="w-12 h-12 object-cover rounded-lg <?= !$item['id_foto'] ? 'border-2 border-orange-500' : 'grayscale-[20%]' ?>"
                                 onerror="this.src='https://via.placeholder.com/100?text=PACK'">
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-[9px] text-gray-500 uppercase font-bold truncate"><?= htmlspecialchars($item['evento_titulo']) ?></p>
                            <p class="text-[11px] text-white font-medium">
                                <?= $item['id_foto'] ? "Foto #".$item['id_foto'] : "<span class='text-orange-500 font-bold'>Pack Completo</span>" ?>
                            </p>
                            <p class="text-[9px] text-gray-400 font-medium italic"><?= $item['fotos_incluidas'] ?> fotos incluidas</p>
                        </div>
                        <p class="text-xs font-bold text-white">$<?= number_format($item['precio'], 0, ',', '.') ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="text-center mb-8">
                <p class="text-[11px] text-gray-500 uppercase font-black mb-1">Total a pagar</p>
                <div class="flex items-center justify-center gap-2">
                    <span class="text-sm font-bold text-gray-500">USD</span>
                    <span class="text-4xl font-black text-white tracking-tight">$<?= number_format($total_precio, 0, ',', '.') ?></span>
                </div>
            </div>

            <div class="wompi-container flex justify-center py-2 scale-110">
                <form>
                    <script
                        src="https://checkout.wompi.co/widget.js"
                        data-render="button"
                        data-public-key="<?= $public_key ?>"
                        data-currency="<?= $currency ?>"
                        data-amount-in-cents="<?= $amount_in_cents2 ?>"
                        data-reference="<?= $transaccion_id ?>"
                        data-redirect-url="https://latincolorsports.com/response.php"
                        data-signature:integrity="<?= $firma ?>"
                    ></script>
                </form>
            </div>
        </div>

        <div class="p-4 bg-black/40 border-t border-white/5 text-center">
            <button onclick="window.history.back()" class="text-[10px] font-bold text-gray-500 hover:text-white transition uppercase tracking-widest flex items-center justify-center gap-2 w-full">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                Cancelar y volver
            </button>
        </div>
    </div>

</body>
</html>