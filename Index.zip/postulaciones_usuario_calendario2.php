<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// 1. Cargar base de datos
require_once "dbfotografos.php"; 

function resp($ok, $msg, $data = null) {
    echo json_encode([
        'success' => $ok,
        'message' => $msg,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 2. Obtener datos
$raw = file_get_contents("php://input");
$input = json_decode($raw, true) ?: $_POST;
$firebaseToken = $input['firebase_token'] ?? null;

if (!$firebaseToken) resp(false, 'Token no recibido.');

try {
    // 3. Verificaci�n manual del Token (Sin librer�as externas)
    $partes = explode('.', $firebaseToken);
    if (count($partes) !== 3) resp(false, 'Token inv�lido.');
    
    $payload = json_decode(base64_decode($partes[1]), true);
    $firebase_uid = $payload['sub'] ?? null;
    
    if (!$firebase_uid) resp(false, 'UID no extra�do del token.');

    // 4. Conectar con PDO
    // Aseg�rate que tu funci�n conectar() exista en dbfotografos.php
    $pdo = conectar(); 

    // 5. Obtener ID de usuario local
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmt->execute([$firebase_uid]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) resp(false, 'Usuario no encontrado en la base de datos.');
    $usuario_id = $user['id'];

    // 6. Consulta de Eventos
    $sql = "
        SELECT 
            p.id AS postulacion_id,
            e.id AS evento_id,
            e.titulo AS evento_nombre,
            e.fecha AS fecha_evento,
            p.estado,
            s.titulo AS nombre_sede,
            esc.nombre AS nombre_escenario,
            d.nombre_disciplina AS nombre_disciplina
        FROM postulaciones p
        LEFT JOIN eventos e ON e.id = p.evento_id
        LEFT JOIN calendarios c ON c.id = p.calendario_id
        LEFT JOIN sedes s ON s.id = c.sede_id
        LEFT JOIN escenarios esc ON esc.id = c.escenario_id
        LEFT JOIN disciplinas d ON d.id = c.disciplina_id
        WHERE p.usuario_id = ?
          AND e.fecha < CURDATE()
        ORDER BY e.fecha DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id]);
    $postulaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    resp(true, 'Postulaciones pasadas obtenidas.', $postulaciones);

} catch (Throwable $e) {
    resp(false, 'Error cr�tico: ' . $e->getMessage());
}