<?php
// api_verificar_registro.php
require_once 'dbfotografos.php';
header('Content-Type: application/json');

$uid = $_GET['uid'] ?? null;

if (!$uid) {
    echo json_encode(['registrado' => false]);
    exit;
}

try {
    // Consulta rápida para ver si el UID ya tiene un descriptor guardado
    $stmt = $pdo->prepare("SELECT id FROM perfiles_biometricos WHERE firebase_uid = ? LIMIT 1");
    $stmt->execute([$uid]);
    $existe = $stmt->fetch();

    echo json_encode(['registrado' => $existe ? true : false]);
} catch (Exception $e) {
    echo json_encode(['registrado' => false, 'error' => $e->getMessage()]);
}