<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latin Color Sports - Dashboard Fotógrafo</title>
    <style>
        :root{ --sidebar-width:270px; --dark:#0b1220; --dark-2:#141d2f; --primary:#ff416c; --secondary:#ff4b2b; --bg:#f5f7fb; --white:#ffffff; --text:#1f2937; --muted:#6b7280; --border:#e5e7eb; }
        *{ margin:0; padding:0; box-sizing:border-box; font-family:Inter,Arial,sans-serif; }
        body{ background:var(--bg); color:var(--text); overflow-x:hidden; }
        .topbar{ position:fixed; top:0; left:0; right:0; height:70px; background:white; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; padding:0 20px; z-index:1000; }
        .left-topbar{ display:flex; align-items:center; gap:15px; }
        .hamburger{ background:none; border:none; cursor:pointer; font-size:24px; }
        .logo{ display:flex; align-items:center; gap:10px; }
        .logo img{ width:45px; height:45px; border-radius:10px; }
        .user-info{ display:flex; align-items:center; gap:10px; }
        .user-info img{ width:42px; height:42px; border-radius:50%; object-fit:cover; }
        .sidebar{ position:fixed; left:0; top:70px; width:var(--sidebar-width); height:calc(100vh - 70px); background:linear-gradient(180deg,var(--dark),var(--dark-2)); color:white; overflow-y:auto; transition:.3s; }
        .sidebar-menu{ padding:20px 12px; }
        .sidebar-title{ font-size:13px; color:#9ca3af; margin:15px 10px; text-transform:uppercase; }
        .sidebar a{ display:flex; align-items:center; gap:12px; text-decoration:none; color:white; padding:14px; border-radius:12px; margin-bottom:5px; transition:.3s; }
        .sidebar a:hover{ background:rgba(255,255,255,.08); }
        .sidebar a.active{ background:linear-gradient(90deg,var(--primary),var(--secondary)); }
        .main{ margin-left:var(--sidebar-width); margin-top:90px; padding:25px; transition:.3s; }
        .hero{ background:white; border-radius:24px; padding:40px; box-shadow:0 4px 20px rgba(0,0,0,.05); }
        .hero h1{ font-size:42px; margin-bottom:10px; background:linear-gradient(90deg,#FF416C,#FF4B2B,#FFD700,#24C6DC); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .cards{ margin-top:25px; display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:20px; }
        .card{ background:white; border-radius:20px; padding:25px; box-shadow:0 4px 15px rgba(0,0,0,.05); border: 1px solid var(--border); }
        .card h3{ font-size:14px; color:var(--muted); margin-bottom:10px; }
        .card .title{ font-size:18px; font-weight:bold; margin-bottom:15px; }
        .btn-view{ display:block; text-align:center; background:var(--primary); color:white; padding:10px; border-radius:10px; text-decoration:none; font-weight:bold; }
        #logoutButton{ width:100%; padding:12px; border:none; border-radius:12px; background:#ef4444; color:#fff; font-weight:600; cursor:pointer; margin-top:20px; }
        @media(max-width:900px){ .sidebar{ transform:translateX(-100%); z-index:1001; } .sidebar.show{ transform:translateX(0); } .main{ margin-left:0; } }
    </style>
</head>
<body>

<div class="overlay" id="overlay"></div>

<header class="topbar">
    <div class="left-topbar">
        <button class="hamburger" id="menuBtn">☰</button>
        <div class="logo"><img src="../uploads/LATIN-SPORTS.png"><span>Latin Color Sports</span></div>
    </div>
    <div class="user-info">
        <img id="userFotoPerfil" src="uploads/perfil.jpg">
        <div>
            <div id="userName">Cargando...</div>
            <small id="userRole">Publicidad</small>
        </div>
    </div>
</header>

<aside class="sidebar" id="sidebar">
    <div class="sidebar-menu">
        <div class="sidebar-title">Navegación</div>
        <a class="active" href="nav_publicidad.php">Inicio</a>
        <a href="editar_perfil.php">Editar Perfil</a>
        <button id="logoutButton">Cerrar Sesión</button>
    </div>
</aside>

<main class="main">
    <section class="hero">
        <h1>Bienvenido Fotógrafo</h1>
        <p>Selecciona un evento para gestionar o visualizar sus galerías.</p>
    </section>

    <section class="section" style="margin-top:25px;">
        <h2>Eventos Disponibles</h2>
        <div id="lista-eventos" class="cards">
            <p>Cargando eventos...</p>
        </div>
    </section>
</main>

<script>
    const menuBtn = document.getElementById("menuBtn");
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("overlay");
    menuBtn.addEventListener("click", () => { sidebar.classList.toggle("show"); overlay.classList.toggle("show"); });
</script>

<script type="module">
    import { auth } from './firebase-config.js';
    import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

    const listaEventos = document.getElementById('lista-eventos');

    async function cargarEventos() {
        try {
            const response = await fetch('get_eventos.php'); // Asegúrate que este archivo exista
            const data = await response.json();
            if (data.status === 'success') {
                listaEventos.innerHTML = '';
                data.eventos.forEach(ev => {
                    const card = document.createElement('div');
                    card.className = 'card';
                    card.innerHTML = `
                        <h3>${ev.fecha}</h3>
                        <div class="title">${ev.titulo}</div>
                        <a href="contenido.php?evento_id=${ev.id}" class="btn-view">Ver Galería</a>
                    `;
                    listaEventos.appendChild(card);
                });
            }
        } catch (e) { listaEventos.innerHTML = '<p>Error al cargar eventos.</p>'; }
    }

    onAuthStateChanged(auth, async (user) => {
        if (!user) { window.location.href = 'login_app.html'; return; }
        cargarEventos();
        // ... (resto de tu lógica de carga de usuario)
    });

    document.getElementById('logoutButton').addEventListener('click', async () => {
        await signOut(auth);
        window.location.href = 'login_app.html';
    });
</script>

</body>
</html>