<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once "conexion.php";
$conn = conectar();

$accion = $_POST['accion'] ?? '';
$id = $_POST['id'] ?? null;
$nombre = $_POST['nombre'] ?? '';

try {
    if ($accion === 'crear') {
        if (!$nombre) throw new Exception("El nombre es obligatorio.");

        $stmt = $conn->prepare("INSERT INTO escenarios (nombre) VALUES (?)");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Escenario creado correctamente.']);

    } elseif ($accion === 'editar' && $id) {
        if (!$nombre) throw new Exception("El nombre es obligatorio.");

        $stmt = $conn->prepare("UPDATE escenarios SET nombre=? WHERE id=?");
        $stmt->bind_param("si", $nombre, $id);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Escenario actualizado correctamente.']);

    } elseif ($accion === 'eliminar' && $id) {
        $stmt = $conn->prepare("DELETE FROM escenarios WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Escenario eliminado correctamente.']);

    } elseif ($accion === 'listar') {
        $result = $conn->query("SELECT * FROM escenarios ORDER BY id DESC");
        $data = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['success' => true, 'data' => $data]);

    } else {
        echo json_encode(['success' => false, 'message' => 'Acción no válida.']);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
