<?php
header("Content-Type: application/json; charset=utf-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once "db.php"; // Este archivo debe definir la variable $pdo

function resp($ok, $msg, $data = null) {
    echo json_encode([
        'success' => $ok,
        'message' => $msg,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$raw = file_get_contents("php://input");
$data = json_decode($raw, true);
if (!$data) $data = $_POST;

$firebaseToken = $data['firebase_token'] ?? null;
if (!$firebaseToken) resp(false, 'Token no recibido.');

try {
    // 1. Extraer UID del Token (Decodificación manual de JWT)
    $parts = explode('.', $firebaseToken);
    if (count($parts) !== 3) throw new Exception("Formato de token inválido.");
    $payload = json_decode(base64_decode(strtr($parts[1], '-_', '+/')), true);
    $firebase_uid = $payload['sub'] ?? null;

    if (!$firebase_uid) resp(false, 'UID no encontrado en el token.');

    // 2. Conexión usando PDO (asumiendo que en db.php la variable es $pdo)
    // Si tu db.php usa una función conectar(), asegúrate que devuelva el objeto PDO.
    if (!isset($pdo)) {
        $pdo = conectar(); 
    }

    // 3. Buscar el usuario
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE firebase_uid = ? LIMIT 1");
    $stmt->execute([$firebase_uid]); // ✅ Sintaxis PDO
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) resp(false, 'Usuario no encontrado en la base de datos.');
    $usuario_id = $user['id'];

    // 4. Obtener postulaciones
    $sql = "
        SELECT 
            p.id AS postulacion_id,
            e.id AS evento_id,
            e.titulo AS evento_nombre,
            e.fecha AS fecha_evento,
            p.estado,
            s.titulo AS nombre_sede,
            esc.nombre AS nombre_escenario,
            d.nombre_disciplina AS nombre_disciplina
        FROM postulaciones p
        LEFT JOIN eventos e ON e.id = p.evento_id
        LEFT JOIN calendarios c ON c.id = p.calendario_id
        LEFT JOIN sedes s ON s.id = c.sede_id
        LEFT JOIN escenarios esc ON esc.id = c.escenario_id
        LEFT JOIN disciplinas d ON d.id = c.disciplina_id
        WHERE p.usuario_id = ?
        ORDER BY e.fecha ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id]); // ✅ Sintaxis PDO
    $postulaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

    resp(true, 'Postulaciones obtenidas correctamente.', $postulaciones);

} catch (Throwable $e) {
    resp(false, 'Error interno: ' . $e->getMessage());
}
?>