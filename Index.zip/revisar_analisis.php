<?php
require 'dbfotografos.php';

// --- API DE ACCIONES (MANEJO DE PETICIONES AJAX) ---
if (isset($_GET['get_pendientes'])) {
    header('Content-Type: application/json');
    $post_id = $_GET['postulacion_id'] ?? 0;
    
    // Solo trae fotos que NO existan en log_procesamiento
    $stmt = $pdo->prepare("
        SELECT f.id, f.url 
        FROM fotos f 
        WHERE f.postulacion_id = ? 
        AND NOT EXISTS (SELECT 1 FROM log_procesamiento lp WHERE lp.foto_id = f.id)
        ORDER BY f.id ASC LIMIT 5
    ");
    $stmt->execute([$post_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $foto_id = $_POST['foto_id'] ?? null;

    try {
        if ($action === 'guardar_rostro') {
            $stmt = $pdo->prepare("INSERT INTO faces (foto_id, descriptor) VALUES (?, ?)");
            $stmt->execute([$foto_id, $_POST['descriptor']]);
            echo json_encode(['success' => true]);
        }
        if ($action === 'marcar_escaneada') {
            $stmt = $pdo->prepare("INSERT IGNORE INTO log_procesamiento (foto_id) VALUES (?)");
            $stmt->execute([$foto_id]);
            echo json_encode(['success' => true]);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

$postulacion_id = $_GET['postulacion_id'] ?? die("ID de postulación requerido.");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robot Scanner Pro | LCS</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .analyzing { outline: 4px solid #f97316; box-shadow: 0 0 30px rgba(249, 115, 22, 0.5); z-index: 10; transform: scale(1.02); }
        .photo-card { transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1); }
        .loader-dots div { animation: blink 1.4s infinite both; }
        .loader-dots div:nth-child(2) { animation-delay: .2s; }
        .loader-dots div:nth-child(3) { animation-delay: .4s; }
        @keyframes blink { 0% { opacity: .2; } 20% { opacity: 1; } 100% { opacity: .2; } }
    </style>
</head>

<body class="bg-[#020617] text-slate-200 min-h-screen">

    <div class="max-w-7xl mx-auto p-4 md:p-8">
        
        <!-- Header Superior -->
        <header class="flex flex-col md:flex-row justify-between items-center mb-8 bg-slate-900/50 p-6 rounded-[2rem] border border-slate-800 backdrop-blur-md">
            <div class="flex items-center gap-4 mb-4 md:mb-0">
                <div class="bg-orange-500 p-3 rounded-2xl shadow-lg shadow-orange-500/20">
                    <i class="fas fa-robot text-2xl text-white"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-black italic tracking-tighter text-white">SCANNER <span class="text-orange-500">AUTO-V2</span></h1>
                    <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Latin Color Sports • IA Engine</p>
                </div>
            </div>

            <div class="flex items-center gap-6">
                <div id="statusIA" class="px-4 py-2 rounded-full bg-black/50 text-[10px] font-black text-orange-500 border border-orange-500/20 uppercase">
                    <i class="fas fa-spinner fa-spin mr-2"></i> Cargando Modelos...
                </div>
                <a href="soporte.php" class="text-slate-400 hover:text-white transition-colors">
                    <i class="fas fa-times text-xl"></i>
                </a>
            </div>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
            
            <!-- Panel de Control Lateral -->
            <aside class="space-y-4">
                <div class="bg-slate-900/80 p-6 rounded-[2rem] border border-slate-800 sticky top-8">
                    <h3 class="text-xs font-black text-slate-500 uppercase mb-4 tracking-widest">Controles</h3>
                    
                    <button id="btnAction" onclick="iniciarProceso()" disabled class="w-full bg-orange-600 disabled:bg-slate-800 disabled:text-slate-600 hover:bg-orange-500 text-white p-5 rounded-2xl font-black uppercase transition-all shadow-xl shadow-orange-900/20 flex items-center justify-center gap-3">
                        <i class="fas fa-play"></i> Iniciar Robot
                    </button>

                    <div class="mt-6 space-y-3">
                        <div class="flex justify-between text-[10px] font-bold uppercase">
                            <span class="text-slate-500">Estado:</span>
                            <span id="label-status" class="text-orange-500">Esperando...</span>
                        </div>
                        <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div id="progress-bar" class="bg-orange-500 h-full w-0 transition-all duration-500"></div>
                        </div>
                    </div>

                    <p class="text-[9px] text-slate-500 mt-6 leading-relaxed font-medium uppercase text-center italic">
                        El sistema procesará fotos en lotes y las eliminará de la pantalla para optimizar RAM.
                    </p>
                </div>
            </aside>

            <!-- Área de Trabajo -->
            <main class="lg:col-span-3">
                
                <div id="galeria-ia" class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    <!-- Las fotos cargan aquí vía AJAX -->
                </div>

                <!-- Estado Vacío / Finalizado -->
                <div id="finish-msg" class="hidden flex flex-col items-center justify-center p-20 bg-slate-900/20 rounded-[3rem] border-2 border-dashed border-slate-800 text-center">
                    <div class="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mb-6">
                        <i class="fas fa-check text-3xl text-green-500"></i>
                    </div>
                    <h2 class="text-2xl font-black text-white uppercase tracking-tighter">Álbum Procesado</h2>
                    <p class="text-slate-500 text-sm mt-2 font-medium">No hay fotos pendientes de escaneo facial.</p>
                </div>

                <!-- Cargador de Lotes -->
                <div id="batch-loader" class="hidden mt-8 text-center">
                    <div class="loader-dots flex justify-center gap-1">
                        <div class="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <div class="w-2 h-2 bg-orange-500 rounded-full"></div>
                        <div class="w-2 h-2 bg-orange-500 rounded-full"></div>
                    </div>
                    <p class="text-[10px] font-black text-slate-500 uppercase mt-2 tracking-widest">Solicitando nuevo lote...</p>
                </div>

            </main>
        </div>
    </div>

<script>
    let modelsLoaded = false;
    let isRunning = false;
    const post_id = "<?= $postulacion_id ?>";

    // Inicializar IA
    async function initIA() {
        try {
            const URL_MODELS = '../face-demo/models/';
            await faceapi.nets.ssdMobilenetv1.loadFromUri(URL_MODELS);
            await faceapi.nets.faceLandmark68Net.loadFromUri(URL_MODELS);
            await faceapi.nets.faceRecognitionNet.loadFromUri(URL_MODELS);
            
            modelsLoaded = true;
            const btn = document.getElementById('btnAction');
            btn.disabled = false;
            document.getElementById('statusIA').innerHTML = "✅ IA ONLINE";
            document.getElementById('label-status').innerText = "LISTO PARA INICIAR";
            
            cargarSiguienteLote();
        } catch (e) {
            document.getElementById('statusIA').innerHTML = "❌ ERROR MODELOS";
            console.error(e);
        }
    }

    // Cargar fotos desde el servidor (Solo las que faltan)
    // Cargar fotos desde el servidor (Respetando extensión original)
    async function cargarSiguienteLote() {
        if (!isRunning && modelsLoaded) {
            document.getElementById('batch-loader').classList.remove('hidden');
        }

        try {
            const res = await fetch(`?get_pendientes=1&postulacion_id=${post_id}`);
            const fotos = await res.json();
            
            const container = document.getElementById('galeria-ia');
            document.getElementById('batch-loader').classList.add('hidden');

            if (fotos.length === 0) {
                if (document.querySelectorAll('.photo-card').length === 0) {
                    document.getElementById('finish-msg').classList.remove('hidden');
                    document.getElementById('label-status').innerText = "FINALIZADO";
                    document.getElementById('btnAction').innerHTML = "✅ TERMINADO";
                }
                return;
            }

            document.getElementById('finish-msg').classList.add('hidden');

            fotos.forEach(f => {
    const card = document.createElement('div');
    card.className = "photo-card relative bg-slate-900 rounded-2xl overflow-hidden border-2 border-slate-800 shadow-lg";
    card.id = `card-${f.id}`;
    card.innerHTML = `
        <img src="imganalisis.php?img=${encodeURIComponent(f.url)}&w=50"
             class="w-full aspect-square object-cover opacity-40 transition-opacity duration-700"
             crossorigin="anonymous"
             onload="this.style.opacity='1'">
        <div class="absolute inset-0 flex items-center justify-center">
            <div class="label-card bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-[8px] font-black text-white border border-white/10 uppercase">Pendiente</div>
        </div>
    `;
    container.appendChild(card);
});

            if (isRunning) procesarBatchActivo();
            
        } catch (e) {
            console.error("Error cargando lote:", e);
        }
    }

    async function procesarBatchActivo() {
        const pendientes = document.querySelectorAll('.photo-card');
        
        if (pendientes.length === 0) {
            await cargarSiguienteLote();
            return;
        }

        for (let card of pendientes) {
            const id = card.id.replace('card-', '');
            await analizarFoto(card, id);
        }
    }

async function analizarFoto(card, id) {
    card.classList.add('analyzing');
    const img = card.querySelector('img');
    const label = card.querySelector('.label-card');

    try {
        if (!img.complete) await new Promise(r => img.onload = r);

        label.innerText = "ESCANEANDO...";
        label.style.background = "#ea580c";

        const detections = await faceapi.detectAllFaces(img).withFaceLandmarks().withFaceDescriptors();

        for (const det of detections) {
            const fd = new FormData();
            fd.append('action', 'guardar_rostro');
            fd.append('foto_id', id);
            fd.append('descriptor', JSON.stringify(Array.from(det.descriptor)));
            await fetch(window.location.href, { method: 'POST', body: fd });
        }

        const fdLog = new FormData();
        fdLog.append('action', 'marcar_escaneada');
        fdLog.append('foto_id', id);
        await fetch(window.location.href, { method: 'POST', body: fdLog });

        label.innerText = detections.length > 0 ? `✅ ${detections.length} ROSTROS` : "❌ SIN ROSTROS";
        label.style.background = detections.length > 0 ? "#16a34a" : "#334155";

        setTimeout(() => {
            card.style.transform = "scale(0)";
            card.style.opacity = "0";
            setTimeout(() => {
                card.remove();
                if (document.querySelectorAll('.photo-card').length === 0) {
                    cargarSiguienteLote();
                }
            }, 400);
        }, 600);

    } catch (e) {
        console.error("Error en ID: " + id, e);
        label.innerText = "⚠️ ERROR";
        label.style.background = "#dc2626";
        card.classList.remove('analyzing');
    }
}

    function iniciarProceso() {
        if (!modelsLoaded || isRunning) return;
        isRunning = true;
        
        const btn = document.getElementById('btnAction');
        btn.innerHTML = "<i class='fas fa-robot fa-spin'></i> ROBOT ACTIVO";
        btn.classList.replace('bg-orange-600', 'bg-green-600');
        document.getElementById('label-status').innerText = "PROCESANDO...";
        
        procesarBatchActivo();
    }

    window.onload = initIA;
</script>

</body>
</html>