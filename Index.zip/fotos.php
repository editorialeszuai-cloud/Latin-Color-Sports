<?php
header('Content-Type: text/html; charset=utf-8');
require 'dbfotografos.php';
$pdo = conectar();

$id_foto = $_GET['id'] ?? null;
$hash_recibido = $_GET['h'] ?? null;
$ip_visitante = $_SERVER['REMOTE_ADDR'];

if (!$id_foto || !$hash_recibido) {
    die("Acceso no autorizado.");
}

// 1. VALIDACIÓN DE SEGURIDAD
$stmt_sec = $pdo->prepare("SELECT firebase_uid FROM link_security WHERE hash_link = :h AND ip_address = :ip LIMIT 1");
$stmt_sec->execute(['h' => $hash_recibido, 'ip' => $ip_visitante]);
$seguridad = $stmt_sec->fetch();

if (!$seguridad) {
    die("Error de seguridad: Este enlace es intransferible.");
}

$uid_autorizado = $seguridad['firebase_uid'];

// 2. CONSULTA DE DATOS
$stmt = $pdo->prepare("
    SELECT f.url, e.titulo AS evento_titulo, u.nombre AS fotografo_nombre
    FROM fotos f
    INNER JOIN postulaciones p ON p.id = f.postulacion_id
    INNER JOIN eventos e ON e.id = p.evento_id
    INNER JOIN usuarios u ON u.id = p.usuario_id
    WHERE f.id = :id
");
$stmt->execute(['id' => $id_foto]);
$foto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$foto) die("Foto no encontrada.");
$original_path = "" . $foto['url'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descarga Premium - Latin Color Sports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap');
        body { background: #050505; color: #eee; font-family: 'Inter', sans-serif; overflow-x: hidden; }
        .glass { background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(12px); border: 1px solid rgba(255, 255, 255, 0.05); }
        .text-gradient { background: linear-gradient(to right, #f97316, #fb923c); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        #contenido-protegido { display: none; }
        
        @keyframes reveal {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-reveal { animation: reveal 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
    </style>
</head>
<body class="min-h-screen flex flex-col">

    <div id="auth-loading" class="fixed inset-0 z-[100] bg-black flex items-center justify-center">
        <div class="text-center">
            <div class="animate-spin rounded-full h-14 w-14 border-t-2 border-orange-500 border-r-2 border-transparent mx-auto mb-6"></div>
            <p class="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500">Autenticando...</p>
        </div>
    </div>

    <div id="contenido-protegido" class="flex-1 flex flex-col">
        <nav class="sticky top-0 z-50 glass border-b border-white/5 px-6 py-4">
            <div class="max-w-5xl mx-auto flex justify-between items-center">
                <div class="flex items-center gap-4">
                    <a href="javascript:history.back()" class="p-2 hover:bg-white/10 rounded-full transition">
                        <span class="material-icons text-gray-400">arrow_back</span>
                    </a>
                    <div>
                        <h2 class="text-[9px] font-black uppercase tracking-[0.3em] text-orange-500">Latin Color Sports</h2>
                        <p class="text-xs font-bold text-white uppercase tracking-tighter italic">Descarga Segura</p>
                    </div>
                </div>
            </div>
        </nav>

        <main class="max-w-5xl mx-auto p-8 lg:p-16 w-full flex-1 flex items-center">
            <div class="grid lg:grid-cols-2 gap-16 items-center w-full">
                
                <!-- Columna Foto: Ahora más pequeña y centrada -->
                <div class="flex justify-center animate-reveal">
                    <div class="relative group w-full max-w-sm"> <!-- Control de tamaño aquí -->
                        <div class="absolute -inset-1 bg-gradient-to-r from-orange-600 to-orange-400 rounded-[2rem] blur opacity-15 group-hover:opacity-30 transition duration-700"></div>
                        <div class="relative rounded-[1.8rem] overflow-hidden border border-white/10 shadow-2xl bg-black">
                            <img src="<?= htmlspecialchars($original_path) ?>" 
                                 class="w-full h-auto block opacity-95 group-hover:scale-105 transition-all duration-700 ease-in-out" 
                                 alt="Preview">
                        </div>
                    </div>
                </div>

                <!-- Columna Info -->
                <div class="space-y-10">
                    <div class="animate-reveal" style="animation-delay: 0.2s">
                        <h1 class="text-4xl lg:text-5xl font-black text-white uppercase italic tracking-tighter leading-none mb-6">
                            ¡Qué gran <span class="text-gradient">momento</span>!
                        </h1>
                        <p class="text-gray-400 text-sm leading-relaxed border-l-2 border-orange-500/40 pl-5">
                            Tu participación en <span class="text-white font-bold"><?= htmlspecialchars($foto['evento_titulo']) ?></span> ha sido inmortalizada. Descarga tu archivo en alta resolución.
                        </p>
                    </div>

                    <div class="animate-reveal" style="animation-delay: 0.4s">
                        <a href="<?= $original_path ?>" download class="group relative inline-flex items-center gap-4 bg-orange-600 hover:bg-orange-500 text-white font-black px-10 py-5 rounded-2xl uppercase tracking-widest transition-all shadow-lg shadow-orange-900/20 active:scale-95">
                            <span class="material-icons">file_download</span>
                            Descargar Original
                        </a>
                    </div>

                    <div class="flex items-center gap-4 animate-reveal" style="animation-delay: 0.6s">
                        <div class="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
                            <span class="material-icons text-orange-500 text-sm">photo_camera</span>
                        </div>
                        <div>
                            <p class="text-[8px] text-gray-500 uppercase font-black tracking-widest">Fotógrafo</p>
                            <p class="text-xs font-bold text-gray-200 uppercase italic"><?= htmlspecialchars($foto['fotografo_nombre']) ?></p>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

<script>
const firebaseConfig = {
    apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
    authDomain: "latin-group-406b1.firebaseapp.com",
    projectId: "latin-group-406b1",
    storageBucket: "latin-group-406b1.firebasestorage.app",
    messagingSenderId: "21494348297",
    appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8"
};
firebase.initializeApp(firebaseConfig);

const uidAutorizado = "<?= $uid_autorizado ?>";

firebase.auth().onAuthStateChanged(user => {
    if (user) {
        if (user.uid === uidAutorizado) {
            document.getElementById('contenido-protegido').style.display = 'flex';
            document.getElementById('auth-loading').style.display = 'none';
        } else {
            alert("Acceso no autorizado para este usuario.");
            window.location.href = "mis_compras.html";
        }
    } else {
        window.location.href = "login_app.html";
    }
});
</script>
</body>
</html>