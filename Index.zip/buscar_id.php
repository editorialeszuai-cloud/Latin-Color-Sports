<?php
define('ACCESO_PERMITIDO', true);
require_once 'dbfotografos.php';

header('Content-Type: application/json');

$id = isset($_POST['id_foto']) ? intval($_POST['id_foto']) : 0;

if ($id > 0) {
    $stmt = $pdo->prepare("SELECT id, url FROM fotos WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['matches' => $resultado]);
} else {
    echo json_encode(['matches' => []]);
}
?>