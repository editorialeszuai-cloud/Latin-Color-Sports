<?php
header('Content-Type: application/json');
require_once "conexion.php";

$conn = conectar();

// Funci��n de respuesta r��pida
function resp($status, $message = '', $data = null){
    echo json_encode(['status'=>$status, 'message'=>$message, 'data'=>$data]);
    exit;
}

// Leer datos JSON
$input = json_decode(file_get_contents('php://input'), true);
if(!$input || !isset($input['accion'])){
    resp('error', 'No se especific�� la acci��n o el formato es incorrecto.');
}

$accion = $input['accion'];

try {
    // �9�7 Crear lugar
    if($accion === 'crear'){
        $nombre_lugar = trim($input['nombre_lugar'] ?? '');
        $direccion = trim($input['direccion'] ?? '');
        $ciudad = trim($input['ciudad'] ?? '');
        $pais = trim($input['pais'] ?? '');
        $descripcion = trim($input['descripcion'] ?? '');

        if($nombre_lugar === ''){
            resp('error','El nombre del lugar es obligatorio.');
        }

        $stmt = $conn->prepare("INSERT INTO lugares (nombre_lugar, direccion, ciudad, pais, descripcion) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nombre_lugar, $direccion, $ciudad, $pais, $descripcion);
        if(!$stmt->execute()) resp('error', 'Error BD: '.$stmt->error);

        resp('success', 'Lugar creado correctamente.');

    // �9�7 Editar lugar
    } elseif($accion === 'editar'){
        $id = intval($input['id'] ?? 0);
        $nombre_lugar = trim($input['nombre_lugar'] ?? '');
        $direccion = trim($input['direccion'] ?? '');
        $ciudad = trim($input['ciudad'] ?? '');
        $pais = trim($input['pais'] ?? '');
        $descripcion = trim($input['descripcion'] ?? '');

        if($id <= 0) resp('error', 'ID inv��lido.');
        if($nombre_lugar === '') resp('error', 'El nombre del lugar es obligatorio.');

        $stmt = $conn->prepare("UPDATE lugares SET nombre_lugar=?, direccion=?, ciudad=?, pais=?, descripcion=? WHERE id=?");
        $stmt->bind_param("sssssi", $nombre_lugar, $direccion, $ciudad, $pais, $descripcion, $id);
        if(!$stmt->execute()) resp('error', 'Error BD: '.$stmt->error);

        resp('success', 'Lugar actualizado correctamente.');

    // �9�7 Eliminar lugar
    } elseif($accion === 'eliminar'){
        $id = intval($input['id'] ?? 0);
        if($id <= 0) resp('error','ID no v��lido.');

        $stmt = $conn->prepare("DELETE FROM lugares WHERE id=?");
        $stmt->bind_param("i", $id);
        if(!$stmt->execute()) resp('error','Error BD: '.$stmt->error);

        resp('success','Lugar eliminado correctamente.');

    // �9�7 Listar lugares
    } elseif($accion === 'listar'){
        $result = $conn->query("SELECT * FROM lugares ORDER BY id DESC");
        $lugares = [];
        while($row = $result->fetch_assoc()) $lugares[] = $row;
        resp('success','Lugares obtenidos',$lugares);

    } else {
        resp('error','Acci��n desconocida.');
    }

} catch(Exception $e){
    resp('error','Error en la operaci��n: '.$e->getMessage());
}
?>
