<?php
require 'dbfotografos.php';
header('Content-Type: application/json');
$pdo = conectar();

$data = json_decode(file_get_contents('php://input'), true);
$uid = $data['firebase_uid'] ?? null;

if (!$uid) {
    echo json_encode(['success' => false, 'fotos' => [], 'message' => 'UID no proporcionado']);
    exit;
}

$secret_key = "LAtinSportSCoLOrs2026";
$ip_cliente = $_SERVER['REMOTE_ADDR']; // Capturamos la IP del usuario actual

try {
    $sql = "
        SELECT 
            f.id AS foto_id,
            f.url AS nombre_archivo,
            e.titulo AS evento_titulo,
            c.id AS compra_id,
            'individual' as tipo
        FROM fotos f
        INNER JOIN detalle_compras dc ON dc.id_foto = f.id
        INNER JOIN compras c ON c.id = dc.id_compra
        INNER JOIN postulaciones p ON p.id = f.postulacion_id
        INNER JOIN eventos e ON e.id = p.evento_id
        WHERE c.firebase_uid = :uid
          AND c.estado = 'APPROVED'
        ORDER BY c.id DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute(['uid' => $uid]);
    
    $fotos_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $fotos_finales = [];

    // Preparamos la consulta de inserción en link_security para usarla dentro del loop
    // Usamos ON DUPLICATE KEY UPDATE por si el usuario recarga la galería, actualizar su IP
    $stmt_sec = $pdo->prepare("
        INSERT INTO link_security (hash_link, firebase_uid, ip_address) 
        VALUES (:hash, :uid, :ip)
        ON DUPLICATE KEY UPDATE ip_address = :ip
    ");

    foreach ($fotos_raw as $fila) {
        // 1. Generamos el Hash ÚNICO combinando Foto ID + UID del cliente
        $hash = hash_hmac('sha256', $fila['foto_id'] . $uid, $secret_key);
        $fila['hash'] = $hash;

        // 2. REGISTRAMOS EL LINK EN LA TABLA DE SEGURIDAD
        // Esto es lo que fotos.php consultará después
        $stmt_sec->execute([
            'hash' => $hash,
            'uid'  => $uid,
            'ip'   => $ip_cliente
        ]);
        
        $fotos_finales[] = $fila;
    }

    echo json_encode([
        'success' => true, 
        'fotos' => $fotos_finales,
        'debug_ip' => $ip_cliente // Opcional: para que sepas qué IP está registrando
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => $e->getMessage()
    ]);
}
?>