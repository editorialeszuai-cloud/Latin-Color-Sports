<?php
// minion.php - Versión Protegida (Proxy)

$urlOriginal = $_GET['img'] ?? '';
$urlFinal = urldecode($urlOriginal);

// 1. Transformar a URL de CloudFront
$urlCloudFront = str_replace(
    "fotos-latincolor-2026.s3-accelerate.amazonaws.com", 
    "d3fnhkeilwwjkl.cloudfront.net", 
    $urlFinal
);

// 2. Obtener el ancho (si no viene, 800)
$width = isset($_GET['w']) ? intval($_GET['w']) : 800;

// 3. Obtener la imagen directamente desde el servidor (No redirigir)
// Esto descarga la imagen internamente en tu servidor y la pasa al usuario
$context = stream_context_create(['http' => ['header' => 'User-Agent: LatinColorServer']]);
$foto = @imagecreatefromjpeg($urlCloudFront . "?w=" . $width);

if (!$foto) {
    // Si falla, al menos redirigir a una imagen de error o original
    header("Location: " . $urlCloudFront);
    exit;
}

// 4. Aplicar Marca de Agua Obligatoria
$marca = @imagecreatefrompng('uploads/watermark.png');
if ($marca) {
    // Pegar marca de agua
    imagecopy($foto, $marca, 10, 10, 0, 0, imagesx($marca), imagesy($marca));
}

// 5. Servir la imagen final (El usuario nunca ve la URL de CloudFront)
header('Content-Type: image/jpeg');
imagejpeg($foto, null, 80);

imagedestroy($foto);
if ($marca) imagedestroy($marca);
exit;
?>