<?php
require 'vendor/autoload.php';

use Kreait\Firebase\Factory;
use Kreait\Firebase\Auth;

$factory = (new Factory)
    ->withServiceAccount(__DIR__.'/firebase_credentials.json');

$auth = $factory->createAuth();
