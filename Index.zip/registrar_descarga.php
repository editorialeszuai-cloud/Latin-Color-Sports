<?php
session_start();
require 'dbfotografos.php';
$pdo = conectar();

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $data['firebase_uid'] ?? null;
$foto_id = $data['foto_id'] ?? 0;
$tipo = $data['tipo'] ?? '';
$compra_id = $data['compra_id'] ?? null;

if (!$firebase_uid || $foto_id <= 0 || !in_array($tipo,['alta','baja']) || !$compra_id) {
    echo json_encode(['status'=>'error','msg'=>'Datos inválidos']); 
    exit;
}

$stmt = $pdo->prepare("
    INSERT INTO descargas (firebase_uid, foto_id, tipo_descarga, compra_id, fecha) 
    VALUES (?, ?, ?, ?, NOW())
");
if ($stmt->execute([$firebase_uid, $foto_id, $tipo, $compra_id])) {
    echo json_encode(['status'=>'ok']);
} else {
    echo json_encode(['status'=>'error','msg'=>'No se pudo registrar descarga']);
}
?>
