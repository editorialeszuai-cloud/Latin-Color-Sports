<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/vendor/autoload.php';
require_once "dbagregar.php";

use Kreait\Firebase\Factory;
use Kreait\Firebase\Exception\AuthException;
use Kreait\Firebase\Exception\FirebaseException;

$conn = conectar();

$uploadDir = __DIR__ . "/uploads/";
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    // Ruta al archivo de credenciales Firebase
    $serviceAccountPath = __DIR__ . '/config/latin-group-406b1-firebase-adminsdk-fbsvc-a4a2cfb821.json';
    if (!file_exists($serviceAccountPath)) {
        die("�7�4 Archivo de credenciales Firebase no encontrado: $serviceAccountPath");
    }

    $factory = (new Factory())->withServiceAccount($serviceAccountPath);
    $auth = $factory->createAuth();

    switch ($accion) {
        /* ==========================================================
           �0�8 AGREGAR USUARIO
        ========================================================== */
        case 'agregar':
            $nombre = trim($_POST['nombre'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $rol = trim($_POST['rol'] ?? '');
            $password = $_POST['password'] ?? '12345678';
            $foto_url = 'uploads/perfil.jpg'; // �9�6 Imagen por defecto

            if (empty($nombre) || empty($email) || empty($rol)) {
                die("�7�2�1�5 Faltan campos obligatorios");
            }

            // �9�2 Subir foto personalizada (si se env��a)
            if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] === UPLOAD_ERR_OK) {
                $nombreArchivo = uniqid() . "_" . basename($_FILES['foto_perfil']['name']);
                $rutaDestino = $uploadDir . $nombreArchivo;
                $rutaRelativa = "uploads/" . $nombreArchivo;

                if (move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $rutaDestino)) {
                    $foto_url = $rutaRelativa;
                }
            }

            try {
                // �0�7 Crear usuario en Firebase
                $userRecord = $auth->createUser([
                    'email' => $email,
                    'emailVerified' => false,
                    'password' => $password,
                    'displayName' => $nombre,
                    'photoUrl' => (($_SERVER['REQUEST_SCHEME'] ?? 'https') . '://' . $_SERVER['HTTP_HOST'] . '/' . $foto_url),
                    'disabled' => false,
                ]);

                $firebase_uid = $userRecord->uid;

                // �9�6�1�5 Insertar en MySQL
                $stmt = $conn->prepare("INSERT INTO usuarios 
                    (firebase_uid, email, nombre, foto_perfil, rol, fecha_registro, ultima_sesion, estado)
                    VALUES (?, ?, ?, ?, ?, NOW(), NOW(), 'activo')");
                $stmt->bind_param("sssss", $firebase_uid, $email, $nombre, $foto_url, $rol);

                if (!$stmt->execute()) {
                    throw new Exception("MySQL Error: " . $stmt->error);
                }

                header("Location: usuarios.php");
                exit;

            } catch (AuthException | FirebaseException $e) {
                echo "<h3 style='color:red;'>�7�4 Error al crear usuario en Firebase:</h3>";
                echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
                exit;

            } catch (Exception $e) {
                echo "<h3 style='color:red;'>�7�4 Error al agregar el usuario:</h3>";
                echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
                exit;
            }
            break;

        /* ==========================================================
           �9�2 ELIMINAR USUARIO
        ========================================================== */
        case 'eliminar':
            $id = (int)$_POST['id'];
            $query = $conn->prepare("SELECT firebase_uid, foto_perfil FROM usuarios WHERE id = ?");
            $query->bind_param("i", $id);
            $query->execute();
            $query->bind_result($firebase_uid, $foto);
            $query->fetch();
            $query->close();

            // �0�3 Eliminar foto (si no es la por defecto)
            if (!empty($foto) && $foto !== 'uploads/perfil.jpg' && file_exists(__DIR__ . "/" . $foto)) {
                unlink(__DIR__ . "/" . $foto);
            }

            // �0�7 Eliminar de Firebase
            if (!empty($firebase_uid)) {
                try {
                    $auth->deleteUser($firebase_uid);
                } catch (Exception $e) {
                    error_log("Error eliminando usuario Firebase UID=$firebase_uid: " . $e->getMessage());
                }
            }

            // �9�6�1�5 Eliminar de MySQL
            $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();

            header("Location: usuarios.php");
            exit;
            break;

        /* ==========================================================
           �0�7 ACTIVAR / DESACTIVAR USUARIO
        ========================================================== */
        case 'toggle_estado':
            $id = (int)$_POST['id'];
            $estado_actual = $_POST['estado_actual'] ?? 'activo';
            $nuevo_estado = ($estado_actual === 'activo') ? 'inactivo' : 'activo';

            $stmt = $conn->prepare("UPDATE usuarios SET estado = ? WHERE id = ?");
            $stmt->bind_param("si", $nuevo_estado, $id);
            $stmt->execute();

            header("Location: usuarios.php");
            exit;
            break;

        /* ==========================================================
           �0�7 ACCI�0�7N DESCONOCIDA
        ========================================================== */
        default:
            die("�7�4 Acci��n no reconocida.");
    }
}
?>
