<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<style>
  /* Quitar márgenes/padding del body y html */
  html, body {
    margin: 0;
    padding: 0;
  }

  header {
    background: #0b1220;
    color: white;
    padding: 1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 50;
    width: 100%; /* Ocupa todo el ancho */
  }

  header nav a {
    color: white;
    text-decoration: none;
    padding: 0.5rem 0.75rem;
    border-radius: 6px;
    transition: background 0.2s;
    font-size: 14px;
  }

  header nav a:hover {
    background: rgba(255,255,255,0.1);
  }

  header .logo {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  header .logo img {
    width: 40px;
    height: 40px;
    border-radius: 6px;
  }

  header .logo span {
    font-weight: 600;
    font-size: 16px;
  }
</style>
</head>
<body>

<header>
  <!-- Logo / marca -->
  <div class="logo">
    <img src="uploads/LATIN-SPORTS.png" alt="Logo">
    <span>Latin Color Sports</span>
  </div>

  <!-- Menú principal -->
  <nav>
    <a href="menu.php">Home</a>
    <a href="eventos.php">Eventos</a>
    <a href="usuarios.php">Usuarios</a>
    <a href="sedes.php">Sedes</a>
    <a href="disciplinas.html">Disciplinas</a>
  </nav>
</header>

</body>
</html>
