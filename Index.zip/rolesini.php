<?php
// =====================================
// rolesini.php
// =====================================

// --- Configuración de cabeceras CORS ---
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Authorization, Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Content-Type: application/json; charset=UTF-8");

// --- Permitir solicitudes OPTIONS (preflight) ---
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- Mostrar errores en entorno local (debug) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- Cargar dependencias ---
require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;
use Firebase\Auth\Token\Exception\InvalidToken;

// --- Leer encabezado Authorization (fix para XAMPP) ---
if (!isset($_SERVER['HTTP_AUTHORIZATION'])) {
    if (function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
        if (isset($headers['Authorization'])) {
            $_SERVER['HTTP_AUTHORIZATION'] = $headers['Authorization'];
        }
    }
}

try {
    // --- Verificar que se haya enviado el encabezado ---
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$authHeader) {
        throw new Exception("Encabezado Authorization no encontrado.");
    }

    // --- Extraer token sin el prefijo 'Bearer ' ---
    $idToken = str_replace('Bearer ', '', $authHeader);

    // --- Inicializar Firebase Auth ---
    $factory = (new Factory)->withServiceAccount(__DIR__ . '/firebase-service-account.json');
    $auth = $factory->createAuth();

    // --- Verificar token ---
    $verifiedIdToken = $auth->verifyIdToken($idToken);

    // --- Obtener UID y datos del usuario ---
    $uid = $verifiedIdToken->claims()->get('sub');
    $firebaseUser = $auth->getUser($uid);

    // --- Leer cuerpo JSON enviado desde el frontend ---
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        throw new Exception("No se recibieron datos válidos en el cuerpo de la solicitud.");
    }

    $role = $input['role'] ?? 'cliente';
    $nombre = $input['nombre'] ?? $firebaseUser->displayName ?? 'Sin nombre';

    // Aquí podrías insertar o actualizar datos en tu base de datos si quieres
    // Por ahora, solo devolvemos confirmación

    echo json_encode([
        'status' => 'success',
        'message' => "Usuario '{$nombre}' (UID: {$uid}) con rol '{$role}' procesado correctamente.",
        'email' => $firebaseUser->email,
        'role' => $role
    ]);
    exit;

} catch (InvalidToken $e) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Token inválido o expirado.']);
    exit;
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    exit;
}
