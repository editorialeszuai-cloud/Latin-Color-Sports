<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patrocinadores y Marca - LatinColorSports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            --red-latin: #ed1c24;
            --orange-latin: #f7941d;
            --yellow-latin: #ffc72c;
            --dark-gray: #1e1e1e;
            --white: #ffffff;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            color: #222;
            background-image: url('../imagenes/fondosecundario.png'); 
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            overflow-x: hidden;
        }

        /* --- WHATSAPP --- */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 30px;
            right: 30px;
            background-color: #25d366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            z-index: 9999;
            animation: pulse-whatsapp 2s infinite;
        }
        .whatsapp-float img { width: 35px; height: 35px; }
        
        @keyframes pulse-whatsapp {
            0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(37, 211, 102, 0); }
            100% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
        }

        /* --- OVERLAY --- */
        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(4px);
            visibility: hidden;
            opacity: 0;
            transition: 0.4s;
            z-index: 4000;
        }
        .menu-overlay.active { visibility: visible; opacity: 1; }

        /* --- HEADER UNIFICADO --- */
        .header-lcs {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f56c1e 60%, #e4312a 100%);
            border-top: 6px solid white;
            border-bottom: 6px solid white;
            height: 75px;
            position: sticky;
            top: 0;
            z-index: 5000;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .logo-lcs a { display: flex; align-items: center; text-decoration: none; }
        .logo-lcs img { height: 35px; width: auto; }

        .right-side { display: flex; align-items: center; gap: 15px; }

        .nav-links { display: flex; align-items: center; gap: 15px; }
        .nav-links a {
            text-decoration: none;
            color: white;
            font-weight: 800;
            font-size: 11px;
            text-transform: uppercase;
        }

        .btn-login-lcs {
            background-color: var(--yellow-latin) !important;
            color: #000 !important;
            padding: 8px 12px !important;
            border-radius: 4px;
            transform: skewX(-12deg);
            display: inline-block;
        }
        .btn-login-lcs span { display: inline-block; transform: skewX(12deg); font-weight: 900; }

        .hamburger {
            display: none;
            cursor: pointer;
            flex-direction: column;
            gap: 5px;
            width: 30px;
            z-index: 5100;
        }
        .hamburger span {
            display: block;
            width: 100%;
            height: 3px;
            background-color: white;
            border-radius: 2px;
            transition: 0.4s;
        }

        @media (max-width: 1100px) {
            .nav-links {
                position: fixed;
                top: 0;
                left: -100%;
                width: 280px;
                height: 100vh;
                background: var(--red-latin);
                flex-direction: column;
                justify-content: flex-start;
                align-items: flex-start;
                padding: 100px 0 0 40px;
                gap: 25px;
                transition: 0.5s cubic-bezier(0.7, 0, 0.3, 1);
                z-index: 4500;
            }
            .nav-links.active { left: 0; }
            .nav-links a { font-size: 1.2rem; }
            .hamburger { display: flex; }
            
            .hamburger.open span:nth-child(1) { transform: translateY(8px) rotate(45deg); }
            .hamburger.open span:nth-child(2) { opacity: 0; }
            .hamburger.open span:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }
        }

        /* --- SECCIÓN HERO & CONTENIDO --- */
        .hero {
            text-align: center;
            padding: 60px 20px;
        }
        .hero h1 {
            color: #000;
            font-weight: 900;
            background-color: var(--yellow-latin);
            display: inline-block;
            padding: 10px 30px;
            border-radius: 5px;
            text-transform: uppercase;
        }
        .button-orange {
            background-color: #ff6600;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            padding: 20px 40px;
            border-radius: 10px;
            margin-top: 25px;
            cursor: pointer;
            border: none;
            box-shadow: 0 4px 15px rgba(255, 102, 0, 0.3);
            transition: 0.3s;
        }
        .button-orange:hover { transform: translateY(-3px); }

        .sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .card {
            background: #fff;
            border-radius: 15px;
            padding: 30px;
            font-weight: 700;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card.yellow { border-top: 8px solid var(--yellow-latin); }
        .card li { text-align: left; list-style: none; margin-bottom: 10px; }
        .card li::before { content: '\2713'; color: var(--orange-latin); margin-right: 10px; font-weight: 900; }

        /* --- SECCIÓN PARTNER (CAFÉ) --- */
        .seccion-partner {
            background: rgba(245, 245, 245, 0.95);
            padding: 60px 40px;
            position: relative;
            max-width: 1000px;
            margin: 60px auto;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .partner-container { display: flex; justify-content: space-between; gap: 40px; }
        .partner-left { width: 45%; font-size: 1.2rem; line-height: 1.5; margin-top: 20px; }
        .partner-divider { width: 4px; background: var(--yellow-latin); border-radius: 2px; }
        .partner-right { width: 45%; font-size: 1.1rem; }
        .partner-right h2 { color: var(--red-latin); font-weight: 900; margin-top: 0; }

        .partner-bottom {
            margin-top: 40px;
            border-top: 4px solid #e85c00;
            padding-top: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .partner-cafe { font-size: 1.8rem; font-weight: 900; }
        .partner-info { font-size: 1.1rem; font-weight: 600; line-height: 1.4; color: #444; }

        footer { background: #222; color: #fff; text-align: center; padding: 25px; margin-top: 50px; }

        @media (max-width: 900px) {
            .partner-container { flex-direction: column; }
            .partner-left, .partner-right { width: 100%; }
            .partner-divider { display: none; }
            .partner-bottom { flex-direction: column; text-align: center; gap: 20px; }
        }
    </style>
</head>
<body>

    <div class="menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>
    
    <a href="https://wa.me/573142958463" class="whatsapp-float" target="_blank">
        <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp" />
    </a>

    <header class="header-lcs">
        <div class="logo-lcs">
            <a href="index.php">
               <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;height:auto;">
                <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="margin-left: 5px;width:85px;height:auto;">
            </a>
        </div>

        <div class="right-side">
            <nav class="nav-links" id="navLinks">
                <a href="conjuntodeventos.php">EVENTOS</a>
                <a href="soyorganizador.php">ORGANIZADOR</a>
                <a href="soyfotografo.php">FOTÓGRAFO</a>
                <a href="soydeportista.php">DEPORTISTA</a>
                <a href="soypatrocinador.php">PATROCINADORES</a>
                <a href="marcas.php">ESCUELA</a>
                <a href="login_app.html" class="btn-login-lcs"><span>INICIAR SESIÓN</span></a>
            </nav>

            <div class="idiomas">
                <img src="imagenes/idioma-02.webp" width="22px" alt="ES" style="cursor:pointer;">
            </div>

            <div class="hamburger" id="hamburger" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </header>

    <section class="hero">
        <h1>Patrocinadores y Marca</h1>
        <p style="font-size: 1.3rem; font-weight: 600; max-width: 850px; margin: 20px auto;">Plataforma especializada en la comercialización de fotografías y videos de eventos deportivos del ciclo olímpico y paralímpico</p>
        <button class="button-orange">
            Asocia <strong>tu marca</strong> a la emoción del deporte real.<br>
            <strong>Tu marca en el corazón</strong> del deporte con propósito
        </button>
    </section>

    <section class="seccion-aliados" style="text-align: center; padding: 40px 20px;">
        <p style="font-size: 1.1rem; color: #555;">Visibilidad auténtica y participación emocional con los atletas y fanáticos.</p>
        <p style="font-size: 1.4rem; font-weight: 700; color: var(--red-latin); margin: 15px 0;">“Conecta tu marca con la emoción del deporte y con inclusión real.”</p>
        <h2 style="font-size: 2.5rem; font-weight: 900; font-style: italic; text-transform: uppercase;">¿POR QUÉ SER ALIADOS?</h2>
    </section>

    <section class="sections">
        <div class="card yellow">
            <ul>
                <li>Presencia visual en galerías y coberturas con impacto sostenible.</li>
                <li>Informe mensual de exposición digital.</li>
            </ul>
        </div>
        <div class="card yellow">
            <p>Atletas y paratletas como embajadores de marca auténticos.</p>
        </div>
        <div class="card yellow">
            <ul>
                <li>Participación en marca personal de deportistas.</li>
                <li>Asociamos tu marca a proyectos con atletas y paratletas.</li>
            </ul>
        </div>
    </section>

    <section class="seccion-partner">
        <div class="partner-container">
            <div class="partner-left">
                Conecta tu marca con la emoción, el esfuerzo y la inspiración del deporte latinoamericano.<br><br>
                <strong style="color: var(--orange-latin); font-size: 1.4rem;">“Tu marca visible donde más importa: en la inclusión.”</strong>
            </div>
            <div class="partner-divider"></div>
            <div class="partner-right">
                <h2>Brand Partner Oficial LatinColorSports</h2>
                <p><strong>Marca inclusiva, impacto real.</strong></p>
                <p>Incluye acceso total a todos los eventos del año + posicionamiento global en nuestras plataformas.</p>
            </div>
        </div>

        <div class="partner-bottom">
            <div class="partner-cafe">Tomémonos un café:</div>
            <div class="partner-info">
                Carolina Arévalo Rodríguez<br>
                CEO LatinColorSports<br>
                +57 314 2958463
            </div>
            <div style="width: 140px;">
                <img src="../uploads/LATIN-SPORTS.png" alt="LatinColor Sports" style="width: 100%;">
            </div>
        </div>
    </section>

    <footer>
        © 2026 LatinColorSports. Todos los derechos reservados.
    </footer>

    <script>
        function toggleMenu() {
            const nav = document.getElementById('navLinks');
            const burger = document.getElementById('hamburger');
            const overlay = document.getElementById('menuOverlay');
            const isOpen = nav.classList.toggle('active');
            burger.classList.toggle('open');
            overlay.classList.toggle('active');
            document.body.style.overflow = isOpen ? 'hidden' : 'auto';
        }
    </script>
</body>
</html>