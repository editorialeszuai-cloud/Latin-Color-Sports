<?php
require 'dbfotografos.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$firebase_uid = $data['firebase_uid'] ?? null;

if(!$firebase_uid){
    echo json_encode(['success'=>false,'message'=>'Usuario no válido']); exit;
}

// Obtener fotos de la galería del usuario
$stmt = $pdo->prepare("
    SELECT f.id AS foto_id, f.url AS nombre_archivo, f.fecha_creacion, e.titulo AS evento_titulo
    FROM mi_galeria mg
    INNER JOIN fotos f ON mg.foto_id = f.id
    INNER JOIN postulaciones p ON f.postulacion_id = p.id
    INNER JOIN eventos e ON p.evento_id = e.id
    WHERE mg.firebase_uid = ?
    ORDER BY mg.id DESC
");
$stmt->execute([$firebase_uid]);
$fotos = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['success'=>true, 'fotos'=>$fotos]);
