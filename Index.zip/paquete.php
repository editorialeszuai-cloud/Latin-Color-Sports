<?php require 'menuadmin.php'; ?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Paquetes de Fotos</title>
<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
<style>
body { font-family: Arial, sans-serif; background:#f4f4f4; margin:0; padding:0;}
h1{text-align:center;color:#333;}
form{background:#fff;padding:20px;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,0.1);margin-bottom:30px;max-width:500px;margin:auto;}
label{display:block;margin-top:10px;color:#555;}
input, textarea{width:100%;padding:8px;margin-top:4px;border:1px solid #ccc;border-radius:5px;}
button{margin-top:15px;padding:10px 15px;border:none;border-radius:5px;background:orange;color:#fff;cursor:pointer;}
button:hover{background:#0056b3;}
table{width:90%;border-collapse:collapse;margin:20px auto;background:#fff;}
th, td{border:1px solid #ccc;padding:8px;text-align:left;}
th{background:orange;color:white;}
.acciones button{margin-right:5px;padding:5px 8px;border:none;border-radius:5px;cursor:pointer;}
.editar{background:#ffc107;color:#000;}
.eliminar{background:#dc3545;color:#fff;}
</style>
</head>
<body>

<h1>Gestión de Paquetes de Fotos</h1>

<form id="formPaquete">
<input type="hidden" id="idPaquete">
<label>Nombre del Paquete</label>
<input type="text" id="nombre_paquete" required>

<label>Descripción</label>
<textarea id="descripcion" rows="3"></textarea>

<label>Precio por Unidad</label>
<input type="number" id="precio_por_unidad" step="0.01" required>

<label>Unidades Incluidas</label>
<input type="number" id="unidades_incluidas" required>

<button type="submit">Guardar Paquete</button>
<button type="button" id="btnCancelar" style="background:#6c757d;display:none;">Cancelar</button>
</form>

<table id="tablaPaquetes">
<thead>
<tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Unidades</th><th>Acciones</th></tr>
</thead>
<tbody></tbody>
</table>

<script>
const form = document.getElementById('formPaquete');
const btnCancelar = document.getElementById('btnCancelar');
const tabla = document.querySelector('#tablaPaquetes tbody');

const limpiarFormulario = () => {
    form.reset();
    document.getElementById('idPaquete').value = '';
    btnCancelar.style.display = 'none';
    form.querySelector('button[type="submit"]').textContent = 'Guardar Paquete';
};

const cargarPaquetes = async () => {
    try {
        const res = await fetch('paquetes.php', {
            method: 'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({accion:'listar'})
        });
        const data = await res.json();
        tabla.innerHTML = '';
        if(data.status === 'success'){
            data.data.forEach(p => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${p.id}</td>
                    <td>${p.nombre_paquete}</td>
                    <td>${parseFloat(p.precio_por_unidad).toFixed(2)}</td>
                    <td>${p.unidades_incluidas}</td>
                    <td class="acciones">
                        <button class="editar" onclick='editarPaquete(${JSON.stringify(p)})'>Editar</button>
                        <button class="eliminar" onclick="eliminarPaquete(${p.id})">Eliminar</button>
                    </td>
                `;
                tabla.appendChild(tr);
            });
        } else {
            alert(data.message);
        }
    } catch(err) {
        console.error(err);
        alert('Error cargando paquetes.');
    }
};

form.addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('idPaquete').value;
    const datos = {
        accion: id ? 'editar' : 'crear',
        id: id,
        nombre_paquete: document.getElementById('nombre_paquete').value,
        descripcion: document.getElementById('descripcion').value,
        precio_por_unidad: document.getElementById('precio_por_unidad').value,
        unidades_incluidas: document.getElementById('unidades_incluidas').value
    };
    try {
        const res = await fetch('paquetes.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify(datos)
        });
        const data = await res.json();
        alert(data.message);
        if(data.status==='success'){ limpiarFormulario(); cargarPaquetes(); }
    } catch(err){
        console.error(err);
        alert('Error guardando paquete.');
    }
});

const editarPaquete = p => {
    document.getElementById('idPaquete').value = p.id;
    document.getElementById('nombre_paquete').value = p.nombre_paquete;
    document.getElementById('descripcion').value = p.descripcion;
    document.getElementById('precio_por_unidad').value = p.precio_por_unidad;
    document.getElementById('unidades_incluidas').value = p.unidades_incluidas;
    form.querySelector('button[type="submit"]').textContent = 'Actualizar Paquete';
    btnCancelar.style.display = 'inline-block';
};

const eliminarPaquete = async id => {
    if(!confirm('¿Seguro que deseas eliminar este paquete?')) return;
    try {
        const res = await fetch('paquetes.php',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({accion:'eliminar',id})
        });
        const data = await res.json();
        alert(data.message);
        if(data.status==='success') cargarPaquetes();
    } catch(err){
        console.error(err);
        alert('Error eliminando paquete.');
    }
};

btnCancelar.addEventListener('click', limpiarFormulario);
document.addEventListener('DOMContentLoaded', cargarPaquetes);
</script>

</body>
</html>
