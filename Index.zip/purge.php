<?php
if (function_exists('litespeed_purge_all')) {
    litespeed_purge_all();
}
echo "Cache de LiteSpeed purgada";
?>
