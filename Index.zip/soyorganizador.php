<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizador de Eventos - LatinColorSports</title>
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root {
            --red-latin: #ed1c24;
            --orange-latin: #f7941d;
            --yellow-latin: #ffc72c;
            --dark-gray: #1e1e1e;
            --white: #ffffff;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('imagenes/foto + textura_Mesa de trabajo 1.webp');
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
            color: #333;
            overflow-x: hidden;
        }

        /* --- WHATSAPP --- */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 30px;
            right: 30px;
            background-color: #25d366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
            z-index: 9999;
            animation: pulse-whatsapp 2s infinite;
        }
        .whatsapp-float img { width: 35px; height: 35px; }
        
        @keyframes pulse-whatsapp {
            0% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0.7); }
            70% { box-shadow: 0 0 0 15px rgba(37, 211, 102, 0); }
            100% { box-shadow: 0 0 0 0 rgba(37, 211, 102, 0); }
        }

        /* --- OVERLAY --- */
        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(4px);
            visibility: hidden;
            opacity: 0;
            transition: 0.4s;
            z-index: 4000;
        }
        .menu-overlay.active { visibility: visible; opacity: 1; }

        /* --- HEADER UNIFICADO --- */
        .header-lcs {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 15px;
            background: linear-gradient(90deg, #ffffff 0%, #ffffff 15%, #f8a700 20%, #f56c1e 60%, #e4312a 100%);
            border-top: 6px solid white;
            border-bottom: 6px solid white;
            height: 75px;
            position: sticky;
            top: 0;
            z-index: 5000;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .logo-lcs a { display: flex; align-items: center; text-decoration: none; }
        .logo-lcs img { height: 35px; width: auto; }

        .right-side { display: flex; align-items: center; gap: 15px; }

        .nav-links { display: flex; align-items: center; gap: 15px; }
        .nav-links a {
            text-decoration: none;
            color: white;
            font-weight: 800;
            font-size: 11px;
            text-transform: uppercase;
        }

        .btn-login-lcs {
            background-color: var(--yellow-latin) !important;
            color: #000 !important;
            padding: 8px 12px !important;
            border-radius: 4px;
            transform: skewX(-12deg);
            display: inline-block;
        }
        .btn-login-lcs span { display: inline-block; transform: skewX(12deg); font-weight: 900; }

        .hamburger {
            display: none;
            cursor: pointer;
            flex-direction: column;
            gap: 5px;
            width: 30px;
            z-index: 5100;
        }
        .hamburger span {
            display: block;
            width: 100%;
            height: 3px;
            background-color: white;
            border-radius: 2px;
            transition: 0.4s;
        }

        @media (max-width: 1100px) {
            .nav-links {
                position: fixed;
                top: 0;
                left: -100%;
                width: 280px;
                height: 100vh;
                background: var(--red-latin);
                flex-direction: column;
                justify-content: flex-start;
                align-items: flex-start;
                padding: 100px 0 0 40px;
                gap: 25px;
                transition: 0.5s cubic-bezier(0.7, 0, 0.3, 1);
                z-index: 4500;
            }
            .nav-links.active { left: 0; }
            .nav-links a { font-size: 1.2rem; }
            .hamburger { display: flex; }
            
            .hamburger.open span:nth-child(1) { transform: translateY(8px) rotate(45deg); }
            .hamburger.open span:nth-child(2) { opacity: 0; }
            .hamburger.open span:nth-child(3) { transform: translateY(-8px) rotate(-45deg); }
        }

        /* --- CONTENIDO ORGANIZADOR --- */
        .page-content-wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .hero-section { text-align: center; margin-bottom: 50px; }
        .main-heading {
            font-size: 3rem;
            font-weight: 900;
            color: var(--orange-latin);
            text-transform: uppercase;
            margin-bottom: 15px;
        }
        .main-heading span { color: #000; }

        .sub-heading {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto 30px;
            font-weight: 600;
        }

        .key-statement-box {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 25px;
            border-radius: 15px;
            max-width: 900px;
            margin: 0 auto;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            font-size: 1.1rem;
        }

        /* --- BENEFICIOS --- */
        .section-title-question {
            text-align: center;
            font-weight: 900;
            color: var(--orange-latin);
            margin: 60px 0 40px;
            font-size: 2rem;
        }

        .benefits-grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .benefit-column {
            background-color: rgba(30, 30, 30, 0.9);
            padding: 30px;
            border-radius: 15px;
            border: 1px solid #444;
        }

        .benefit-item { display: flex; gap: 12px; margin-bottom: 20px; color: #ccc; }
        .benefit-item i { color: var(--orange-latin); font-size: 1.2rem; }
        .benefit-item strong { color: #fff; }

        /* --- FEATURES BOXES --- */
        .features-cta-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 60px;
        }

        .feature-box { padding: 30px; border-radius: 15px; color: #fff; }
        .orange-bg-box { background-color: var(--orange-latin); }
        .yellow-bg-box { background-color: var(--yellow-latin); color: #222; }

        .demo-box {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .demo-visual-placeholder {
            height: 200px;
            background: url('imagenes/reconocimiento.webp') center/cover;
            border-radius: 10px;
            margin: 15px 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .start-demo-btn, .register-event-btn {
            background: var(--orange-latin);
            color: #fff;
            border: none;
            padding: 12px 35px;
            border-radius: 30px;
            font-weight: 800;
            text-transform: uppercase;
            cursor: pointer;
            transition: 0.3s;
        }

        .final-cta-section { text-align: center; padding: 60px 0; }
        .final-cta-section h3 { font-size: 2rem; font-weight: 800; margin-bottom: 30px; font-style: italic; }

        footer { background: #222; color: #fff; text-align: center; padding: 25px; margin-top: 50px; }

        @media (max-width: 768px) {
            .main-heading { font-size: 2rem; }
            .features-cta-section { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <div class="menu-overlay" id="menuOverlay" onclick="toggleMenu()"></div>
    
    <a href="https://wa.me/573142958463" class="whatsapp-float" target="_blank">
        <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp" />
    </a>

    <header class="header-lcs">
        <div class="logo-lcs">
            <a href="index.php">
                <img src="../imagenes/LATINCOLOR.png" alt="Logo 1" style="width:85px;height:auto;">
                <img src="../uploads/LATIN-SPORTS.png" alt="Logo 2" style="margin-left: 5px;width:85px;height:auto;">
            </a>
        </div>

        <div class="right-side">
            <nav class="nav-links" id="navLinks">
                <a href="conjuntodeventos.php">EVENTOS</a>
                <a href="soyorganizador.php">ORGANIZADOR</a>
                <a href="soyfotografo.php">FOTÓGRAFO</a>
                <a href="soydeportista.php">DEPORTISTA</a>
                <a href="soypatrocinador.php">PATROCINADORES</a>
                <a href="marcas.php">ESCUELA</a>
                <a href="login_app.html" class="btn-login-lcs"><span>INICIAR SESIÓN</span></a>
            </nav>

            <div class="idiomas">
                <img src="imagenes/idioma-02.webp" width="22px" alt="ES" style="cursor:pointer;">
            </div>

            <div class="hamburger" id="hamburger" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </header>

    <main class="page-content-wrapper">
        <section class="hero-section">
            <h1 class="main-heading">Organizador <span>de eventos</span></h1>
            <p class="sub-heading">Plataforma especializada en la comercialización de fotografías y vídeos de eventos deportivos del ciclo <strong style="color:var(--orange-latin)">olímpico y paralímpico</strong></p>
            
            <div class="key-statement-box">
                <p>Ofrece <strong>recuerdos visuales únicos y personalizados</strong>, respaldados por tecnología de <strong>reconocimiento facial y dorsal</strong>, accesibilidad e inclusión.</p>
            </div>
        </section>

        <section class="why-us-section">
            <h2 class="section-title-question">¿POR QUÉ SER ALIADOS?</h2>
            <div class="benefits-grid-container">
                <div class="benefit-column">
                    <div class="benefit-item">
                        <i class="fa-solid fa-check-circle"></i>
                        <p><strong>Posiciona TU evento</strong> a nivel regional y nacional.</p>
                    </div>
                    <div class="benefit-item">
                        <i class="fa-solid fa-check-circle"></i>
                        <p>Recibes paquetes de <strong>COMISIONES</strong> por ventas.</p>
                    </div>
                </div>
                <div class="benefit-column">
                    <div class="benefit-item">
                        <i class="fa-solid fa-check-circle"></i>
                        <p>Ofrece <strong>VALOR AGREGADO</strong> a patrocinadores y atletas.</p>
                    </div>
                    <div class="benefit-item">
                        <i class="fa-solid fa-check-circle"></i>
                        <p><strong>SISTEMA PROFESIONAL</strong> para archivo y difusión.</p>
                    </div>
                </div>
                <div class="benefit-column">
                    <div class="benefit-item">
                        <i class="fa-solid fa-check-circle"></i>
                        <p>Plataforma que <strong>AUTOMATIZA</strong> la cobertura digital.</p>
                    </div>
                    <div class="benefit-item">
                        <i class="fa-solid fa-check-circle"></i>
                        <p>Mejora la <strong>EXPERIENCIA</strong> real del deportista.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="features-cta-section">
            <div class="feature-box orange-bg-box">
                <h3>Cobertura integral con IA</h3>
                <p>Reconocimiento facial y entrega en <strong>24h</strong>. Incluye acceso total al panel del organizador para métricas.</p>
            </div>

            <div class="demo-box">
                <div style="font-weight: 800; color: var(--orange-latin); border-bottom: 2px solid; padding-bottom: 5px;">Demo de Reconocimiento</div>
                <div class="demo-visual-placeholder">
                    <button class="start-demo-btn">PROBAR</button>
                </div>
            </div>

            <div class="feature-box yellow-bg-box">
                <p>¿Quieres que tu evento tenga una <strong>imagen profesional</strong> y atraiga patrocinadores de alto nivel?</p>
                <p><strong>LatinColorSports</strong> hace que tu evento viva más allá de la competencia.</p>
            </div>
        </section>

        <section class="final-cta-section">
            <h3>"Visibilidad total para tu organización"</h3>
            <a href="registro.html"><button class="register-event-btn">inscribe tu evento</button></a>
        </section>
    </main>

    <footer>
        © 2026 LatinColorSports. Todos los derechos reservados.
    </footer>

    <script>
        function toggleMenu() {
            const nav = document.getElementById('navLinks');
            const burger = document.getElementById('hamburger');
            const overlay = document.getElementById('menuOverlay');
            const isOpen = nav.classList.toggle('active');
            burger.classList.toggle('open');
            overlay.classList.toggle('active');
            document.body.style.overflow = isOpen ? 'hidden' : 'auto';
        }
    </script>
</body>
</html>