<?php require 'navcomercial.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
	<link rel="icon" type="image/png" href="../uploads/LATIN-SPORTS.png">
    <title>Mis Comisiones</title>
   <style>
        body { font-family: Arial, sans-serif;}
        table { border-collapse: collapse; width: 100%; margin-top: 20px;  }
        th, td { border: 1px solid black; padding: 8px; text-align: center; }
        th { background-color: orange;color:white; }
        h1 {text-align: center;color:orange;font-size:45px; font-weight:bold;}
        #mensaje { color: red; font-weight: bold; margin-top: 20px; }
        #subtotalContainer { margin-top: 20px; font-size: 18px; }
        button { padding: 10px 20px; font-size: 16px; cursor: pointer; margin-top: 10px; }
        #retirarBtn {
  background-color: #ff4d4d; /* rojo suave */
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

#retirarBtn:hover {
  background-color: #e60000;
  transform: scale(1.05);
}

#retirarBtn:active {
  background-color: #cc0000;
  transform: scale(0.98);
}
/* Pendiente de retirar */
td.pendiente-de-retirar {
  background-color: #fff3cd;
  color: #856404;
  font-weight: bold;
}

/* En proceso */
td.en-proceso {
  background-color: #cce5ff;
  color: #004085;
  font-weight: bold;
}

/* Pagado */
td.pagado {
  background-color: #d4edda;
  color: #155724;
  font-weight: bold;
}


    </style>
</head>
<body>
    <h1>Mis Comisiones</h1>
    <div id="mensaje"></div>
    <table>
        <thead>
            <tr>
                <th>Seleccionar</th>
                <th>ID Comisi車n</th>
                <th>Monto</th>
                <th>ID Compra</th>
                <th>ID Foto</th>
                <th>Estado de Retiro</th>
            </tr>
        </thead>
        <tbody id="tablaComisiones"></tbody>
    </table>

    <div id="subtotalContainer">
        Subtotal a retirar: $<span id="subtotal">0.00</span><br>
        <button id="retirarBtn">Retirar seleccionadas</button>
    </div>

    <!-- Firebase -->
    <script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-auth-compat.js"></script>
<script>
    // 1. Configuraci車n de Firebase
    const firebaseConfig = {
        apiKey: "AIzaSyC941NOdoSPhXYDZIm1Z2SZqKqzmdOzmFk",
        authDomain: "latin-group-406b1.firebaseapp.com",
        projectId: "latin-group-406b1",
        storageBucket: "latin-group-406b1.firebasestorage.app",
        messagingSenderId: "21494348297",
        appId: "1:21494348297:web:53335b18bdb35ca8a1d6d8",
        measurementId: "G-NXZW7KNWW1"
    };

    // 2. Inicializaci車n Segura
    let auth;
    try {
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }
        auth = firebase.auth();
    } catch (e) {
        console.error("Error inicializando Firebase:", e);
    }

    // 3. L車gica de Autenticaci車n y Carga
    auth.onAuthStateChanged((user) => {
        if (user) {
            console.log("Usuario autenticado:", user.uid);
            cargarComisiones(user.uid);
        } else {
            window.location.href = 'login_app.html';
        }
    });

    async function cargarComisiones(firebase_uid) {
    const tablaBody = document.getElementById('tablaComisiones');
    const subtotalSpan = document.getElementById('subtotal');

    try {
        const res = await fetch('get_comisionescomercial.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ firebase_uid })
        });
        
        const data = await res.json();

        if (data.status === 'success') {
            tablaBody.innerHTML = ''; // Limpiar tabla
            subtotalSpan.textContent = '0.00'; // Resetear total

            if (data.comisiones.length === 0) {
                tablaBody.innerHTML = '<tr><td colspan="6" class="text-center p-4">No hay comisiones disponibles.</td></tr>';
                return;
            }

            // Renderizar cada comisi車n recibida
            data.comisiones.forEach(c => {
                const tr = document.createElement('tr');
                tr.className = "border-b hover:bg-gray-50";
                
                // Definir si se puede marcar (solo si est芍 pendiente)
                const isRetirable = c.estado_retiro === 'Pendiente de retirar';
                const claseEstado = c.estado_retiro.toLowerCase().replace(/\s+/g, '-');

                tr.innerHTML = `
                    <td class="p-3 text-center">
                        <input type="checkbox" class="checkComision w-5 h-5 accent-orange-500" 
                               data-monto="${c.monto}" 
                               value="${c.comision_id}" 
                               ${!isRetirable ? 'disabled' : ''}>
                    </td>
                    <td class="p-3 font-mono text-sm">${c.comision_id}</td>
                    <td class="p-3 font-bold">$${parseFloat(c.monto).toFixed(2)}</td>
                    <td class="p-3 text-gray-500 text-xs">${c.compra_id}</td>
                    <td class="p-3 text-center">
                        <img src="${c.foto_url}" class="w-12 h-12 object-cover rounded shadow-sm mx-auto" onerror="this.src='placeholder.jpg'">
                    </td>
                    <td class="p-3">
                        <span class="px-2 py-1 rounded-full text-[10px] font-bold uppercase badge-${claseEstado}">
                            ${c.estado_retiro}
                        </span>
                    </td>
                `;
                tablaBody.appendChild(tr);
            });

            // Re-vincular el evento para calcular el subtotal
            document.querySelectorAll('.checkComision').forEach(cb => {
                cb.addEventListener('change', () => {
                    let total = 0;
                    document.querySelectorAll('.checkComision:checked').forEach(checked => {
                        total += parseFloat(checked.dataset.monto);
                    });
                    subtotalSpan.textContent = total.toFixed(2);
                });
            });

        }
    } catch (e) {
        console.error("Error al renderizar tabla:", e);
    }
}

// 4. Lógica para procesar el botón de retiro
document.getElementById('retirarBtn').addEventListener('click', async () => {
    // Obtenemos los IDs de los checkboxes seleccionados
    const seleccionadas = Array.from(document.querySelectorAll('.checkComision:checked'))
        .map(cb => cb.value);

    // Validaciones previas
    if (seleccionadas.length === 0) {
        alert('Por favor, selecciona al menos una comisión pendiente.');
        return;
    }

    const subtotal = document.getElementById('subtotal').textContent;
    if (!confirm(`¿Estás seguro de solicitar el retiro de $${subtotal}?`)) {
        return;
    }

    try {
        const user = auth.currentUser; // Obtenemos el usuario actual de Firebase
        
        const res = await fetch('retirar_comisionescomercial.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                comisiones: seleccionadas,
                firebase_uid: user.uid
            })
        });

        const data = await res.json();

        if (data.status === 'success') {
            alert('¡Solicitud enviada con éxito!');
            // Recargamos la tabla para que los estados pasen a "En Proceso"
            cargarComisiones(user.uid);
        } else {
            alert('Error: ' + data.message);
        }

    } catch (err) {
        console.error("Error al retirar:", err);
        alert('Ocurrió un error al procesar la solicitud.');
    }
});
</script>
</body>
</html>
